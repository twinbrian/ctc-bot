"""Open the untouched 120-season lockbox once, using frozen choices.

All parameter comparisons here are reported sensitivity diagnostics, not a
second tuning set. Subsequent changes require a new independent evaluation set.
"""

import hashlib
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from backtest import simulate, summarize
from common import BASKETS, OUTLOOKS, SYMBOLS, dump_json, load_cache, partitions
from endgame import simulate_endgame
from short_horizon import simulate_short


def bootstrap_mean(x, seed=2026):
    rng = np.random.default_rng(seed)
    means = x[rng.integers(0, len(x), size=(10000, len(x)))].mean(1)
    return np.quantile(means, [0.025, 0.975]).tolist()


def combine(a, b):
    return {
        "pnl": a["pnl"] + b["pnl"],
        "positions": b["positions"],
        "actions": a["actions"] + b["actions"],
        "cost": a["cost"] + b["cost"],
        "turnover_shares": a["turnover_shares"] + b["turnover_shares"],
        "drawdown": a["drawdown"] + b["drawdown"],  # conservative upper bound
        "attribution": a["attribution"] + b["attribution"],
    }


def main():
    d, p = load_cache("cache.npz"), load_cache("predictions.npz")
    short = load_cache("short_predictions.npz")
    _, val, test = partitions()
    frozen = json.loads(Path("results/engines_frozen.json").read_text())
    digest = hashlib.sha256(
        Path("results/engines_frozen.json").read_bytes()
    ).hexdigest()
    market, truth = d["market"][test], d["settlement_truth"][test]
    fair = p["structural"][test, 2, list(p["times"]).index(740)]
    short_config, end_config = frozen["short_horizon"], frozen["primary"]
    scenarios = {
        "base": {},
        "10bps": {"cost_bps": 10},
        "50bps": {"cost_bps": 50},
        "100bps": {"cost_bps": 100},
        "4s_latency": {"latency": 4},
        "8s_latency": {"latency": 8},
        "12s_latency": {"latency": 12},
        "10_share_depth": {"fill_cap": 10},
        "combined_stress": {"cost_bps": 50, "latency": 4, "fill_cap": 25},
        "extra_25bps_adverse": {"adverse_bps": 25},
    }
    results, records = {}, []
    for name, stress in scenarios.items():
        sc, ec = {**short_config, **stress}, {**end_config, **stress}
        # When delayed exits reach the endgame window, wait for the account to
        # be flat before starting endgame orders. No overlapping account risk.
        ec["start_delay"] = max(0, int(np.ceil(sc["latency"] / 2)) * 2 - 10)
        a = simulate_short(market, truth, short["delta"][test], short["times"], **sc)
        b = simulate_endgame(market, truth, fair, **ec)
        c = combine(a, b)
        for engine, result in [("short", a), ("final_report", b), ("combined", c)]:
            summary = summarize(result)
            summary["mean_ci95_usd"] = bootstrap_mean(result["pnl"])
            records.append({"scenario": name, "engine": engine, **summary})
        if name == "base":
            results = {"short": a, "final_report": b, "combined": c}
    df = pd.DataFrame(records)
    df.to_csv("results/holdout_scenarios.csv", index=False)
    direction = frozen["directional_challenger"].copy()
    mode = direction.pop("model")
    direction.pop("selection")
    scales = load_cache("results/uncertainty.npz")[mode]
    exploratory = simulate(
        market, truth, p[mode][test], p["times"], scales, **direction
    )
    reversed_signal = simulate_short(
        market, truth, -short["delta"][test], short["times"], **short_config
    )
    controls = {
        "directional_challenger": summarize(exploratory),
        "reversed_short_signal": summarize(reversed_signal),
    }
    pd.DataFrame(
        {
            "season": np.arange(1, 601)[test],
            **{name: r["pnl"] for name, r in results.items()},
            "directional_challenger": exploratory["pnl"],
        }
    ).to_csv("results/holdout_seasons.csv", index=False)
    attribution = pd.DataFrame(
        {
            "symbol": SYMBOLS,
            **{
                name + "_mean_usd": r["attribution"].mean(0)
                for name, r in results.items()
            },
        }
    )
    attribution.to_csv("results/attribution.csv", index=False)
    rmse = np.sqrt(np.mean((fair - truth) ** 2, axis=0))
    mae = np.mean(np.abs(fair - truth), axis=0)
    pd.DataFrame(
        {
            "symbol": SYMBOLS,
            "structural_rmse_usd": rmse,
            "structural_mae_usd": mae,
            "house_740s_rmse_usd": np.sqrt(
                np.mean((market[:, 2, 370] - truth) ** 2, axis=0)
            ),
        }
    ).to_csv("results/valuation_accuracy.csv", index=False)
    sources = []
    ads = d["advisories"]
    for split_name, mask in zip(["train", "validation", "test"], partitions()):
        selected = mask[ads[:, 0] - 1]
        for official in [0, 1]:
            for age_lo, age_hi in [(0, 480), (0, 120), (120, 300), (300, 480)]:
                rows = ads[
                    selected
                    & (ads[:, 3] == official)
                    & (ads[:, 2] >= age_lo)
                    & (ads[:, 2] < age_hi)
                ]
                sources.append(
                    {
                        "split": split_name,
                        "source": "official" if official else "wire",
                        "age_lo": age_lo,
                        "age_hi": age_hi,
                        "messages": len(rows),
                        "accuracy": float(np.mean(rows[:, 4] == rows[:, 5])),
                    }
                )
    pd.DataFrame(sources).to_csv("results/source_accuracy.csv", index=False)
    confusion = {}
    for official in [0, 1]:
        rows = ads[(ads[:, 0] >= 241) & (ads[:, 3] == official)]
        counts = np.zeros((6, 6), dtype=int)
        np.add.at(counts, (rows[:, 5], rows[:, 4]), 1)
        confusion["official" if official else "wire"] = counts.tolist()
    dump_json(
        "results/source_confusion_training.json",
        {"order": OUTLOOKS, "truth_rows_reported_columns": confusion},
    )
    # Dollar-neutral ETF conversion edges after paying all hypothetical legs.
    etf_rows = []
    for k, etf in enumerate(["ARCH", "REBLD"]):
        basket = market[..., :10] @ BASKETS[k]
        basis = market[..., 10 + k] - basket
        for bps in [10, 25, 50]:
            basket_cost = (market[..., :10] * bps / 10000 + 0.02) @ BASKETS[k]
            etf_cost = market[..., 10 + k] * bps / 10000 + 0.02
            net = np.abs(basis) - basket_cost - etf_cost
            etf_rows.append(
                {
                    "etf": etf,
                    "cost_bps_each_side": bps,
                    "mean_abs_basis_usd": float(np.abs(basis).mean()),
                    "positive_fraction": float((net > 0).mean()),
                    "p99_net_edge_usd": float(np.quantile(net, 0.99)),
                    "max_net_edge_usd": float(net.max()),
                }
            )
    pd.DataFrame(etf_rows).to_csv("results/etf_diagnostics.csv", index=False)
    # Attribute short-horizon PnL to decision times and third-storm regimes.
    event = results["short"]["event_pnl"]
    pd.DataFrame(
        {
            "second_after_open": short["times"],
            **{"round_" + str(r + 1): event[:, r].mean(0) for r in range(3)},
        }
    ).to_csv("results/short_timing_attribution.csv", index=False)
    regimes = []
    for k, name in enumerate(OUTLOOKS):
        rows = d["pattern_truth"][test, 2] == k
        if rows.any():
            regimes.append(
                {
                    "round3_initial_pattern": name,
                    "seasons": int(rows.sum()),
                    "mean_combined_usd": float(results["combined"]["pnl"][rows].mean()),
                    "win_rate": float(np.mean(results["combined"]["pnl"][rows] > 0)),
                }
            )
    pd.DataFrame(regimes).to_csv("results/regimes.csv", index=False)
    # Bootstrap on whole seasons; top-5% removal checks dependence on winners.
    combo = results["combined"]["pnl"]
    summary = {
        "config_sha256": digest,
        "currency": "USD",
        "test_seasons": "120..1",
        "scenario_results": records,
        "controls": controls,
        "mean_without_best_5pct_usd": float(np.sort(combo)[:-6].mean()),
        "structural_rmse_usd": dict(zip(SYMBOLS, rmse.tolist())),
        "combined_drawdown_note": "Sum of component maximum drawdowns is an upper bound, not exact combined drawdown.",
        "execution_note": "Consensus scenarios, not executable-book PnL; spread, depth, replenishment and adverse selection remain unobserved.",
    }
    dump_json("results/holdout_summary.json", summary)
    make_charts(results, df, attribution, rmse, sources)
    print(
        df[
            df.scenario.isin(["base", "combined_stress", "8s_latency", "12s_latency"])
        ].to_string(index=False)
    )
    print("CONTROLS", controls)
    print("STRUCTURAL RMSE", dict(zip(SYMBOLS, rmse)))
    print("SOURCES", [s for s in sources if s["age_lo"] == 0 and s["age_hi"] == 480])
    print("ETF", etf_rows)


def make_charts(results, df, attribution, rmse, sources):
    plt.style.use("seaborn-v0_8-whitegrid")
    fig, axes = plt.subplots(2, 2, figsize=(13, 8))
    for engine, color in [
        ("combined", "#176B87"),
        ("short", "#59A14F"),
        ("final_report", "#F28E2B"),
    ]:
        # Each season resets; this curve sums independent simulated outcomes.
        axes[0, 0].plot(
            np.cumsum(results[engine]["pnl"][::-1]), label=engine, color=color
        )
    axes[0, 0].set(
        title="120 unseen seasons: cumulative hypothetical PnL",
        xlabel="Independent season, chronological order",
        ylabel="USD",
    )
    axes[0, 0].legend()
    axes[0, 1].hist(results["combined"]["pnl"], bins=18, color="#176B87")
    axes[0, 1].axvline(0, color="#B22222")
    axes[0, 1].set(
        title="Combined PnL distribution", xlabel="USD per season", ylabel="Seasons"
    )
    subset = df[df.engine == "combined"]
    axes[1, 0].barh(
        subset.scenario,
        subset.mean_usd,
        color=["#B22222" if x < 0 else "#176B87" for x in subset.mean_usd],
    )
    axes[1, 0].set(title="Execution sensitivity", xlabel="Mean USD per season")
    axes[1, 1].bar(attribution.symbol, attribution.combined_mean_usd, color="#176B87")
    axes[1, 1].tick_params(axis="x", rotation=45)
    axes[1, 1].set(title="PnL attribution", ylabel="Mean USD per season")
    fig.suptitle(
        "CTC 2026 • Locked holdout • Hypothetical fills, not recorded order books",
        fontsize=14,
    )
    fig.tight_layout()
    fig.savefig("results/research-dashboard.png", dpi=180)
    plt.close(fig)


if __name__ == "__main__":
    main()
