"""Research challenger: learn public-information price response over 10 seconds."""

import pickle

import numpy as np
from sklearn.ensemble import HistGradientBoostingRegressor

from common import SYMBOLS, load_cache, partitions, with_etfs
from models import features
from train import TIMES


def main():
    d = load_cache("cache.npz")
    train, _, _ = partitions()
    x, _, _, _ = features(d, TIMES)
    market = d["market"][:, :, TIMES // 2]
    change = x - np.concatenate([x[:, :, :1], x[:, :, :-1]], axis=2)
    lag10 = d["market"][:, :, np.maximum(TIMES - 10, 0) // 2]
    lag30 = d["market"][:, :, np.maximum(TIMES - 30, 0) // 2]
    predictors = np.concatenate(
        [x, change, market, market - lag10, market - lag30], axis=-1
    )
    # Last sample lacks a same-round 10-second target and is excluded from fitting.
    target = d["market"][:, :, np.minimum(TIMES + 10, 778) // 2, :10] - market[..., :10]
    prediction = np.zeros((*x.shape[:-1], 10))
    models = []
    for j, symbol in enumerate(SYMBOLS[:10]):
        model = HistGradientBoostingRegressor(
            max_iter=160,
            max_leaf_nodes=15,
            learning_rate=0.06,
            l2_regularization=30,
            min_samples_leaf=100,
            early_stopping=False,
            random_state=2026,
        )
        model.fit(
            predictors[train, :, :-1].reshape(-1, predictors.shape[-1]),
            target[train, :, :-1, j].ravel(),
        )
        prediction[..., j] = model.predict(
            predictors.reshape(-1, predictors.shape[-1])
        ).reshape(x.shape[:-1])
        models.append(model)
        print("10s", symbol, "fitted", flush=True)
    np.savez_compressed(
        "short_predictions.npz", delta=with_etfs(prediction), times=TIMES
    )
    with open("short_models.pkl", "wb") as f:
        pickle.dump(models, f)


def simulate_short(
    market,
    truth,
    delta,
    times,
    *,
    cost_bps=25,
    fixed_cost=0.02,
    latency=2,
    fill_cap=50,
    threshold=0.15,
    top_k=3,
    fraction=0.5,
    adverse_bps=0.0,
    cycle_seconds=10,
):
    """Non-overlapping 10/20-second cycles, close at t+10+latency.

    <=18 place + 18 exit actions/min for a 10s cycle. The last round stops new
    entries before 730, leaving the final-report engine separate. No overnight
    inventory. If entry/exit coincide, close old positions before new fills.
    """
    from common import LIMITS

    n = len(market)
    pnl = np.zeros(n)
    actions = np.zeros(n)
    costs = np.zeros(n)
    turnover = np.zeros(n)
    attribution = np.zeros((n, 12))
    peak = np.zeros(n)
    drawdown = np.zeros(n)
    marks = []
    event_pnl = np.zeros((n, 3, len(times)))
    delay = max(1, int(np.ceil(latency / 2)))
    for r in range(3):
        for pi, t in enumerate(times):
            if (
                t % cycle_seconds != 0
                or (r == 2 and t >= 730)
                or t + 10 + delay * 2 >= 780
            ):
                continue
            now = market[:, r, t // 2]
            pred = delta[:, r, pi]
            side = np.sign(pred)
            edge = np.abs(pred) - 2 * (now * cost_bps / 10000 + fixed_cost) - threshold
            ranking = np.argsort(
                -edge * np.minimum(fill_cap, LIMITS * fraction), axis=1
            )
            entry = market[:, r, t // 2 + delay]
            exit_price = market[:, r, t // 2 + 5 + delay]
            trade_pnl = np.zeros(n)
            start_pnl = pnl.copy()
            open_qty = np.zeros((n, 12))
            entry_cost = np.zeros(n)
            for k in range(top_k):
                j = ranking[:, k]
                i = np.arange(n)
                valid = edge[i, j] > 0
                qty = (
                    np.floor(np.minimum(fill_cap, LIMITS[j] * fraction))
                    * side[i, j]
                    * valid
                )
                cost = (entry[i, j] + exit_price[i, j]) * (
                    cost_bps + adverse_bps
                ) / 10000 + 2 * fixed_cost
                gain = qty * (exit_price[i, j] - entry[i, j]) - np.abs(qty) * cost
                pnl += gain
                trade_pnl += gain
                costs += np.abs(qty) * cost
                turnover += np.abs(qty) * 2
                actions += valid * 2
                attribution[i, j] += gain
                open_qty[i, j] = qty
                entry_cost += np.abs(qty) * (
                    entry[i, j] * (cost_bps + adverse_bps) / 10000 + fixed_cost
                )
            # Mark every 2s while the trade is live, rather than reporting only
            # closed-cycle drawdown. These future prices never affect decisions.
            for step in range(6):
                mark = (
                    start_pnl
                    + np.sum(
                        open_qty * (market[:, r, t // 2 + delay + step] - entry), axis=1
                    )
                    - entry_cost
                )
                peak = np.maximum(peak, mark)
                drawdown = np.maximum(drawdown, peak - mark)
            peak = np.maximum(peak, pnl)
            drawdown = np.maximum(drawdown, peak - pnl)
            event_pnl[:, r, pi] = trade_pnl
            marks.append(pnl.copy())
    return {
        "pnl": pnl,
        "actions": actions,
        "cost": costs,
        "turnover_shares": turnover,
        "positions": np.zeros((n, 12)),
        "drawdown": drawdown,
        "attribution": attribution,
        "mark_curve": np.stack(marks, axis=1),
        "event_pnl": event_pnl,
    }


if __name__ == "__main__":
    main()
