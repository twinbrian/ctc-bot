"""Training-only model identification. Printed fits are not holdout results."""

import numpy as np
from scipy.optimize import least_squares

from common import SYMBOLS, load_cache, partitions


def main():
    d = load_cache("cache.npz")
    tr = partitions()[0]
    o = d["obs"][tr, :, :240]
    dist = np.linalg.norm(o[..., None, :2] - d["site_xy"], axis=-1) / o[..., None, 4]
    wind = o[..., None, 5] * np.exp(-(dist**2))
    weights = np.zeros((17, 5))
    weights[np.arange(17), d["site_company"]] = d["site_weight"]
    outage = ((wind >= 0.35).sum((1, 2)) * 2 / 120) @ weights
    damage = d["report_truth"][tr].sum(1)
    y = d["settlement_truth"][tr]
    beta = np.linalg.lstsq(damage, d["loss_truth"][tr].sum(1), rcond=None)[0]
    print(
        "LOSS coefficients USD millions",
        beta,
        "rmse",
        np.sqrt(np.mean((damage @ beta - d["loss_truth"][tr].sum(1)) ** 2)),
    )
    for j, inds in [(5, [0, 3, 4]), (6, list(range(5))), (7, [3])]:
        x = outage[:, inds] if j == 7 else damage[:, inds]
        for form in ["exp", "tanh", "ratio", "log"]:

            def pred(p):
                z = x @ p[2:]
                f = {
                    "exp": lambda z: 1 - np.exp(-z),
                    "tanh": np.tanh,
                    "ratio": lambda z: z / (1 + z),
                    "log": np.log1p,
                }[form]
                return p[0] + p[1] * f(z)

            fit = least_squares(
                lambda p: pred(p) - y[:, j],
                np.r_[35, 25, np.full(x.shape[1], 0.5)],
                bounds=(0, np.inf),
                max_nfev=3000,
            )
            print(
                SYMBOLS[j], form, "params", fit.x, "rmse", np.sqrt(np.mean(fit.fun**2))
            )
    for power in [1, 2, 3]:
        for threshold in [0, 0.15, 0.35]:
            exposure = np.sum(np.maximum(wind - threshold, 0) ** power, axis=2) * 2
            cumulative = exposure.cumsum(1)
            target = d["report_truth"][tr].cumsum(1)
            fits = []
            for j in range(5):
                ix = np.where(d["site_company"] == j)[0]

                def fun(p):
                    return (
                        (1 - np.exp(-cumulative[:, :, ix] * p)) @ d["site_weight"][ix]
                        - target[:, :, j]
                    ).ravel()

                f = least_squares(fun, np.full(len(ix), 0.01), bounds=(0, 0.2))
                fits.append(
                    (round(np.sqrt(np.mean(f.fun**2)), 6), np.round(f.x, 6).tolist())
                )
            print("DAMAGE", power, threshold, fits)


if __name__ == "__main__":
    main()
