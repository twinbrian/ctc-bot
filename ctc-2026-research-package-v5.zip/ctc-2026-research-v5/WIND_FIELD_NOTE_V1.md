# Wind field and the two-radii hypothesis — v1

The suggested Gaussian attenuation is

`wind_at_site = intensity * exp(-(distance / radius)^2)`.

Distance is Euclidean distance from the storm center to each of the 17 sites, not
distance to an island center. Radius and intensity change as observations arrive.
At the center the wind proxy is 100% of intensity; at one radius it is 36.79%; at
two radii it is 1.83%. The exponential alone never reaches exactly zero.

If "two radii" specifies a hard outer boundary, the candidate is:

```python
wind = intensity * np.exp(-(distance / radius)**2)
wind = np.where(distance <= 2*radius, wind, 0.0)
```

The supplied case packet, README and case.json do not explicitly specify this
cutoff. It could instead describe the practically relevant reach of the Gaussian.
The exact wording is needed to distinguish those interpretations.

## What is already implemented

The research models already use `intensity * exp(-(distance/radius)^2)` for site
wind features and outage reconstruction. The fitted closure threshold is 0.35.
Wind is an intermediate physical variable, not itself a damage fraction or a
price change. Asset vulnerability, accumulated exposure, remaining undamaged
assets, sheltering and damage caps still need identification.

## Check on the original training data

Across 360 training seasons / 1,080 storms:

- Adding the proposed 2r cutoff changes **zero site-time closure classifications**.
- It removes **1.1204% of total unweighted integrated wind exposure**, mostly very
  weak distant tails. This aggregate does not bound individual-company damage or
  feature-model sensitivity.
- Maximum observed intensity is 1.856. At 2r that implies only about 0.034 wind,
  well below the fitted 0.35 closure threshold; hence the unchanged outage flags.
- In 1,040 storm/company observations, every company site remains outside 2r at
  every sampled observation. Of these, 1,039 report zero damage; one ISLE event
  reports a 0.0001 fraction (0.01 percentage point). Rounding, unsampled movements
  and other damage thresholds prevent this from proving a hard cutoff.

This supports treating distant wind as negligible but does not establish the
simulator's exact damage update. A damage forecast needs a separately fitted
wind-to-damage mapping, then a causal distribution of future storm paths.

The v2 PnL results are unchanged: the dominant formation strategy starts before
the current storm exists. Replacing wind features in the later model would require
refitting and another explicitly labeled research evaluation; no additional PnL
improvement is claimed from this audit.

Reproduce with `python wind_cutoff_audit.py` after preparing `cache.npz`.
