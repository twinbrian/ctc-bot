# v3 research plan — declared before selecting new policies

Goal: infer spatial cutoff and physical damage patterns, then improve **mean net
terminal USD PnL** under the same two-second latency, 50-share per-symbol depth,
25-bps plus USD 0.02 per-side costs, position limits and one-key rolling 60-action
budget used in v2. No extra assumed liquidity or extra bot keys in the comparison.

## Physics

1. Estimate the positive-damage support boundary using single-site PORT. Profile
   minimum normalized distance on original training seasons 600–241, with a
   season-cluster bootstrap and confirmation on 240–121 and 120–1.
2. Fit site-level exponential cumulative-damage regressions across radius cutoffs
   1, 1.25, 1.5, 1.7, 1.8, 1.9, 1.95, 2, 2.05, 2.1, 2.2, 2.5, 3 and no cutoff.
   Distinguish spatial support identification from regression-optimal prediction.
3. Diagnose missing structure using capped-capacity gradient boosting of final
   per-storm damage from full observed paths, which is valid only after dissipation.

## Trading hypotheses

- **Inventory allocation:** optimize formation target lots globally instead of
  spending entry actions on every positive symbol at each tick. Respect the time
  needed to acquire each instrument's target using 50-share clips.
- **Aftermath:** after round-3 dissipation, no future storm remains. Regress final
  valuation residuals against observed path, current quotes, and preliminary
  reports, then compare early settlement-value positioning against waiting for
  the final report. This can add an independent source of PnL to formation.
- Retain the existing short-horizon engine outside the new aftermath window.

Use the same five disjoint 360/120/120 train/inner-validation/outer-evaluation
season splits as v2. Freeze all fold decisions before opening new outer-policy
results. Assess new policy with paired per-season differences against v2 and
fixed execution stresses. All three storms stay together. These are further
research estimates on an already examined dataset, not a fresh lockbox or proof
of live executability. Any exploratory extension must be recorded explicitly.

## Additional routing hypothesis (before v3 outer policy results)

The documented free create/redeem operations can acquire desired stock baskets in
fewer order actions. Test using ETF market orders plus atomic conversions as an
execution route, with the same 50-share quote depth, latency, total position limits
and 60-action budget. Reserve both signs of every pending leg so that arbitrary
arrival ordering cannot violate a limit. Conversion itself produces no cash PnL.
Underlying market legs remain non-atomic and pay costs.

Compare entry starts 0/20/40, earliest exits 70/80/100/120, and exposure fractions
0.75/1.0. Restart later trading only after a full rolling minute following route
flattening, and verify the combined action history. This deliberately sacrifices
some interim alpha to keep independent execution phases honest. Select on each
fold's inner validation only. It is a new implementation family, not a change to
the assumed per-symbol available liquidity.
