"""Check the user's two-radii hypothesis on the original training partition.

This is a diagnostic only: it does not modify fitted features or claim a PnL gain.
The supplied README/case do not explicitly specify a hard 2r cutoff.
"""

import numpy as np

from common import SYMBOLS, dump_json, load_cache, partitions


def main():
    d = load_cache("cache.npz")
    training = partitions()[0]
    obs = d["obs"][training, :, :240]
    distance_ratio = (
        np.linalg.norm(obs[..., None, :2] - d["site_xy"], axis=-1) / obs[..., None, 4]
    )
    gaussian = obs[..., None, 5] * np.exp(-(distance_ratio**2))
    truncated = gaussian * (distance_ratio <= 2)
    companies = []
    for j, symbol in enumerate(SYMBOLS[:5]):
        sites = d["site_company"] == j
        outside = np.all(distance_ratio[:, :, :, sites] > 2, axis=(2, 3))
        damage = d["report_truth"][training, :, j]
        companies.append(
            {
                "symbol": symbol,
                "storm_company_observations_always_outside_2r": int(outside.sum()),
                "nonzero_reported_damage_in_those_observations": int(
                    np.sum((damage > 0) & outside)
                ),
                "maximum_reported_damage_fraction_outside": float(
                    np.max(damage[outside])
                ),
            }
        )
    result = {
        "hypothesis": "wind = intensity * exp(-(distance/radius)^2) if distance<=2*radius, else zero",
        "status": "Gaussian already used; explicit two-radii cutoff not confirmed by supplied documentation",
        "training_seasons": 360,
        "training_storms": 1080,
        "intensity_range": [float(obs[..., 5].min()), float(obs[..., 5].max())],
        "closure_threshold": 0.35,
        "changed_site_time_closure_classifications": int(
            np.sum((gaussian >= 0.35) != (truncated >= 0.35))
        ),
        "discarded_share_of_total_unweighted_integrated_wind": float(
            (gaussian - truncated).sum() / gaussian.sum()
        ),
        "maximum_discarded_wind": float(np.max(gaussian * (distance_ratio > 2))),
        "companies": companies,
        "qualification": "Two-second rounded observations and rounded company reports cannot uniquely identify a hard cutoff. No refit or PnL claim made.",
    }
    dump_json("results_v2/wind_cutoff_audit.json", result)
    print(result)


if __name__ == "__main__":
    main()
