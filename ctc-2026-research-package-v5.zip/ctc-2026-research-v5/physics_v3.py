"""Identify spatial support and fit damage responses on season-separated data.

The cutoff is fitted from physical observations/damage, never selected by test PnL.
The original 360/120/120 split is reused and explicitly not a fresh lockbox.
"""

from pathlib import Path

import numpy as np
import pandas as pd
from scipy.optimize import least_squares
from sklearn.ensemble import HistGradientBoostingRegressor

from common import SYMBOLS, dump_json, load_cache, partitions


def geometry(d):
    o = d["obs"][:, :, :240]
    rho = np.linalg.norm(o[..., None, :2] - d["site_xy"], axis=-1) / o[..., None, 4]
    intensity = o[..., None, 5]
    return rho, intensity


def predict_survival(exposure, rates, weights):
    return (1 - np.exp(-np.cumsum(exposure, axis=1) * rates)) @ weights


def path_features(d, cutoff=2.0):
    rho, intensity = geometry(d)
    wind = intensity * np.exp(-(rho**2)) * (rho <= cutoff)
    x = [
        rho.min(2),
        wind.max(2),
        wind.sum(2) * 2,
        (wind**2).sum(2) * 2,
        (rho <= cutoff).sum(2) * 2,
        (wind >= 0.35).sum(2) * 2,
    ]
    # Full storm path is public when these features are used after dissipation.
    # Earlier rounds' final reports are public; current/future truth is excluded.
    prior = np.concatenate(
        [np.zeros((len(rho), 1, 5)), d["damage"][:, :-1, -1].cumsum(1)], axis=1
    )
    x += [
        prior,
        np.broadcast_to(np.arange(1, 4)[None, :, None], (*prior.shape[:2], 1)),
        np.max(intensity[..., 0], axis=2)[..., None],
        np.mean(intensity[..., 0], axis=2)[..., None],
    ]
    return np.concatenate(x, axis=-1)


def main():
    out = Path("results_v3")
    out.mkdir(exist_ok=True)
    d = load_cache("cache.npz")
    train, val, test = partitions()
    rho, intensity = geometry(d)
    wind = intensity * np.exp(-(rho**2))
    incremental = d["report_truth"]
    cumulative = incremental.cumsum(1)
    # PORT has a single, fully exposed site. It provides a clean support test.
    closest = rho[:, :, :, 0].min(2)
    labels = incremental[:, :, 0] > 0
    cutoffs = np.round(np.arange(0.5, 3.001, 0.005), 3)
    errors = (
        (closest[train, None, :] <= cutoffs[None, :, None]) != labels[train, None, :]
    ).mean((0, 2))
    best_error = errors.min()
    optimal = cutoffs[errors == best_error]
    cutoff = float(np.mean([optimal.min(), optimal.max()]))
    support = {
        "estimator": "PORT nonzero reported damage vs minimum normalized site distance",
        "selected_cutoff": cutoff,
        "zero_training_error_grid_interval": [
            float(optimal.min()),
            float(optimal.max()),
        ],
        "training_positive_upper_distance": float(closest[train][labels[train]].max()),
        "training_zero_lower_distance": float(closest[train][~labels[train]].min()),
        "training_errors": int(round(best_error * labels[train].size)),
        "splits": {},
    }
    for label, mask in zip(["train", "validation", "evaluation"], [train, val, test]):
        pred = closest[mask] <= cutoff
        support["splits"][label] = {
            "storms": int(mask.sum() * 3),
            "errors": int(np.sum(pred != labels[mask])),
            "false_positive": int(np.sum(pred & ~labels[mask])),
            "false_negative": int(np.sum(~pred & labels[mask])),
        }
    rng = np.random.default_rng(2026)
    ids = np.flatnonzero(train)
    intervals = []
    for _ in range(2000):
        sample = rng.choice(ids, len(ids), replace=True)
        intervals.append(
            [
                closest[sample][labels[sample]].max(),
                closest[sample][~labels[sample]].min(),
            ]
        )
    support["bootstrap_season_bounds_95pct"] = np.quantile(
        intervals, [0.025, 0.975], axis=0
    ).tolist()
    dump_json(out / "cutoff_support.json", support)
    pd.DataFrame({"cutoff": cutoffs, "training_error": errors}).to_csv(
        out / "cutoff_support_profile.csv", index=False
    )

    # Cumulative site survival naturally retains each site's prior damage.
    # Fit each site vulnerability; profile the common hard cutoff with Gaussian fixed.
    rows = []
    parameters = {}
    grid = [1.0, 1.25, 1.5, 1.7, 1.8, 1.9, 1.95, 2.0, 2.05, 2.1, 2.2, 2.5, 3.0, None]
    for c in grid:
        exposure = (wind * (rho <= c)).sum(2) * 2 if c is not None else wind.sum(2) * 2
        for j, name in enumerate(SYMBOLS[:5]):
            sites = d["site_company"] == j
            e = exposure[:, :, sites]
            weights = d["site_weight"][sites]
            fit = least_squares(
                lambda k: (
                    predict_survival(e[train], k, weights) - cumulative[train, :, j]
                ).ravel(),
                np.full(sites.sum(), 0.01),
                bounds=(0, 0.2),
                max_nfev=300,
            )
            pred = predict_survival(e, fit.x, weights)
            for label, mask in zip(
                ["train", "validation", "evaluation"], [train, val, test]
            ):
                err = pred[mask] - cumulative[mask, :, j]
                rows.append(
                    {
                        "cutoff": c if c is not None else "none",
                        "company": name,
                        "split": label,
                        "rmse_pp": float(np.sqrt(np.mean(err**2)) * 100),
                        "mae_pp": float(np.abs(err).mean() * 100),
                    }
                )
            if c == 2.0:
                parameters[name] = fit.x.tolist()
        print("Damage cutoff profile", c, flush=True)
    pd.DataFrame(rows).to_csv(out / "damage_cutoff_regressions.csv", index=False)
    dump_json(out / "damage_survival_coefficients_at_2r.json", parameters)

    # Diagnose missing structure with incremental damage regressions. All model
    # capacities are fixed before evaluating validation/evaluation seasons.
    x = path_features(d)
    mlrows = []
    mlpred = np.empty_like(incremental)
    for j, name in enumerate(SYMBOLS[:5]):
        model = HistGradientBoostingRegressor(
            max_iter=180,
            max_leaf_nodes=7,
            learning_rate=0.05,
            min_samples_leaf=25,
            l2_regularization=10,
            early_stopping=False,
            random_state=2026,
        )
        model.fit(x[train].reshape(-1, x.shape[-1]), incremental[train, :, j].ravel())
        mlpred[:, :, j] = np.maximum(
            0, model.predict(x.reshape(-1, x.shape[-1])).reshape(x.shape[:2])
        )
        for label, mask in zip(
            ["train", "validation", "evaluation"], [train, val, test]
        ):
            err = mlpred[mask, :, j] - incremental[mask, :, j]
            mlrows.append(
                {
                    "company": name,
                    "split": label,
                    "rmse_pp": float(np.sqrt(np.mean(err**2)) * 100),
                }
            )
    pd.DataFrame(mlrows).to_csv(out / "path_damage_regressions.csv", index=False)
    np.savez_compressed(
        out / "damage_diagnostics.npz", pred=mlpred, closest=closest, labels=labels
    )
    print("SUPPORT", support, flush=True)
    print(pd.DataFrame(mlrows).to_string(index=False), flush=True)


if __name__ == "__main__":
    main()
