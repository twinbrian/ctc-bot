"""Pure exchange-state/risk primitives, independent of any HTTP client.

This is a research kit, not a connected bot. Integrate the supplied starter kit
only after testnet measurements establish actual quote/depth and API behavior.
"""

from collections import deque

import numpy as np

from common import BASKETS, LIMITS, SYMBOLS


class FeedState:
    def __init__(self, competition_id):
        self.reset(competition_id)

    def reset(self, competition_id):
        self.competition_id = competition_id
        self.seen = set()
        self.watermark = -1
        self.reports = {}
        self.announcements = []
        self.invalid_models = set()
        self.outage_complete = False

    def apply_report(self, msg):
        key = (msg["round"], msg["storm"])
        existing = self.reports.get(key)
        if existing and existing["stage"] == "final" and msg["stage"] != "final":
            return
        self.reports[key] = msg

    def apply(self, msg):
        if msg["type"] == "snapshot":
            if msg["last_seq"] < self.watermark:
                return False
            for report in msg.get("damage", []):
                self.apply_report(report)
            # Snapshot headlines contain only eight events: never assume a late
            # connection recovered every economics change or full outage path.
            for headline in msg.get("headlines", []):
                if headline.get("type") == "announcement":
                    self.invalidate(headline)
            self.watermark = msg["last_seq"]
            return True
        seq = msg["seq"]
        if seq <= self.watermark or seq in self.seen:
            return False
        self.seen.add(seq)
        # Gaps are normal; no 'previous seq + 1' requirement.
        if msg["type"] == "damage_report":
            self.apply_report(msg)
        elif msg["type"] == "announcement":
            self.invalidate(msg)
        return True

    def invalidate(self, msg):
        self.announcements.append(msg)
        affected = set(msg.get("symbols", []))
        # A physical company's economics can affect insured losses and repairs.
        if affected.intersection(SYMBOLS[:5]) or not affected:
            affected.update(SYMBOLS)
        for k, basket in enumerate(BASKETS):
            if any(SYMBOLS[j] in affected for j in np.flatnonzero(basket)):
                affected.add(SYMBOLS[10 + k])
        self.invalid_models.update(affected)

    def totals(self):
        damage = np.zeros(5)
        loss = 0.0
        for report in self.reports.values():
            damage += [report["damage_pct"][s] / 100 for s in SYMBOLS[:5]]
            loss += report["industry_loss_musd"]
        return damage, loss


def order_room(positions, resting_buys, resting_sells):
    return (
        np.maximum(0, LIMITS - positions - resting_buys),
        np.maximum(0, LIMITS + positions - resting_sells),
    )


def conversion_delta(etf, quantity, create=True):
    if etf not in ["ARCH", "REBLD"] or quantity <= 0 or int(quantity) != quantity:
        raise ValueError("Invalid conversion")
    k = ["ARCH", "REBLD"].index(etf)
    result = np.zeros(12)
    result[:10] = -BASKETS[k] * quantity
    result[10 + k] = quantity
    return result if create else -result


def can_convert(positions, buys, sells, delta):
    after = positions + delta
    return bool(np.all(after + buys <= LIMITS) and np.all(after - sells >= -LIMITS))


class ActionLimiter:
    """One central limiter for all keys; caller supplies monotonic real seconds."""

    def __init__(self, key_limit=60, team_limit=180):
        self.key_limit, self.team_limit = key_limit, team_limit
        self.keys = {}
        self.team = deque()

    def take(self, key, now, reserve=0):
        window = self.keys.setdefault(key, deque())
        for q in [window, self.team]:
            while q and q[0] <= now - 60:
                q.popleft()
        if (
            len(window) >= self.key_limit - reserve
            or len(self.team) >= self.team_limit - reserve
        ):
            return False
        window.append(now)
        self.team.append(now)
        return True
