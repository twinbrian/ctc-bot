# CTC 2026: the larger edge is the holding horizon

## Executive result

**We raised the highest completed historical mean from roughly USD 11,100 to USD 19,230 per season.** The main improvement is a scheduled directional reversal held for several minutes, rather than repeatedly trading ten-second forecasts. Better weather forecasting contributes little additional baseline PnL.

The most useful distinction is between the highest point estimate and the most stable explanation of the edge:

- **Highest frozen point estimate:** weather-conditioned HGB, mean **USD 19,230.10**, median **USD 18,730.68**, profitable in **95.5%** of 600 seasons, worst **USD -23,288.11**.
- **Simpler scheduled policy:** mean **USD 19,189.16**, median **USD 18,996.21**, profitable in **95.33%**, worst **USD -28,797.70**.
- HGB adds only **USD 40.95** to baseline mean. Its conditional paired 95% interval is **USD -234.18 to USD 294.05**, and all 30 training bootstraps underperform the simpler policy at baseline. The tiny point-estimate advantage is not persuasive evidence of a durable incremental edge.
- HGB is more useful when execution is expensive: strict combined stress mean **USD 8,502.58**, versus **USD 7,891.64** for the simple policy. It beats the simple policy in 27 of 30 training bootstraps under that stress.

**Recommendation:** carry the frozen scheduled strategy forward as the implementation benchmark, retain HGB as the originally selected conditional challenger, and calibrate execution on the testnet before deciding between them. This is an engineering recommendation, not a new retuned policy or a switch in the primary objective. We still maximize mean net terminal PnL; we have not proved a globally optimal strategy.

**Evidence boundary:** all 600 seasons were previously researched. Fits exclude their evaluation seasons, but the reported results are post-selection historical estimates, not a new untouched holdout. Fills are hypothetical because the dataset has no order books, receipt timestamps or competitor impact. The 54-setting stress grid is a sensitivity exercise, not calibrated live execution.

![Main results and stability](research_v5/report/results-overview-v5.png)

## 1. What changed the economics of the strategy

The house's average path contains a repeatable reversal. Island businesses and HAVEN tend to rise around storm formation, then decline during the active storm; rebuilders generally do the opposite. The early move is useful for a short formation trade. The later move is useful when held for minutes, allowing expected gross movement to exceed the cost of entering and exiting.

The previous ten-second tail contributed only **USD 468.84** mean after the formation phase. Replacing it with the fixed active-storm holding window contributes **USD 8,533.24**. Formation and the final-report phase are held identical in this matched comparison. This is the dominant improvement.

These are empirically measured conditional average paths, not a recovered formula for the house's internal consensus. The live simulator may change economics through announcements that do not occur in the historical data.

![Scheduled reversal in mean quotes](research_v5/report/clock-drift-v5.png)

The figure is descriptive: it averages all 600 seasons and all three rounds. Evaluation trades use only the curve fitted on the corresponding training seasons. Dates, storm names, season identifiers and simulator truth are not prediction inputs.

### Frozen schedule

All times below are real seconds after open. Storm age is 60 seconds less during the storm. One real second equals 30 market seconds.

| Phase | Decision / acquisition | Earliest liquidation | Economic position |
|---|---|---|---|
| Formation, every round | Start 20; acquire through 60 | 100 | Typically long island/HAVEN exposure, short rebuilders |
| Active storm, every round | Start 180; acquire through 240 | 540 | Typically reverse the formation direction |
| Final report, round 3 | 740, after flatness and cooldown | Final settlement | Trade modeled settlement fair minus executable price |

Liquidation start is not flatness. In the independently audited 120-season clock baseline, formation is actually flat at 116 and the active phase at 556. HGB's mixed-direction routes take longer: baseline active-phase flat times range from 540 to 604, with a mean near 579. The executor waits for actual gross-pending flatness and depth cooldown before handing the account to a later phase.

The long phase closes within the round, so it does not occupy inventory needed for the next formation trade. The executor preserves continuous rolling action history across round boundaries, using a conservative zero-pause mapping. Only the round-3 final-report engine carries a terminal position to the single final settlement.

### Signal and sizing

For stock or ETF i in round r, the simple policy estimates a price change from the training-only mean curve:

```
mu[i,r] = mean_train(mean(price[542:552 inclusive]) - price[180])
exit_fair[i] = current_entry_price[i] + mu[i,r]
target[i] = signed published limit, only if edge clears round-trip costs
```

For formation, the same idea uses its earlier acquisition and exit window. These are direction and full-limit targets, not an assertion that every target can be filled. The router clips actual orders to inventory, pending-side, depth and action capacity. It uses ETF creation/redemption where this helps acquire or unwind the desired basket with fewer constrained market actions.

The eight predeclared clock candidates were entry 180 or 300, liquidation start 540 or 660, and position fraction 0.5 or 1.0. Inner mean PnL selected **180 / 540 / full fraction**. No later timing grid was run after diagnostic evaluation.

### Conditional weather forecast

The HGB version replaces only the active-phase forecast. Ten stock models predict the six-quote mean at 542, 544, 546, 548, 550 and 552 minus the stock quote at 180. Inputs are 94 public-as-of-180 features: observed path/wind exposure, prior public damage/outages/losses, current guidance and quotes, and round context. Rounds are pooled for fitting; entire seasons stay together in splits.

Each stock uses squared-error histogram gradient boosting: 100 iterations, seven leaves, minimum 40 rows per leaf, L2 30, learning rate 0.06, no early stopping. The worker froze seed 0 before fitting, whereas the parent's written plan said 2026. The discrepancy is recorded; seed 0 was retained without a seed search or retrospective refit. A fixed ridge comparator was also run and retained as a negative result.

ETF expected exit values are coherent baskets of stock exit values. The expected ETF change subtracts the actual ETF entry quote, allowing an observed ETF/basket basis to affect the signal. This does not assume executable basket arbitrage at published midpoint prices.

## 2. Comparable whole-account PnL

All rows below use the same 600 evaluation seasons, whole-season folds, one account, original exchange position limits and baseline execution assumptions. Amounts are USD per season. The matched old-tail row is the fixed old policy rerun through the audited common account, not the previous report's fold-selected incumbent.

| Policy | Mean USD | Median USD | Worst USD | Win rate |
|---|---:|---:|---:|---:|
| Formation + final only | 10,655.92 | 9,680.63 | -10,382.33 | 84.67% |
| Matched old ten-second tail | 11,124.76 | 10,130.49 | -8,979.61 | 86.00% |
| Scheduled active-storm holding | 19,189.16 | 18,996.21 | -28,797.70 | 95.33% |
| Weather HGB holding | 19,230.10 | 18,730.68 | -23,288.11 | 95.50% |

The scheduled improvement over the matched old account is **USD 8,064.40** mean; HGB improves it by **USD 8,105.35**. The earlier published mean of **USD 11,100.59** remains an older, differently selected comparator; HGB's point estimate is about 73% larger, but the matched increment above is the cleaner attribution.

| Additional metric | Scheduled | Weather HGB |
|---|---:|---:|
| Fifth percentile, USD | 689.64 | 651.41 |
| Mean of worst 5% of seasons, USD | -4,134.80 | -3,393.99 |
| Mean charged costs, USD | 6,404.74 | 5,698.05 |
| Mean order actions / season | 599.69 | 618.59 |
| Formation mean PnL, USD | 10,360.97 | 10,360.97 |
| Active phase mean PnL, USD | 8,533.24 | 8,574.19 |
| Final-report mean PnL, USD | 294.94 | 294.94 |

HGB's **USD 40.95** mean advantage decomposes into **USD 665.74 less gross PnL** and **USD 706.69 lower costs**. It is not evidence that detailed storm forecasting generates a large new gross edge. More actions with lower costs is possible because conversion and market actions have different cash-cost consequences and route sizes differ.

The whole-season conditional 95% mean intervals are USD 18,201.12–20,179.21 for scheduled and USD 18,303.16–20,178.95 for HGB. These intervals condition on the already selected policies, existing data and assumed fills; they do not account fully for the entire adaptive research history or uncertainty in live market conditions.

The worst single-season loss becomes materially worse than the old strategy despite a higher win rate and better worst-5% average. Optimizing mean PnL with full published position limits entails that tradeoff; neither strategy is a guaranteed winning season.

## 3. Execution sensitivity

Baseline costs are **25 basis points plus USD 0.02 per share per side**, applied to market legs, with two-second execution latency and 50 shares per symbol per two-second replenishment interval. ETF conversions have no fee and no net cash flow, but consume an action and create inventory that must be financed or unwound through separately charged trades. One bot key is capped at 60 actions per rolling real minute.

Strict combined stress uses **50 basis points plus USD 0.04 per side**, six-second latency, 25-share depth, and an additional ten basis points of adverse execution. Regular combined uses 50 basis points plus USD 0.02, six-second latency and 25-share depth.

| Scenario | Scheduled mean USD | HGB mean USD |
|---|---:|---:|
| Baseline | 19,189.16 | 19,230.10 |
| 50 basis points | 13,212.78 | 14,413.31 |
| Six-second latency | 18,980.91 | 18,887.96 |
| 25-share depth | 12,108.10 | 12,538.09 |
| Regular combined | 8,936.30 | 9,636.43 |
| Strict combined | 7,891.64 | 8,502.58 |
| Twelve-second latency | 17,508.30 | 17,442.93 |
| Ten-share depth | 5,495.83 | 5,838.58 |
| Ten-second depth replenishment | 18,173.02 | 17,713.62 |

Weather conditioning helps mainly under higher cost or shallow depth, and is worse than the clock control in some latency/replenishment tests. We retain all of these outcomes rather than choosing the scenario that makes a policy look best.

### Full fixed execution matrix

Each policy was evaluated on the entire Cartesian grid of 25/50/100 basis points, 2/6/12-second latency, 10/25/50-share depth and 2/10-second replenishment: **54 settings per policy**. Fixed per-share cost here is USD 0.02 per side. This is 64,800 policy-scenario-season replays but only **600 unique seasons**, not 64,800 independent observations.

All 54 mean PnLs are positive for each policy; no scenario was excluded as blocked. Maximum observed rolling actions were 60 and maximum position fraction 1.0. At the harshest mean-PnL setting—100 basis points, 12-second latency, ten-share depth and ten-second replenishment—the scheduled mean is **USD 1,665.00**, versus HGB **USD 1,988.16**. HGB wins 78.67% of seasons there, with a worst of **USD -5,816.91**.

This grid tests broad assumed frictions, but it cannot model a competitor removing the opportunity, an unobserved price-protection rule rejecting orders, or fills disappearing systematically when the signal is strongest. Testnet order-book and fill measurements remain the next relevant source of evidence.

## 4. Stability, forward panels and information timing

### Forward whole-season panels

Larger season numbers are further in the fictional past. Each panel fits older seasons and evaluates a newer block. P2/P3 reuse the original fitted model and forecast bytes; P1/P4 add only the declared unchanged fits. All blocks had already been exposed to earlier research, including the separately authorized seasons 1–120.

| Fit seasons → evaluate seasons | Scheduled mean USD | HGB mean USD | HGB strict mean USD |
|---|---:|---:|---:|
| 481–600 → 361–480 | 19,575.02 | 19,021.46 | 8,214.39 |
| 361–600 → 241–360 | 19,423.69 | 19,450.03 | 8,795.72 |
| 241–600 → 121–240 | 18,986.54 | 19,166.58 | 8,403.19 |
| 121–600 → 1–120 | 18,765.97 | 19,267.00 | 8,620.95 |

The simple scheduled result is consistent across these panels. HGB's incremental baseline benefit varies in sign. HGB improves forecast RMSE versus the unconditional round-mean jump in all four panels (USD/share: 2.698/2.764, 2.680/2.799, 2.495/2.736, 2.482/2.666), but that does not translate mechanically into PnL improvement under constrained inventory and routing.

### Thirty whole-season training bootstraps

All 30 bootstrap resamples use fixed RNG 20261019, resample complete seasons 361–600, and evaluate the same 120 seasons 241–360. Every fitted forecast was evaluated; no seed or model was selected, averaged into an ensemble, or discarded. The formation curve and final structural model stay fixed; this probes active-forecast training instability, not all possible sources of model uncertainty.

| Distribution of 30 mean PnLs | Scheduled USD | HGB USD |
|---|---:|---:|
| Baseline: mean across fits | 19,424.69 | 18,982.15 |
| Baseline: minimum–maximum | 19,423.69–19,453.28 | 18,292.16–19,304.17 |
| Strict: mean across fits | 7,788.91 | 8,352.85 |
| Strict: minimum–maximum | 7,303.33–8,301.10 | 7,831.08–8,705.72 |

**HGB loses to the scheduled baseline in all 30 fits**, by a mean **USD 442.54** and a range of USD 130.24–1,131.52. Under strict execution it wins in 27/30, with a mean paired gain of **USD 563.94** and a range of USD -232.17 to USD 1,193.28. This is the strongest reason not to overstate the original USD 40.95 baseline improvement. The full ordered distribution and sample membership are retained.

### Stale public information

The decision remains at 180, but current-round HGB inputs are deliberately delayed to 170 or 150. Prior completed-round information remains available. A forecast based on stale prices is anchored to the stale quote to form the future fair value, then compared with the actual current quote; already realized price changes are not credited as tradable future edge.

| Active HGB input staleness | Baseline mean USD | Strict mean USD |
|---|---:|---:|
| Zero seconds | 19,230.10 | 8,502.58 |
| Ten seconds | 18,772.40 | 8,226.62 |
| Thirty seconds | 17,342.84 | 7,145.79 |

Formation and final-report inputs are unchanged in this sensitivity. It is not a network-receipt calibration, and the fixed model was not refitted to stale features. Zero-lag results exactly reproduce the existing outcomes.

## 5. What the physical regressions say about 2r

The earlier cutoff work remains valid and was not rescored to optimize V5. Let rho be distance to a site divided by storm radius. The wind kernel is:

```
wind = intensity * exp(-rho**2)
```

The Gaussian attenuation and a hard damage-support boundary are separate. At rho=2, the untruncated wind is exp(-4), about 1.83% of central intensity; it is not mathematically zero.

For single-site PORT, nonzero reported damage versus minimum normalized distance strongly supports a **2r damage-support boundary**. In the earlier fixed split, a threshold selected on 1,080 storms made zero classification errors on each of the two separate 360-storm evaluation blocks. The largest positive training distance was **1.99061r** and the smallest zero-damage distance **2.00953r**. Grid thresholds 1.995–2.005 had zero training errors. That brackets a threshold; it does not identify 2.000000 exactly.

Damage severity is harder than support classification. The earlier severity-regression error surface was nearly flat beyond about 1.9r, and some misspecified company regressions preferred slight tails beyond 2r. Thus support evidence favors 2r, while minimum predictive squared error does not tightly identify the exact boundary.

Outage closure uses a different condition: wind approximately 0.35. At intensity 1, its radius is sqrt(-log(0.35)) times r, approximately **1.025r**. Using 2r as the outage boundary would substantially overstate closures. Nor is 2r a universally optimal trading-entry threshold: prices, remaining path risk, accumulated damage and costs determine tradable edge.

## 6. Recovered terminal economics

The final-report engine uses structurally fitted terminal values rather than generic price prediction. The all-600 fit below is provided for interpretation and research deployment; evaluation used fold-specific fits, not these all-data coefficients.

Let D be season cumulative publicly reported damage as a fraction of original weighted assets, O be site-weighted outage hours on the accelerated market clock, and L be season insured losses measured in **millions of USD**. Values below are USD per share, rounded to the evident parameter scale:

```
PORT  ≈ 100 - 55*D_PORT - 2.4*O_PORT
ISLE  ≈  60 - 38*D_ISLE
AQUA  ≈  35 - 20*D_AQUA
GRID  ≈  50 - 24*D_GRID - 6.0*O_GRID
FERRY ≈  25 -  5*D_FERRY - 7.2*O_FERRY

RECON ≈ 40 + 24*(1-exp(-(0.9*D_PORT+0.7*D_GRID+0.12*D_FERRY)))
MAT   ≈ 28 + 14*(1-exp(-(0.75*D_PORT+0.50*D_ISLE+
                        0.2083*D_AQUA+0.5836*D_GRID+0.10*D_FERRY)))
GEN   ≈ 32 + 18.04*(1-exp(-0.9967*O_GRID))

HAVEN ≈ 75 - 0.06*min(max(L-400,0),900)
REIN  ≈ 90 - 0.0350*max(L-1300,0)   [observed range only]
```

Insured-loss regression weights are approximately USD 900M, 600M, 250M, 700M and 120M per unit of cumulative damage for PORT, ISLE, AQUA, GRID and FERRY respectively. HAVEN attaches near **USD 400M** and exhausts after another **USD 900M**, at season losses near **USD 1,300M**. REIN attaches near **USD 1,300M**, but its upper cap is not identified: the largest observed training-season loss in the all-data fit is **USD 1,766.2M**. We do not invent a detachment point beyond observed support.

Before the season is complete, nonlinear valuation requires averaging payoffs over the distribution of remaining damage/losses, not inserting mean losses into a clipped insurer function. A dedicated remaining-season distribution candidate was tested, but it did not beat the selected terminal-horizon ridge candidate, and neither standalone terminal engine displaced the scheduled common-account result. A structurally sensible model is not automatically the best trading strategy.

## 7. Negative results and rejected alternatives

Experiments were declared as small bounded families, with selection on the inner panel and unchanged diagnostic evaluation. The research program itself was adaptive, which is why the final global result remains post-selection. Standalone engine results below cannot be added to the headline account PnL.

| Experiment | Result | Decision |
|---|---|---|
| Earlier ten-second-tail handoff after actual flatness | Inner mean increment USD -7.31; fixed stress results mostly worse | Retain the old 60-second wait for that comparator |
| Eight clock holding schedules | Inner winner entry 180, exit start 540, full limits | Freeze schedule before diagnostic |
| Fixed ridge vs clock/HGB active forecast | Inner ridge USD 19,259.18; clock USD 19,423.69; HGB USD 19,450.03 | HGB selected by inner mean; ridge negative retained |
| Renewable event-forecast lease | Standalone diagnostic USD 2,955.90 vs old USD 2,500.92; slightly worse worst season | Improves that engine, not the final winner |
| Formation + event lease + final, common account | Diagnostic USD 13,723.23; strict USD 4,153.42 | Less profitable than the clock account |
| Terminal-value physical/quote ridge, C05 | Standalone diagnostic USD 6,624.48; worst USD -14,649.91; large inter-round inventory | Not additive to formation; no combined promotion |
| Explicit future-storm payoff distribution, C06 | Inferior inner mean to C05 | Retain as negative; no second candidate |
| Exactly one price-aware acquisition-stop rule | Inner increment USD -283.01; diagnostic USD -162.33 | Reject under primary mean-PnL objective |

The acquisition-stop rule saved diagnostic costs of USD 88.83 but lost USD 251.16 gross. Its required same-tick conversion financing and replanning changed route sizes/timing, so the comparison is not pure signal filtering. It helped some shallow-depth stresses, but those did not override its lower baseline mean. The patch is preserved separately and is not integrated into the selected executor.

The old event policy's validation had actually completed before recovery. We reused its `COMPLETE.json` and corrected the earlier statement that it was incomplete: diagnostic baseline mean USD 2,500.92, 113/120 wins; its original combined stress mean USD -27.19. That event stress used its own original settings and should not be confused with the parent account's 25-share strict stress.

## 8. Testing and audit framework

### Statistical separation

- Whole seasons are the unit of training, evaluation, resampling and uncertainty reporting; all three storms of a season stay together.
- Inner fitting uses 361–600 and selection 241–360. Frozen diagnostic refits on 241–600 and evaluates 121–240. Later authorized 1–120 evaluation is explicitly retrospective.
- Pooled five-fold evaluation excludes each 120-season test block and its adjacent 120-season block from the 360-season training set. The already selected strategy specification is held fixed.
- All negative policies, all stress scenarios and all 30 bootstrap fits remain recorded. No best bootstrap, best seed or best stress result is substituted for the original objective.
- Forecast-only RMSE is kept separate from trading PnL. Source, prediction, sample-membership and artifact hashes provide provenance.

### Public-information causality

The metadata audit covered 415,563 messages from seasons 121–600: 1,440 rounds. All 347,040 storm messages had publication time equal to 60 plus storm age. Preliminary and final reports occurred once per round at 570 and 740; no sequence duplicates, conflicts or publication-order reversals were found. This validates metadata chronology, not raw-payload/cache equivalence or real receipt timing.

Feature poisoning tests change unavailable future quotes, future weather, truth labels and season identity without changing a current public prefix's decision features. Forecast labels are only training/evaluation data. The final valuation uses cumulative public final reports and observed outages available at 740. The independent audit reproduced those final fair values bit-for-bit from JSON parameters without fitting or executing a serialized model.

### Common-account execution

- Cash and inventory are updated from actual simulated fills; there is one final settlement. Fully flat phases can be composed because positions and gross pending orders have been cleared, not because independently scored sleeves are assumed additive.
- Buy and sell pending capacity are reserved separately. Opposing pending orders cannot hide gross position-limit violations through netting.
- ETF creation/redemption has zero net cash, changes constituent/ETF inventory, consumes one action and preserves all symbol limits. Financing trades and unwind costs are charged separately.
- Rolling action history is integer/finite, continuous across rounds and shared by phases. Duplicate rounds, invalid histories and endgame readiness bypasses are rejected.
- Depth applies at delayed fills; recovery must wait for actual flatness and replenishment. Quote padding past close cannot generate orders or fills.

The focused independent audit exactly reproduced all 13 output fields of the frozen 120-season clock baseline. Its separate ledger reconciled cash plus settlement, fees, turnover, inventory, action submissions and **12,240 ETF conversion fills**. It observed maximum depth 50 and rolling actions 49. Synthetic cases included 40-second latency with 25-share depth, opposing pending orders, padding poisoning and future-information perturbation.

The current source tests pass **50 tests plus 34 subtests**. The metadata/account audit is narrower than a live end-to-end certification: the independent ledger covered the 120-season clock baseline, not every HGB/stress run. All 600 results additionally passed the shared executor's accounting and constraint assertions.

### Reproduction

`reproduce_v5.py` refits the frozen models from the prepared data and does not depend on saved prediction files. The executed reconstruction matched **every per-season PnL exactly**, maximum absolute difference 0.0, for both selected policies on all 600 seasons. It used the existing public-data cache. The supplied command can also create that cache from the original organizer ZIP; this run did not independently re-audit every raw cached payload.

The compact package includes source, reports, all key per-season outcomes, the full stress/negative tables, audit evidence, split/fit manifests and one all-600 research model. The raw dataset and duplicate fitted checkpoint models are omitted with a manifest. See `README_V5.md` for the direct reproduction command and scope of optional experiment scripts.

## 9. Next implementation decision

The next high-value experiment is execution calibration, rather than another large model grid on these same 600 seasons. Record the testnet's actual bid/ask, per-level depth, fill/reject events, price-protection behavior and receipt timestamps; replay the frozen clock and HGB policies through that measured adapter. Preserve the model settings and compare on identical accounts.

The live adapter must reconcile positions/resting orders after reconnect, deduplicate by competition and sequence, use snapshots without double-counting preliminary/final reports, preserve per-key and team action budgets, and stop treating historical economic coefficients as current when an announcement changes them. Those are concrete unimplemented live-market dependencies, not evidence against the historical signal.

The research ran locally with tmux-backed jobs, atomic checkpoints and three independent workers; no Ramp repository changes were made. The authorization was a maximum of USD 400 estimated model cost and five active hours, not a requirement to spend either cap. Actual measured duration and startup-inclusive worker estimates are saved in `research_v5/report/BUDGET_V5.json`; idle/restart time is not counted as continuous research. The completed bounded searches and robustness tests are preserved rather than continuing to tune the same data merely to consume the allowance.

At research close on 2026-10-19 at 14:42 UTC, elapsed wall time since authorization was **57.4 minutes**. The supervisor recorded **53.8 active minutes**, plus roughly three minutes of initial setup and a short unextrapolated final interval. This run used approximately one active hour, not five. Concurrent worker times are not added to wall time.

The last aggregate local model estimate was **USD 150.97**: parent increment USD 34.16, event/entry worker USD 41.59, terminal/forecast/stability worker USD 42.22, and audit worker USD 33.00. An additional **USD 10.00 delivery/measurement allowance** brings the conservative estimate to **USD 160.97**, below the USD 400 cap. These are estimates from local telemetry and worker reports, not verified billing; the allowance is not measured expenditure. No external paid compute or data was purchased.
