"""Mean-PnL-only inner selection; freeze every fold before outer evaluation."""

import argparse
import hashlib
import itertools
import json
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

import numpy as np
import pandas as pd

from backtest import summarize
from common import SYMBOLS, dump_json, load_cache
from endgame import simulate_endgame
from evaluate import bootstrap_mean, combine
from pnl_v2_simulator import simulate
from short_horizon import simulate_short
from train import TIMES

OUT = Path("results_v2")
SCENARIOS = {
    "base": {},
    "50bps": {"cost_bps": 50},
    "100bps": {"cost_bps": 100},
    "4s_latency": {"latency": 4},
    "8s_latency": {"latency": 8},
    "12s_latency": {"latency": 12},
    "25_share_depth": {"depth": 25},
    "10_share_depth": {"depth": 10},
    "combined_stress": {"cost_bps": 50, "latency": 4, "depth": 25},
    "extra_25bps_adverse": {"adverse_bps": 25},
    "10s_depth_replenishment": {"replenish_seconds": 10},
}


def inputs(fold, split):
    d = load_cache("cache.npz")
    p = load_cache(OUT / f"fold-{fold}-predictions.npz")
    select = np.isin(p["ids"], p[f"{split}_ids"])
    ids = p["ids"][select]
    return ids, (
        d["market"][ids],
        d["settlement_truth"][ids],
        p["delta"][select],
        p["final_fair"][select],
        p["formation_curve"],
    )


def select_fold(fold):
    ids, args = inputs(fold, "val")
    plan = json.loads((OUT / "research_plan.json").read_text())
    records = []

    def evaluate(config, stage):
        result = simulate(*args, **config)
        record = {
            "fold": fold,
            "stage": stage,
            "config": json.dumps(config, sort_keys=True),
            **summarize(result),
        }
        records.append(record)
        return record["mean_usd"]

    best_form, best_mean = None, 0.0
    for start, exit_at, budget in itertools.product(
        plan["formation_starts"],
        plan["formation_exit_starts"],
        plan["formation_entry_action_budgets"],
    ):
        form = {"start": start, "exit": exit_at, "entry_budget": budget}
        mean = evaluate({"formation": form}, "formation")
        if mean > best_mean:
            best_form, best_mean = form, mean
    best_config = {"formation": best_form}
    for formation in [None, best_form]:
        for threshold, top_k, cycle in itertools.product(
            plan["ongoing_thresholds_usd"],
            plan["ongoing_top_k"],
            plan["ongoing_cycles_seconds"],
        ):
            config = {
                "formation": formation,
                "ongoing": {"threshold": threshold, "top_k": top_k, "cycle": cycle},
            }
            mean = evaluate(config, "ongoing")
            if mean > best_mean:
                best_config, best_mean = config, mean
    without_end = best_config.copy()
    for margin in plan["endgame_margins_usd"]:
        config = {**without_end, "end_margin": margin}
        mean = evaluate(config, "endgame")
        if mean > best_mean:
            best_config, best_mean = config, mean
    frozen = {
        "fold": fold,
        "config": best_config,
        "validation_mean_usd": best_mean,
        "selection_metric": "mean net terminal USD PnL only",
        "validation_seasons": (ids + 1).tolist(),
        "candidate_count": len(records),
        "best_formation_only": best_form,
    }
    pd.DataFrame(records).to_csv(OUT / f"fold-{fold}-validation.csv", index=False)
    dump_json(OUT / f"fold-{fold}-frozen.json", frozen)
    print("FROZEN", fold, round(best_mean, 2), best_config, flush=True)
    return frozen


def evaluate_fold(fold):
    ids, args = inputs(fold, "test")
    frozen_path = OUT / f"fold-{fold}-frozen.json"
    frozen = json.loads(frozen_path.read_text())
    config = frozen["config"]
    results = {}
    for name, stress in SCENARIOS.items():
        results[name] = simulate(*args, **config, **stress, audit=name == "base")
    # V1 policy is held fixed, with the same fold-specific training-only models.
    v1 = json.loads(Path("results/engines_frozen.json").read_text())
    a = simulate_short(args[0], args[1], args[2], TIMES, **v1["short_horizon"])
    b = simulate_endgame(args[0], args[1], args[3], **v1["primary"])
    results["v1_reference"] = combine(a, b)
    form = frozen["best_formation_only"]
    results["formation_only"] = simulate(*args, formation=form)
    results["formation_plus_final"] = simulate(
        *args, formation=form, end_margin=config.get("end_margin")
    )
    # Audit the actual rolling sequence, not just an average actions/min count.
    action_ticks = results["base"]["action_ticks"]
    cumulative = np.cumsum(action_ticks, axis=2)
    prior = np.concatenate(
        [np.zeros_like(cumulative[:, :, :30]), cumulative[:, :, :-30]], axis=2
    )
    assert (cumulative - prior).max() <= 60
    assert results["base"]["max_position_fraction"].max() <= 1
    serial = {
        f"{name}__{key}": value
        for name, result in results.items()
        for key, value in result.items()
    }
    np.savez_compressed(OUT / f"fold-{fold}-outer-results.npz", ids=ids, **serial)
    print("OUTER", fold, round(results["base"]["pnl"].mean(), 2), flush=True)
    return {
        "fold": fold,
        "frozen_sha256": hashlib.sha256(frozen_path.read_bytes()).hexdigest(),
        "config": config,
        "validation_mean_usd": frozen["validation_mean_usd"],
        "outer_summary": summarize(results["base"]),
        "v1_summary": summarize(results["v1_reference"]),
    }


def aggregate(folds):
    all_results = [load_cache(OUT / f"fold-{k}-outer-results.npz") for k in range(5)]
    order = np.argsort(np.concatenate([x["ids"] for x in all_results]))
    joined = {
        key: np.concatenate([x[key] for x in all_results])[order]
        for key in all_results[0]
    }
    assert np.array_equal(joined["ids"], np.arange(600))
    records = []
    names = list(SCENARIOS) + ["v1_reference", "formation_only", "formation_plus_final"]
    for name in names:
        result = {
            key.split("__", 1)[1]: value
            for key, value in joined.items()
            if key.startswith(name + "__")
        }
        summary = {
            "scenario": name,
            **summarize(result),
            "mean_ci95_usd": bootstrap_mean(result["pnl"]),
        }
        if "max_rolling_actions" in result:
            summary.update(
                {
                    "max_rolling_actions": int(result["max_rolling_actions"].max()),
                    "max_position_fraction": float(
                        result["max_position_fraction"].max()
                    ),
                    "engine_mean_usd": result["by_engine"].mean(0).tolist(),
                }
            )
        records.append(summary)
    paired = joined["base__pnl"] - joined["v1_reference__pnl"]
    report = {
        "qualification": "Post-selection nested season CV; all seasons were previously examined during v1",
        "objective": "mean net terminal USD PnL, no risk or stress penalty",
        "folds": folds,
        "scenarios": records,
        "paired_improvement_mean_usd": float(paired.mean()),
        "paired_improvement_ci95_usd": bootstrap_mean(paired),
        "paired_win_fraction": float(np.mean(paired > 0)),
        "formation_timing_seconds_after_open": {
            key: {
                "mean": float(joined["base__formation_" + key].mean()),
                "min": int(joined["base__formation_" + key].min()),
                "max": int(joined["base__formation_" + key].max()),
            }
            for key in ["last_entry", "first_exit", "flat"]
        },
        "mean_formation_peak_shares": float(
            joined["base__formation_peak_shares"].mean()
        ),
        "mean_engine_actions": joined["base__engine_actions"].mean(0).tolist(),
    }
    dump_json(OUT / "summary.json", report)
    pd.DataFrame(records).to_csv(OUT / "scenarios.csv", index=False)
    pd.DataFrame(
        {
            "season": joined["ids"] + 1,
            "outer_fold": joined["ids"] // 120,
            **{name: joined[name + "__pnl"] for name in names},
            "formation_attribution": joined["base__by_engine"][:, 0],
            "ongoing_attribution": joined["base__by_engine"][:, 1],
            "final_attribution": joined["base__by_engine"][:, 2],
            "actions": joined["base__actions"],
            "max_rolling_actions": joined["base__max_rolling_actions"],
            "max_drawdown_usd": joined["base__drawdown"],
            "cost_usd": joined["base__cost"],
        }
    ).to_csv(OUT / "outer_seasons.csv", index=False)
    pd.DataFrame(
        {
            "symbol": SYMBOLS,
            "v2_mean_usd": joined["base__attribution"].mean(0),
            "v1_mean_usd": joined["v1_reference__attribution"].mean(0),
        }
    ).to_csv(OUT / "attribution.csv", index=False)
    print(
        pd.DataFrame(records)[
            ["scenario", "mean_usd", "minimum_usd", "win_rate"]
        ].to_string(index=False),
        flush=True,
    )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--stage", choices=["select", "evaluate", "all"], default="all")
    parser.add_argument("--workers", type=int, default=5)
    args = parser.parse_args()
    if args.stage in ("select", "all"):
        # This expansion is declared before inner-validation/outer results are opened.
        path = OUT / "research_plan.json"
        plan = json.loads(path.read_text())
        plan["formation_entry_action_budgets"] = [10, 20, 30, 45, 60]
        plan["execution_note"] = (
            "Formation exits can wait for expiring action budget; ongoing trades reserve exit actions"
        )
        dump_json(path, plan)
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            list(pool.map(select_fold, range(5)))
    if args.stage in ("evaluate", "all"):
        # All five choices must exist before any outer evaluation begins.
        assert all((OUT / f"fold-{k}-frozen.json").exists() for k in range(5))
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            folds = list(pool.map(evaluate_fold, range(5)))
        aggregate(folds)


if __name__ == "__main__":
    main()
