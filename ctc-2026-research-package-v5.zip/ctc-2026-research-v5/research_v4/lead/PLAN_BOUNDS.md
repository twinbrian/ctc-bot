# Lead second hypothesis: public-state economic bounds

This is distinct from the rejected analog forecast. Use final published damage
and known-to-date measured outages to derive conservative terminal-value bounds.
Storm damage/outages only accumulate; insurer layers are capped; rebuilders have
bounded, monotone response. Fit the economic coefficients on fit seasons only.

Examples: HAVEN terminal value cannot fall below its exhausted-layer value; known
season loss bounds its highest possible final value. Rebuilder known damage gives
a value floor. Physical-company known damage/outages give a value ceiling. The
remaining storm time bounds additional outage duration. Max aggregate damage1
per company bounds loss and rebuild upside. ETF intervals sum constituent bounds.

Only exact final damage reports count as known damage/loss; preliminary reports
are not bounds. Site wind/closure integration is approximate, so include twice the
maximum training terminal-value residual plus a fixed cushion in every bound.

Two predeclared policies: extra cushion USD0.10 or USD0.30/share, no other grid.
Buy only below the lower bound after cost; sell only above the upper bound after
cost. Arrival-price-capped limits,50-share clips,2s latency,60actions/min, full
symbol limits. Non-crossing orders receive no passive-fill credit and keep their
inventory reservation. Positions and reservations carry between rounds. Hold fills
to settlement. Exclude round3 t>=740, already served by the incumbent endgame.

Fit361..600, choose on241..360 retaining no trades, freeze and refit241..600 before
one validation121..240 pass. Do not call bounds guaranteed in the actual market:
unmodeled announcements, parameter uncertainty, future support changes and missing
books can invalidate an apparent bound. Check the known historical terminal value
against bound-triggered fills only as an evaluation diagnostic.
