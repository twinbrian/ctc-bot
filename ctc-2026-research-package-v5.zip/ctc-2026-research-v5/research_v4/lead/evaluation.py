"""Season-level comparison and conditional multiple-candidate diagnostics.

These diagnostics do not erase adaptive reuse of the historical dataset. All
headline claims must retain that limitation, even if a bootstrap p-value is small.
"""

import hashlib
import json
from pathlib import Path

import numpy as np


def assert_disjoint(train_ids, evaluation_ids):
    overlap = np.intersect1d(train_ids, evaluation_ids)
    if len(overlap):
        raise ValueError(f"Training/evaluation season overlap: {overlap[:10].tolist()}")


def season_summary(pnl):
    x = np.asarray(pnl, dtype=float)
    if x.ndim != 1 or len(x) < 2 or not np.isfinite(x).all():
        raise ValueError("Need finite season-level PnLs")
    return {"n": len(x), "mean_usd": float(x.mean()), "median_usd": float(np.median(x)),
            "win_rate": float((x > 0).mean()), "worst_usd": float(x.min()),
            "p05_usd": float(np.quantile(x, .05)), "p95_usd": float(np.quantile(x, .95)),
            "worst_5pct_mean_usd": float(np.sort(x)[:max(1, int(np.ceil(.05*len(x))))].mean()),
            "std_usd": float(x.std(ddof=1))}


def paired_comparison(candidate, reference, draws=10000, seed=2026):
    candidate, reference = np.asarray(candidate), np.asarray(reference)
    if candidate.shape != reference.shape or candidate.ndim != 1:
        raise ValueError("Require paired per-season arrays")
    diff = candidate-reference
    rng = np.random.default_rng(seed)
    bootstrap = diff[rng.integers(0, len(diff), (draws, len(diff)))].mean(1)
    return {"candidate": season_summary(candidate), "reference": season_summary(reference),
            "mean_difference_usd": float(diff.mean()),
            "conditional_mean_difference_ci95_usd": np.quantile(bootstrap, [.025, .975]).tolist(),
            "paired_win_rate": float((diff > 0).mean()),
            "qualification": "Conditional season bootstrap; excludes research/fit/market-model uncertainty"}


def max_statistic_check(increments, draws=10000, seed=2026):
    """Centered season bootstrap across an explicitly reported candidate family.

    One-sided max-t check retains cross-candidate dependence by resampling whole
    season rows. Diagnostic only: model and strategy selection outside this matrix
    is not corrected by the test.
    """
    x = np.asarray(increments, dtype=float)
    if x.ndim != 2 or x.shape[0] < 2 or not np.isfinite(x).all():
        raise ValueError("Need finite [season,candidate] incremental PnLs")
    n, k = x.shape
    scale = np.maximum(x.std(axis=0, ddof=1), 1e-9)
    observed_each = np.sqrt(n)*x.mean(0)/scale
    observed_max = float(observed_each.max())
    centered = x-x.mean(0)
    rng = np.random.default_rng(seed)
    null_max = []
    for start in range(0, draws, 500):
        count = min(500, draws-start)
        index = rng.integers(0, n, (count, n))
        means = centered[index].mean(1)
        null_max.extend((np.sqrt(n)*means/scale).max(1).tolist())
    null_max = np.asarray(null_max)
    p = (1+np.sum(null_max >= observed_max))/(draws+1)
    adjusted = [(1+np.sum(null_max >= t))/(draws+1) for t in observed_each]
    return {"seasons": n, "candidate_count": k, "observed_max_t": observed_max,
            "family_pvalue": float(p), "candidate_adjusted_pvalues": adjusted,
            "qualification": "Conditional centered max-t bootstrap; not a fresh-holdout guarantee"}


def freeze(path, config, fit_ids, tuning_ids, evaluation_ids, hypothesis):
    assert_disjoint(fit_ids, evaluation_ids)
    assert_disjoint(tuning_ids, evaluation_ids)
    body = {"hypothesis": hypothesis, "config": config,
            "fit_ids": list(map(int, fit_ids)), "tuning_ids": list(map(int, tuning_ids)),
            "evaluation_ids": list(map(int, evaluation_ids))}
    payload = json.dumps(body, indent=2, sort_keys=True)+"\n"
    target = Path(path)
    if target.exists() and target.read_text() != payload:
        raise ValueError("A frozen candidate cannot be silently overwritten")
    target.write_text(payload)
    return hashlib.sha256(payload.encode()).hexdigest()
