# Lead track: path-conditioned insurance payoff distributions

Registered before scoring this family. This track is distinct from event-price
response, ETF basis, conditional formation positioning and execution auditing.

Hypothesis: the house may price a clipped insurance layer at a point loss forecast
rather than integrating the full loss distribution. A causal analog distribution
of current-storm damage, adjusted for remaining asset capacity, may identify a
terminal-value gap in HAVEN or REIN during round 3.

Use the development split in RESEARCH_CONTRACT.md. No original seasons1..120.
Fit the structural settlement map and feature scales on fit seasons only. Use
historical storm outcomes as labels, never current-season future information.

At fixed round3 t=330, select same-round historical analogs from public prior
damage/loss, observed wind path so far, current position/velocity/radius/intensity.
Two feature blocks: physical-only, physical+latest public official/wire guidance.
Use k=20 or60 nearest neighbors. For each neighbor rescale its current-storm final
damage by the ratio of current-to-neighbor remaining assets, clipped at current
remaining capacity. Convert each sample to loss and average the insurer's payoff
over samples. Compare to applying the payoff to the mean loss (Jensen diagnostic).

Twelve policy configurations: 2 feature blocks x 2 k x 3 forecast weights
(0.25,0.5,1.0 blended toward current price). Fixed USD0.10 valuation cushion,
50-share clips at two-second delayed arrival, at most each insurer's limit.
Trade only during a 20-second entry window and hold to settlement. Non-crossing
limits receive no passive-fill credit. No standalone profit is added to incumbent
until a shared-account integration checks conflicts and action/position budgets.

If any analog REIN loss exceeds the maximum training loss, suppress that REIN
trade because the upper exhaustion point is unidentified. Report this frequency.
Select by inner mean PnL, retain zero trades as an alternative, refit the chosen
model on seasons241..600, and evaluate121..240 once. Log all twelve outcomes,
prediction errors, confidence intervals, Jensen differences, and latency/cost
stresses. A failed hypothesis remains a negative result; no second grid follows.
