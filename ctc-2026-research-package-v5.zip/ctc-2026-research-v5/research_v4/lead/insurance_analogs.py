"""Causal, distribution-valued insurance research on restricted development data."""

import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.neighbors import NearestNeighbors
from sklearn.preprocessing import StandardScaler

ROOT=Path(__file__).resolve().parents[1]
PROJECT=ROOT.parent
sys.path.insert(0,str(PROJECT))
sys.path.insert(0,str(ROOT))
from common import LIMITS, dump_json
from lab import load_development, masks, summarize_pnl
from models import StructuralModel, features, weather


def feature_matrix(data):
    x=features(data,[330])[0][:,2,0]
    # Schema: time2, priorD5, priorLoss1, priorO5, currentO5, obs6,
    # cumulative exposure17, peak17, current wind17, reports7, opinions27.
    return {"physical":x[:,2:58],"guidance":np.concatenate([x[:,2:58],x[:,82:109]],axis=1)}


def fit_predict(data,train_mask,eval_mask,feature_kind,k):
    x=feature_matrix(data)[feature_kind]
    scale=StandardScaler().fit(x[train_mask])
    train_ids=np.flatnonzero(train_mask)
    val_ids=np.flatnonzero(eval_mask)
    fit=NearestNeighbors(n_neighbors=k).fit(scale.transform(x[train_mask]))
    distance,index=fit.kneighbors(scale.transform(x[eval_mask]))
    analog=train_ids[index]
    weights=1/np.maximum(distance,0.25)**2
    weights/=weights.sum(1,keepdims=True)
    prior=data["damage"][:,:2,-1].sum(1)
    prior_loss=data["loss"][:,:2,-1].sum(1)
    current_remaining=1-prior[val_ids]
    neighbor_remaining=np.maximum(1-prior[analog],0.01)
    incremental=data["report_truth"][analog,2]
    adjusted=np.clip(incremental*current_remaining[:,None,:]/neighbor_remaining,0,current_remaining[:,None,:])
    total_outage=weather(data)[2].sum(1)
    economics=StructuralModel().fit(data["report_truth"][train_mask].sum(1),total_outage[train_mask],
                                    data["loss_truth"][train_mask].sum(1),data["settlement_truth"][train_mask])
    samples=prior_loss[val_ids,None]+adjusted@economics.insured_weights
    point=samples@np.ones(k)  # overwritten with correctly weighted mean below
    point=np.sum(samples*weights,axis=1)
    forecasts=np.empty((len(val_ids),2))
    plug_in=np.empty_like(forecasts)
    for j,params in enumerate(economics.insurers):
        payoff=np.maximum(samples-params[2],0)
        point_payoff=np.maximum(point-params[2],0)
        if len(params)==4:
            payoff=np.minimum(payoff,params[3])
            point_payoff=np.minimum(point_payoff,params[3])
        forecasts[:,j]=params[0]-params[1]*np.sum(weights*payoff,axis=1)
        plug_in[:,j]=params[0]-params[1]*point_payoff
    unsupported=np.max(samples,axis=1)>economics.max_training_loss
    return {"ids":val_ids,"fair":forecasts,"plugin":plug_in,"unsupported_rein":unsupported,
            "mean_loss":point,"loss_std":np.sqrt(np.sum(weights*(samples-point[:,None])**2,axis=1))}


def simulate_entry(data,pred,weight=1.,cost_bps=25,latency=2,depth=50,fixed_cost=.02):
    ids=pred["ids"]
    m=data["market"][ids,2]
    truth=data["settlement_truth"][ids,8:10]
    current=m[:,165,8:10]
    fair=current+weight*(pred["fair"]-current)
    allowed=np.ones_like(fair,dtype=bool)
    allowed[:,1]=~pred["unsupported_rein"]
    q=np.zeros_like(fair,dtype=int)
    reserved=np.zeros_like(q)
    cash=np.zeros(len(ids))
    actions=np.zeros(len(ids),dtype=int)
    costs=np.zeros(len(ids))
    delay=max(1,int(np.ceil(latency/2)))
    queue=[[] for _ in range(190+delay)]
    for tick in range(165,175+delay):
        for j,ii,qty,limit in queue[tick]:
            quote=m[ii,tick,8+j]
            fee=quote*cost_bps/10000+fixed_cost
            execution=quote+np.sign(qty)*fee
            filled=qty*((execution-limit)*np.sign(qty)<=0)
            reserved[ii,j]-=filled
            q[ii,j]+=filled
            cash[ii]-=filled*execution
            costs[ii]+=np.abs(filled)*fee
        if tick>=175:
            continue
        quote=m[:,tick,8:10]
        edge=fair-quote
        direction=np.sign(edge).astype(int)
        quantity=np.minimum(depth,np.maximum(0,LIMITS[None,8:10]-np.abs(q)-np.abs(reserved)))
        net=np.abs(edge)-(quote*cost_bps/10000+fixed_cost)-.1
        for j in range(2):
            eligible=allowed[:,j]&(net[:,j]>0)&(quantity[:,j]>0)&((q[:,j]+reserved[:,j])*direction[:,j]>=0)
            ii=np.where(eligible)[0]
            qty=quantity[ii,j]*direction[ii,j]
            limit=fair[ii,j]-direction[ii,j]*.1
            queue[tick+delay].append((j,ii,qty,limit))
            reserved[ii,j]+=qty
            actions[ii]+=1
    assert np.all(np.abs(q)+np.abs(reserved)<=LIMITS[None,8:10])
    assert actions.max()<=20
    pnl=cash+np.sum(q*truth,axis=1)
    return {"pnl":pnl,"positions":q,"actions":actions,"cost":costs}


def main():
    data=load_development()
    fit,tune,val=masks(data)
    out=Path(__file__).parent
    rows=[]
    best_mean=0.
    best=None
    for feature in ["physical","guidance"]:
        for k in [20,60]:
            pred=fit_predict(data,fit,tune,feature,k)
            for weight in [.25,.5,1.]:
                result=simulate_entry(data,pred,weight=weight)
                row={"feature":feature,"k":k,"weight":weight,**summarize_pnl(result["pnl"])}
                rows.append(row)
                if row["mean_usd"]>best_mean:
                    best_mean=row["mean_usd"]
                    best={"feature":feature,"k":k,"weight":weight}
    pd.DataFrame(rows).to_csv(out/"insurance_inner_candidates.csv",index=False)
    dump_json(out/"insurance_frozen.json",{"candidate":best,"inner_mean_usd":best_mean,"zero_trade_option_retained":True})
    if best is None:
        print("Insurance analog hypothesis rejected on inner development.")
        print(pd.DataFrame(rows).sort_values("mean_usd",ascending=False).to_string(index=False))
        return
    pred=fit_predict(data,fit|tune,val,best["feature"],best["k"])
    result=simulate_entry(data,pred,weight=best["weight"])
    metrics={"base":summarize_pnl(result["pnl"])}
    for label,params in [("50bps",{"cost_bps":50}),("8s",{"latency":8}),("25shares",{"depth":25})]:
        metrics[label]=summarize_pnl(simulate_entry(data,pred,weight=best["weight"],**params)["pnl"])
    metrics["unsupported_rein_fraction"]=float(pred["unsupported_rein"].mean())
    metrics["mean_jensen_gap_usd"]=(pred["fair"]-pred["plugin"]).mean(0).tolist()
    metrics["validation_rmse_usd"]=np.sqrt(np.mean((pred["fair"]-data["settlement_truth"][val,8:10])**2,axis=0)).tolist()
    dump_json(out/"insurance_validation.json",metrics)
    pd.DataFrame({"season":data["season_ids"][val],"pnl":result["pnl"],"haven_fair":pred["fair"][:,0],
                  "rein_fair":pred["fair"][:,1],"mean_loss":pred["mean_loss"],"loss_std":pred["loss_std"]}).to_csv(out/"insurance_validation_seasons.csv",index=False)
    print(best,metrics)


if __name__=="__main__":
    main()
