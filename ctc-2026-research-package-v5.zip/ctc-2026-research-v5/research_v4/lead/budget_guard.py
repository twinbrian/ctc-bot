"""User-authorized budget/deadline guard, not a worker-progress poll.

Reads local OpenCode's reported model cost. Interrupts only the listed research
subagents at a conservative USD 300 increment or 15 minutes before the deadline.
The USD 50/time reserve is for in-flight usage and final delivery. Estimates are
not an invoice; do not spend on external services or paid compute.
"""

import datetime as dt
import json
import subprocess
import time
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def interrupt_workers(state):
    records = []
    for worker in state["agents_launched"]:
        sid = worker["session_id"]
        assert sid.startswith("ses_")
        try:
            result = subprocess.run(
                ["opencode", "api", "post", f"/api/session/{sid}/interrupt"],
                capture_output=True, text=True, timeout=20,
            )
            records.append({"track": worker["track"], "returncode": result.returncode,
                            "response": result.stdout[:2000]})
        except subprocess.TimeoutExpired:
            records.append({"track": worker["track"], "error": "interrupt timeout"})
    return records


def main():
    failures = 0
    while True:
        state = json.loads((ROOT / "phase_state.json").read_text())
        if state["status"] != "active":
            print("Budget guard stopped: phase is", state["status"], flush=True)
            return
        now = dt.datetime.now(dt.timezone.utc)
        deadline = dt.datetime.fromisoformat(state["deadline_utc"].replace("Z", "+00:00"))
        reason = None
        snapshot = {"time_utc": now.isoformat()}
        try:
            result = subprocess.run(
                ["opencode", "stats", "--days", "0", "--cost", "--json"],
                capture_output=True, text=True, timeout=30, check=True,
            )
            stats = json.loads(result.stdout)
            cost = float(stats["cost"])
            snapshot.update(total_reported_cost_usd=cost,
                            phase_increment_usd=cost-state["initial_reported_cost_usd"],
                            sessions=stats["sessions"], subagents=stats["subagents"])
            failures = 0
            if snapshot["phase_increment_usd"] >= state["target_finish_additional_cost_usd"]:
                reason = "reported model cost reached reserve boundary"
        except (subprocess.SubprocessError, ValueError, KeyError) as exc:
            failures += 1
            snapshot["telemetry_error"] = type(exc).__name__
            if failures >= 3:
                reason = "budget telemetry unavailable for three checks"
        with (ROOT / "lead/budget_history.jsonl").open("a") as f:
            f.write(json.dumps(snapshot) + "\n")
        (ROOT / "lead/latest_budget.json").write_text(json.dumps(snapshot, indent=2) + "\n")
        if now >= deadline-dt.timedelta(minutes=15):
            reason = "research deadline reserve reached"
        if reason:
            snapshot["stop_reason"] = reason
            snapshot["worker_interrupts"] = interrupt_workers(state)
            (ROOT / "lead/RESEARCH_STOP.json").write_text(json.dumps(snapshot, indent=2) + "\n")
            print("RESEARCH STOP:", json.dumps(snapshot), flush=True)
            return
        time.sleep(60)


if __name__ == "__main__":
    main()
