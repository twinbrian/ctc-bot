"""Trade only outside conservative, public-state terminal-value intervals."""

import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT.parent))
sys.path.insert(0,str(ROOT))
from common import BASKETS,LIMITS,dump_json
from lab import load_development,masks,summarize_pnl
from models import StructuralModel,weather


def fit_economics(data,training):
    out=weather(data)[2].sum(1)
    e=StructuralModel().fit(data['report_truth'][training].sum(1),out[training],
                             data['loss_truth'][training].sum(1),data['settlement_truth'][training])
    fitted=e.predict(data['report_truth'][training].sum(1),out[training],data['loss_truth'][training].sum(1))
    buffer=2*np.max(np.abs(fitted-data['settlement_truth'][training]),axis=0)
    return e,buffer


def intervals(data,e,buffer,extra):
    _,outage,final_outage,_,_=weather(data)
    n=len(data['market'])
    prev_d=np.concatenate([np.zeros((n,1,5)),data['damage'][:,:-1,-1].cumsum(1)],axis=1)
    prev_l=np.concatenate([np.zeros((n,1)),data['loss'][:,:-1,-1].cumsum(1)],axis=1)
    prev_o=np.concatenate([np.zeros((n,1,5)),final_outage[:,:-1].cumsum(1)],axis=1)
    times=np.arange(390)*2
    idx=np.clip((times-60)//2,0,239)
    lo=np.zeros((n,3,390,12));hi=np.zeros_like(lo)
    for r in range(3):
        exact=data['stage'][:,r]==2
        known_d=prev_d[:,r,None]+data['damage'][:,r]*exact[...,None]
        known_l=prev_l[:,r,None]+data['loss'][:,r]*exact
        current_o=outage[:,r,idx]*(times>=60)[None,:,None]
        current_o[:,times>=540]=final_outage[:,r,None]
        known_o=prev_o[:,r,None]+current_o
        future=(np.maximum(0,540-np.maximum(times,60))/120)+(2-r)*4
        worst_d=np.ones_like(known_d)
        worst_o=known_o+future[None,:,None]
        max_loss=np.maximum(known_l,np.maximum(e.insured_weights,0).sum()+.5)
        minimum_economics=e.predict(known_d,known_o,known_l)
        maximum_damage=e.predict(worst_d,worst_o,max_loss)
        lo[:,r,:,:5]=maximum_damage[...,:5]
        hi[:,r,:,:5]=minimum_economics[...,:5]
        lo[:,r,:,5:8]=minimum_economics[...,5:8]
        hi[:,r,:,5:8]=maximum_damage[...,5:8]
        lo[:,r,:,8:10]=maximum_damage[...,8:10]
        hi[:,r,:,8:10]=minimum_economics[...,8:10]
        lo[:,r,:,10:]=lo[:,r,:,:10]@BASKETS.T
        hi[:,r,:,10:]=hi[:,r,:,:10]@BASKETS.T
    lo-=buffer[None,None,None,:]+extra
    hi+=buffer[None,None,None,:]+extra
    assert np.all(lo<=hi+1e-8)
    return lo,hi


def simulate(data,ids,lower,upper,latency=2,depth=50,cost_bps=25):
    n=len(ids);row=np.arange(n);delay=max(1,int(np.ceil(latency/2)))
    q=np.zeros((n,12),int);pp=q.copy();pn=q.copy();rb=q.copy();rs=q.copy()
    cash=np.zeros(n);actions=np.zeros(n,int);fees=np.zeros(n);maxwindow=np.zeros(n,int)
    fills=np.zeros(n,int);adverse_gross=np.zeros(n,int)
    for r in range(3):
        hist=np.zeros((n,30),int);used=np.zeros(n,int);queue=[[] for _ in range(390+delay)]
        for t in range(390):
            used-=hist[:,t%30];hist[:,t%30]=0
            price=data['market'][ids,r,t]
            for i,j,requested,cap in queue[t]:
                pp[i,j]-=np.maximum(requested,0);pn[i,j]-=np.maximum(-requested,0)
                side=np.sign(requested);cost=price[i,j]*cost_bps/10000+.02
                execution=price[i,j]+side*cost
                quantity=requested*((execution-cap)*side<=0)
                rb[i,j]+=np.maximum(requested-quantity,0);rs[i,j]+=np.maximum(quantity-requested,0)
                q[i,j]+=quantity;cash[i]-=quantity*execution;fees[i]+=np.abs(quantity)*cost
                fills[i]+=quantity!=0
                # Diagnostic only; realized future truth never chooses an order.
                adverse_gross[i]+=(quantity*(data['settlement_truth'][ids[i],j]-execution)<-1e-8)
            assert np.all(q+pp+rb<=LIMITS) and np.all(q-pn-rs>=-LIMITS)
            if t+delay>=390 or (r==2 and t>=370):continue
            fee=price*cost_bps/10000+.02
            buy=lower[ids,r,t]-price-fee
            sell=price-upper[ids,r,t]-fee
            side=np.where(buy>sell,1,-1)
            edge=np.maximum(buy,sell)
            room=np.where(side>0,LIMITS-q-pp-rb,LIMITS+q-pn-rs)
            quantity=np.minimum(depth,np.maximum(room,0))
            ranking=np.argsort(-edge*quantity,axis=1)
            for k in range(12):
                j=ranking[:,k];ok=(used<60)&(edge[row,j]>0)&(quantity[row,j]>0)
                i=np.where(ok)[0];qty=quantity[i,j[i]]*side[i,j[i]]
                cap=np.where(qty>0,lower[ids[i],r,t,j[i]],upper[ids[i],r,t,j[i]])
                queue[t+delay].append((i,j[i],qty,cap))
                pp[i,j[i]]+=np.maximum(qty,0);pn[i,j[i]]+=np.maximum(-qty,0)
                used[i]+=1;hist[i,t%30]+=1;actions[i]+=1
            maxwindow=np.maximum(maxwindow,used)
        assert np.all(pp+pn==0)
    pnl=cash+(q*data['settlement_truth'][ids]).sum(1)
    return {'pnl':pnl,'actions':actions,'cost':fees,'positions':q,'fills':fills,
            'adverse_terminal_fills':adverse_gross,'max_rolling_actions':maxwindow}


def main():
    d=load_development();fit,tune,val=masks(d);out=Path(__file__).parent
    e,buffer=fit_economics(d,fit)
    rows=[];best=0.;choice=None
    for extra in [.1,.3]:
        lower,upper=intervals(d,e,buffer,extra)
        result=simulate(d,np.flatnonzero(tune),lower,upper)
        row={'extra':extra,**summarize_pnl(result['pnl']),'fills':int(result['fills'].sum()),
             'adverse_terminal_fills':int(result['adverse_terminal_fills'].sum())}
        rows.append(row)
        if row['mean_usd']>best:best=row['mean_usd'];choice=extra
    pd.DataFrame(rows).to_csv(out/'bounds_inner_candidates.csv',index=False)
    dump_json(out/'bounds_frozen.json',{'extra':choice,'inner_mean_usd':best,'zero_trade_retained':True})
    if choice is None:
        print('Economic bounds rejected',rows);return
    e,buffer=fit_economics(d,fit|tune)
    lower,upper=intervals(d,e,buffer,choice)
    ids=np.flatnonzero(val);result=simulate(d,ids,lower,upper)
    metrics={'base':summarize_pnl(result['pnl']),'fills':int(result['fills'].sum()),
             'adverse_terminal_fills':int(result['adverse_terminal_fills'].sum()),
             'max_rolling_actions':int(result['max_rolling_actions'].max()),'buffer':buffer.tolist()}
    for name,kw in [('50bps',{'cost_bps':50}),('8s',{'latency':8}),('25shares',{'depth':25})]:
        metrics[name]=summarize_pnl(simulate(d,ids,lower,upper,**kw)['pnl'])
    dump_json(out/'bounds_validation.json',metrics)
    pd.DataFrame({'season':d['season_ids'][val],'pnl':result['pnl'],'fills':result['fills'],
                  'adverse_terminal_fills':result['adverse_terminal_fills']}).to_csv(out/'bounds_validation_seasons.csv',index=False)
    print(rows,metrics)


if __name__=='__main__':main()
