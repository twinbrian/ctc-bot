import numpy as np

from shared_account import shifted_history,simulate_account


def fixture():
    from common import with_etfs
    market=np.full((1,3,390,10),100.)
    market[:,:,32:]=105
    market=with_etfs(market)
    truth=market[:,2,-1].copy()
    delta=np.zeros((1,3,78,12))
    curve=market[0].copy()
    return market,truth,curve,delta,truth


def test_round_gap_never_invents_extra_rate_capacity():
    history=np.arange(30)[None,:]
    np.testing.assert_array_equal(shifted_history(history,0),history)
    np.testing.assert_array_equal(shifted_history(history,1),history)
    np.testing.assert_array_equal(shifted_history(history,2)[0,:29],np.arange(1,30))
    assert shifted_history(history,60).sum()==0


def test_contiguous_rounds_obey_actual_combined_budget():
    args=list(fixture())
    args[3][:]=20
    result=simulate_account(*args,route_config={'start':0,'exit_at':70,'fraction':1.},
                            tail_top_k=8,handoff='ready',round_gap_seconds=0)
    assert result['max_rolling_actions'].max()<=60
    flat=result['action_ticks'].reshape(1,-1)
    assert np.convolve(flat[0],np.ones(30),mode='full').max()<=60
    np.testing.assert_allclose(result['by_engine'].sum(1),result['pnl'])


def test_ready_handoff_requires_flat_inventory_and_depth_cooldown():
    args=fixture()
    result=simulate_account(*args,handoff='ready',replenish_seconds=10)
    assert np.all(result['tail_ready_times']>=result['formation_flat_times']+10)


def test_old_handoff_keeps_full_minute_separation():
    result=simulate_account(*fixture(),handoff='wait60')
    assert np.all(result['tail_ready_times']>=result['formation_flat_times']+60)
