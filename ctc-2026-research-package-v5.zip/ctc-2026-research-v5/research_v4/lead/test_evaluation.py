import numpy as np
import pytest

from evaluation import assert_disjoint, freeze, max_statistic_check, paired_comparison


def test_pairing_and_difference_are_preserved():
    baseline = np.arange(120.)*100
    result = paired_comparison(baseline+50, baseline, draws=100)
    assert result["mean_difference_usd"] == 50
    assert result["conditional_mean_difference_ci95_usd"] == [50, 50]


def test_train_test_overlap_is_rejected():
    with pytest.raises(ValueError):
        assert_disjoint([1, 2, 3], [3, 4])


def test_frozen_configuration_cannot_be_retuned(tmp_path):
    path = tmp_path/"frozen.json"
    freeze(path, {"k": 20}, [1, 2], [3], [4], "test")
    with pytest.raises(ValueError):
        freeze(path, {"k": 40}, [1, 2], [3], [4], "test")


def test_negative_candidates_do_not_pass_one_sided_family_check():
    x = np.full((120, 4), -50.)
    result = max_statistic_check(x, draws=100)
    assert result["family_pvalue"] == 1


def test_cross_candidate_dependence_is_not_counted_as_extra_seasons():
    rng = np.random.default_rng(42)
    x = rng.normal(size=120)
    x -= x.mean()
    one = max_statistic_check(x[:,None], draws=500)
    duplicated = max_statistic_check(np.tile(x[:,None], (1, 20)), draws=500)
    assert one["family_pvalue"] == duplicated["family_pvalue"]
