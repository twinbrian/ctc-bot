# Parameter-free shared-budget handoff

The v3 route engine flattens and then waits a whole minute before later signals
can trade. That was a conservative way to avoid double-spending a rate limit,
not an economic necessity. Hypothesis: expose the actual preceding route action
history to the later engine, and allow it to start after flattening plus one
depth-replenishment interval whenever real remaining action capacity permits.

Exactly one new policy; no model or threshold search. Fixed v3 chronological
configuration: formation start20, earliest exit100, full fraction; later top5,
10s forecast grid, zero extra cushion; final-report margin0. Compare old60s wait
versus new depth-cooldown handoff using the same predictors and fills. Fit the
unchanged160-iteration15-leaf predictor on361..600 for inner241..360. If mean
increment is positive, freeze the algorithm and refit/reuse241..600 predictors
for one validation121..240 pass. No outcomes1..120.

The route must be truly flat with no pending orders. No route action may occur
after the later-engine readiness time. Inject actual route action counts into
the shared rolling window; later-engine exits retain action reservations.
Combined market-depth/position budgets cannot overlap. Exclude canceled or
unfilled inventory credit. Reproduce the old60s-control exactly before judging
the challenger. Report same-signal incremental PnL and execution stresses; no
claim of a new forecasting signal or fresh-holdout evidence.
