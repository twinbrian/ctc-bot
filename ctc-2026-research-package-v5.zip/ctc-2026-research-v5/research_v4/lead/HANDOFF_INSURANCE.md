# Insurance analog distribution — rejected on inner development

The 12 predeclared variants did not beat zero trading on seasons241–360. The best
was guidance+k20 with full forecast weight: mean net PnL **USD -18.39**, median
USD -30.80, 38.3% profitable seasons; its conditional 95% mean interval spanned
approximately USD -224 to USD 188. Most variants were substantially worse.

No final validation seasons121–240 were opened for this hypothesis. It is not a
promotion candidate and should not be mixed into the incumbent. The likely
limitation is forecast precision: the current market already incorporates useful
information about the current path, while nonparametric damage analogs remain
noisy and the insurer payoff is nonlinear. This result does not prove the house
correctly prices every layer state; it rejects this specific bounded model family.

Reproduce: `OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 python
research_v4/lead/insurance_analogs.py`. The registered plan, all12 inner results and
the zero-trade frozen choice are in this directory. There was no model tuning after
looking at the rejection.
