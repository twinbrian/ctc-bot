"""Sequential flat phases sharing one continuous real-time action ledger.

Each round's route is simulated with the previous round's actual late actions.
The tail then receives both that prior history and the current route actions.
Positions/pending orders are proven flat at handover, never reset to create room.
Conservative default is zero inter-round pause; a measured pause is explicit.
"""

import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT.parent))
from etf_route_v3 import simulate_routes
from pnl_v2_simulator import simulate
from train import TIMES


def shifted_history(counts, gap_seconds):
    if not np.isfinite(gap_seconds) or gap_seconds < 0:
        raise ValueError("round gap must be finite and nonnegative")
    # Floor means a fractional quote interval never grants extra capacity.
    gap = max(0, int(gap_seconds // 2))
    if gap >= 30:
        return np.zeros_like(counts)
    if not gap:
        return counts.copy()
    return np.concatenate(
        [counts[:, gap:], np.zeros((len(counts), gap), dtype=int)], axis=1
    )


def simulate_account(
    market,
    truth,
    curve,
    delta,
    final_fair,
    *,
    route_config=None,
    handoff="ready",
    round_gap_seconds=0,
    tail_top_k=5,
    cost_bps=25,
    fixed_cost=0.02,
    latency=2,
    depth=50,
    adverse_bps=0.0,
    replenish_seconds=2,
):
    if handoff not in ["ready", "wait60"]:
        raise ValueError(handoff)
    if not np.isfinite(round_gap_seconds) or round_gap_seconds < 0:
        raise ValueError("round gap must be finite and nonnegative")
    if route_config is None:
        route_config = {"start": 20, "exit_at": 100, "fraction": 1.0}
    n = len(market)
    prior = np.zeros((n, 30), dtype=int)
    counts = np.zeros((n, 3, 390), dtype=int)
    pnl = np.zeros(n)
    cost = np.zeros(n)
    actions = np.zeros(n, int)
    shares = np.zeros(n)
    attrib = np.zeros((n, 12))
    by_engine = np.zeros((n, 3))
    positions = np.zeros((n, 12), int)
    drawdown_bound = np.zeros(n)
    flat = np.zeros((n, 3), int)
    ready = np.zeros((n, 3), int)
    max_position = np.zeros(n)
    settings = dict(
        cost_bps=cost_bps,
        fixed_cost=fixed_cost,
        latency=latency,
        depth=depth,
        adverse_bps=adverse_bps,
        replenish_seconds=replenish_seconds,
        audit=True,
    )
    timeline = []
    for r in range(3):
        history = shifted_history(prior, round_gap_seconds if r else 0)
        route = simulate_routes(
            market,
            truth,
            curve,
            **route_config,
            **settings,
            round_indices=[r],
            prior_action_ticks=history,
        )
        assert np.all(route["positions"] == 0)
        flat[:, r] = route["flat_times"][:, r]
        delay = max(60, replenish_seconds) if handoff == "wait60" else replenish_seconds
        readiness = np.zeros((n, 3), int)
        readiness[:, r] = np.ceil((flat[:, r] + delay) / 10).astype(int) * 10
        ready[:, r] = readiness[:, r]
        signals = delta.copy()
        signals[:, r][TIMES[None, :] < readiness[:, r, None]] = 0
        tail = simulate(
            market,
            truth,
            signals,
            final_fair,
            curve,
            formation=None,
            ongoing={"cycle": 10, "top_k": tail_top_k, "threshold": 0},
            end_margin=0,
            external_actions=route["action_ticks"],
            readiness_times=readiness,
            round_indices=[r],
            prior_action_ticks=history,
            **settings,
        )
        if r < 2:
            assert np.all(tail["positions"] == 0)
        else:
            positions = tail["positions"]
        counts[:, r] = route["action_ticks"][:, r] + tail["action_ticks"][:, r]
        prior = counts[:, r, -30:]
        if r and round_gap_seconds:
            timeline.append(np.zeros((n, int(round_gap_seconds // 2)), dtype=int))
        timeline.append(counts[:, r])
        pnl += route["pnl"] + tail["pnl"]
        cost += route["cost"] + tail["cost"]
        shares += route["turnover_shares"] + tail["turnover_shares"]
        actions += route["actions"] + tail["actions"]
        attrib += route["attribution"] + tail["attribution"]
        by_engine[:, 0] += route["pnl"]
        by_engine += tail["by_engine"]
        max_position = np.maximum(
            max_position,
            np.maximum(route["max_position_fraction"], tail["max_position_fraction"]),
        )
        drawdown_bound += route["drawdown"] + tail["drawdown"]
    tickcounts = np.concatenate(timeline, axis=1)
    c = tickcounts.cumsum(1)
    lag = np.pad(c[:, :-30], ((0, 0), (30, 0)))
    maximum = (c - lag).max(1)
    assert maximum.max() <= 60, maximum.max()
    np.testing.assert_allclose(attrib.sum(1), pnl, atol=1e-8)
    np.testing.assert_allclose(by_engine.sum(1), pnl, atol=1e-8)
    np.testing.assert_array_equal(counts.sum((1, 2)), actions)
    return {
        "pnl": pnl,
        "positions": positions,
        "actions": actions,
        "cost": cost,
        "turnover_shares": shares,
        "attribution": attrib,
        "by_engine": by_engine,
        "max_rolling_actions": maximum,
        "max_position_fraction": max_position,
        "action_ticks": counts,
        "formation_flat_times": flat,
        "tail_ready_times": ready,
        "drawdown_upper_bound": drawdown_bound,
        "round_gap_seconds": round_gap_seconds,
    }
