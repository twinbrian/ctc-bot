import numpy as np

from economic_bounds import intervals, simulate


def test_limits_and_fee_accounting_for_true_lower_bound():
    from common import LIMITS
    data={'market':np.full((1,3,390,12),100.),'settlement_truth':np.full((1,12),110.)}
    lower=np.full((1,3,390,12),110.)
    upper=np.full_like(lower,120.)
    result=simulate(data,np.array([0]),lower,upper,cost_bps=0)
    np.testing.assert_array_equal(result['positions'][0],LIMITS)
    np.testing.assert_allclose(result['pnl'],LIMITS.sum()*(10-.02))
    assert result['adverse_terminal_fills'][0]==0
    assert result['max_rolling_actions'][0]<=60


def test_arrival_price_that_crosses_limit_gets_no_fill():
    data={'market':np.full((1,3,390,12),120.),'settlement_truth':np.full((1,12),110.)}
    data['market'][:,0,0]=100
    lower=np.full((1,3,390,12),110.)
    upper=np.full_like(lower,130.)
    result=simulate(data,np.array([0]),lower,upper,cost_bps=0)
    assert result['fills'][0]==0
    assert result['pnl'][0]==0


def test_no_trading_inside_interval():
    data={'market':np.full((1,3,390,12),100.),'settlement_truth':np.full((1,12),100.)}
    lower=np.full((1,3,390,12),90.)
    upper=np.full_like(lower,110.)
    result=simulate(data,np.array([0]),lower,upper)
    assert result['actions'][0]==0


def test_preliminary_damage_does_not_tighten_bounds():
    from models import StructuralModel
    e=StructuralModel()
    e.physical=[np.array([100,-55,-2.4]),np.array([60,-38]),np.array([35,-20]),np.array([50,-24,-6]),np.array([25,-5,-7.2])]
    e.rebuild=[np.array([40,24,.9,.7,.12]),np.array([28,14,.75,.5,.20833,.58333,.1]),np.array([32,18,1])]
    e.insurers=[np.array([75,.06,400,900]),np.array([90,.035,1300])]
    e.insured_weights=np.array([900,600,250,700,120])
    data={'market':np.full((1,3,390,12),100.),'obs':np.zeros((1,3,241,6)),
          'damage':np.zeros((1,3,390,5)),'loss':np.zeros((1,3,390)),
          'stage':np.zeros((1,3,390),dtype=int),'site_xy':np.zeros((17,2)),
          'site_weight':np.full(17,1/17),'site_company':np.array([0]+[1]*3+[2]*4+[3]*5+[4]*4)}
    data['obs'][...,4]=1
    a=intervals(data,e,np.zeros(12),.1)
    data['stage'][:,2,285:370]=1
    data['damage'][:,2,285:370]=.99
    data['loss'][:,2,285:370]=2000
    b=intervals(data,e,np.zeros(12),.1)
    np.testing.assert_array_equal(a[0],b[0])
    np.testing.assert_array_equal(a[1],b[1])
