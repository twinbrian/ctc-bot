# Budgeted research phase v4

User authorization: continue searching for better trading signals and expected
net-terminal-PnL strategies, without overfitting. Parallel agents are authorized.
All work stays under `/tmp/opencode/ctc-research`; no Ramp repository changes,
branches, commits, deployments, external trades or paid external services.

## Budget and checkpoint

- Phase start: 2026-10-19 05:25:00 UTC.
- Hard deadline: 2026-10-19 10:25:00 UTC (five hours).
- Additional reported-model-cost ceiling: USD 350. Start-of-phase OpenCode daily
  reported model cost: USD 40.972237. This is estimated model usage, not an invoice.
- Lead monitors the cumulative counter, avoids new delegation after USD 220
  additional usage, and targets completion by USD 300, retaining a USD 50 buffer.
- Initial wave: four independent research agents, no child delegation, roughly
  45–60 minutes per track. Further work depends on evidence and remaining budget.

## Non-negotiable evaluation rules

The entire 600-season dataset has already informed earlier research. There is no
fresh global holdout. Do not call new results fresh/unbiased out-of-sample proof.

Agents receive only `development.npz` (original season IDs 121–600). It has 480
rows, in increasing season-ID order, with explicit `season_ids`. Do not load the
full parent `cache.npz`, raw seasons 1–120, old outer-result files, or any parent
file containing outcomes for seasons 1–120. All three storms of a season stay in
the same partition. Never fit on individual ticks randomly split across seasons.

Use these roles:

1. **Fit:** seasons 361–600, 240 seasons.
2. **Inner tune:** seasons 241–360, 120 seasons. Declare a hypothesis and a finite
   candidate grid in a `PLAN.md` before evaluating it. Prefer <=12 configurations;
   at most 24 for a genuinely distinct family. Log every tried configuration.
3. **Validation:** seasons 121–240, 120 seasons. After fixing a candidate and its
   hyperparameters, refit its forecast model on seasons 241–600 and evaluate here
   once. Save frozen configuration before opening results. Do not tune further on
   this validation result; record failure honestly and report it.
4. The lead owns any retrospective cross-fitting/outer audit and combined-policy
   evaluation. Return at most two fixed candidates per track with a clear reason.

Dates, season IDs, storm names, true pattern, true erratic-transition time and
future reports/paths/settlements are never trading features. Ground truth is a
training label or diagnostic only. Measured future prices are labels and fill
outcomes, never order-decision inputs. Previous rounds' published final reports
are valid inputs. Track/forecast information must respect publication times.

## Common economic/exchange contract

- Objective: arithmetic mean of realized cash plus final-settlement inventory,
  after modeled transaction costs. No Sharpe or win-rate objective replaces PnL.
- Baseline: 25 bps plus USD 0.02/share/side; two-second decision-to-arrival latency;
  at most 50 executable market shares/symbol/two-second interval; one key's 60
  actions/rolling real minute. The 180/team limit is not permission to invent keys.
- Same published per-symbol position limits. Resting and pending orders reserve
  capacity. ETF conversions consume one action, have zero net cash and no fee,
  transform all legs atomically after latency, and must respect every interim limit.
- Data are house consensus marks, not executable books. No passive-fill credit,
  unlimited size, zero-latency fills, hindsight direction, risk-free fills at marks,
  or uncharged repeated conversion/hedging legs. Report capacity as an assumption.
- Initial stock positions are zero, inventory carries between rounds unless the
  strategy actually closes it, and settlement occurs only at the end of round 3.
- Distinguish real seconds from the 30x market clock. Each round has 390 two-second
  quotes; storm starts t=60, ends t=540; preliminary report t=570; final t=740;
  last quote t=778. Official advisories start t=90, then every 60 real seconds.

## Existing findings (context, not new experiments)

- Completed v3 uses ETF conversions to route formation exposure. Reported mean
  terminal PnL was approximately USD 11,101 over five post-selection outer folds;
  this is hypothetical-fill performance and not a fresh holdout.
- Large, repeatable price response at storm formation: stocks start repricing
  about +4s; ETFs about +10s. Existing strategy pre-positions before formation.
- A Gaussian `I*exp(-(d/r)^2)` with a hard 2r support matches PORT zero-versus-
  positive damage across 1,800 storms. Severity is still uncertain. Closure
  threshold is approximately 0.35, a different boundary.
- Settlement economics are identified well after final reports. See
  `../REPORT.md` sections 3–4 for formulas. HAVEN attachment/exhaustion approximately
  USD 400/1,300 million; REIN attachment USD 1,300 million, upper cap unidentified.
- Previous generic full-path aftermath regressions did not beat house marks enough
  to cover costs. Repeating this without a new hypothesis is low priority.

## Files and interfaces

- Read-only source in parent directory: `common.py`, `models.py`, `prepare.py`,
  `pnl_v2_simulator.py`, `etf_route_v3.py`, `short_horizon.py`, `endgame.py`.
- `development.npz`: season-subset cache with market `[480,3,390,12]`, storm obs
  `[480,3,241,6]` (`x,y,vx,vy,radius,intensity`; valid observations through index239),
  current public report/advisory feature cubes, and separately named label arrays.
  Static `site_xy`, `site_weight`, `site_company` are unchanged.
- `reference.npz`: v1 short-model deltas and final-report fair values for development
  seasons only. These are trained on seasons 241–600; do not use their in-sample
  rows as honest training-fold validation evidence.
- `common.py` has the symbol ordering, baskets and limits. Its old `partitions()`
  assumes 600 rows: use explicit IDs for this subset instead.
- Each track owns only its assigned subdirectory. Do not modify shared code or
  sibling work. Copy/adapt a simulator locally if necessary; explain changes.
- Keep CPU use to at most two worker processes and set OMP/BLAS threads to one.
- Output: `PLAN.md`, readable code, all candidate metrics, a frozen config,
  season-level validation PnL and an end-of-track `HANDOFF.md`. Record negative
  results, assumptions, source of alpha, compatibility/conflict with v3, and exact
  reproduction commands. Do not publish artifacts; the lead will review/package.

The strongest candidate is one that explains a new economic effect, survives
small parameter perturbations and realistic execution stress, and adds incremental
PnL in a shared account. A larger standalone backtest number is not enough.
