"""Focused accounting, capacity, split, and prefix-causality checks."""

import json
from pathlib import Path

import numpy as np

from event_model import PUBLIC_KEYS, STATIC_KEYS, event_rows
from event_simulator import simulate


def run():
    market = np.full((1, 3, 390, 12), 100.0)
    market[0, 0, 61:66, 0] = 99
    market[0, 0, 66:, 0] = 90
    pred = {"delta": np.zeros_like(market), "source": np.zeros((1,3,390), dtype=int),
            "regime": np.ones((1,3,390), dtype=int), "regime_names": ["test"], "horizon": 10}
    pred["source"][0,0,60] = 1
    pred["delta"][0,0,60,0] = -20
    result = simulate(market, pred, top_k=1, capture_trades=True)
    expected = 50*(99-90)-50*((99+90)*.0025+.04)
    assert np.isclose(result["pnl"][0], expected)
    assert result["actions"][0] == 2 and result["positions"].sum() == 0
    assert result["trades"][0]["entry_time"] == 122
    assert result["trades"][0]["exit_time"] == 132
    smaller = simulate(market, pred, top_k=1, depth=25)
    assert np.isclose(smaller["pnl"][0], expected/2)
    # Deliberate saturation: every tick fires, all symbols attractive. The
    # reserve invariant must prevent orphaned inventory at the action cap.
    crowded = {**pred, "delta": np.full_like(market, 20),
               "source": np.zeros((1,3,390), dtype=int), "horizon": 6}
    crowded["source"][:, :, 60:251] = 2
    stress = simulate(np.full_like(market, 100), crowded, latency=6)
    assert stress["max_rolling_actions"][0] <= 60
    assert stress["blocked_entries"][0] > 0
    assert not stress["positions"].any()
    assert np.isclose(stress["pnl"][0], -stress["cost"][0])
    # Only a fit-season public prefix is used for causality tests.
    data = np.load(Path(__file__).resolve().parent.parent / "development.npz", allow_pickle=False)
    fit_index = int(np.where(data["season_ids"] == 361)[0][0])
    base = {k: data[k][fit_index:fit_index+1].copy() for k in PUBLIC_KEYS}
    base.update({k: data[k].copy() for k in STATIC_KEYS})
    checks = []
    for family, cutoff in [("news", 210), ("motion", 220), ("report", 570)]:
        before = event_rows(base, [0], family)
        mutated = {k: v.copy() for k,v in base.items()}
        ti = cutoff//2
        for k in PUBLIC_KEYS:
            if k == "obs":
                oi = min(239, (cutoff-60)//2)
                mutated[k][:,0,oi+1:] *= 1.5
            elif k in ("official", "wire"):
                mutated[k][:,0,ti+1:] = 5
            elif k == "stage":
                mutated[k][:,0,ti+1:] = 2
            else:
                mutated[k][:,0,ti+1:] *= 1.5
        after = event_rows(mutated, [0], family)
        a = (before["ri"] == 0) & (before["time"] <= cutoff)
        b = (after["ri"] == 0) & (after["time"] <= cutoff)
        assert np.array_equal(before["time"][a], after["time"][b])
        assert np.allclose(before["x"][a], after["x"][b])
        checks.append({"family": family, "cutoff": cutoff, "rows_unchanged": int(a.sum())})
    result = {"short_two_leg_arrival_price_pnl": expected,
              "crowded_max_actions": int(stress["max_rolling_actions"][0]),
              "crowded_blocked_entries": int(stress["blocked_entries"][0]),
              "prefix_causality": checks, "status": "passed"}
    Path("audit.json").write_text(json.dumps(result, indent=2)+"\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    run()
