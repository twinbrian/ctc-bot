# Recorded event-study results

## Entire inner grid

| Family | Horizon | Mean net | SE | Clock/price control | Increment | Combined stress | Trades/season | Qualifies |
|---|---:|---:|---:|---:|---:|---:|---:|---|
| news | 6 | 184.62 | 36.85 | 151.82 | 32.80 | -691.20 | 7.8 | False |
| news | 10 | 213.87 | 52.75 | 130.63 | 83.24 | -881.14 | 12.3 | False |
| news | 30 | 443.66 | 75.42 | 217.13 | 226.53 | -865.23 | 23.4 | False |
| news | 60 | 979.24 | 114.35 | 520.62 | 458.62 | -594.20 | 31.4 | False |
| motion | 6 | 713.13 | 66.07 | 599.84 | 113.29 | -1749.65 | 17.1 | False |
| motion | 10 | 644.82 | 70.27 | 437.31 | 207.51 | -1867.76 | 19.4 | False |
| motion | 30 | 1036.19 | 97.36 | 650.20 | 385.99 | -1439.25 | 30.7 | False |
| motion | 60 | 1482.44 | 131.93 | 715.10 | 767.34 | -946.12 | 41.5 | False |
| report | 6 | 326.09 | 30.29 | -49.97 | 376.05 | -273.66 | 8.4 | False |
| report | 10 | 409.60 | 44.30 | -62.51 | 472.10 | -231.44 | 8.5 | False |
| report | 30 | 408.47 | 44.99 | -62.75 | 471.22 | -235.98 | 8.5 | False |
| report | 60 | 169.39 | 21.88 | -15.87 | 185.26 | -96.78 | 3.6 | False |

## Frozen one-time validation

| Candidate | Scenario | Mean net | SE | Median | Min | Gross | Cost | Actions | Worst drawdown |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| motion_h60 | base | 1595.08 | 146.16 | 1551.39 | -2566.96 | 2807.30 | 1212.22 | 80.3 | 4249.69 |
| motion_h60 | latency6 | 886.31 | 147.39 | 883.40 | -4278.66 | 2097.80 | 1211.50 | 80.3 | 5587.12 |
| motion_h60 | double_cost | 382.86 | 139.65 | 309.81 | -3961.06 | 2807.30 | 2424.44 | 80.3 | 5347.39 |
| motion_h60 | depth25 | 797.54 | 73.08 | 775.69 | -1283.48 | 1403.65 | 606.11 | 80.3 | 2124.85 |
| motion_h60 | combined | -777.67 | 142.93 | -730.37 | -6476.59 | 2097.80 | 2875.48 | 80.3 | 7217.60 |

## Validation attribution

Time buckets are [120,210), [210,330), [330,450), [450,540), preliminary at570, final at740.

### motion_h60

Clock/price-only control: $849.58/season; paired increment $745.50, SE $118.29.
Time-bucket means: [175.24, 559.3, 820.24, 40.3, 0.0, 0.0].
Round means: [574.52, 557.96, 462.6].
Sources: {"official": 0.0, "wire": 0.0, "motion": 1595.08, "preliminary": 0.0, "final": 0.0}.
Symbols: {"PORT": 205.22, "ISLE": 31.92, "AQUA": 24.39, "GRID": 40.93, "FERRY": 20.08, "RECON": 22.18, "MAT": 3.16, "GEN": 8.54, "HAVEN": 309.46, "REIN": 0.0, "ARCH": 785.88, "REBLD": 143.32}.
Regimes: {'risk_only': 1018.77, 'velocity_shock': 576.3}.
Maximum rolling actions: 15; maximum symbol-limit fraction: 1.00.

## Inner-only, non-selectable parameter neighbors

| Candidate | Parameter | Value | Mean net |
|---|---|---:|---:|
| motion_h60 | alpha | 0.01 | 1495.15 |
| motion_h60 | alpha | 0.04 | 1495.21 |
| motion_h60 | margin | 0.05 | 1421.43 |
| motion_h60 | margin | 0.25 | 1558.15 |
