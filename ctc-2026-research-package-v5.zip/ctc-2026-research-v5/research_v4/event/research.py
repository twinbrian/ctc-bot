"""Reproducible preregistered inner search, freeze, then one validation pass."""

import argparse
import csv
import hashlib
import json
import os
import pickle
from datetime import datetime, timezone
from pathlib import Path

os.environ["OMP_NUM_THREADS"] = "1"
os.environ["OPENBLAS_NUM_THREADS"] = "1"

import numpy as np

from event_model import SOURCE_NAMES, SYMBOLS, event_rows, fit_from_rows
from event_simulator import SCENARIOS, simulate, summarize

ROOT = Path(__file__).resolve().parent
DATA_PATH = ROOT.parent / "development.npz"
GRID = [{"family": f, "horizon": h, "alpha": .02, "margin": .15, "top_k": 2}
        for f in ("news", "motion", "report") for h in (6, 10, 30, 60)]


def stamp():
    return datetime.now(timezone.utc).isoformat()


def name(config):
    return f"{config['family']}_h{config['horizon']}"


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, allow_nan=False)+"\n")


def write_csv(path, records):
    path.parent.mkdir(parents=True, exist_ok=True)
    if not records:
        path.write_text("")
        return
    with path.open("w", newline="") as f:
        writer = csv.DictWriter(f, list(records[0]))
        writer.writeheader()
        writer.writerows(records)


def season_records(result, season_ids, candidate, scenario):
    records = []
    for i, sid in enumerate(season_ids):
        rec = {"season_id": int(sid), "candidate": candidate, "scenario": scenario}
        for key in ("pnl", "cost", "turnover_shares", "actions", "trades_count", "drawdown",
                    "max_rolling_actions", "max_position_fraction", "blocked_entries"):
            rec[key] = float(result[key][i])
        rec.update({s+"_pnl": float(result["attribution"][i,j]) for j,s in enumerate(SYMBOLS)})
        records.append(rec)
    return records


def save_result(path, result, season_ids):
    np.savez_compressed(path, season_ids=season_ids,
                        **{k: v for k,v in result.items() if k != "trades"})


def evaluate(market, pred, config, directory, season_ids, *, all_stress=True,
             capture_trades=False):
    results = {}
    records = []
    for scenario, kw in (SCENARIOS if all_stress else {"base": {}}).items():
        result = simulate(market, pred, margin=config["margin"], top_k=config["top_k"],
                          capture_trades=capture_trades and scenario == "base", **kw)
        results[scenario] = summarize(result)
        records += season_records(result, season_ids, name(config), scenario)
        if directory is not None:
            directory.mkdir(parents=True, exist_ok=True)
            save_result(directory / f"{scenario}.npz", result, season_ids)
            if capture_trades and scenario == "base":
                for trade in result["trades"]:
                    trade["season_id"] = int(season_ids[trade["season_index"]])
                write_csv(directory / "trades.csv", result["trades"])
        print(name(config), scenario, f"mean={results[scenario]['mean_pnl']:.3f}",
              f"trades={results[scenario]['mean_trades']:.2f}", flush=True)
    if directory is not None:
        write_json(directory / "metrics.json", results)
        write_csv(directory / "seasons.csv", records)
    return results, records


def inner():
    out = ROOT / "inner"
    if (out / "complete.json").exists():
        raise RuntimeError("Inner search already complete; preserve recorded attempts")
    data = np.load(DATA_PATH, allow_pickle=False)
    ids = data["season_ids"]
    fit_ids = np.where(ids >= 361)[0]
    tune_ids = np.where((ids >= 241) & (ids <= 360))[0]
    assert len(fit_ids) == 240 and len(tune_ids) == 120
    all_metrics = []
    all_seasons = []
    for family in ("news", "motion", "report"):
        print("Building", family, "public features", stamp(), flush=True)
        train = event_rows(data, fit_ids, family)
        tune = event_rows(data, tune_ids, family)
        for config in [c for c in GRID if c["family"] == family]:
            directory = out / name(config)
            directory.mkdir(parents=True, exist_ok=True)
            print("Fitting", name(config), stamp(), flush=True)
            prediction = fit_from_rows(train, tune, config)
            control = fit_from_rows(train, tune, config, control=True)
            write_json(directory / "predictive.json", {
                "full": prediction["predictive_metrics"],
                "clock_price_control": control["predictive_metrics"]})
            write_json(directory / "feature_names.json", prediction["feature_names"])
            np.savez_compressed(directory / "prediction.npz", delta=prediction["delta"],
                                source=prediction["source"], regime=prediction["regime"],
                                times=prediction["times"])
            with (directory / "models.pkl").open("wb") as f:
                pickle.dump(prediction["models"], f)
            metrics, seasons = evaluate(tune["market"], prediction, config, directory,
                                        ids[tune_ids], capture_trades=True)
            control_metrics, control_seasons = evaluate(
                tune["market"], control, config, directory / "control", ids[tune_ids],
                all_stress=False)
            full_pnl = np.load(directory / "base.npz")["pnl"]
            control_pnl = np.load(directory / "control" / "base.npz")["pnl"]
            paired = full_pnl-control_pnl
            record = {"config": config, "metrics": metrics,
                      "control": control_metrics,
                      "incremental_mean": float(paired.mean()),
                      "incremental_se": float(paired.std(ddof=1)/np.sqrt(len(paired))),
                      "predictive": prediction["predictive_metrics"],
                      "regime_names": prediction["regime_names"]}
            record["qualifies"] = bool(metrics["base"]["mean_pnl"] > 0 and
                                        paired.mean() > 0 and
                                        metrics["combined"]["mean_pnl"] >= 0)
            all_metrics.append(record)
            all_seasons += seasons
            all_seasons += [{**r, "candidate": r["candidate"]+"_control"} for r in control_seasons]
            write_json(out / "all_metrics.json", all_metrics)
            write_csv(out / "all_seasons.csv", all_seasons)
    write_json(out / "complete.json", {"finished": stamp(), "n_candidates": len(all_metrics)})


def freeze():
    if (ROOT / "frozen.json").exists():
        raise RuntimeError("Already frozen")
    all_metrics = json.loads((ROOT / "inner" / "all_metrics.json").read_text())
    assert len(all_metrics) == len(GRID)
    ordered = sorted(all_metrics, key=lambda r: r["metrics"]["base"]["mean_pnl"], reverse=True)
    eligible = [r for r in ordered if r["qualifies"]]
    selected = []
    for r in eligible:
        if all(s["config"]["family"] != r["config"]["family"] for s in selected):
            selected.append(r)
        if len(selected) == 2:
            break
    if not selected:
        selected = ordered[:1]
    write_json(ROOT / "frozen.json", {
        "frozen_at": stamp(), "plan_sha256": hashlib.sha256((ROOT / "PLAN.md").read_bytes()).hexdigest(),
        "status": "eligible_for_validation" if eligible else "negative_result_only",
        "selection_rule": "positive base and paired increment, nonnegative combined stress; best mean per distinct family; max2",
        "fit_seasons": [241, 600], "validation_seasons": [121, 240],
        "execution_scenarios": SCENARIOS,
        "candidates": [{"id": name(r["config"]), "config": r["config"],
                        "inner_qualifies": r["qualifies"],
                        "inner_mean": r["metrics"]["base"]["mean_pnl"],
                        "inner_incremental_mean": r["incremental_mean"],
                        "inner_combined_mean": r["metrics"]["combined"]["mean_pnl"]}
                       for r in selected]})
    print((ROOT / "frozen.json").read_text(), flush=True)


def sensitivity():
    """Prespecified diagnostic neighbors; cannot replace a frozen candidate."""
    frozen = json.loads((ROOT / "frozen.json").read_text())
    out = ROOT / "sensitivity"
    if (out / "metrics.json").exists():
        raise RuntimeError("Sensitivity already complete")
    data = np.load(DATA_PATH, allow_pickle=False)
    ids = data["season_ids"]
    fit_ids, tune_ids = np.where(ids >= 361)[0], np.where((ids >= 241) & (ids <= 360))[0]
    metrics = []
    for candidate in frozen["candidates"]:
        config = candidate["config"]
        train = event_rows(data, fit_ids, config["family"])
        tune = event_rows(data, tune_ids, config["family"])
        for parameter, values in (("alpha", [.01, .04]), ("margin", [.05, .25])):
            for value in values:
                perturbed = {**config, parameter: value}
                pred = fit_from_rows(train, tune, perturbed)
                label = name(config)+f"_{parameter}{value}"
                result, _ = evaluate(tune["market"], pred, perturbed, out / label,
                                     ids[tune_ids], all_stress=False)
                metrics.append({"candidate": candidate["id"], "parameter": parameter,
                                "value": value, "metrics": result})
    write_json(out / "metrics.json", metrics)


def validation():
    frozen = json.loads((ROOT / "frozen.json").read_text())
    out = ROOT / "validation"
    if (out / "STARTED.json").exists():
        raise RuntimeError("Validation already opened. Do not adaptively rerun.")
    # Guard is persisted BEFORE loading or evaluating held-out outcomes.
    write_json(out / "STARTED.json", {"started": stamp(), "frozen_sha256":
               hashlib.sha256((ROOT / "frozen.json").read_bytes()).hexdigest()})
    data = np.load(DATA_PATH, allow_pickle=False)
    ids = data["season_ids"]
    fit_ids = np.where(ids >= 241)[0]
    eval_ids = np.where((ids >= 121) & (ids <= 240))[0]
    metrics = []
    seasons = []
    for candidate in frozen["candidates"]:
        config = candidate["config"]
        directory = out / candidate["id"]
        directory.mkdir(parents=True, exist_ok=True)
        train = event_rows(data, fit_ids, config["family"])
        evaluation = event_rows(data, eval_ids, config["family"])
        pred = fit_from_rows(train, evaluation, config)
        # Same prespecified ablation, reported without selection or retuning.
        control = fit_from_rows(train, evaluation, config, control=True)
        with (directory / "models.pkl").open("wb") as f:
            pickle.dump({"models": pred["models"], "config": config,
                         "feature_names": pred["feature_names"]}, f)
        np.savez_compressed(directory / "prediction.npz", delta=pred["delta"],
                            source=pred["source"], regime=pred["regime"], times=pred["times"])
        m, rows = evaluate(evaluation["market"], pred, config, directory, ids[eval_ids],
                           capture_trades=True)
        cm, cr = evaluate(evaluation["market"], control, config, directory / "control",
                          ids[eval_ids], all_stress=False)
        full_pnl = np.load(directory / "base.npz")["pnl"]
        control_pnl = np.load(directory / "control" / "base.npz")["pnl"]
        paired = full_pnl-control_pnl
        metrics.append({"candidate": candidate["id"], "config": config, "metrics": m,
                        "control": cm, "incremental_mean": float(paired.mean()),
                        "incremental_se": float(paired.std(ddof=1)/np.sqrt(len(paired))),
                        "predictive": pred["predictive_metrics"],
                        "control_predictive": control["predictive_metrics"],
                        "regime_names": pred["regime_names"]})
        seasons += rows
        seasons += [{**r, "candidate": r["candidate"]+"_control"} for r in cr]
    write_json(out / "all_metrics.json", metrics)
    write_csv(ROOT / "validation_per_season.csv", seasons)
    write_json(out / "COMPLETE.json", {"finished": stamp(), "n_candidates": len(metrics)})


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("command", choices=["inner", "freeze", "sensitivity", "validation"])
    args = parser.parse_args()
    globals()[args.command]()
