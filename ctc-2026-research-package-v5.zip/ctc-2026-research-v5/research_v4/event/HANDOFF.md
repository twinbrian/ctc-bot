# Event-information research handoff

## Conclusion

**There is incremental information outside formation, but no candidate passed
the preregistered combined execution-stress requirement. Do not treat this as a
deployment recommendation.** One configuration, `motion_h60`, was frozen as the
plan's negative-result fallback and evaluated on seasons 121–240 exactly once.

| Mean terminal cash PnL / season | Inner 241–360 | Validation 121–240 |
|---|---:|---:|
| Baseline: 2s latency, 25bp+$0.02 per side, 50 shares | $1,482.44 | **$1,595.08** |
| Same-event clock/price-only benchmark | $715.10 | $849.58 |
| Paired increment over benchmark | $767.34 | **$745.50** |
| 6s latency | $794.27 | $886.31 |
| 50bp+$0.04 per side | $214.85 | $382.86 |
| 25-share depth | $741.22 | $797.54 |
| 6s latency + 50bp+$0.04 + 10bp adverse/side | **−$946.12** | **−$777.67** |

Validation baseline standard error is $146.16/season; paired-increment SE is
$118.29. Approximate unadjusted 95% mean intervals are [$1,309,$1,882] and
[$514,$977], respectively. These are descriptive season-level intervals, not
selection-adjusted or fresh-holdout proof. The entire dataset informed previous
research. Worst baseline season: −$2,566.96; worst marked drawdown: $4,249.69.

No tuning followed validation. The original negative deployment status remains.
Completed well before the 06:30 UTC deadline; further search was unnecessary
given the decisive prespecified stress failure.

## Economic mechanism and attribution

On a 10-second observation grid, a substantial velocity change or change in
projected company wind exposure identifies an information event. New measured
exposure and the revised path threat help predict remaining repricing after the
two-second arrival delay. A regularized linear cross-sectional model forecasts
all twelve symbols; there is no generic fit on every quote.

Evidence against this being primarily formation carryover:

- No orders before real second 120. Validation mean PnL by **decision** time:
  120–209: $175; 210–329: $559; 330–449: $820; 450–539: $40.
  Thus $1,420, or 89%, comes from decisions at/after 210.
- Round means: $575, $558, $463. Observable `risk_only` events contribute
  $1,019, and `velocity_shock` events $576 per season.
- Symbol contributions: ARCH $786, HAVEN $309, PORT $205, REBLD $143;
  remaining eight symbols collectively $151. Shorts contribute $1,359;
  longs $237. Both legs and all fees are included.

The full-vs-price benchmark includes **public levels as well as innovations**;
the entire $745 increment cannot be attributed exclusively to changed inputs.
An inner-only, no-refit diagnostic zeroing the existing model's innovation
features raises MSE from 3.7007 to 3.7539 (1.4%). The incremental innovation
contribution is directionally useful but modest; current projected threat is
also important. See `innovation_diagnostics.json`. This is descriptive, not a
causal importance estimate or another candidate.

The large ETF latency penalty suggests delayed house adjustment is an important
part of the effect. In validation, moving arrival from 2s to 6s cuts gross PnL
from $2,807 to $2,098. Combined stress then charges $2,875, exceeding the gross
opportunity. No market-depth evidence supports more aggressive scaling.

## Other attempts and negative findings

`PLAN.md` predates scoring. The finite eligible family was three event types
(news, motion, reports) × horizons 6/10/30/60: **12 policies**, plus 12
non-selectable same-event clock/price ablations. Every eligible policy had
positive inner baseline PnL and failed combined stress. All results are retained.

- Best news result: h60, $979 baseline, $459 incremental, −$594 combined stress.
- Report h10: $410 baseline versus −$63 control, but −$231 combined stress.
  Preliminary and final publications contribute $171 and $239 respectively.
- Short-horizon motion and news profits are especially latency-sensitive.
  Motion h6 falls from $713 baseline to −$740 at 6s latency.
- News and report configurations were **not refit or validated on 121–240**.
  They are negative inner results, not additional returned candidates.
- The four preregistered, non-selectable inner neighbors for frozen motion-h60
  give $1,495/$1,495 at ridge 0.01/0.04 and $1,421/$1,558 at entry margin
  $0.05/$0.25. Frozen alpha=0.02 and margin=$0.15 were retained.

Full tables: `RESULTS.md`; machine-readable attempts: `inner/all_metrics.json`,
`inner/all_seasons.csv`, and `sensitivity/metrics.json`.

## Frozen candidate and interface

```python
from event_model import fit_predict

prediction = fit_predict(data, train_ids, eval_ids, {
    "family": "motion", "horizon": 60,
    "alpha": 0.02, "margin": 0.15, "top_k": 2,
})
```

`data` is the provided `np.load('../development.npz', allow_pickle=False)` or
equivalent dictionary. `train_ids` and `eval_ids` are **zero-based row indices
into that data**, not season numbers. With the original subset ordering:

- Initial fit: indices 240..479; inner evaluation: 120..239.
- Frozen refit: indices 120..479; validation: 0..119.

Returned interface:

- `delta`: `[len(eval_ids),3,390,12]`, valid only where `source > 0`.
- `times`: `[0,2,...,778]`, **real seconds**; `horizon=60`, `target_latency=2`.
- Forecast target: `market(t+62)-market(t+2)`, not `market(t+60)-market(t)`.
- `source`: 3 for motion; zero means no eligible event. Other studied source
  codes: official=1, wire=2, preliminary=4, final=5.
- `regime`, `regime_names`, `models`, `feature_names`, predictive metrics.
- Symbol order: PORT, ISLE, AQUA, GRID, FERRY, RECON, MAT, GEN, HAVEN, REIN,
  ARCH, REBLD.

Exact fixed feature/event settings, in addition to `frozen.json`:

1. Decision grid 120,130,...,530. Trigger if 10s velocity-change Euclidean norm
   >=1.0 map-unit/second **or** any company projected peak-wind change >=0.05
   in absolute value, across 60/120/240s physical projection windows.
2. Projection uses current measured position/velocity/radius/intensity, a fixed
   20s projection grid, and scheduled dissipation at540. The old projection is
   aligned to the same future interval using the 10s-old observation. It never
   reads a realized future path.
3. Gaussian wind is truncated at distance 2×radius; static site weights aggregate
   to companies. Measured wind exposure, peak wind, and >=0.35 outage duration
   use prefix accumulations only.
4. 221 fixed feature columns include round/time, current prices, 2/6/10/30s price
   changes, public current state, and explicit 10s physical/advisory/report
   innovations. Constant columns have zero fitted effect. No search over feature
   subsets. Source-specific linear ridge; normalized penalty0.02, training
   standardization, clipping at ±8 training standard deviations, free intercept.
5. Gate: `abs(delta) > 2*(current_price*0.0025 + 0.02) + 0.15`.
   Rank available symbols by predicted net dollars; at most two new symbols per
   event, one 50-share lot per symbol, no stacking. Gate assumptions remain at
   baseline during execution stress.
6. Enter at decision+latency; submit exit at decision+60. Baseline fills are
   therefore t+2 and t+62. Close at market, with both sides charged. No conversions.

`validation/motion_h60/models.pkl` contains the frozen 241–600 refit, config,
and feature ordering. `validation/motion_h60/prediction.npz` contains its saved
one-time validation forecasts. `event_rows` builds features independently of
labels; future marks enter training targets and predictive diagnostics only.

## Public data and availability

Only `../development.npz` was read for data. Accessed keys: market, obs, damage,
loss, stage, official, wire, probability, cone, site_xy, site_weight,
site_company, season_ids. No truth arrays, reference forecasts, original seasons
1–120, parent cache, or old outer results were used.

Advisory/report cubes are the prepared as-of publication cubes; wire events are
observed category changes, so repeat messages with unchanged categories are not
events. Official decisions start at150 here; the90-second formation-adjacent
advisory is excluded. Preliminary/final publications are at570/740. No advisory
table truth field is accessed. Observation index is `(t-60)//2`, capped at239;
previous-round final reports are available inputs. Season IDs never enter a fit.

## Execution and interaction with formation

The local simulator uses only market orders and arrival-time consensus marks
plus charged per-side expenses. It enforces published position limits, pending
reservations, <=50 shares per symbol per 2s interval, one key's rolling60 actions,
and reserved exit capacity. Each round actually closes inventory; terminal PnL
is cash with zero settlement inventory. No passive-fill or settlement shortcut.

Validation averaged 40.14 round trips and 80.28 actions per season. Maximum
rolling usage was15; no entries were action-blocked. The 50-share ARCH lot uses
its **entire position limit**, so shared inventory is the important constraint.

Baseline decision times were120–530, entries122–532, exits182–592. The signal
can coexist in time with early formation exposure only where the shared account
has available inventory and actions. Parent integration must reserve capacity for
formation exits, block conflicting pending orders, and net or reject overlapping
symbol exposure. Particularly check ARCH, HAVEN, PORT, and REBLD. Late motion
holds may cross the570 preliminary report; final-report/endgame at740 is separate.
The $1,595 standalone result **must not be added mechanically to v3 PnL**.

Consensus marks are not executable books. Capacity is an assumption; the
25-share scenario halves PnL mechanically and does not establish real capacity.
The parent owns shared-account evaluation and any retrospective outer audit.

## Reproduction, checks, and saved evidence

Working directory: `/tmp/opencode/ctc-research/project/research_v4/event`.
Dependencies: Python3 and NumPy only. All runs used OMP/OPENBLAS threads=1 and
at most two concurrent single-worker processes. Exact study commands used:

```bash
OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 python audit.py
OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 python research.py inner
OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 python research.py freeze
OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 python research.py sensitivity
OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 python research.py validation
OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 python innovation_diagnostics.py
OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 python summarize_results.py
```

The search/freeze/validation commands intentionally refuse to overwrite completed
artifacts. The validation `STARTED.json` guard was persisted before evaluation;
`COMPLETE.json` records successful completion. `frozen.json` was written first.

A non-destructive exact reproduction of the frozen **inner** baseline, runnable
with all current artifacts present:

```bash
OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 python - <<'PY'
import json
import numpy as np
from event_model import fit_predict
from event_simulator import simulate, summarize
d = np.load('../development.npz', allow_pickle=False)
s = d['season_ids']
c = json.load(open('frozen.json'))['candidates'][0]['config']
train = np.flatnonzero(s >= 361)
test = np.flatnonzero((s >= 241) & (s <= 360))
p = fit_predict(d, train, test, c)
r = simulate(d['market'][test], p, margin=c['margin'], top_k=c['top_k'])
print(summarize(r))  # mean_pnl = 1482.4449270833325
PY
```

Primary evidence:

- `validation_baseline_per_season.csv`: exactly120 rows, one per season.
- `validation_per_season.csv`: all five fixed execution scenarios plus control.
- `validation/motion_h60/trades.csv`: every baseline trade, direction, forecast,
  arrival times/prices, both-leg expenses, event regime, and realized net PnL.
- `inner/*/{base,latency6,double_cost,depth25,combined}.npz` and validation
  counterparts: season outcomes, attribution, inventories, and action ticks.
- `audit.json`: passed prefix-causality, charged short-trip arrival-price PnL,
  half-depth sizing, saturated rolling-action accounting, and flat-inventory tests.
- `provenance.json`: Python/NumPy versions and hashes of plan, core code, freeze.
- `validation_descriptive.json`, `RESULTS.md`: descriptive attribution and risk.
- `inner_run.log`, `sensitivity_run.log`, `validation_run.log`: complete logs.

All writes remained in this assigned directory. Parent sources were read-only;
there were no branches, commits, services, external trades, publication, or child agents.
