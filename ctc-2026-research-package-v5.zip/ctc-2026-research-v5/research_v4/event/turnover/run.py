"""Saved-signal execution comparison; no forecasting or model fitting occurs."""

import argparse
import csv
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

from simulator import SCENARIOS, simulate, summarize

ROOT = Path(__file__).resolve().parent
PARENT = ROOT.parent


def stamp():
    return datetime.now(timezone.utc).isoformat()


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,indent=2,allow_nan=False)+"\n")


def write_csv(path,rows):
    path.parent.mkdir(parents=True,exist_ok=True)
    if not rows:
        path.write_text("")
        return
    with path.open("w",newline="") as f:
        w = csv.DictWriter(f,list(rows[0]))
        w.writeheader(); w.writerows(rows)


def load(split):
    source = PARENT / split / "motion_h60"
    raw = np.load(source / "prediction.npz",allow_pickle=False)
    p = {k:raw[k] for k in raw.files}
    p.update(horizon=60,regime_names=["risk_only","velocity_shock"])
    data = np.load(PARENT.parent / "development.npz",allow_pickle=False)
    ids = data["season_ids"]
    mask = (ids >= 241) & (ids <= 360) if split == "inner" else (ids >= 121) & (ids <= 240)
    market = data["market"][mask]
    assert market.shape == p["delta"].shape and mask.sum() == 120
    return market,p,ids[mask],source


def compare(split,rules):
    out = ROOT / split
    market,p,ids,source = load(split)
    metrics,rows,parity = [],[],[]
    for scenario,kw in SCENARIOS.items():
        control = simulate(market,p,"control",**kw)
        archived = np.load(source / f"{scenario}.npz",allow_pickle=False)
        for key in ("pnl","cost","turnover_shares","actions","drawdown","attribution",
                    "positions","action_ticks","max_rolling_actions"):
            assert np.allclose(control[key],archived[key],rtol=0,atol=1e-8), (scenario,key)
        parity.append({"scenario": scenario,"original_control_exact": True})
        for rule in ["control"]+rules:
            result = control if rule == "control" else simulate(market,p,rule,**kw)
            summary = summarize(result)
            paired = result["pnl"]-control["pnl"]
            gross_change = result["pnl"]+result["cost"]-control["pnl"]-control["cost"]
            saving = control["cost"]-result["cost"]
            assert np.allclose(paired,gross_change+saving)
            summary.update(paired_mean=float(paired.mean()),
                           paired_se=float(paired.std(ddof=1)/np.sqrt(len(paired))),
                           gross_change=float(gross_change.mean()),cost_saving=float(saving.mean()))
            metrics.append({"rule": rule,"scenario": scenario,**summary})
            directory = out / rule
            directory.mkdir(parents=True,exist_ok=True)
            np.savez_compressed(directory / f"{scenario}.npz",season_ids=ids,
                **{k:v for k,v in result.items() if k not in ("trades","orders")})
            if scenario == "base":
                for trade in result["trades"]:
                    trade["season_id"] = int(ids[trade["season_index"]])
                write_csv(directory / "trades.csv",result["trades"])
            for i,sid in enumerate(ids):
                row = {"season_id": int(sid),"rule": rule,"scenario": scenario,
                       "pnl": float(result["pnl"][i]),"gross": float(result["pnl"][i]+result["cost"][i]),
                       "cost": float(result["cost"][i]),"actions": int(result["actions"][i]),
                       "turnover_shares": float(result["turnover_shares"][i]),
                       "round_trips": int(result["trades_count"][i]),
                       "paired_pnl": float(paired[i]),"gross_change": float(gross_change[i]),
                       "cost_saving": float(saving[i]),"drawdown": float(result["drawdown"][i]),
                       "max_rolling_actions": int(result["max_rolling_actions"][i])}
                rows.append(row)
            print(split,rule,scenario,f"mean={summary['mean_pnl']:.3f}",
                  f"increment={summary['paired_mean']:.3f}",
                  f"gross_change={summary['gross_change']:.3f}",
                  f"saving={summary['cost_saving']:.3f}",flush=True)
        write_json(out / "metrics.json",metrics)
        write_csv(out / "per_season_comparisons.csv",rows)
    write_json(out / "control_parity.json",parity)
    write_json(out / "COMPLETE.json",{"finished": stamp(),"rules": rules,
        "prediction_sha256": digest(source / "prediction.npz")})


def inner():
    if (ROOT / "inner" / "COMPLETE.json").exists():
        raise RuntimeError("Completed inner results are immutable")
    assert json.loads((ROOT / "audit.json").read_text())["status"] == "passed"
    compare("inner",["exit_retain","target_expiry"])


def freeze():
    if (ROOT / "frozen.json").exists():
        raise RuntimeError("Execution rule already frozen")
    metrics = json.loads((ROOT / "inner" / "metrics.json").read_text())
    baseline = [r for r in metrics if r["scenario"] == "base"]
    order = {"control":0,"exit_retain":1,"target_expiry":2}
    ranked = sorted(baseline,key=lambda r:(-r["mean_pnl"],order[r["rule"]]))
    selected = next(r for r in ranked if r["rule"] != "control")
    control = next(r for r in baseline if r["rule"] == "control")
    stress = next(r for r in metrics if r["rule"] == selected["rule"] and r["scenario"] == "combined")
    frozen = {"frozen_at": stamp(),"rule": selected["rule"],
        "winner_including_control": ranked[0]["rule"],
        "replacement_eligible_inner": selected["mean_pnl"] > control["mean_pnl"],
        "combined_stress_positive_inner": stress["mean_pnl"] > 0,
        "inner_mean": selected["mean_pnl"],"inner_increment": selected["paired_mean"],
        "inner_combined_mean": stress["mean_pnl"],
        "forecast": "unchanged motion_h60; reuse existing saved refit; no fitting",
        "parameters": {"horizon_seconds":60,"max_continuous_holding_seconds":120,
                       "exit_retain_freshness_seconds":10,"margin":.15,"top_k_new_risk":2},
        "scenarios": SCENARIOS,"validation_status": "post_selection_reuse_of_observed_121_240",
        "hashes": {f:digest(ROOT/f) for f in ("PLAN.md","simulator.py","run.py","audit.py")},
        "inner_predictions_sha256": digest(PARENT / "inner" / "motion_h60" / "prediction.npz")}
    write_json(ROOT / "frozen.json",frozen)
    print(json.dumps(frozen,indent=2))


def validation():
    frozen = json.loads((ROOT / "frozen.json").read_text())
    out = ROOT / "validation"
    if (out / "STARTED.json").exists():
        raise RuntimeError("Post-selection validation already opened")
    for f,h in frozen["hashes"].items():
        assert digest(ROOT/f) == h, f"Frozen source changed: {f}"
    write_json(out / "STARTED.json",{"started": stamp(),"frozen_sha256": digest(ROOT/"frozen.json"),
        "disclosure": "Explicit post-selection reuse, not fresh validation; saved refit forecasts only"})
    compare("validation",[frozen["rule"]])


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("command",choices=["inner","freeze","validation"])
    args = ap.parse_args()
    globals()[args.command]()
