"""Synthetic execution tests; no study price outcomes are opened."""

import json
from pathlib import Path

import numpy as np

from simulator import LIMITS, simulate


def fixture(events, symbol=0):
    market = np.full((1, 3, 390, 12), 100.0)
    p = {"delta": np.zeros_like(market), "source": np.zeros((1,3,390), dtype=int),
         "regime": np.ones((1,3,390), dtype=int), "regime_names": ["test"], "horizon": 60}
    for time, value in events:
        p["source"][0,0,time//2] = 3
        p["delta"][0,0,time//2,symbol] = value
    return market,p


def verify(result, depth=50):
    assert not result["positions"].any()
    ticks = result["action_ticks"].reshape(len(result["pnl"]), -1)
    for row in ticks:
        assert np.convolve(row, np.ones(30, dtype=int), mode="full").max() <= 60
    if "inventory_ticks" in result:
        assert np.all(np.abs(result["inventory_ticks"]) <= LIMITS)
        assert not result["inventory_ticks"][:,:,-1].any()
    if "orders" in result:
        arrival = {}
        for order in result["orders"]:
            key = (order["season_index"],order["round"],order["symbol"],order["arrival_time"])
            arrival[key] = arrival.get(key,0)+abs(order["quantity"])
        assert not arrival or max(arrival.values()) <= depth
    if "max_holding_seconds" in result:
        assert result["max_holding_seconds"].max() <= 120
    assert np.isclose(sum(t["pnl"] for t in result["trades"]),result["pnl"].sum())


def run():
    records = []
    # Constant-price case isolates actual charged round-trip savings.
    market,p = fixture([(120,10),(170,10),(190,10),(230,10)])
    for rule in ("control","exit_retain","target_expiry"):
        r = simulate(market,p,rule,audit=True)
        verify(r)
        expected = -54 if rule == "control" else -27
        assert np.isclose(r["pnl"][0],expected)
        assert np.isclose(r["pnl"][0],-r["cost"][0])
        records.append({"test": "same_price", "rule": rule,
                        "pnl": float(r["pnl"][0]),"actions": int(r["actions"][0])})
    # The two rules are genuinely distinct: a stale renewal extends a target's
    # expiry, but cannot rescue a scheduled exit when it is >10s old.
    market,p = fixture([(120,10),(140,10)])
    a = simulate(market,p,"exit_retain",audit=True)
    b = simulate(market,p,"target_expiry",audit=True)
    assert a["trades"][0]["exit_time"] == 182
    assert b["trades"][0]["exit_time"] == 202
    verify(a); verify(b)
    # A new opposite signal vetoes an older fresh same-direction signal.
    market,p = fixture([(120,10),(170,10),(178,-10)])
    a = simulate(market,p,"exit_retain",audit=True)
    assert a["trades"][0]["exit_time"] == 182
    verify(a)
    # Pending order is irrevocable. Reversal must pay for four actual fills,
    # each at its own arrival, with an observable zero-inventory interval.
    market,p = fixture([(120,10),(122,-10)],symbol=10)
    a = simulate(market,p,"target_expiry",latency=6,audit=True)
    verify(a)
    assert np.isclose(a["pnl"][0],-54)
    assert [(o["time"],o["arrival_time"],o["quantity"]) for o in a["orders"]] == [
        (120,126,50),(126,132,-50),(132,138,-50),(182,188,50)]
    assert a["inventory_ticks"][0,0,66,10] == 0
    # Updating an already pending same-direction target must not duplicate it.
    market,p = fixture([(120,10),(122,10),(124,10)],symbol=10)
    a = simulate(market,p,"target_expiry",latency=6,audit=True)
    verify(a)
    assert a["actions"][0] == 2 and np.isclose(a["pnl"][0],-27)
    # Depth stress and an entry at the final admissible decision tick.
    market,p = fixture([(716,10)],symbol=10)
    for rule in ("exit_retain","target_expiry"):
        a = simulate(market,p,rule,depth=25,audit=True)
        verify(a,25)
        assert a["trades"][0]["exit_time"] == 778
        assert np.isclose(a["pnl"][0],-13.5)
    # Saturate target flips and independently reconstruct rolling action usage.
    market,p = fixture([])
    for ti in range(60,251):
        p["source"][0,0,ti] = 3
        p["delta"][0,0,ti] = 10*(-1 if ti % 2 else 1)
    a = simulate(market,p,"target_expiry",latency=2,audit=True)
    verify(a)
    assert a["max_rolling_actions"][0] == 60 and a["blocked_entries"][0] > 0
    assert np.isclose(a["pnl"][0],-a["cost"][0])
    records.append({"test": "saturated_budget","max_actions": int(a["max_rolling_actions"][0]),
                    "blocked": int(a["blocked_entries"][0])})
    # Prefix decisions and inventories must not depend on future prices/signals.
    market,p = fixture([(120,10),(170,10),(190,10),(230,10)])
    future_market = market.copy()
    future_market[:,:,91:] *= 1.25
    future_p = {k:v.copy() if isinstance(v,np.ndarray) else v for k,v in p.items()}
    future_p["delta"][:,:,91:] *= -1
    for rule in ("exit_retain","target_expiry"):
        a = simulate(market,p,rule,audit=True)
        b = simulate(future_market,future_p,rule,audit=True)
        assert [o for o in a["orders"] if o["round"] == 1 and o["time"] <= 180] == [
            o for o in b["orders"] if o["round"] == 1 and o["time"] <= 180]
        assert np.array_equal(a["inventory_ticks"][:,0,:91],b["inventory_ticks"][:,0,:91])
        verify(a); verify(b)
    result = {"status": "passed", "records": records,
        "checks": ["same_price_both_leg_costs","freshness_and_opposite_veto",
                   "irrevocable_pending","pending_same_side_netting","charged_two_step_flip",
                   "rolling_60_actions","symbol_depth","absolute_limits","120s_hard_cap",
                   "end_of_round_zero_inventory","prefix_causality"]}
    Path("audit.json").write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps(result,indent=2))


if __name__ == "__main__":
    run()
