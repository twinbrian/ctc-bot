# Fixed motion-h60 turnover follow-up

## Conclusion

**Causal target/expiry management materially improves the fixed forecast's
baseline PnL, but still fails the positive combined-stress criterion.** Keep it
as the frozen execution challenger for parent shared-account research, rather
than calling it execution-robust alpha.

No forecasts, features, thresholds, sizes, or horizon parameters were refit or
optimized. The old fixed60 control was replayed from the identical saved
predictions and reconciled to its original per-season results in all scenarios.
Completed parent/event results remain intact.

### Post-selection validation, seasons121–240

All table amounts are **USD per season**.

| Execution scenario | Unchanged fixed60 | Frozen target_expiry | Paired gain | Gross change | Cost saving |
|---|---:|---:|---:|---:|---:|
| Baseline: latency2,25bp+0.02/side,depth50 | 1,595.08 | **2,500.92** | **905.85** | 767.29 | 138.55 |
| Latency6 | 886.31 | 1,441.02 | 554.71 | 411.17 | 143.54 |
| 50bp+0.04/side | 382.86 | 1,427.26 | 1,044.40 | 767.29 | 277.11 |
| Depth25 | 797.54 | 1,250.46 | 452.92 | 383.65 | 69.28 |
| Latency6,50bp+0.04,+10bp adverse/side | −777.67 | **−27.19** | **750.48** | 411.17 | 339.31 |

The baseline paired-gain standard error is USD84.44; total-PnL SE is USD171.62.
Combined-stress total-PnL SE is USD160.82, and its paired-gain SE is USD78.15.
The stressed point estimate remains negative; do not round it to zero or infer
that robustness was established. Baseline worst season is −USD2,346.70 and worst
marked drawdown USD3,451.92. Combined-stress worst season is −USD4,368.46 and
worst marked drawdown USD5,679.39.

This is **explicit post-selection reuse of an already observed validation set**,
not fresh out-of-sample evidence. The execution family was proposed after the
original research. The challenger was frozen using only inner results before
this single follow-up validation pass. No changes followed validation.

## What improved—and what did not

Validation round trips fall from40.14 to33.82 per season, and exchange actions
from80.28 to67.63. Turnover falls from4,014 to3,382 shares/season. Baseline costs
fall from USD1,212.22 to USD1,073.67, an11.4% saving.

The benefit is **mostly better gross capture, not just saved fees**: gross rises
from USD2,807.30 to USD3,574.59. Target expiry retains supported exposure through
otherwise forced close/reopen gaps and can reverse earlier on a genuine opposite
signal. The comparison therefore changes the inventory path, as intended; it is
not an accounting-only deletion of paired trades.

Average filled holding time rises from60s to86.62s, with a hard observed maximum
of120s. Of challenger round trips,63.9% exceed60s and13.3% are shorter than60s.
There are about99.6 logical same-side renewals,4.43 opposite intents, and12.43
hard-cap exits per season. Renewals are internal state updates, not exchange
orders. No real-data entry was blocked by the action budget; maximum observed
rolling usage was21 actions, below60.

Baseline symbol gains versus fixed60 are led by ARCH (+USD578.95), REBLD
(+USD92.13), PORT (+USD70.04), and HAVEN (+USD64.98). Challenger round means are
USD964.80,USD827.38,USD708.74. Long positions contribute USD563.69 and shorts
USD1,937.23 per season. Both sides of every short are charged.

Latency still matters: target-expiry gross capture drops from USD3,574.59 at2s
to USD2,508.97 at6s. The same combined stress that rejected the original policy
still rejects this challenger. There was no gross-capture decline relative to
the original control in any prescribed scenario, but gross declines materially
when the challenger itself is subjected to longer latency.

## Two predeclared rules and inner selection

`PLAN.md` was saved before scoring. Both rules reuse the original raw eligible
event/sign/forecast stream, lot50, original two-leg cost gate plus USD0.15/share,
top-two new-risk ranking, limits, depth, and action constraints.

1. **exit_retain:** At a scheduled exit, retain only if the latest qualifying
   event is same-direction and no more than10s old. A newer opposite signal
   vetoes retention. Expiry becomes that event's time+60s, capped by the120s
   continuous-holding deadline. Otherwise execute the original exit.
2. **target_expiry:** Same-direction eligible events refresh an existing signed
   one-lot target's expiry to event time+60s. Flat entries and opposite target
   changes compete for the original top-two new-risk slots. Net held and pending
   exposure against the target; never duplicate an already covered order.
   Opposite targets close to zero with an actual charged fill before a separately
   charged opposite entry. Pending market orders are irrevocable.

They are genuinely distinct: an event40s before a scheduled exit can renew a
target's expiry but cannot satisfy exit_retain's10s freshness requirement;
only target_expiry permits early reversals.

Inner means, **USD/season**, using the existing fit361–600 predictions on241–360:

| Rule | Baseline | Gain over control | Gross gain | Cost saving | Combined stress |
|---|---:|---:|---:|---:|---:|
| Unchanged fixed60 | 1,482.44 | 0 | 0 | 0 | −946.12 |
| exit_retain | 1,927.09 | 444.64 | 197.09 | 247.55 | −166.14 |
| **target_expiry** | **2,363.00** | **880.56** | **740.90** | **139.66** | **−375.98** |

The predeclared arithmetic-mean **baseline** objective selected target_expiry.
Exit_retain saves more fees and loses less under inner combined stress, but was
not substituted after seeing that tradeoff and was **not evaluated on121–240**
in this follow-up. All15 inner rule/scenario outcomes are retained.

## Exact causal execution and shared-account caveats

- A signal's expiry is its own timestamp+60s. No hindsight merging and no
  extension beyond an old signal's forecast horizon.
- A new filled episode has maximum continuous holding120s. The hard exit is
  submitted at first-entry submission+120s, so with constant scenario latency
  its arrival is first fill+120s. The round boundary is an additional hard stop.
- At the hard stop, discard that symbol's intent. A new qualifying signal after
  it is flat is required to restart. Same-side signals cannot reset episode age.
- Holding/pending renewal consumes no action. A reversal of a50-share lot is
  **two**50-share orders with separate arrivals, never one100-share fill.
- Pending orders cannot be cancelled for free. Opposite intent arriving during
  an entry's latency still allows the entry to fill, then pays to close it.
- One pending order/symbol; absolute limits cover both held and pending
  endpoints. Each live/pending entry reserves an exit action. Actual submission
  history is maintained across rounds; no synthetic team/key capacity.
- All inventories are actually closed each round; terminal PnL is cash, with
  no final-settlement substitution or passive-fill credit.
- Raw signals are identical across policies. Actual fresh-entry rankings can
  differ because held availability differs; this is an execution consequence.
  Same-side renewals still pass the original **two-leg** gate, not a cheaper
  one-leg threshold.

Longer occupation of ARCH's entire50-share limit increases potential conflict
with formation inventory and pending exits. The parent must coordinate targets,
pending shares, depth, and the shared rolling-action budget. Do not add this
standalone PnL mechanically to formation PnL. Consensus marks remain hypothetical
execution prices; depth25 halves PnL mechanically and does not prove capacity.

## Code, artifacts, and reproduction

All follow-up artifacts are in
`/tmp/opencode/ctc-research/project/research_v4/event/turnover`.
The prior forecast code/models/results outside this directory were read-only.

- `simulator.py`: `simulate(market, prediction, rule, **execution_scenario)`.
  `rule` is `control`, `exit_retain`, or frozen `target_expiry`. Market and delta
  shapes are `[n,3,390,12]`; `source>0` is the original eligibility event mask;
  time is real seconds. `audit=True` also records orders and inventory ticks.
- `run.py`: loads existing saved predictions; contains **no model fitting**.
- `frozen.json`: fixed rule, parameters, scenarios, selection result, source and
  prediction hashes; saved before opening follow-up validation.
- `inner/metrics.json`, `validation/metrics.json`: complete attempted metrics.
- `inner/paired_per_season.csv`:1,200 challenger/scenario/season comparisons.
- `validation/paired_per_season.csv`:600 paired rows,120 seasons×5 scenarios;
  includes both policies' PnL/gross/cost/actions and the exact paired decomposition.
- `validation/baseline_per_season.csv`:240 long-form rows,120 seasons×2 policies.
- `*/{rule}/{scenario}.npz`: season outcomes, positions, action ticks, attribution.
- `*/{rule}/trades.csv`: every baseline actual round trip with arrival prices,
  quantity, both-leg cost, and realized PnL.
- `*/control_parity.json`: control replay matched every original scenario to
  absolute tolerance1e-8 for PnL, costs, actions, depth/turnover, drawdown,
  attribution, positions, and action ticks.
- `audit.json`: passed synthetic accounting/causality tests. A constant-price
  example costs USD54 for two control round trips versus USD27 for one retained
  round trip. A latency6 pending reversal requires four charged fills. Saturation
  reaches exactly60 rolling actions and blocks excess entries.
- `artifact_audit.json`: frozen hashes unchanged; independent reconstruction of
  rolling action usage; saved-trade cashflows reconcile; every terminal inventory
  is zero; every challenger holding period is <=120s.
- `RESULTS.md`, `descriptive.json`: complete scenario and holding-period tables.

Exact commands used, from this directory:

```bash
OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 python audit.py
OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 python run.py inner
OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 python run.py freeze
OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 python run.py validation
OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 python report.py
```

Completed inner/freeze/validation commands have overwrite guards. The following
non-destructive **inner-only** reproduction works with current artifacts present:

```bash
OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 python - <<'PY'
from run import load
from simulator import simulate, summarize
market, prediction, _, _ = load('inner')
for rule in ('control', 'target_expiry'):
    result = simulate(market, prediction, rule)
    print(rule, summarize(result))
# Expected mean PnL: USD1482.4449270833325 and USD2363.0010833333345.
PY
```

### Restart/timing disclosure

The original06:30 UTC cutoff passed during server interruption. On explicit
instructions to continue, work resumed at13:33 UTC from the saved preregistration
and simulator. Inner comparison completed13:35 UTC, execution froze13:36 UTC,
and a single post-selection validation pass followed. Completed work was not
repeated after either restart. No shared edits, subagents, external trading,
paid services, or forecast retuning occurred.
