"""Two fixed-signal, causal turnover rules with real market-order accounting."""

import os
import sys
from pathlib import Path

os.environ["OMP_NUM_THREADS"] = "1"
os.environ["OPENBLAS_NUM_THREADS"] = "1"
sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import numpy as np

from event_model import LIMITS, SYMBOLS
from event_simulator import SCENARIOS, simulate as original_control


def simulate(market, prediction, rule, *, latency=2, cost_bps=25, fixed_cost=.02,
             adverse_bps=0, depth=50, audit=False):
    """Use fixed original signals; change only position/intent management.

    Held+pending netting never cancels orders. A sign reversal closes to zero
    before opening its opposite, each with its own arrival and charge.
    """
    if rule == "control":
        return original_control(market, prediction, margin=.15, top_k=2,
                                latency=latency, cost_bps=cost_bps,
                                fixed_cost=fixed_cost, adverse_bps=adverse_bps,
                                depth=depth, capture_trades=True)
    assert rule in ("exit_retain", "target_expiry")
    assert prediction["horizon"] == 60 and 0 < depth <= 50
    n = len(market)
    delay = max(1, int(np.ceil(latency/2)))
    row = np.arange(n)
    lot = np.minimum(depth, LIMITS)
    q = np.zeros((n, 12), dtype=int)
    pending = np.zeros_like(q)
    cash, cost, turnover = np.zeros((3, n))
    actions = np.zeros(n, dtype=int)
    used = np.zeros(n, dtype=int)
    history = np.zeros((n, 30), dtype=int)
    max_actions = np.zeros(n, dtype=int)
    peak, dd = np.zeros((2, n))
    max_inventory = np.zeros(n)
    max_holding = np.zeros(n, dtype=int)
    blocked = np.zeros(n, dtype=int)
    renewals = np.zeros(n, dtype=int)
    target_changes = np.zeros(n, dtype=int)
    opposite_intents = np.zeros(n, dtype=int)
    hard_exits = np.zeros(n, dtype=int)
    trades_count = np.zeros(n, dtype=int)
    attribution = np.zeros((n, 12))
    by_round = np.zeros((n, 3))
    action_ticks = np.zeros((n, 3, 390), dtype=np.int8)
    inventory_ticks = np.zeros((n, 3, 390, 12), dtype=np.int16) if audit else None
    trades, order_log = [], []
    max_fill = 0
    for r in range(3):
        queue = np.zeros((390+delay, n, 12), dtype=np.int16)
        target = np.zeros((n, 12), dtype=int)
        expiry = np.full((n, 12), -1, dtype=int)
        intent_time = np.full((n, 12), -1, dtype=int)
        intent_forecast = np.zeros((n, 12))
        intent_score = np.zeros((n, 12))
        latest_time = np.full((n, 12), -1000, dtype=int)
        latest_side = np.zeros((n, 12), dtype=int)
        hard_deadline = np.full((n, 12), 10000, dtype=int)
        hard_block = np.zeros((n, 12), dtype=bool)
        entry_fill = np.full((n, 12), -1, dtype=int)
        entry_submit = np.full((n, 12), -1, dtype=int)
        entry_signal = np.full((n, 12), -1, dtype=int)
        entry_price = np.zeros((n, 12))
        entry_fee = np.zeros((n, 12))
        entry_forecast = np.zeros((n, 12))
        end_submit = 389-delay
        for ti in range(390):
            global_tick = r*390+ti
            slot = global_tick % 30
            used -= history[:, slot]
            history[:, slot] = 0
            price = market[:, r, ti]
            fills = queue[ti]
            ii, jj = np.where(fills != 0)
            if len(ii):
                signed = fills[ii, jj]
                max_fill = max(max_fill, int(np.max(np.abs(signed))))
                assert np.all(np.abs(signed) <= depth)
                fees = np.abs(signed)*(price[ii,jj]*(cost_bps+adverse_bps)/10000+fixed_cost)
                old = q[ii,jj].copy()
                is_exit = old != 0
                assert np.all(old[is_exit]+signed[is_exit] == 0), "No atomic over-depth flip"
                np.add.at(cash, ii, -signed*price[ii,jj]-fees)
                np.add.at(cost, ii, fees)
                np.add.at(turnover, ii, np.abs(signed))
                for k in np.where(is_exit)[0]:
                    i,j = ii[k],jj[k]
                    holding = (ti-entry_fill[i,j])*2
                    assert holding <= 120, "Continuous holding limit breached"
                    max_holding[i] = max(max_holding[i], holding)
                    pnl = old[k]*(price[i,j]-entry_price[i,j])-entry_fee[i,j]-fees[k]
                    attribution[i,j] += pnl
                    by_round[i,r] += pnl
                    trades_count[i] += 1
                    trades.append({"season_index": int(i), "round": r+1,
                        "symbol": SYMBOLS[j], "quantity": int(old[k]),
                        "signal_time": int(entry_signal[i,j]*2),
                        "decision_time": int(entry_submit[i,j]*2),
                        "entry_time": int(entry_fill[i,j]*2), "exit_time": ti*2,
                        "holding_seconds": holding, "forecast": float(entry_forecast[i,j]),
                        "entry_price": float(entry_price[i,j]), "exit_price": float(price[i,j]),
                        "cost": float(entry_fee[i,j]+fees[k]), "pnl": float(pnl)})
                    hard_deadline[i,j] = 10000
                    hard_block[i,j] = False
                    entry_fill[i,j] = -1
                ie,je = ii[~is_exit],jj[~is_exit]
                entry_fill[ie,je] = ti
                entry_price[ie,je] = price[ie,je]
                entry_fee[ie,je] = fees[~is_exit]
                q += fills
                pending -= fills
            assert np.all(np.maximum(np.abs(q),np.abs(q+pending)) <= LIMITS)
            assert np.all(np.abs(q) <= lot)
            max_inventory = np.maximum(max_inventory,np.max(np.abs(q)/LIMITS,axis=1))
            wealth = cash+np.sum(q*price,axis=1)
            peak = np.maximum(peak,wealth)
            dd = np.maximum(dd,peak-wealth)
            if audit:
                inventory_ticks[:,r,ti] = q
            sent = np.zeros((n,12),dtype=bool)

            def submit(i,j,quantity,kind):
                if not len(i):
                    return
                assert np.all(used[i] < 60)
                assert not sent[i,j].any() and not pending[i,j].any()
                assert not queue[ti+delay,i,j].any()
                assert np.all(np.abs(quantity) <= depth)
                queue[ti+delay,i,j] = quantity
                pending[i,j] += quantity
                sent[i,j] = True
                used[i] += 1
                history[i,slot] += 1
                actions[i] += 1
                action_ticks[i,r,ti] += 1
                if kind == "entry":
                    hard_deadline[i,j] = np.minimum(ti+60,end_submit)
                    entry_submit[i,j] = ti
                    entry_signal[i,j] = intent_time[i,j]
                    entry_forecast[i,j] = intent_forecast[i,j]
                if audit:
                    for a,b,qty in zip(i,j,quantity):
                        order_log.append({"season_index": int(a),"round": r+1,
                            "time": ti*2,"arrival_time": (ti+delay)*2,
                            "symbol": SYMBOLS[int(b)],"quantity": int(qty),"kind": kind})

            if ti+delay >= 390:
                continue
            episode = (q != 0)|(pending != 0)
            hard_due = episode & (ti >= hard_deadline)
            newly_hard = hard_due & ~hard_block
            hard_exits += newly_hard.sum(axis=1)
            hard_block |= hard_due
            if ti >= end_submit:
                hard_block |= episode
            target[hard_block] = 0
            expiry[hard_block] = -1

            pred = prediction["delta"][:,r,ti]
            edge = np.abs(pred)-2*(price*.0025+.02)-.15
            side = np.sign(pred).astype(int)
            # Same raw event eligibility and original full-horizon timing gate.
            event = (prediction["source"][:,r,ti] > 0) & (ti+30+delay <= 389)
            qualifying = event[:,None] & (edge > 0)
            latest_time[qualifying] = ti
            latest_side[qualifying] = side[qualifying]

            if rule == "exit_retain":
                due = episode & (expiry <= ti) & ~hard_block
                same = latest_side == np.sign(q+pending)
                fresh = ti-latest_time <= 5
                extend = due & same & fresh & (q+pending != 0)
                new_expiry = np.minimum(latest_time+30,hard_deadline)
                extend &= new_expiry > ti
                expiry[extend] = new_expiry[extend]
                renewals += extend.sum(axis=1)
                target[episode & (expiry <= ti)] = 0
            else:
                same = qualifying & (target != 0) & (side == np.sign(target)) & ~hard_block
                # Intent expiry is tied to a genuine forecast timestamp. The
                # current episode's hard deadline separately overrides it.
                renewals += (same & (expiry < ti+30)).sum(axis=1)
                expiry[same] = ti+30
                intent_time[same] = ti
                intent_forecast[same] = pred[same]
                intent_score[same] = (edge*lot[None])[same]
                candidate = qualifying & ~same & ~hard_block
                score = edge*lot[None]
                score[~candidate] = -np.inf
                rank = np.argsort(-score,axis=1,kind="stable")
                accepted = np.zeros(n,dtype=int)
                for k in range(12):
                    j = rank[:,k]
                    valid = (score[row,j] > 0) & (accepted < 2)
                    i = np.where(valid)[0]
                    jj = j[i]
                    old_direction = np.sign(np.where(target[i,jj] != 0,target[i,jj],q[i,jj]+pending[i,jj]))
                    opposite_intents[i] += (old_direction != 0) & (old_direction != side[i,jj])
                    target[i,jj] = lot[jj]*side[i,jj]
                    expiry[i,jj] = ti+30
                    intent_time[i,jj] = ti
                    intent_forecast[i,jj] = pred[i,jj]
                    intent_score[i,jj] = score[i,jj]
                    target_changes[i] += 1
                    accepted[i] += 1
                target[expiry <= ti] = 0

            # Exits always precede entries. An opposite target means close to
            # zero first; pending orders are never cancelled or netted away.
            for j in range(12):
                need_exit = (q[:,j] != 0) & ((target[:,j] == 0) | (q[:,j]*target[:,j] < 0))
                ready = need_exit & (pending[:,j] == 0) & (used < 60)
                i = np.where(ready)[0]
                submit(i,np.full(len(i),j),-q[i,j],"exit")

            if rule == "exit_retain":
                available = (q == 0) & (pending == 0) & ~sent & ~hard_block
                score = edge*lot[None]
                score[~available] = -np.inf
                rank = np.argsort(-score,axis=1,kind="stable")
                accepted = np.zeros(n,dtype=int)
                for k in range(12):
                    j = rank[:,k]
                    reserve = np.sum(q+pending != 0,axis=1)
                    eligible = event & (score[row,j] > 0) & (accepted < 2)
                    capacity = used+reserve+2 <= 60
                    blocked += eligible & ~capacity
                    i = np.where(eligible & capacity)[0]
                    jj = j[i]
                    target[i,jj] = lot[jj]*side[i,jj]
                    expiry[i,jj] = ti+30
                    intent_time[i,jj] = ti
                    intent_forecast[i,jj] = pred[i,jj]
                    target_changes[i] += 1
                    submit(i,jj,target[i,jj],"entry")
                    accepted[i] += 1
            else:
                ready = (target != 0) & (q == 0) & (pending == 0) & ~sent & ~hard_block
                # No entry whose entire remaining intent horizon ends before
                # its arrival. Waiting risk targets are not fictitious fills.
                ready &= expiry > ti+delay
                score = intent_score.copy()
                score[~ready] = -np.inf
                rank = np.argsort(-score,axis=1,kind="stable")
                for k in range(12):
                    j = rank[:,k]
                    reserve = np.sum(q+pending != 0,axis=1)
                    eligible = score[row,j] > 0
                    capacity = used+reserve+2 <= 60
                    blocked += eligible & ~capacity
                    i = np.where(eligible & capacity)[0]
                    jj = j[i]
                    submit(i,jj,target[i,jj],"entry")
            max_actions = np.maximum(max_actions,used)
            assert np.all(used+np.sum(q+pending != 0,axis=1) <= 60)
            assert np.all(np.maximum(np.abs(q),np.abs(q+pending)) <= LIMITS)
        assert not q.any() and not pending.any(), "Inventory must actually close each round"
    assert np.allclose(attribution.sum(axis=1),cash)
    assert np.allclose(by_round.sum(axis=1),cash)
    result = {"pnl": cash,"cost": cost,"turnover_shares": turnover,"actions": actions,
        "trades_count": trades_count,"drawdown": dd,"max_rolling_actions": max_actions,
        "max_position_fraction": max_inventory,"blocked_entries": blocked,
        "positions": q,"attribution": attribution,"by_round": by_round,
        "action_ticks": action_ticks,"trades": trades,"renewals": renewals,
        "target_changes": target_changes,"opposite_intents": opposite_intents,
        "hard_exits": hard_exits,"max_holding_seconds": max_holding,
        "max_fill_shares": np.array(max_fill)}
    if audit:
        result["inventory_ticks"] = inventory_ticks
        result["orders"] = order_log
    return result


def summarize(result):
    p = result["pnl"]
    out = {"n": len(p),"mean_pnl": float(p.mean()),
        "se_pnl": float(p.std(ddof=1)/np.sqrt(len(p))),
        "mean_gross": float((p+result["cost"]).mean()),
        "mean_cost": float(result["cost"].mean()),
        "mean_actions": float(result["actions"].mean()),
        "mean_turnover_shares": float(result["turnover_shares"].mean()),
        "mean_round_trips": float(result["trades_count"].mean()),
        "min_pnl": float(p.min()),"median_pnl": float(np.median(p)),
        "p05_pnl": float(np.quantile(p,.05)),
        "mean_drawdown": float(result["drawdown"].mean()),
        "worst_drawdown": float(result["drawdown"].max()),
        "max_rolling_actions": int(result["max_rolling_actions"].max()),
        "max_position_fraction": float(result["max_position_fraction"].max()),
        "symbol_mean_pnl": dict(zip(SYMBOLS,result["attribution"].mean(0).tolist())),
        "round_mean_pnl": result["by_round"].mean(0).tolist()}
    for key in ("renewals","target_changes","opposite_intents","hard_exits","blocked_entries"):
        if key in result:
            out["mean_"+key] = float(result[key].mean())
    if "max_holding_seconds" in result:
        out["max_holding_seconds"] = int(result["max_holding_seconds"].max())
    return out
