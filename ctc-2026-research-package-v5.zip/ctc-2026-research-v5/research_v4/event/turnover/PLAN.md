# Fixed-signal turnover follow-up: preregistration

Declared 2026-10-19 before new inner scoring. All writes are confined to this
`event/turnover` directory; completed event research remains read-only.
No forecast refits, feature changes, gate changes, horizon/size search, or child
agents. Only two parameter-free execution challengers are eligible.

## Immutable signal and control

Reuse `../inner/motion_h60/prediction.npz` (model fit361–600, inner241–360) and,
only after freezing execution selection, `../validation/motion_h60/prediction.npz`
(existing refit241–600, validation121–240). No original season1–120 data.

The twelve raw forecasts, motion-event masks, 60s horizon, per-symbol signs,
25bp+$0.02/side round-trip gate plus $0.15 margin, size50 (25 in depth stress),
published limits, and top-two new-risk ranking remain fixed. A held-position
renewal is not a new order or an additional ranked symbol: it must nevertheless
pass the original **two-leg** net-edge gate on an eligible event. Raw eligible
signals are identical across policies; filled positions and thus available-entry
rankings can differ as a consequence of execution management.

The unchanged fixed60 control is the original simulator, replayed from the same
saved forecasts and reconciled season-by-season against its completed artifacts.
Use all five original scenarios: baseline; latency6; double_cost; depth25;
combined latency6,50bp+$0.04/side,+10bp adverse/side. Gate/ranking expenses stay at
baseline even in stresses, exactly as before.

## Exactly two execution rules

### 1. `exit_retain`

Fresh entries and their ranking are the unchanged control's. For each live or
pending position, record the most recent qualifying event's time and direction.
At its scheduled exit, retain only if that latest event has the same direction
and is at most10 real seconds old, inclusive. Set expiry to that event's
decision time+60s (not beyond the forecast's actual horizon). A newer qualifying
opposite signal vetoes retention. Otherwise submit the charged market exit.
There is no early reversal under this rule.

### 2. `target_expiry`

Maintain a signed one-lot target and intent expiry. Every new qualifying
same-direction event for an existing target refreshes expiry to event time+60s;
zero orders are sent when held+pending exposure already satisfies that target.
Flat entries and opposite-direction target changes compete for the original
top-two new-risk slots, using the unchanged net-dollar ranking. Target updates
are logical intent updates, not fills or free order cancellations.

At expiry, target becomes zero. Reversal requires an actual charged fill to
zero, followed by a separately charged entry toward the opposite one-lot target;
never submit a 100-share reversal against50-share depth. Pending market orders
are irrevocable. New targets wait for their fills, and are then reconciled against
actual inventory. A pending opposite entry still incurs its entry and closing
costs if a newer signal reverses it. An accepted target is valid only until its
latest signal's60s expiry; action-limited reopening may shorten its live horizon.

## Common bounds and accounting

- Maximum continuous **filled** holding period120s. With fixed scenario latency,
  submit the hard exit at first-entry submission+120s, so its arrival is no later
  than first-entry fill+120s. Both policies cap renewal expiry at this hard limit.
  At the hard exit, discard the symbol's intent; a new signal after the position
  is flat is required to restart. Never silently reset the holding-age clock.
- Close all positions with actual fills before each round ends. Handle the round
  boundary as an additional hard deadline; no settlement substitution.
- One pending order/symbol, one lot/symbol, <=50 shares/symbol/2s interval,
  absolute published limits including pending reservations, no passive fills.
- Charge both sides using arrival-time marks and the original costs. Record real
  order submissions in the single-key rolling60-action budget. Reserve one exit
  action for every live/pending entry; potential future reversal entries reserve
  capacity only when actually submitted and may wait or expire.
- Renewals consume no exchange action. Opposite targets cannot manufacture a
  cancellation or a free crossing. Preserve both gross PnL and cost attribution.

## Selection and post-selection validation

Evaluate control plus both rules on inner241–360. Rank by arithmetic mean net
baseline season PnL; exact ties prefer control, then exit_retain. Retain control
as the fixed benchmark. Freeze the highest-mean challenger for one diagnostic
validation pass regardless of whether it beats control; label replacement
eligibility false if it does not. No stress-based or threshold retuning.

After saving `frozen.json`, reuse the existing saved refit's forecasts on121–240
exactly once for the frozen challenger and the unchanged control, under all five
predeclared scenarios. This is explicitly **post-selection reuse of an already
observed validation set**, not fresh out-of-sample evidence. A deployment claim
requires positive combined-stress mean as well as improvement over the control.
No policy changes follow validation. Preserve all attempted outcomes.

## Verification and outputs

Before scoring, synthetic tests cover same-price round trips, fee-only benefits
of retention, fresh/opposite signal handling, irrevocable pending orders, charged
two-step reversals, rolling action history, symbol depth, limits,120s hard stops,
prefix causality, and zero end-of-round inventory. Original-control parity is
checked on every scenario before evaluating challengers.

Deliver runnable local code, `HANDOFF.md`, frozen configuration, per-season net,
gross, cost, actions, turnover and paired comparisons; distinguish cost saving
from lost gross capture. OMP/OPENBLAS=1, <=2 workers, no shared-source edits.
Target completion <=30 minutes and before06:30 UTC.
