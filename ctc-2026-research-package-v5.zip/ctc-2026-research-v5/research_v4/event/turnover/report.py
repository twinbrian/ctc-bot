"""Summarize archived results; performs no forecasts, fills, or selection."""

import csv
import json
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent


def run():
    lines = ["# Turnover follow-up results", "", "All monetary amounts are USD.",
             "Original forecasts, signal gates, size and execution scenarios are unchanged."]
    descriptive = []
    for split in ("inner","validation"):
        file = ROOT / split / "metrics.json"
        if not file.exists():
            continue
        metrics = json.loads(file.read_text())
        lines += ["", f"## {split}", "",
            "| Rule | Scenario | Net mean | Paired increment | Paired SE | Gross change | Cost saving | Actions | Trips |",
            "|---|---|---:|---:|---:|---:|---:|---:|---:|"]
        for m in metrics:
            lines.append(f"| {m['rule']} | {m['scenario']} | {m['mean_pnl']:.2f} | "
                f"{m['paired_mean']:.2f} | {m['paired_se']:.2f} | {m['gross_change']:.2f} | "
                f"{m['cost_saving']:.2f} | {m['mean_actions']:.2f} | {m['mean_round_trips']:.2f} |")
        for rule in dict.fromkeys(m["rule"] for m in metrics):
            trades = list(csv.DictReader((ROOT / split / rule / "trades.csv").open()))
            holds = np.array([int(t["exit_time"])-int(t["entry_time"]) for t in trades])
            desc = {"split": split,"rule": rule,"trades": len(trades),
                "mean_holding_seconds": float(holds.mean()),"max_holding_seconds": int(holds.max()),
                "fraction_above_60s": float(np.mean(holds > 60)),
                "fraction_below_60s": float(np.mean(holds < 60)),
                "long_net_per_season": sum(float(t["pnl"]) for t in trades if int(t["quantity"]) > 0)/120,
                "short_net_per_season": sum(float(t["pnl"]) for t in trades if int(t["quantity"]) < 0)/120}
            descriptive.append(desc)
        rows = list(csv.DictReader((ROOT / split / "per_season_comparisons.csv").open()))
        baseline = [r for r in rows if r["scenario"] == "base"]
        with (ROOT / split / "baseline_per_season.csv").open("w",newline="") as f:
            w = csv.DictWriter(f,list(baseline[0])); w.writeheader(); w.writerows(baseline)
        controls = {(r["season_id"],r["scenario"]):r for r in rows if r["rule"] == "control"}
        paired_rows = []
        for r in rows:
            if r["rule"] == "control":
                continue
            c = controls[(r["season_id"],r["scenario"])]
            paired = {"season_id": r["season_id"],"rule": r["rule"],"scenario": r["scenario"]}
            for key in ("pnl","gross","cost","actions","turnover_shares","round_trips","drawdown"):
                paired["control_"+key] = c[key]
                paired["candidate_"+key] = r[key]
            for key in ("paired_pnl","gross_change","cost_saving"):
                paired[key] = r[key]
            paired_rows.append(paired)
        with (ROOT / split / "paired_per_season.csv").open("w",newline="") as f:
            w = csv.DictWriter(f,list(paired_rows[0])); w.writeheader(); w.writerows(paired_rows)
    lines += ["", "## Baseline holding periods", "",
        "| Split | Rule | Mean seconds | Max seconds | Above60s | Below60s |",
        "|---|---|---:|---:|---:|---:|"]
    for d in descriptive:
        lines.append(f"| {d['split']} | {d['rule']} | {d['mean_holding_seconds']:.2f} | "
            f"{d['max_holding_seconds']} | {d['fraction_above_60s']:.1%} | {d['fraction_below_60s']:.1%} |")
    (ROOT / "RESULTS.md").write_text("\n".join(lines)+"\n")
    (ROOT / "descriptive.json").write_text(json.dumps(descriptive,indent=2)+"\n")
    print("Wrote descriptive summaries from archived results.")


if __name__ == "__main__":
    run()
