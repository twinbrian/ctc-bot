# Turnover follow-up results

All monetary amounts are USD.
Original forecasts, signal gates, size and execution scenarios are unchanged.

## inner

| Rule | Scenario | Net mean | Paired increment | Paired SE | Gross change | Cost saving | Actions | Trips |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| control | base | 1482.44 | 0.00 | 0.00 | 0.00 | 0.00 | 83.03 | 41.52 |
| exit_retain | base | 1927.09 | 444.64 | 58.93 | 197.09 | 247.55 | 67.27 | 33.63 |
| target_expiry | base | 2363.00 | 880.56 | 86.30 | 740.90 | 139.66 | 70.62 | 35.31 |
| control | latency6 | 794.28 | 0.00 | 0.00 | -0.00 | 0.00 | 83.03 | 41.52 |
| exit_retain | latency6 | 1234.30 | 440.02 | 53.16 | 192.69 | 247.33 | 67.27 | 33.63 |
| target_expiry | latency6 | 1166.48 | 372.21 | 89.52 | 227.19 | 145.02 | 70.28 | 35.14 |
| control | double_cost | 214.85 | 0.00 | 0.00 | 0.00 | 0.00 | 83.03 | 41.52 |
| exit_retain | double_cost | 907.05 | 692.19 | 62.52 | 197.09 | 495.11 | 67.27 | 33.63 |
| target_expiry | double_cost | 1235.07 | 1020.22 | 88.07 | 740.90 | 279.32 | 70.62 | 35.31 |
| control | depth25 | 741.22 | 0.00 | 0.00 | 0.00 | 0.00 | 83.03 | 41.52 |
| exit_retain | depth25 | 963.54 | 222.32 | 29.46 | 98.54 | 123.78 | 67.27 | 33.63 |
| target_expiry | depth25 | 1181.50 | 440.28 | 43.15 | 370.45 | 69.83 | 70.62 | 35.31 |
| control | combined | -946.12 | 0.00 | 0.00 | 0.00 | 0.00 | 83.03 | 41.52 |
| exit_retain | combined | -166.14 | 779.98 | 58.43 | 192.69 | 587.29 | 67.27 | 33.63 |
| target_expiry | combined | -375.98 | 570.14 | 100.57 | 227.19 | 342.95 | 70.28 | 35.14 |

## validation

| Rule | Scenario | Net mean | Paired increment | Paired SE | Gross change | Cost saving | Actions | Trips |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| control | base | 1595.08 | 0.00 | 0.00 | -0.00 | 0.00 | 80.28 | 40.14 |
| target_expiry | base | 2500.92 | 905.85 | 84.44 | 767.29 | 138.55 | 67.63 | 33.82 |
| control | latency6 | 886.31 | 0.00 | 0.00 | 0.00 | 0.00 | 80.28 | 40.14 |
| target_expiry | latency6 | 1441.02 | 554.71 | 69.86 | 411.17 | 143.54 | 67.32 | 33.66 |
| control | double_cost | 382.86 | 0.00 | 0.00 | 0.00 | 0.00 | 80.28 | 40.14 |
| target_expiry | double_cost | 1427.26 | 1044.40 | 86.58 | 767.29 | 277.11 | 67.63 | 33.82 |
| control | depth25 | 797.54 | 0.00 | 0.00 | -0.00 | 0.00 | 80.28 | 40.14 |
| target_expiry | depth25 | 1250.46 | 452.92 | 42.22 | 383.65 | 69.28 | 67.63 | 33.82 |
| control | combined | -777.67 | 0.00 | 0.00 | -0.00 | 0.00 | 80.28 | 40.14 |
| target_expiry | combined | -27.19 | 750.48 | 78.15 | 411.17 | 339.31 | 67.32 | 33.66 |

## Baseline holding periods

| Split | Rule | Mean seconds | Max seconds | Above60s | Below60s |
|---|---|---:|---:|---:|---:|
| inner | control | 60.00 | 60 | 0.0% | 0.0% |
| inner | exit_retain | 82.53 | 120 | 38.9% | 0.0% |
| inner | target_expiry | 85.38 | 120 | 62.6% | 13.5% |
| validation | control | 60.00 | 60 | 0.0% | 0.0% |
| validation | target_expiry | 86.62 | 120 | 63.9% | 13.3% |
