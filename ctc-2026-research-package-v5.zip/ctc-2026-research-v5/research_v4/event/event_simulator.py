"""Bounded market-order event execution; consensus marks are hypothetical fills."""

import numpy as np

from event_model import LIMITS, SOURCE_NAMES, SYMBOLS

SCENARIOS = {
    "base": {},
    "latency6": {"latency": 6},
    "double_cost": {"cost_bps": 50, "fixed_cost": .04},
    "depth25": {"depth": 25},
    "combined": {"latency": 6, "cost_bps": 50, "fixed_cost": .04, "adverse_bps": 10},
}


def simulate(market, prediction, *, horizon=None, margin=.15, top_k=2,
             latency=2, cost_bps=25, fixed_cost=.02, adverse_bps=0,
             depth=50, capture_trades=False):
    """One independent account per input season, one key, actual two-leg exits.

    Exit reserves count active/pending entries, excluding exits already sent.
    Fees used to decide trades stay fixed at baseline in all execution stresses.
    Order size is <=depth<=50; no pyramiding or per-symbol opposing orders.
    """
    assert 0 < depth <= 50
    n = len(market)
    horizon = horizon or prediction["horizon"]
    delay = max(1, int(np.ceil(latency/2)))
    q = np.zeros((n, 12), dtype=int)
    pending = np.zeros_like(q)
    cash = np.zeros(n)
    cost = np.zeros(n)
    turnover = np.zeros(n)
    actions = np.zeros(n, dtype=int)
    max_actions = np.zeros(n, dtype=int)
    max_inventory = np.zeros(n)
    blocked = np.zeros(n, dtype=int)
    peak = np.zeros(n)
    drawdown = np.zeros(n)
    attribution = np.zeros((n, 12))
    by_source = np.zeros((n, 5))
    by_round = np.zeros((n, 3))
    # Explicit time buckets: 120..209,210..329,330..449,450..539,570,740.
    by_time = np.zeros((n, 6))
    by_regime = np.zeros((n, max(1, len(prediction["regime_names"]))))
    trades_per_season = np.zeros(n, dtype=int)
    trades = []
    action_ticks = np.zeros((n, 3, 390), dtype=np.int8)
    lot = np.minimum(LIMITS, depth)
    row = np.arange(n)
    for r in range(3):
        queue = np.zeros((390+delay, n, 12), dtype=np.int16)
        used = np.zeros(n, dtype=int)
        history = np.zeros((n, 30), dtype=np.int8)
        active = np.zeros((n, 12), dtype=bool)
        closing = np.zeros_like(active)
        due = np.full((n, 12), 10000, dtype=int)
        trade_src = np.zeros((n, 12), dtype=np.int8)
        trade_regime = np.zeros_like(trade_src)
        decision_tick = np.zeros((n, 12), dtype=int)
        entry_tick = np.zeros((n, 12), dtype=int)
        entry_price = np.zeros((n, 12))
        entry_fee = np.zeros((n, 12))
        entry_qty = np.zeros((n, 12), dtype=int)
        expected = np.zeros((n, 12))
        for ti in range(390):
            used -= history[:, ti % 30]
            history[:, ti % 30] = 0
            price = market[:, r, ti]
            fill = queue[ti]
            ii, jj = np.where(fill != 0)
            if len(ii):
                signed = fill[ii, jj]
                unit_cost = price[ii, jj] * (cost_bps+adverse_bps)/10000 + fixed_cost
                fee = np.abs(signed)*unit_cost
                # add.at is necessary because several symbols can fill for a season.
                np.add.at(cash, ii, -signed*price[ii, jj]-fee)
                np.add.at(cost, ii, fee)
                np.add.at(turnover, ii, np.abs(signed))
                is_exit = closing[ii, jj]
                for k in np.where(is_exit)[0]:
                    i, j = ii[k], jj[k]
                    pnl = entry_qty[i, j]*(price[i, j]-entry_price[i, j])-entry_fee[i, j]-fee[k]
                    attribution[i, j] += pnl
                    by_source[i, trade_src[i, j]-1] += pnl
                    by_round[i, r] += pnl
                    t = decision_tick[i, j]*2
                    bucket = 5 if t >= 740 else 4 if t >= 570 else 3 if t >= 450 else 2 if t >= 330 else 1 if t >= 210 else 0
                    by_time[i, bucket] += pnl
                    by_regime[i, trade_regime[i, j]-1] += pnl
                    trades_per_season[i] += 1
                    if capture_trades:
                        trades.append({"season_index": int(i), "round": r+1,
                                       "decision_time": int(t), "entry_time": int(entry_tick[i,j]*2),
                                       "exit_time": ti*2, "symbol": SYMBOLS[j],
                                       "source": SOURCE_NAMES[int(trade_src[i,j])],
                                       "regime": prediction["regime_names"][trade_regime[i,j]-1],
                                       "quantity": int(entry_qty[i,j]),
                                       "forecast": float(expected[i,j]),
                                       "entry_price": float(entry_price[i,j]),
                                       "exit_price": float(price[i,j]),
                                       "cost": float(entry_fee[i,j]+fee[k]), "pnl": float(pnl)})
                ie, je = ii[~is_exit], jj[~is_exit]
                entry_price[ie, je] = price[ie, je]
                entry_fee[ie, je] = fee[~is_exit]
                entry_qty[ie, je] = signed[~is_exit]
                entry_tick[ie, je] = ti
                ix, jx = ii[is_exit], jj[is_exit]
                active[ix, jx] = False
                closing[ix, jx] = False
                due[ix, jx] = 10000
                q += fill
                pending -= fill
            assert np.all(np.maximum(np.abs(q), np.abs(q+pending)) <= LIMITS)
            wealth = cash + np.sum(q*price, axis=1)
            peak = np.maximum(peak, wealth)
            drawdown = np.maximum(drawdown, peak-wealth)
            max_inventory = np.maximum(max_inventory, np.max(np.abs(q)/LIMITS, axis=1))
            sent = np.zeros((n, 12), dtype=bool)

            def submit(i, j, quantity):
                if not len(i):
                    return
                assert np.all(used[i] < 60)
                assert not sent[i, j].any()
                assert np.all(np.abs(quantity) <= depth)
                queue[ti+delay, i, j] = quantity
                pending[i, j] += quantity
                sent[i, j] = True
                used[i] += 1
                history[i, ti % 30] += 1
                actions[i] += 1
                action_ticks[i, r, ti] += 1

            if ti+delay >= 390:
                continue
            # One order per symbol can arrive in a quote interval. Constant
            # scenario latency maps distinct submission ticks to distinct fills.
            for j in range(12):
                ready = active[:, j] & ~closing[:, j] & (due[:, j] <= ti)
                ready &= (pending[:, j] == 0) & (q[:, j] != 0) & (used < 60)
                i = np.where(ready)[0]
                submit(i, np.full(len(i), j), -q[i, j])
                closing[i, j] = True
            event = prediction["source"][:, r, ti] > 0
            if event.any() and 2*ti+horizon+2*delay <= 778:
                pred = prediction["delta"][:, r, ti]
                # Fixed, ex ante round-trip expense estimate at current mark.
                edge = np.abs(pred) - 2*(price*25/10000+.02) - margin
                available = ~active & (q == 0) & (pending == 0) & ~sent
                score = edge*lot[None]
                score[~available] = -np.inf
                rank = np.argsort(-score, axis=1, kind="stable")
                accepted = np.zeros(n, dtype=int)
                for k in range(12):
                    j = rank[:, k]
                    reserve = np.sum(active & ~closing, axis=1)
                    eligible = event & (score[row, j] > 0) & (accepted < top_k)
                    capacity = used+reserve+2 <= 60
                    blocked += eligible & ~capacity
                    i = np.where(eligible & capacity)[0]
                    jj = j[i]
                    qty = lot[jj]*np.sign(pred[i, jj]).astype(int)
                    submit(i, jj, qty)
                    active[i, jj] = True
                    due[i, jj] = ti+horizon//2
                    trade_src[i, jj] = prediction["source"][i, r, ti]
                    trade_regime[i, jj] = prediction["regime"][i, r, ti]
                    decision_tick[i, jj] = ti
                    expected[i, jj] = pred[i, jj]
                    accepted[i] += 1
            max_actions = np.maximum(max_actions, used)
            assert np.all(used+np.sum(active & ~closing, axis=1) <= 60)
        assert not q.any() and not pending.any() and not active.any(), "Unclosed round inventory"
    assert np.allclose(attribution.sum(1), cash)
    assert np.allclose(by_source.sum(1), cash)
    assert np.allclose(by_round.sum(1), cash)
    assert np.allclose(by_time.sum(1), cash)
    assert np.allclose(by_regime.sum(1), cash)
    return {"pnl": cash, "cost": cost, "turnover_shares": turnover, "actions": actions,
            "trades_count": trades_per_season, "drawdown": drawdown,
            "max_rolling_actions": max_actions, "max_position_fraction": max_inventory,
            "blocked_entries": blocked, "positions": q, "attribution": attribution,
            "by_source": by_source, "by_round": by_round, "by_time": by_time,
            "by_regime": by_regime, "action_ticks": action_ticks, "trades": trades}


def summarize(result):
    pnl = result["pnl"]
    return {"n": len(pnl), "mean_pnl": float(pnl.mean()),
            "se_pnl": float(pnl.std(ddof=1)/np.sqrt(len(pnl))),
            "median_pnl": float(np.median(pnl)), "min_pnl": float(pnl.min()),
            "p05_pnl": float(np.quantile(pnl, .05)), "p95_pnl": float(np.quantile(pnl, .95)),
            "positive_fraction": float(np.mean(pnl > 0)),
            "mean_cost": float(result["cost"].mean()),
            "mean_gross_pnl": float((pnl+result["cost"]).mean()),
            "mean_actions": float(result["actions"].mean()),
            "mean_trades": float(result["trades_count"].mean()),
            "max_rolling_actions": int(result["max_rolling_actions"].max()),
            "max_position_fraction": float(result["max_position_fraction"].max()),
            "mean_drawdown": float(result["drawdown"].mean()),
            "worst_drawdown": float(result["drawdown"].max()),
            "mean_blocked_entries": float(result["blocked_entries"].mean()),
            "symbol_mean_pnl": dict(zip(SYMBOLS, result["attribution"].mean(0).tolist())),
            "source_mean_pnl": dict(zip(SOURCE_NAMES.values(), result["by_source"].mean(0).tolist())),
            "round_mean_pnl": result["by_round"].mean(0).tolist(),
            "time_bucket_mean_pnl": result["by_time"].mean(0).tolist(),
            "regime_mean_pnl": result["by_regime"].mean(0).tolist()}
