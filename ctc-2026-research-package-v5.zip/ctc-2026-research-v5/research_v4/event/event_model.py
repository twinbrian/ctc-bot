"""Causal event forecasts. Public input cubes only; no truth arrays are accessed.

All times are real seconds. `fit_predict` IDs index the supplied data, zero-based.
Prediction target is mark(t+h+2)-mark(t+2), not the decision-to-future return.
"""

import os

os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")

import numpy as np

SYMBOLS = ["PORT", "ISLE", "AQUA", "GRID", "FERRY", "RECON", "MAT", "GEN",
           "HAVEN", "REIN", "ARCH", "REBLD"]
LIMITS = np.array([200, 300, 500, 400, 800, 500, 700, 600, 250, 200, 50, 100])
SOURCE_NAMES = {1: "official", 2: "wire", 3: "motion", 4: "preliminary", 5: "final"}
PUBLIC_KEYS = ["market", "obs", "damage", "loss", "stage", "official", "wire",
               "probability", "cone"]
STATIC_KEYS = ["site_xy", "site_weight", "site_company"]


def subset(data, ids):
    ids = np.asarray(ids, dtype=int)
    out = {key: np.asarray(data[key])[ids] for key in PUBLIC_KEYS}
    out.update({key: np.asarray(data[key]) for key in STATIC_KEYS})
    return out


def projection(state, site_xy, weights, remaining, offset=0):
    """Observed straight-line forecast, never a realized future path.

    Peak weighted Gaussian wind within 60/120/240s; projected timestamps are
    capped at scheduled storm dissipation. `offset=10` aligns a 10s-old forecast
    with the current decision's future interval.
    """
    peaks = np.zeros((len(state), len(site_xy)))
    outputs = []
    for lead in range(0, 241, 20):
        tau = offset + np.minimum(lead, remaining)
        p = state[:, :2] + state[:, 2:4] * tau[:, None]
        d2 = np.sum((p[:, None] - site_xy[None]) ** 2, axis=-1)
        radius = np.maximum(state[:, 4, None], 1)
        wind = state[:, 5, None] * np.exp(-d2 / radius ** 2)
        wind *= d2 <= (2 * radius) ** 2
        peaks = np.maximum(peaks, wind)
        if lead in (60, 120, 240):
            outputs.append(peaks @ weights)
    return np.concatenate(outputs, axis=1)


def cone_risk(cone, state, site_xy, weights):
    pts = cone.reshape(-1, 3, 3)
    d2 = np.sum((pts[:, :, None, :2] - site_xy[None, None]) ** 2, axis=-1)
    r2 = np.maximum(state[:, None, 4, None], 1) ** 2
    spread2 = pts[:, :, 2, None] ** 2
    wind = state[:, None, 5, None] * np.exp(-d2 / (r2 + spread2))
    wind *= np.sqrt(r2 / (r2 + spread2))
    return np.max(wind, axis=1) @ weights


def event_rows(data, ids, family):
    """Build event features from as-of feed prefixes for the selected seasons.

    Evaluating vectorized cumulative histories does not expose future rows to
    earlier features. The last valid observation is age478 at real second538.
    """
    d = subset(data, ids)
    market = d["market"]
    n = len(market)
    grid = np.arange(390) * 2
    previous = np.maximum(np.arange(390) - 1, 0)
    source = np.zeros((n, 3, 390), dtype=np.int8)
    if family == "news":
        wire_change = d["wire"] != d["wire"][:, :, previous]
        wire_change &= (grid >= 120)[None, None] & (grid <= 538)[None, None]
        source[wire_change] = 2
        official_times = np.arange(150, 511, 60) // 2
        source[:, :, official_times] = 1
    elif family == "motion":
        source[:, :, np.arange(120, 531, 10) // 2] = 3
    elif family == "report":
        source[:, :, 570 // 2] = 4
        source[:, :, 740 // 2] = 5
    else:
        raise ValueError(f"Unknown family {family}")
    si, ri, ti = np.where(source > 0)
    t = ti * 2
    src = source[si, ri, ti]
    oi = np.clip((t - 60) // 2, 0, 239)
    old_oi = np.clip((t - 70) // 2, 0, 239)
    prev_ti = np.maximum(ti - 1, 0)
    obs = d["obs"][:, :, :240]
    state = obs[si, ri, oi]
    old_state = obs[si, ri, old_oi]
    weights = np.zeros((len(d["site_xy"]), 5))
    weights[np.arange(len(weights)), d["site_company"].astype(int)] = d["site_weight"]
    dist2 = np.sum((obs[..., None, :2] - d["site_xy"]) ** 2, axis=-1)
    radius = np.maximum(obs[..., None, 4], 1)
    wind = obs[..., None, 5] * np.exp(-dist2 / radius ** 2)
    wind *= dist2 <= (2 * radius) ** 2
    dt = np.full(240, 2.0)
    dt[0] = 0
    exposure = np.cumsum(wind * dt[None, None, :, None], axis=2) @ weights
    outage = np.cumsum((wind >= .35) * dt[None, None, :, None], axis=2) @ weights
    peak = np.maximum.accumulate(wind, axis=2) @ weights
    wind_company = wind @ weights
    remaining = np.maximum(540 - t, 0)
    risk = projection(state, d["site_xy"], weights, remaining)
    # After dissipation there is no new 10s observation. The age difference is
    # zero, rather than pretending the last observation continues moving.
    obs_elapsed = (oi - old_oi) * 2
    old_risk = projection(old_state, d["site_xy"], weights, remaining,
                          offset=obs_elapsed)
    risk_delta = risk - old_risk
    velocity_delta = state[:, 2:4] - old_state[:, 2:4]
    velocity_norm = np.linalg.norm(velocity_delta, axis=1)
    if family == "motion":
        keep = (velocity_norm >= 1.0) | (np.max(np.abs(risk_delta), axis=1) >= .05)
    else:
        keep = np.ones(len(si), dtype=bool)

    names, innovation_names = [], []
    control, context, innovations = [], [], []

    def add(collection, prefix, values, name_list):
        values = np.asarray(values)
        if values.ndim == 1:
            values = values[:, None]
        collection.append(values)
        name_list.extend([prefix] if values.shape[1] == 1 else
                         [f"{prefix}_{j}" for j in range(values.shape[1])])

    control_names = []
    add(control, "round", np.eye(3)[ri], control_names)
    add(control, "source", np.eye(5)[src - 1], control_names)
    add(control, "time", t / 780, control_names)
    add(control, "time_sq", (t / 780) ** 2, control_names)
    price = market[si, ri, ti]
    add(control, "price", price, control_names)
    for lag in (2, 6, 10, 30):
        add(control, f"return_{lag}s", price - market[si, ri, np.maximum(ti-lag//2, 0)],
            control_names)

    add(context, "observation", state, names)
    add(context, "wind", wind_company[si, ri, oi], names)
    add(context, "measured_exposure", exposure[si, ri, oi], names)
    add(context, "measured_outage_seconds", outage[si, ri, oi], names)
    add(context, "measured_peak", peak[si, ri, oi], names)
    add(context, "projected_peak", risk, names)
    add(context, "probability", d["probability"][si, ri, ti], names)
    add(context, "cone_risk", cone_risk(d["cone"][si, ri, ti], state,
                                        d["site_xy"], weights), names)
    for key in ("official", "wire"):
        add(context, key, np.eye(7)[d[key][si, ri, ti] + 1], names)
    damage = d["damage"][si, ri, ti]
    loss = d["loss"][si, ri, ti]
    add(context, "damage_report", damage, names)
    add(context, "loss_report", loss, names)
    prior_damage = np.concatenate([np.zeros((n, 1, 5)),
                                   np.cumsum(d["damage"][:, :-1, -1], axis=1)], axis=1)
    prior_loss = np.concatenate([np.zeros((n, 1)),
                                 np.cumsum(d["loss"][:, :-1, -1], axis=1)], axis=1)
    add(context, "previous_rounds_damage", prior_damage[si, ri], names)
    add(context, "previous_rounds_loss", prior_loss[si, ri], names)

    add(innovations, "velocity_change_10s", velocity_delta, innovation_names)
    add(innovations, "radius_intensity_change_10s", state[:, 4:] - old_state[:, 4:],
        innovation_names)
    add(innovations, "position_surprise_10s",
        state[:, :2] - old_state[:, :2] - obs_elapsed[:, None] * old_state[:, 2:4],
        innovation_names)
    add(innovations, "projected_risk_change_10s", risk_delta, innovation_names)
    add(innovations, "wind_change_10s", wind_company[si, ri, oi] -
        wind_company[si, ri, old_oi], innovation_names)
    add(innovations, "new_exposure_10s", exposure[si, ri, oi] -
        exposure[si, ri, old_oi], innovation_names)
    add(innovations, "new_outage_10s", outage[si, ri, oi] -
        outage[si, ri, old_oi], innovation_names)
    for key in ("official", "wire"):
        now = np.eye(7)[d[key][si, ri, ti] + 1]
        old = np.eye(7)[d[key][si, ri, prev_ti] + 1]
        add(innovations, key + "_revision", now - old, innovation_names)
    add(innovations, "probability_revision", d["probability"][si, ri, ti] -
        d["probability"][si, ri, prev_ti], innovation_names)
    new_cone = d["cone"][si, ri, ti]
    old_cone = d["cone"][si, ri, prev_ti]
    add(innovations, "cone_revision", new_cone - old_cone, innovation_names)
    add(innovations, "cone_risk_revision",
        cone_risk(new_cone, state, d["site_xy"], weights) -
        cone_risk(old_cone, state, d["site_xy"], weights), innovation_names)
    agreement = (d["wire"][si, ri, ti] == d["official"][si, ri, ti]).astype(float)
    old_agreement = (d["wire"][si, ri, prev_ti] ==
                     d["official"][si, ri, prev_ti]).astype(float)
    add(innovations, "agreement_revision", agreement - old_agreement, innovation_names)
    add(innovations, "damage_revision", damage - d["damage"][si, ri, prev_ti],
        innovation_names)
    add(innovations, "loss_revision", loss - d["loss"][si, ri, prev_ti],
        innovation_names)

    x_control = np.concatenate(control, axis=1)
    x = np.concatenate(control + context + innovations, axis=1)
    feature_names = control_names + names + innovation_names
    # Observable regimes only, not latent pattern truth.
    regime = np.where(agreement > 0, "agree", "disagree")
    if family == "motion":
        regime = np.where(velocity_norm >= 1.0, "velocity_shock", "risk_only")
    if family == "report":
        revision = np.max(np.abs(damage - d["damage"][si, ri, prev_ti]), axis=1)
        regime = np.where(revision >= .05, "large_report_revision", "small_report_revision")
    return {
        "x": x[keep].astype(np.float64), "control": x_control[keep].astype(np.float64),
        "si": si[keep], "ri": ri[keep], "ti": ti[keep], "time": t[keep],
        "source": src[keep], "regime": regime[keep], "market": market,
        "feature_names": feature_names, "control_names": control_names,
        "innovation_start": len(control_names) + len(names),
        "n_seasons": n,
    }


def labels(rows, horizon):
    valid = rows["time"] + horizon + 2 <= 778
    si, ri, ti = (rows[key][valid] for key in ("si", "ri", "ti"))
    market = rows["market"]
    y = market[si, ri, ti + horizon // 2 + 1] - market[si, ri, ti + 1]
    return valid, y


def ridge_fit(x, y, alpha=.02):
    mean = x.mean(axis=0)
    scale = x.std(axis=0)
    scale[scale < 1e-8] = 1
    z = np.clip((x - mean) / scale, -8, 8)
    center = z.mean(axis=0)
    z -= center
    ymean = y.mean(axis=0)
    gram = z.T @ z / len(z)
    gram.flat[::len(gram)+1] += alpha
    coef = np.linalg.solve(gram, z.T @ (y-ymean) / len(z))
    return {"mean": mean, "scale": scale, "center": center, "coef": coef,
            "ymean": ymean, "alpha": alpha, "n": len(y)}


def ridge_predict(model, x):
    z = np.clip((x-model["mean"]) / model["scale"], -8, 8) - model["center"]
    return z @ model["coef"] + model["ymean"]


def fit_from_rows(train, evaluation, config, control=False):
    horizon = int(config["horizon"])
    train_valid, ytrain = labels(train, horizon)
    eval_valid, yeval = labels(evaluation, horizon)
    key = "control" if control else "x"
    xt = train[key][train_valid]
    xe = evaluation[key][eval_valid]
    st = train["source"][train_valid]
    se = evaluation["source"][eval_valid]
    pred = np.zeros_like(yeval)
    pred_train = np.zeros_like(ytrain)
    innovation_contribution = np.zeros_like(yeval)
    models = {}
    for source in np.unique(st):
        m = ridge_fit(xt[st == source], ytrain[st == source], config.get("alpha", .02))
        models[int(source)] = m
        pred[se == source] = ridge_predict(m, xe[se == source])
        pred_train[st == source] = ridge_predict(m, xt[st == source])
        if not control:
            no_change = xe[se == source].copy()
            no_change[:, evaluation["innovation_start"]:] = 0
            innovation_contribution[se == source] = (pred[se == source] -
                                                     ridge_predict(m, no_change))
    n = evaluation["n_seasons"]
    delta = np.zeros((n, 3, 390, 12), dtype=np.float32)
    event_source = np.zeros((n, 3, 390), dtype=np.int8)
    event_regime = np.zeros((n, 3, 390), dtype=np.int8)
    si, ri, ti = (evaluation[key][eval_valid] for key in ("si", "ri", "ti"))
    delta[si, ri, ti] = pred
    event_source[si, ri, ti] = se
    regime_names, regime_codes = np.unique(evaluation["regime"][eval_valid], return_inverse=True)
    event_regime[si, ri, ti] = regime_codes + 1

    def metrics(y, p):
        return {"n_events": len(y), "mse": float(np.mean((y-p)**2)),
                "zero_mse": float(np.mean(y**2)),
                "r2_zero": float(1-np.sum((y-p)**2)/np.sum(y**2)),
                "mae": float(np.mean(np.abs(y-p))),
                "mean_abs_forecast": float(np.mean(np.abs(p))),
                "per_symbol_mse": np.mean((y-p)**2, axis=0).tolist()}

    predictive = {"fit": metrics(ytrain, pred_train), "evaluation": metrics(yeval, pred)}
    predictive["by_source"] = {
        SOURCE_NAMES[int(s)]: metrics(yeval[se == s], pred[se == s]) for s in np.unique(se)}
    predictive["innovation_mean_abs_contribution"] = float(np.abs(innovation_contribution).mean())
    predictive["innovation_mean_abs_by_symbol"] = np.abs(innovation_contribution).mean(0).tolist()
    return {"delta": delta, "source": event_source, "regime": event_regime,
            "regime_names": regime_names.tolist(), "times": np.arange(390)*2,
            "horizon": horizon, "target_latency": 2, "models": models,
            "feature_names": train["control_names"] if control else train["feature_names"],
            "predictive_metrics": predictive, "config": dict(config)}


def fit_predict(data, train_ids, eval_ids, config):
    """Fit public event models and return dense, explicitly gated forecasts.

    `data` accepts a dict or an open numpy NpzFile. `train_ids` and `eval_ids` are
    zero-based indices INTO THAT DATA, never season labels. Result delta has
    shape [len(eval_ids),3,390,12]. It is valid only where result['source'] > 0.
    All feature construction is independent of labels; `market` future marks
    enter only training targets and returned predictive diagnostics.
    """
    if set(train_ids) & set(eval_ids):
        raise ValueError("Training and evaluation seasons overlap")
    train = event_rows(data, train_ids, config["family"])
    evaluation = event_rows(data, eval_ids, config["family"])
    return fit_from_rows(train, evaluation, config)
