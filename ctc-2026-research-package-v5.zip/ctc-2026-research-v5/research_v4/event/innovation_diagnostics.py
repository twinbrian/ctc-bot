"""Post-freeze, inner-only diagnostics of an existing model; no refit/search.

Zeroing innovation features is descriptive, not a new candidate or a causal
feature-importance claim: correlated level features remain in the fitted model.
"""

import json
import pickle
from pathlib import Path

import numpy as np

from event_model import SYMBOLS, event_rows, labels, ridge_predict

ROOT = Path(__file__).resolve().parent


def run():
    frozen = json.loads((ROOT / "frozen.json").read_text())
    data = np.load(ROOT.parent / "development.npz", allow_pickle=False)
    ids = np.where((data["season_ids"] >= 241) & (data["season_ids"] <= 360))[0]
    output = []
    for candidate in frozen["candidates"]:
        config = candidate["config"]
        rows = event_rows(data, ids, config["family"])
        valid, y = labels(rows, config["horizon"])
        x, sources = rows["x"][valid], rows["source"][valid]
        models = pickle.load((ROOT / "inner" / candidate["id"] / "models.pkl").open("rb"))
        pred, no_change = np.zeros_like(y), np.zeros_like(y)
        coefficient_summary = []
        for source, model in models.items():
            which = sources == source
            pred[which] = ridge_predict(model, x[which])
            modified = x[which].copy()
            modified[:, rows["innovation_start"]:] = 0
            no_change[which] = ridge_predict(model, modified)
            for j, symbol in enumerate(SYMBOLS):
                coef = model["coef"][:,j]
                order = np.argsort(-np.abs(coef))[:12]
                coefficient_summary.append({"source": source, "symbol": symbol,
                    "largest_standardized_coefficients": [
                        {"feature": rows["feature_names"][k], "coefficient": float(coef[k])}
                        for k in order]})
        delta = pred-no_change
        # Scalar through-origin slope of realized innovation residual on the
        # model's innovation contribution, descriptive only.
        slope = np.sum(delta*(y-no_change), axis=0)/np.maximum(np.sum(delta**2, axis=0), 1e-12)
        per_symbol = []
        for j, symbol in enumerate(SYMBOLS):
            per_symbol.append({"symbol": symbol,
                "full_mse": float(np.mean((y[:,j]-pred[:,j])**2)),
                "zero_innovation_mse": float(np.mean((y[:,j]-no_change[:,j])**2)),
                "innovation_abs_mean": float(np.mean(np.abs(delta[:,j]))),
                "residual_alignment_slope": float(slope[j])})
        output.append({"candidate": candidate["id"], "split": "inner_241_360_only",
            "n_events": len(y), "full_mse": float(np.mean((y-pred)**2)),
            "zero_innovation_mse": float(np.mean((y-no_change)**2)),
            "per_symbol": per_symbol, "coefficients": coefficient_summary,
            "limitations": "Zero substitution is descriptive; correlated public levels remain. No refit and no policy retuning."})
    (ROOT / "innovation_diagnostics.json").write_text(json.dumps(output, indent=2)+"\n")
    for row in output:
        print(row["candidate"], "full MSE", row["full_mse"],
              "zero-innovation MSE", row["zero_innovation_mse"])


if __name__ == "__main__":
    run()
