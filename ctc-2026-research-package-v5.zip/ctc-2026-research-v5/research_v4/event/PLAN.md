# Information-innovation research: preregistered plan

Written 2026-10-19, before inspecting any price-change labels or scoring policies.
Scope: only `../development.npz`; no original seasons 1–120, parent cache, outer
outcomes, reference forecasts, or sibling results. All writes stay in this folder.

## Hypotheses and finite family

The house may assimilate **changes** in public hurricane information slowly.
Trade only identifiable events at/after real second 120, excluding formation:

1. **news:** official advisory publications (150,210,...,510) and observed wire
   category changes between 120 and 538. Official cone/probability revisions and
   changes in official/wire agreement alter the distribution of future impacts.
2. **motion:** 10-second observation innovations on a 10-second decision grid,
   120..530. Trigger when the 10-second velocity-change norm is at least 1.0
   map-unit/second OR the largest company projected peak-wind change is >=0.05.
   These are preset physical thresholds, not selected on returns.
3. **report:** preliminary publication at 570 and final correction at 740.
   Compare published damage/loss to measured impact and the prior public report.

For each family fit a separate standardized, multi-output linear ridge forecast
at **6, 10, 30, and 60 real seconds**: **12 eligible policy configurations total**.
Targets are `price(t+h+2)-price(t+2)`; they measure response remaining after the
baseline two-second order latency. Samples without a same-round target are absent
(in particular, final-report h=60). A single fixed normalized ridge penalty 0.02,
feature clipping at 8 training standard deviations, and separate intercepts/source
interactions are used. Prices and features at decision time only are predictors.
No season ID, storm name, latent pattern, future path/report, or settlement input.

Features: current public context, lagged house prices, current/lagged measured
wind risk and cumulative impacts, linearly projected physical risk, advisory
category transitions, probability/cone revisions, and published report changes.
Linear projections use only observed position/velocity and a finite fixed grid;
they are not future realized paths. No boosted trees or generic all-tick fit.

## Split and selection

- Fit seasons 361..600; score every one of the 12 policies on 241..360.
- Rank by arithmetic mean net season PnL, subject to positive incremental mean
  versus the same-event clock/price-only diagnostic and nonnegative combined
  cost/latency stress. Return at most two, preferably economically distinct.
- The same-event clock/price-only ridge is a **diagnostic ablation**, not an
  eligible replacement policy (12 ablations; 24 total forecast specifications).
- If nothing qualifies, freeze the best primary configuration as a negative
  research result and clearly reject deployment.
- Write `frozen.json` before any evaluation on seasons 121..240. Refit frozen
  forecasts on 241..600, run validation once, save all season-level results, and
  do not change selected features, gates, horizons, or parameters afterward.
- This dataset has previously informed research; validation is not fresh proof.

## Execution and diagnostics fixed in advance

One active lot per symbol; up to two new symbols per event; lot <=50 shares and
published position limits. Rank by predicted net dollars. Enter only if absolute
forecast exceeds estimated two-leg 25bp + $0.02/share/side costs plus $0.15/share.
Submit exit at decision t+h (or after entry arrival if latency exceeds h).
Arrival-time consensus marks plus adverse costs; no passive fill assumption.
All positions actually close before each round ends; both short legs are charged.
Enforce per-symbol 50-share/2s capacity, pending reservations, and one key's
60 actions/rolling real minute with exit reservations. No ETF conversion credits.

Prespecified execution scenarios: baseline; latency 6s; 50bp+$0.04/side;
depth 25 shares; combined latency 6s, 50bp+$0.04/side, additional adverse 10bp/side.
Gate/ranking fee assumptions remain frozen at baseline under stresses.

For selected configurations only, report **non-selectable** local sensitivity:
ridge penalties 0.01 and 0.04 and entry margins $0.05 and $0.25, on the inner
split only. These diagnostics cannot generate replacement configurations.
Report symbol, source, round, decision-time bucket, and observed agreement/
motion/impact regime attribution; realized latent storm labels, if used at all,
are diagnostic only. Include fit/inner predictive error and event-response
statistics, every attempted metric, and all negative results.

## Deliverables and resource limits

Runnable causal `fit_predict(data, train_ids, eval_ids, config)` with zero-based
indices into the provided data, explicit real-second times/horizons, a bounded
standalone simulator, all candidate metrics, frozen parameters, per-season
validation CSV, and `HANDOFF.md` describing integration with formation positions.
OMP/BLAS threads=1; one worker; no child agents; finish by 06:30 UTC.
