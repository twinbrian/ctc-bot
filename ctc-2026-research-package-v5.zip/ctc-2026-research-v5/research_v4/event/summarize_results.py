"""Descriptive reporting of saved results only; no fitting or policy selection."""

import csv
import json
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent


def run():
    inner = json.loads((ROOT / "inner" / "all_metrics.json").read_text())
    lines = ["# Recorded event-study results", "", "## Entire inner grid", "",
             "| Family | Horizon | Mean net | SE | Clock/price control | Increment | Combined stress | Trades/season | Qualifies |",
             "|---|---:|---:|---:|---:|---:|---:|---:|---|"]
    for r in inner:
        c, b = r["config"], r["metrics"]["base"]
        lines.append(f"| {c['family']} | {c['horizon']} | {b['mean_pnl']:.2f} | {b['se_pnl']:.2f} | "
                     f"{r['control']['base']['mean_pnl']:.2f} | {r['incremental_mean']:.2f} | "
                     f"{r['metrics']['combined']['mean_pnl']:.2f} | {b['mean_trades']:.1f} | {r['qualifies']} |")
    path = ROOT / "validation" / "all_metrics.json"
    if path.exists():
        validation = json.loads(path.read_text())
        lines += ["", "## Frozen one-time validation", "",
                  "| Candidate | Scenario | Mean net | SE | Median | Min | Gross | Cost | Actions | Worst drawdown |",
                  "|---|---|---:|---:|---:|---:|---:|---:|---:|---:|"]
        for r in validation:
            for scenario, m in r["metrics"].items():
                lines.append(f"| {r['candidate']} | {scenario} | {m['mean_pnl']:.2f} | {m['se_pnl']:.2f} | "
                             f"{m['median_pnl']:.2f} | {m['min_pnl']:.2f} | {m['mean_gross_pnl']:.2f} | "
                             f"{m['mean_cost']:.2f} | {m['mean_actions']:.1f} | {m['worst_drawdown']:.2f} |")
        lines += ["", "## Validation attribution", "",
                  "Time buckets are [120,210), [210,330), [330,450), [450,540), preliminary at570, final at740."]
        for r in validation:
            b = r["metrics"]["base"]
            lines += ["", f"### {r['candidate']}", "",
                      f"Clock/price-only control: ${r['control']['base']['mean_pnl']:.2f}/season; "
                      f"paired increment ${r['incremental_mean']:.2f}, SE ${r['incremental_se']:.2f}.",
                      f"Time-bucket means: {np.round(b['time_bucket_mean_pnl'], 2).tolist()}.",
                      f"Round means: {np.round(b['round_mean_pnl'], 2).tolist()}.",
                      f"Sources: {json.dumps({k: round(v, 2) for k,v in b['source_mean_pnl'].items()})}.",
                      f"Symbols: {json.dumps({k: round(v, 2) for k,v in b['symbol_mean_pnl'].items()})}.",
                      f"Regimes: {dict(zip(r['regime_names'], np.round(b['regime_mean_pnl'],2).tolist()))}.",
                      f"Maximum rolling actions: {b['max_rolling_actions']}; maximum symbol-limit fraction: "
                      f"{b['max_position_fraction']:.2f}."]
    sensitivity = ROOT / "sensitivity" / "metrics.json"
    if sensitivity.exists():
        lines += ["", "## Inner-only, non-selectable parameter neighbors", "",
                  "| Candidate | Parameter | Value | Mean net |", "|---|---|---:|---:|"]
        for r in json.loads(sensitivity.read_text()):
            lines.append(f"| {r['candidate']} | {r['parameter']} | {r['value']} | "
                         f"{r['metrics']['base']['mean_pnl']:.2f} |")
    (ROOT / "RESULTS.md").write_text("\n".join(lines)+"\n")
    print("Wrote RESULTS.md from preserved metrics.")


if __name__ == "__main__":
    run()
