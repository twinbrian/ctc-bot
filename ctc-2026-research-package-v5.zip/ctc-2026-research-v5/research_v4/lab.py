"""Small data/metrics helpers for development agents. No policy selection."""

from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent


def load_development():
    return dict(np.load(ROOT / "development.npz", allow_pickle=False))


def masks(data):
    ids = data["season_ids"]
    return ids >= 361, (ids >= 241) & (ids <= 360), ids <= 240


def subset(data, mask):
    """Slice only season axes, preserving static sites and filtered advisory IDs."""
    ids = data["season_ids"][mask]
    n = len(data["season_ids"])
    result = {}
    for key, value in data.items():
        if key == "advisories":
            result[key] = value[np.isin(value[:, 0], ids)]
        elif value.ndim and value.shape[0] == n:
            result[key] = value[mask]
        else:
            result[key] = value
    return result


def summarize_pnl(pnl):
    pnl = np.asarray(pnl)
    rng = np.random.default_rng(2026)
    means = pnl[rng.integers(0, len(pnl), (5000, len(pnl)))].mean(1)
    return {"seasons": int(len(pnl)), "mean_usd": float(pnl.mean()),
            "median_usd": float(np.median(pnl)), "win_rate": float((pnl > 0).mean()),
            "minimum_usd": float(pnl.min()), "p05_usd": float(np.quantile(pnl, .05)),
            "std_usd": float(pnl.std(ddof=1)),
            "conditional_mean_ci95_usd": np.quantile(means, [.025, .975]).tolist()}
