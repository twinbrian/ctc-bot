"""Create a new-adaptation-restricted subset for independent research agents."""

import json
from pathlib import Path

import numpy as np


def main():
    project = Path(__file__).resolve().parent.parent
    out = project / "research_v4"
    raw = dict(np.load(project / "cache.npz", allow_pickle=False))
    subset = {}
    for key, value in raw.items():
        if key == "advisories":
            subset[key] = value[value[:, 0] >= 121]
        elif value.ndim and value.shape[0] == 600:
            subset[key] = value[120:]
        else:
            subset[key] = value
    subset["season_ids"] = np.arange(121, 601)
    np.savez_compressed(out / "development.npz", **subset)
    short = dict(np.load(project / "short_predictions.npz", allow_pickle=False))
    fair = dict(np.load(project / "predictions.npz", allow_pickle=False))
    np.savez_compressed(out / "reference.npz", season_ids=np.arange(121, 601),
                        delta=short["delta"][120:], times=short["times"],
                        final_fair=fair["structural"][120:, 2, 74])
    manifest = {
        "season_ids": "121..600", "n": 480,
        "fit": "361..600", "inner_tune": "241..360", "validation_once": "121..240",
        "outcomes_from_seasons_1_to_120_included": False,
        "reference_forecast_model_fit": "241..600; in-sample on those rows",
        "array_shapes": {k: list(v.shape) for k, v in subset.items()},
    }
    (out / "development_manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    for name in ["event", "relative", "formation", "audit", "lead"]:
        (out / name).mkdir(exist_ok=True)
    print("Prepared 480 development seasons and reference forecasts; no seasons 1..120.")


if __name__ == "__main__":
    main()
