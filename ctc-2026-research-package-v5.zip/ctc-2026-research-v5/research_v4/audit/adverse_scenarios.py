"""Fixed-policy synthetic execution stresses, not a strategy/PnL search.

The scenarios use invented marks. Fault injection is explicit in-memory source
instrumentation; it does not establish that the original replay supports faults.
"""

import json

from audit_checks import HERE, BASKETS, LIMITS, fixture, formation_fixture, local_module, np, simulate, simulate_routes, with_etfs


def scheduled_formation(jump_second=64):
    args = formation_fixture()
    args[0][:] = with_etfs(np.full(10, 100.0))
    change = np.array([4, 3, 2, 5, 2, -3, -2, -4, 3, 1])
    args[0][:, :, jump_second // 2:, :10] += change
    # ETF consensus follows the same synthetic stock jump six seconds later.
    args[0][:, :, (jump_second + 6) // 2:, 10:] += change @ BASKETS.T
    return args


def rejection_stress():
    """An acknowledged atomic conversion rejection: no partial conversion."""
    module = local_module("etf_route_v3.py", [
        ("                if kind == \"market\":", "                change = execution_fault(r, ti, change, kind)\n                if kind == \"market\":"),
    ])
    rejected = []

    def reject(r, ti, change, kind):
        if kind == "convert" and not rejected:
            rejected.append({"round": r + 1, "second": ti * 2, "delta": change.tolist()})
            return np.zeros_like(change)
        return change

    module["execution_fault"] = reject
    args = formation_fixture()
    baseline = simulate_routes(args[0], args[1], args[4], start=20, exit_at=100)
    stressed = module["simulate_routes"](args[0], args[1], args[4], start=20, exit_at=100)
    assert np.all(stressed["positions"] == 0)
    return {"fault": rejected, "baseline_pnl": baseline["pnl"].tolist(), "stress_pnl": stressed["pnl"].tolist(), "stress_flat_times": stressed["flat_times"].tolist(), "status": "this single rejection recovers via observed positions; not general rejection support"}


def partial_remainder_stress():
    """Half of the first market order fills; the rest stays live and reserved."""
    module = local_module("etf_route_v3.py", [
        ("                if kind == \"market\":", "                executed = execution_fault(r, ti, change, kind)\n                remainder = change - executed\n                pp[i] += np.maximum(remainder, 0)\n                pn[i] += np.maximum(-remainder, 0)\n                change = executed\n                if kind == \"market\":"),
    ])
    partial = []

    def half(r, ti, change, kind):
        if kind == "market" and not partial:
            executed = np.sign(change) * (np.abs(change) // 2)
            partial.append({"round": r + 1, "second": ti * 2, "requested": change.tolist(), "executed": executed.tolist()})
            return executed
        return change

    module["execution_fault"] = half
    args = formation_fixture()
    try:
        module["simulate_routes"](args[0], args[1], args[4], start=20, exit_at=100)
    except AssertionError as error:
        assert "flatten" in str(error)
        return {"fault": partial, "status": "round-end assertion; unresolved remainder prevents closing handover", "error": str(error)}
    raise AssertionError("Expected the missing cancellation/remainder lifecycle to be exposed")


def jittered_arrival_depth():
    """Batch arrivals into ten-second buckets: 2..10 seconds of latency.

    This is a deliberate change to the fixed-latency premise, not a claim that
    the baseline simulator offers variable latency. It illustrates why depth
    must be consumed at fill time once latency is variable.
    """
    module = local_module("etf_route_v3.py", [
        ("queue[ti + delay].append((i.copy(), change.copy(), kind))", "queue[((ti + delay + 4) // 5) * 5].append((i.copy(), change.copy(), kind))"),
        ("                q[i] += change", "                audit_fill(r, ti, change, kind)\n                q[i] += change"),
    ])
    fills = {}

    def record(r, ti, change, kind):
        if kind == "market":
            for j in np.flatnonzero(change[0]):
                fills[r, ti, int(j)] = fills.get((r, ti, int(j)), 0) + abs(int(change[0, j]))

    module["audit_fill"] = record
    args = formation_fixture()
    result = module["simulate_routes"](args[0], args[1], args[4], start=20, exit_at=100)
    peak = max(fills.values())
    assert peak > 50
    return {"maximum_market_shares_one_symbol_one_arrival_tick": peak, "stated_depth": 50, "peak_tick": [list(k) for k, v in fills.items() if v == peak][:3], "positions_flat": bool(np.all(result["positions"] == 0)), "status": "fixed-latency admission-depth equivalence fails under bunched arrivals"}


def ignored_resting_adverse_fill():
    args = fixture()
    args[1][0, 0] = 90
    args[3][0, 0] = 110
    args[0][0, 2, 370:378:2, 0] = 100
    args[0][0, 2, 371:378:2, 0] = 120
    args[0][0, 2, 378:386, 0] = 120
    args[0][0, 2, 386:, 0] = 100
    result = simulate(*args, end_margin=0, cost_bps=0, fixed_cost=0, audit=True)
    assert result["pnl"][0] == 0
    assert result["actions"][0] == 4
    # Four 50-share limits are live. An explicit adverse alternative fills 50
    # shares at each of t772,774,776,778, at 100, before settlement at 90.
    alternative = 4 * 50 * (90 - 100)
    return {"nominal_replay_pnl": float(result["pnl"][0]), "live_buy_limits_shares": 200, "adverse_fill_alternative_pnl": alternative, "alternative_assumption": "50 shares/tick of retained limits execute at 100 on t772..778; settlement=90", "status": "ignoring later resting fills is not a worst-case PnL bound"}


def main():
    # This finite stress table is fixed in source before execution. It never
    # compares policies or chooses the best timing, cost or execution parameter.
    cases = [
        ("base", 64, {}),
        ("formation_20s_later", 84, {}),
        ("formation_60s_later", 124, {}),
        ("latency_12s", 64, {"latency": 12}),
        ("replenishment_10s", 64, {"replenish_seconds": 10}),
        ("replenishment_30s", 64, {"replenish_seconds": 30}),
        ("depth_10_latency_12_replenishment_10", 64, {"depth": 10, "latency": 12, "replenish_seconds": 10}),
    ]
    results = []
    for name, jump, stress in cases:
        args = scheduled_formation(jump)
        result = simulate_routes(args[0], args[1], args[4], start=20, exit_at=100, **stress)
        results.append({"scenario": name, "synthetic_pnl": float(result["pnl"][0]), "actions": int(result["actions"][0]), "cost": float(result["cost"][0]), "flat_times": result["flat_times"].tolist()})
    output = {"qualification": "Invented paths and one fixed policy; numbers are not historical performance or live estimates", "fixed_policy": {"start": 20, "exit_at": 100, "fraction": 1}, "fixed_policy_stresses": results,
              "atomic_rejection": rejection_stress(), "partial_live_remainder": partial_remainder_stress(), "arrival_bunching": jittered_arrival_depth(), "resting_fill_risk": ignored_resting_adverse_fill()}
    (HERE / "adverse.json").write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
