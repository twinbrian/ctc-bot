# Audit handoff

Read `AUDIT.md` for severity, exact source lines, fixes and rerun boundaries.

**Nominal route accounting passed:** coherent ETF conversion has zero cash/value
creation, market costs reconcile independently, all-leg route reservations survive
reversed same-time arrivals, and t+2s arrival prices are used. All **39 baseline
tests + 11 independent audit tests pass**; some audit tests prove defects.

Confirmed issues:
1. **High, conditional on round gap:** per-round action-history reset. Synthetic
   contiguous-round maxima are **95** (v2 combined) and **84** (v3 routed combined),
   while both report60. Verify actual inter-round timing before trusting combined
   action compliance. A fix affects execution/selection, not forecast fitting.
2. **High, delayed-feed case:** prepared storm observations ignore publication time;
   an age60 message published124 is visible in replay at120.
3. **Medium, reordered-feed case:** final reports regress to preliminary and prefix
   readers can stop before already-published records. Canonical sorted feeds pass.
4. **Medium, expanded latency:** v2 signed-net pending capacity permits ARCH100
   pending buys versus limit50 at latency22s. Published <=12s results are not
   proven affected; routed separate-side reservations do not have this defect.

Execution stresses remain assumptions: one partial live hedge strands route
closing; variable latency can bunch250 shares into a nominal50-share arrival
interval; ignoring later resting fills can omit losses. A single acknowledged
conversion rejection recovered in the tested example. These are synthetic fault
demonstrations, not measured execution outcomes.

Fit-only development diagnostics confirm stock response near+4s and ETF response
near+10s. No depth/replenishment/latency is identified by consensus data. Recommend
one continuous-time account with actual arrival liquidity, explicit acknowledgments,
partial/cancel/reject handling, and fixed-policy joint execution stresses before
candidate promotion. The ~USD11,101 mean was not rerun and is not live-attainable
profit evidence; v3's post-selection/bootstrap qualifiers are materially accurate.

Reproduce with `bash run_audit.sh` in this directory. All writes are local; no
baseline changes, external services, child agents or policy tuning. Only fit
seasons361–600 market data were analyzed. Scope caveat: the whole-file prior report
read exposed an embedded1–120 aggregate fold summary; no underlying/season-level
outcome files were opened or used. Full details are in `AUDIT.md`.
