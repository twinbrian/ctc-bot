"""Canonical prefix-selection equivalence without reading numerical outcomes.

Loads sanitized timing metadata only. Executes the ORIGINAL public_prefix code
with virtual files whose payloads are unique artificial event tokens. This tests
which observation/quote/report/advisory is exposed, not real economic values.
All raw-file enumeration and SHA256 work is done once by scan_metadata.py.
"""

import gzip
import hashlib
import inspect
import json
import os
from pathlib import Path
import sys
from types import FunctionType, SimpleNamespace

HERE = Path(__file__).resolve().parent
PROJECT = HERE.parents[2]
sys.dont_write_bytecode = True
for name in (
    "OMP_NUM_THREADS",
    "OPENBLAS_NUM_THREADS",
    "MKL_NUM_THREADS",
    "NUMEXPR_NUM_THREADS",
):
    os.environ[name] = "1"
sys.path.insert(0, str(PROJECT))

import numpy as np
from common import ISLANDS, PHYSICAL, SYMBOLS
from predict_prefix import public_prefix
from reference_adapter import Publication, ReferenceAdapter, publication

CHECKPOINTS = [0, 60, 90, 120, 538, 540, 570, 740, 778]


def tokenize(messages, quotes):
    feed = []
    for meta in messages:
        m = meta.copy()
        token = m["seq"] + 2
        kind = m["type"]
        if kind == "storm":
            m.update(
                dict.fromkeys(["x", "y", "vx", "vy", "radius", "intensity"], token)
            )
        elif kind == "damage_report":
            m["damage_pct"] = dict.fromkeys(PHYSICAL, 100 * token)
            m["industry_loss_musd"] = token
        elif kind == "advisory":
            # A tokenized label index is deliberate: unlike six repeated
            # outlook labels, it distinguishes every selected advisory event.
            m["outlook"] = token
            if m["source"] == "official":
                m["hurricane_conditions"] = dict.fromkeys(ISLANDS, token)
                m["cone"] = [
                    {"age": m["age"] + lead, "x": token, "y": token, "spread": token}
                    for lead in [60, 240]
                ]
        feed.append(m)
    market = []
    for k, meta in enumerate(quotes):
        market.append({**meta, **dict.fromkeys(SYMBOLS, 10000 + k)})
    return feed, market


def virtual_legacy(feed, market):
    case = {
        "companies": {
            name: {
                "sites": [{"x": 0, "y": 0, "weight": 1 / count} for _ in range(count)]
            }
            for name, count in zip(PHYSICAL, [1, 3, 4, 5, 4])
        }
    }

    class VirtualPath:
        def __init__(self, name):
            self.name = str(name)

        def __truediv__(self, part):
            return VirtualPath(self.name + "/" + str(part))

        def read_text(self):
            assert self.name.endswith("case.json")
            return case

        def open(self):
            if self.name.endswith("market.csv"):
                return market
            assert self.name.endswith("feed.jsonl")
            return feed

    namespace = public_prefix.__globals__.copy()
    namespace.update(
        Path=VirtualPath,
        json=SimpleNamespace(loads=lambda x: x),
        csv=SimpleNamespace(DictReader=lambda x: x),
        OUTLOOKS=SimpleNamespace(index=lambda token: token),
    )
    return FunctionType(public_prefix.__code__, namespace)


def artificial_receipt(p):
    # An ordered test coordinate only. 10000 has NO wall-clock interpretation.
    return p.round * 10000 + p.second


def compare_snapshot(state, cube, r, t):
    known_obs = {
        (rr - 1, int(age // 2)): event
        for (rr, age), event in state["observations"].items()
    }
    expected_obs = np.zeros((3, 241, 6))
    expected_obs[..., 4] = 1
    for (rr, index), event in known_obs.items():
        expected_obs[rr, index] = event.message["seq"] + 2
    np.testing.assert_array_equal(cube["obs"][0], expected_obs)
    expected_market = np.ones((3, 390, 12))
    for p, event in state["quotes"].items():
        expected_market[p.round - 1, int(p.second // 2)] = list(
            event.message["prices"].values()
        )
    np.testing.assert_array_equal(cube["market"][0], expected_market)
    for rr in range(1, r + 1):
        tick = t // 2 if rr == r else 389
        reports = [
            event for (round_id, _), event in state["reports"].items() if round_id == rr
        ]
        assert len(reports) <= 1
        expected = reports[0].message["seq"] + 2 if reports else 0
        np.testing.assert_array_equal(cube["damage"][0, rr - 1, tick], [expected] * 5)
        assert cube["loss"][0, rr - 1, tick] == expected
        assert cube["stage"][0, rr - 1, tick] == (
            2
            if reports and reports[0].message["stage"] == "final"
            else int(bool(reports))
        )
        for source in ["official", "wire"]:
            adv = state["advisories"].get((rr, source))
            assert cube[source][0, rr - 1, tick] == (
                adv.message["seq"] + 2 if adv else -1
            )
            if source == "official" and adv:
                np.testing.assert_array_equal(
                    cube["probability"][0, rr - 1, tick], [adv.message["seq"] + 2] * 4
                )
                np.testing.assert_array_equal(
                    cube["cone"][0, rr - 1, tick], [adv.message["seq"] + 2] * 9
                )
        assert state["observation_status"][rr]["trajectory_complete_asof"]
        assert not state["observation_status"][rr]["stale"]


def run_binding():
    functions = (tokenize, virtual_legacy, artificial_receipt, compare_snapshot)
    return {
        "reference_sha256": hashlib.sha256(
            (HERE / "reference_adapter.py").read_bytes()
        ).hexdigest(),
        "original_sha256": hashlib.sha256(
            (PROJECT / "predict_prefix.py").read_bytes()
        ).hexdigest(),
        "metadata_sha256": hashlib.sha256(
            (HERE / "metadata_only.jsonl.gz").read_bytes()
        ).hexdigest(),
        "comparison_sha256": hashlib.sha256(
            "".join(inspect.getsource(f) for f in functions).encode()
        ).hexdigest(),
    }


def main(resume=False):
    reference_hash = hashlib.sha256(
        (HERE / "reference_adapter.py").read_bytes()
    ).hexdigest()
    original_hash = hashlib.sha256(
        (PROJECT / "predict_prefix.py").read_bytes()
    ).hexdigest()
    summary = json.loads((HERE / "scan_results.json").read_text())
    checks = summary["checks"]
    required = [
        key for key in checks if key not in ("seq_gaps", "terminal_observations_age480")
    ]
    assert all(checks[key] == 0 for key in required), (
        "Canonical predicates failed; do not claim equivalence"
    )
    records = []
    output = HERE / "equivalence_progress.jsonl"
    binding_path = HERE / "equivalence_binding.json"
    binding = run_binding()
    if resume:
        saved = json.loads(binding_path.read_text())
        assert all(saved[key] == value for key, value in binding.items()), (
            "Resume inputs/code changed"
        )
        records = [json.loads(line) for line in output.read_text().splitlines()]
        assert all(row["matched"] for row in records)
    else:
        binding_path.write_text(json.dumps(binding, indent=2) + "\n")
    completed = {row["season"] for row in records}
    assert len(completed) == len(records)
    resumed_seasons = len(records)
    with (
        gzip.open(HERE / "metadata_only.jsonl.gz", "rt") as archive,
        output.open("a" if resume else "w") as progress,
    ):
        for line in archive:
            data = json.loads(line)
            assert 121 <= data["season"] <= 600
            if data["season"] in completed:
                continue
            feed, market = tokenize(data["messages"], data["quotes"])
            legacy = virtual_legacy(feed, market)
            adapter = ReferenceAdapter()
            for msg in feed:
                adapter.ingest(msg, received_at=artificial_receipt(publication(msg)))
            for row in market:
                adapter.ingest(
                    {
                        "type": "quote",
                        "round": row["round"],
                        "time": row["time"],
                        "prices": {symbol: row[symbol] for symbol in SYMBOLS},
                    },
                    received_at=artificial_receipt(publication(row)),
                )
            # Exhaustive metadata membership over every two-second grid cutoff:
            # bisect (legacy early break) versus an independent filter (as-of).
            keys = np.array([artificial_receipt(publication(m)) for m in feed])
            quote_keys = np.array([artificial_receipt(publication(m)) for m in market])
            cutoffs = np.array(
                [
                    artificial_receipt(Publication(r, t))
                    for r in range(1, 4)
                    for t in range(0, 780, 2)
                ]
            )
            for series in [keys, quote_keys]:
                np.testing.assert_array_equal(
                    np.searchsorted(series, cutoffs, side="right"),
                    np.sum(series[None, :] <= cutoffs[:, None], axis=1),
                )
            grid_checks = len(cutoffs)
            for r in range(1, 4):
                for t in CHECKPOINTS:
                    state = adapter.snapshot(
                        round_number=r,
                        second=t,
                        received_through=artificial_receipt(Publication(r, t)),
                    )
                    cube = legacy("virtual", data["season"], r, t)
                    compare_snapshot(state, cube, r, t)
            record = {
                "season": data["season"],
                "grid_prefixes": grid_checks,
                "original_adapter_tokenized_prefixes": 3 * len(CHECKPOINTS),
                "matched": True,
            }
            records.append(record)
            progress.write(json.dumps(record) + "\n")
            progress.flush()
    assert {row["season"] for row in records} == set(range(121, 601))
    result = {
        "seasons": len(records),
        "season_range": [121, 600],
        "exhaustive_grid_prefixes": sum(x["grid_prefixes"] for x in records),
        "tokenized_original_adapter_prefixes": sum(
            x["original_adapter_tokenized_prefixes"] for x in records
        ),
        "checkpoint_seconds": CHECKPOINTS,
        "all_matched": True,
        "resumed_completed_seasons": resumed_seasons,
        "input_manifest_sha256": summary["manifest_sha256"],
        "original_adapter_sha256": original_hash,
        "reference_adapter_sha256": reference_hash,
        "qualification": "Metadata selection/as-of equivalence, including original adapter execution on artificial identity tokens. No real numerical weather, price or report payload comparison; no recorded network receipts.",
    }
    assert (
        hashlib.sha256((HERE / "reference_adapter.py").read_bytes()).hexdigest()
        == reference_hash
    )
    assert (
        hashlib.sha256((PROJECT / "predict_prefix.py").read_bytes()).hexdigest()
        == original_hash
    )
    (HERE / "equivalence_results.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main(resume="--resume" in sys.argv)
