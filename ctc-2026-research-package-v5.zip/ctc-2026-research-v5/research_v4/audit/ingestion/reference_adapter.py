"""Receipt-aware reference ingestion, with no strategy or synthetic trajectory.

Publication is a (round, round-relative second) logical key. ``received_at`` is
an independently supplied monotonic wall-clock timestamp. They are NEVER added
together: fictional dates and round duration cannot identify inter-round pauses.
Archived feeds have no receipts; an explicit archive replay clock may be used
for tests, but is not evidence of actual network receipt time.
"""

from copy import deepcopy
from dataclasses import dataclass, replace
import json
import math


@dataclass(frozen=True, order=True)
class Publication:
    round: int
    second: float

    def __post_init__(self):
        if not 1 <= self.round <= 3 or not math.isfinite(self.second):
            raise ValueError("Invalid publication clock")


def publication(message):
    """Clock-of-day only; no subtraction of fictional dates."""
    clock = message["time"].split("T", 1)[1]
    hour, minute, second = map(int, clock.split(":")[:3])
    return Publication(
        int(message["round"]), (hour * 3600 + minute * 60 + second - 34200) / 30
    )


@dataclass(frozen=True)
class Receipt:
    publication: Publication
    received_at: float
    event_age: float | None
    message: dict

    @property
    def version(self):
        return self.publication, self.message.get("seq", -1)


class DuplicateConflict(ValueError):
    """Same event identity with different payload: caller must reconcile it."""


def usable_observation(event):
    fields = ("x", "y", "vx", "vy", "radius", "intensity")
    values = [event.message.get(field) for field in fields]
    return (
        all(
            isinstance(value, (int, float)) and math.isfinite(value) for value in values
        )
        and event.message["radius"] > 0
    )


class ReferenceAdapter:
    def __init__(self):
        self._events = {}
        self._fingerprints = {}
        self.duplicates = 0

    def ingest(self, message, *, received_at):
        """Store one received envelope, idempotently. Never synthesize receipts.

        Quotes use type='quote' and a caller's payload, e.g. a prices dictionary.
        Feed seq is season-global; create a new adapter on competition-ID change.
        Calling order may differ from publication or receipt order. Identical
        duplicates retain the earliest actual receipt; conflicts raise loudly.
        """
        if not math.isfinite(received_at):
            raise ValueError("received_at must be a finite monotonic-clock reading")
        p = publication(message)
        kind = message["type"]
        key = ("quote", p) if kind == "quote" else ("feed", message["seq"])
        age = message.get("age")
        if kind == "storm":
            if age is None or not math.isfinite(age) or age < 0:
                raise ValueError("Storm observation needs nonnegative finite event age")
            if 60 + age > p.second:
                raise ValueError("Storm observation published before its event age")
        fingerprint = json.dumps(message, sort_keys=True, separators=(",", ":"))
        if key in self._events:
            if self._fingerprints[key] != fingerprint:
                raise DuplicateConflict(f"Conflicting duplicate identity {key}")
            self.duplicates += 1
            old = self._events[key]
            self._events[key] = replace(
                old, received_at=min(old.received_at, received_at)
            )
            return False
        self._fingerprints[key] = fingerprint
        self._events[key] = Receipt(p, received_at, age, deepcopy(message))
        return True

    def snapshot(self, *, round_number, second, received_through):
        """Return only information both published and received by this cutoff.

        There are no zero-filled future observations, forward-filled fake storm
        trajectories, or backdated corrections. Historical snapshots are rebuilt
        using original receipts, so later messages cannot change past knowledge.
        Reports use final-over-preliminary, then publication/seq version ordering.
        """
        if not math.isfinite(received_through):
            raise ValueError("received_through must be finite")
        now = Publication(round_number, second)
        visible = sorted(
            (
                x
                for x in self._events.values()
                if x.publication <= now and x.received_at <= received_through
            ),
            key=lambda x: x.version,
        )
        observations, reports, advisories, quotes = {}, {}, {}, {}
        visible_sequences = []
        for event in visible:
            msg = event.message
            r = event.publication.round
            kind = msg["type"]
            if "seq" in msg:
                visible_sequences.append(msg["seq"])
            if kind == "storm":
                observations[r, event.event_age] = event
            elif kind == "quote":
                quotes[event.publication] = event
            elif kind == "advisory":
                advisories[r, msg["source"]] = event
            elif kind == "damage_report":
                if msg["stage"] not in ("preliminary", "final"):
                    raise ValueError("Unknown report stage")
                key = (r, msg.get("storm"))
                old = reports.get(key)
                priority = (msg["stage"] == "final", event.version)
                if old is None or priority > (
                    old.message["stage"] == "final",
                    old.version,
                ):
                    reports[key] = event
        status = {}
        for r in range(1, round_number + 1):
            end = second if r == round_number else 778
            last_age = min(478, 2 * math.floor((end - 60) / 2))
            expected = list(range(0, last_age + 1, 2)) if last_age >= 0 else []
            missing = [age for age in expected if (r, age) not in observations]
            unusable = [
                age
                for age in expected
                if (r, age) in observations
                and not usable_observation(observations[r, age])
            ]
            # Age480 may be a terminal observation; retain it in the raw state,
            # but do not replace the last active-path sample (age478) with it.
            ages = [
                age
                for rr, age in observations
                if rr == r
                and age <= last_age
                and usable_observation(observations[rr, age])
            ]
            latest = observations[r, max(ages)] if ages else None
            status[r] = {
                "expected_latest_age": expected[-1] if expected else None,
                "latest": latest,
                "missing_ages": missing,
                "unusable_ages": unusable,
                "stale": bool(
                    expected and (latest is None or latest.event_age < expected[-1])
                ),
                "trajectory_complete_asof": not (missing or unusable),
                "storm_complete": end >= 540 and not (missing or unusable),
            }
        # Deep copy prevents callers from mutating the adapter through snapshots.
        return deepcopy(
            {
                "publication_cutoff": now,
                "receipt_cutoff": received_through,
                "observations": observations,
                "observation_status": status,
                "reports": reports,
                "advisories": advisories,
                "quotes": quotes,
                "visible_sequences": visible_sequences,
            }
        )
