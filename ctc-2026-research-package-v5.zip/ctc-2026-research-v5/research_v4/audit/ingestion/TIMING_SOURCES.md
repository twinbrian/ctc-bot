# Timing source excerpts

Source PDF: `/tmp/files/b8ad-[External] CTC 2026 Case Packet.pdf`.
Page numbers are PDF page numbers, counted from one.

## Packet page12, Section7 (testnet)

The comparison table is headed **Same as the live case** and **Different from
the live case**. “Message formats and round timing” is in the former column;
“The pauses between rounds” is in the latter column.

Exact timing paragraph:

> After each close, and after the testnet prepares a new season, the clock stops
> for 2 minutes. When the clock starts again, the market opens after 1 real minute.

The same page states that accounts, teams, bot keys and WebSocket connections
stay the same between testnet seasons, positions reset to zero, and the
competition gets a new ID. Reset ingestion identity on that competition change.

## Packet page3, Section2 (intraround clock)

> One market day, from 09:30 to 16:00, takes 13 real minutes. One real second is
> 30 market seconds. All feed timestamps use the market clock.

## Research data README

`hurricane-season-research/README.md:6–9` describes the same simulator and shared
rules, map, companies, ETFs, feed and timing. Lines27–29 explicitly say a round
takes780 real seconds and storm age is real seconds since formation. Lines63–68
describe sequence-ordered feed archives without snapshots. Lines72–76 identify
two-second house-consensus samples rather than traded prices/orderbooks.

## Starter-kit README

`hurricane-season-research/starter_kit/README.md:40–44` describes exact testnet
replay. Lines57–65 discuss connection gaps, snapshots and competition-ID changes.
Neither README supplies a numeric live inter-round pause.

## Interpretation

The specific packet exception governs the pause: testnet's stated two-minute
stop plus one real minute to opening must not be transferred to live. No elapsed
wall time was inferred from fictional dates. With no actions during the testnet
pause, prior 60-real-second action use has expired by the next open. Live should
retain one actual monotonic-clock action history, including any paused-period
actions; the supplied passages do not quantify the live gap.

Only timing excerpts are retained here. The full PDF's illustrative feed payloads
are not needed for the provenance analysis or included in this deliverable.
