# Ingestion provenance follow-up

## Historical scope resolved

**H2 and M1 are not observed in the authorized canonical histories, seasons
121–600.** Preserve the original `../AUDIT.md` findings as delayed/reordered
input counterexamples; this follow-up narrows their demonstrated historical
scope. There is no H2/M1-specific reason from this scan to revise the permitted
seasons' historical PnL. No PnL was calculated, and nothing here establishes
receipt-time or live execution validity.

Only explicitly enumerated `feed.jsonl` and `market.csv` files from seasons
121–600 were scanned. No historical manifest, settlement file, model or parent
cache was opened. Weather, price and damage-value payloads were discarded after
metadata projection; numerical payloads were not analyzed. The original audit
and parent source remain unchanged.

### Exact scan inventory

| Item | Count |
|---|---:|
| Seasons | 480 |
| Rounds | 1,440 |
| Raw input files | 960 |
| Raw bytes hashed | 174,437,288 |
| Market timestamp rows | 561,600 |
| Feed messages | 415,563 |
| Storm observations | 347,040 |
| Active-path observations, ages0–478 | 345,600 |
| Terminal observations at age480 | 1,440 |
| Storm-formed / storm-dissipated events | 1,440 each |
| Track messages | 34,560 |
| Advisories | 26,090 |
| Impact messages | 2,113 |
| Preliminary / final damage reports | 1,440 each |
| Distinct feed-publication keys also present in quote grid | 349,920 |

Every round has all 390 quote times0,2,...,778 and every active observation age
0,2,...,478. The additional age480 observation is retained as a terminal event;
it is not silently substituted for the age478 active-path sample.

**Zero occurrences** were found of: storm publication differing from
round-open+60+age; quote or feed chronological regressions; duplicate quote times;
duplicate or regressive feed sequences; sequence gaps; duplicate observation
ages; missing active-path observations; off-grid quote samples; repeated/missing
report stages; reports outside preliminary570/final740; preliminary reports
after a final in either file order or publication order; multiple storm identities
within a round. Full timestamp order and same-round feed/quote fictional-date
identity also match; those identity comparisons do not infer wall-clock gaps.
No numerical comparison of preliminary versus final damage was
performed or needed: a revised estimate can legitimately change in either
direction. “Regression” here means stage/sequence regression.

`input_manifest.csv` contains each exact relative path, byte length, record count
and SHA256. Its SHA256 is:

```
93bfa0393a44288743779169a3a0f006897961452eacc6ffde332f30a5c58002
```

`scan_results.json` includes all counters, including zeros, and per-season
results. `metadata_only.jsonl.gz` retains only timing/type/sequence/age/stage/
source/storm-identity metadata for local reproducibility; it has no numerical
market/weather/damage payloads. Checksums do not imply that numeric outcomes were
evaluated. This scan certifies message presence and timing, not the numerical
validity of real observation payloads.

## Reference adapter and proof scope

`reference_adapter.py` separates three concepts:

1. **Event age:** a storm sample's nominal real-second age.
2. **Publication:** an ordered `(round, second-after-open)` key derived from the
   documented 30x clock-of-day conversion, without subtracting fictional dates.
3. **Receipt:** an independently supplied monotonic-clock timestamp. A snapshot
   requires both publication and receipt to be at or before their cutoffs.

The adapter retains raw received observations. It never supplies zero-intensity
stand-ins for missing samples. It reports missing ages, unusable samples, stale
latest observations and completeness of the observed path. A late older sample
can fill a gap in *current* knowledge but cannot rewrite an earlier as-received
snapshot. Final reports take precedence over preliminaries; publication/sequence
versioning breaks ties among reports of the same stage. Identical duplicates are
idempotent and retain the earliest receipt; a conflicting identity raises an
explicit reconciliation error. A new adapter is required on competition-ID
change. Snapshot messages are intentionally not implemented as fictitious full
history; integration must handle them separately.

### Why canonical selection is equivalent

The scan establishes the preconditions on every authorized season:

- A file prefix ending at a publication cutoff equals filtering the entire file
  by that cutoff, because its publication keys are nondecreasing.
- For each active storm observation, `publication = 60 + age`; therefore nominal
  age-based exposure and publication-based exposure select the identical event
  at each decision cutoff. The optional terminal age480 is also preserved.
- Sequences are unique and increasing. Every round has exactly one preliminary
  at570 followed by exactly one final at740. Last-writer selection and
  final-precedence selection therefore choose the same report.

`check_equivalence.py` verifies feed/quote prefix membership at **every two-second
grid cutoff** of every allowed season. It also executes the **original unchanged
`predict_prefix.public_prefix` function** on virtual files in which all numerical
payloads and advisory labels are artificial unique event-identity tokens. This
compares selected observations, quotes, reports, report stages, official/wire
advisories, probabilities and cone slots with the new reference state at
0,60,90,120,538,540,570,740,778 for each round.

The persisted `equivalence_results.json` is the authoritative run result and
binds the adapter source hashes. **All 561,600 grid-prefix checks and all 12,960
original-adapter tokenized prefix comparisons matched.** This is a **payload-selection/as-of equivalence
proof**, not an analysis of actual price or damage values. It assumes immediate
receipt in an explicitly artificial archive clock solely to compare publication
prefixes. No real network receipts exist in these files. The arbitrary test clock
spacing is not a claim about inter-round wall time.

`test_reference_adapter.py` uses invented payloads to demonstrate the H2 and M1
fixes, duplicate/conflict handling, historical receipt causality, independently
gated publication/receipt cutoffs, missing/unusable observation flags, terminal
age480 handling, and snapshot isolation. See `synthetic_tests.json` for results.
**All 11 synthetic tests pass.**

## Testnet pause versus live timing

The supplied **CTC 2026 Case Packet, page12, Section7** states:

> After each close, and after the testnet prepares a new season, the clock stops
> for 2 minutes. When the clock starts again, the market opens after 1 real minute.

The same page's comparison table places **“The pauses between rounds” under
“Different from the live case.”** Thus the stated testnet schedule includes a
two-minute stopped-clock interval and another real minute before opening—enough
to clear a 60-real-second action window **if no new actions are submitted during
the pause**. The original H1 contiguous-round counterexample is not evidence of
a violation under that documented testnet schedule.

The research README lines27–29 specifies 780 real seconds per round and a 30x
fictional clock; lines6–9 gives the general shared-simulator timing statement.
It does not specify a live inter-round pause. The packet's specific testnet/live
exception prevents treating that general timing statement as a guarantee of
identical pauses. Neither fictional date differences nor the next round's09:30
timestamp identifies wall-clock elapsed time. The live pause remains unspecified
in the supplied timing passages. Retain shared monotonic action state and observe
the real clock; the parent owns that integration.

Relevant source excerpts are retained in `TIMING_SOURCES.md`: PDF page12, the
packet page3 clock description, and the supplied research/starter-kit READMEs.
`provenance_manifest.json` records source-document checksums.

## Integration recommendation

1. Preserve publication keys and receipt timestamps in future caches. Reuse the
   reference `Publication`/`Receipt` distinction rather than collapsing both to
   storm age. Keep clock-of-day parsing separate from actual wall-time ordering.
2. Put one deduplicating, final-precedence-safe feed state ahead of features.
   Maintain per-competition identity and explicitly reconcile conflicting seq.
3. Gate outage/full-path features on `trajectory_complete_asof` and validity.
   Missing path segments cannot be reconstructed by inserting zero wind. Either
   suppress dependent decisions or adopt an explicitly fitted missing-data model.
4. Use snapshot reports and latest observations only as received. A snapshot's
   abbreviated track is not a full two-second outage history; set an incomplete
   flag rather than silently rebuilding unavailable samples.
5. Keep the original array adapter only as a verified canonical-archive adapter.
   A receipt-aware live adapter is not drop-in equivalent on delayed feeds; that
   difference is the intended fix. Any live latency evaluation must declare and
   stress transport receipt delays separately from order-arrival latency.
6. H2/M1 do not currently require historical strategy retuning or a new PnL scan
   on seasons121–600. Rebuild/re-evaluate only if new receipt assumptions or actual
   dirty records change feature visibility. No assertion is made about unscanned
   seasons1–120. Preserve the original synthetic counterexamples as regression
   cases, and do not assume documented testnet pauses apply to live timing.

## Reproduction

Run `bash run_followup.sh` in this directory. It reads the fixed authorized file
set and writes only here; it uses one process and BLAS/OMP=1. It does not fit or
run any strategy. The original audit files remain preserved outside this folder.
Allow approximately seven minutes for the full tokenized equivalence pass. If
interrupted, use `python check_equivalence.py --resume` without regenerating the
metadata archive; saved input/source fingerprints guard the continuation. The
final run retained 364 completed seasons after a 300-second command timeout and
checked the remaining116; the unchanged-source recovery is recorded explicitly
in `equivalence_binding.json`.

The follow-up began before the original06:30 deadline but was interrupted by
server restarts. Continuation was explicitly requested after restart; the local
clock was13:33 UTC on resumption. This deliverable does not claim completion by
the original deadline.
