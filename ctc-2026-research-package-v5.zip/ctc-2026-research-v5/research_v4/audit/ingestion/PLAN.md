# Follow-up ingestion/provenance audit

Authorized 2026-10-19 05:45 UTC; target <=25 minutes, hard stop 06:30 UTC.

- Enumerate only explicit season IDs 121..600; open only their `feed.jsonl` and
  `market.csv`. Never open any historical manifest or settlement file.
- Scan timing/type/sequence/age/report-stage metadata, exact grids, chronological
  order, duplicates and stage precedence. Hash the 960 authorized raw files.
- Build a publication/receipt-aware reference state adapter locally. Keep event
  age and availability separate, missing/stale observations explicit, report
  stage/version precedence, and duplicate/conflict diagnostics.
- Prove metadata-level canonical prefix equivalence across all authorized seasons;
  use a metadata-tokenized run of the existing adapter so no real prices, damage,
  intensity, forecasts or PnL are analyzed. Test real-valued adapter semantics
  independently on invented delayed/reordered/duplicate examples.
- Check supplied packet and README text for testnet pause and live timing. Do
  not infer wall-clock gaps from fictional calendar dates. Parent owns rate state.
- Preserve original AUDIT.md counterexamples. Deliver addendum, exact scan counts,
  checksum manifest, tests and integration guidance in this subdirectory only.

All execution uses one Python process at a time and BLAS/OMP=1. No external
services, agents, tuning, model fitting or parent-source edits.
