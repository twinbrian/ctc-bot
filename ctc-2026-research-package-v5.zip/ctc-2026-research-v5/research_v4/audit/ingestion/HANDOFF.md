# Ingestion follow-up handoff

**Historical scope:** H2/M1 did not trigger in any scanned canonical season 121–600.
Keep their original delayed/reordered synthetic counterexamples. No H2/M1-specific
historical PnL rerun is indicated by this provenance scan; no PnL was evaluated.

- Scanned 960 authorized files: 561,600 market rows, 415,563 feed messages and
  347,040 storm observations across 480 seasons / 1,440 rounds. All storm messages
  publish exactly at round-open + 60 + age. All streams are chronological; no duplicate
  seq/quote times, sequence regressions, missing active-path samples, or report
  stage regressions. Exactly 1,440 preliminaries at 570 and 1,440 finals at 740.
- All rounds include a terminal age-480 observation in addition to ages 0..478.
- All 561,600 grid-prefix selection checks and 12,960 original-adapter tokenized
  prefix comparisons match. This is metadata/event-identity equivalence, not a
  comparison of real numerical outcomes or proof of client receipt timestamps.
- Added a publication/receipt-aware reference adapter. Event age stays separate;
  missing, stale and unusable observations are explicit; final precedence and
  conflicting-duplicate handling are enforced. All 11 invented fault tests pass.
- **Packet page 12:** testnet clock stops 2 minutes after close, then opens 1 real
  minute after restart. “Pauses between rounds” explicitly differ from live.
  H1's contiguous-round counterexample therefore does not establish a testnet
  violation when no actions occur during the pause. Live gap remains unspecified.
  Parent should retain shared monotonic-time state; no rate implementation added.

`INGESTION_ADDENDUM.md` supplies integration/rerun guidance. `input_manifest.csv`
lists exact per-file SHA256/bytes/rows; its SHA256 is
`93bfa0393a44288743779169a3a0f006897961452eacc6ffde332f30a5c58002`.
`scan_results.json`, `equivalence_results.json`, `synthetic_tests.json` and
`provenance_manifest.json` retain counts and verification provenance.

Reproduce: `bash run_followup.sh` here. Only season121..600 feed/market metadata
is loaded; no manifest/settlements, strategy evaluation or parent edits. Original
audit files are preserved. Server restarts passed the original deadline; the
continuation was completed after the explicit resume request, not by 06:30 UTC.
