"""Explicitly restricted metadata-only scan of seasons 121..600.

No manifest, settlement, model, cache, or season 1..120 file is opened. Payload
numbers are neither retained nor analyzed. Raw-file SHA256 covers bytes only.
The sanitized metadata archive allows equivalence checks without rereading raw
payloads. A fictional date is never converted into elapsed wall-clock time.
"""

from collections import Counter, defaultdict
import csv
import gzip
import hashlib
import io
import json
from pathlib import Path

from reference_adapter import publication

HERE = Path(__file__).resolve().parent
DATA = Path("/tmp/opencode/ctc-research/hurricane-season-research")
FIELDS = ("type", "seq", "round", "time", "age", "stage", "source", "storm")
CHECKS = [
    "quote_timestamp_regressions",
    "feed_timestamp_regressions",
    "quote_multi_date_rounds",
    "feed_quote_round_date_mismatches",
    "quote_chronology_regressions",
    "duplicate_quote_times",
    "missing_quote_ticks",
    "unexpected_quote_ticks",
    "round_open_not_0930",
    "feed_chronology_regressions",
    "seq_regressions",
    "duplicate_seq",
    "same_seq_different_bytes",
    "seq_gaps",
    "storm_publication_not_event_time",
    "duplicate_observation_ages",
    "missing_observation_ages",
    "unexpected_observation_ages",
    "terminal_observations_age480",
    "regressive_reports_file_order",
    "regressive_reports_publication_order",
    "repeated_report_stages",
    "missing_report_stages",
    "report_publication_off_schedule",
    "unexpected_report_stages",
    "round_storm_identity_conflicts",
]


def calendar_metadata_checks(quotes, messages):
    """Compare timestamp order/date identity, never infer wall-clock durations."""
    checks = Counter()
    checks["quote_timestamp_regressions"] = sum(
        b["time"] < a["time"] for a, b in zip(quotes, quotes[1:])
    )
    checks["feed_timestamp_regressions"] = sum(
        b["time"] < a["time"] for a, b in zip(messages, messages[1:])
    )
    dates = {
        r: {q["time"].split("T")[0] for q in quotes if q["round"] == r}
        for r in (1, 2, 3)
    }
    checks["quote_multi_date_rounds"] = sum(len(value) != 1 for value in dates.values())
    checks["feed_quote_round_date_mismatches"] = sum(
        m["time"].split("T")[0] not in dates[m["round"]] for m in messages
    )
    return checks


def read_authorized(season, name):
    if not 121 <= season <= 600 or name not in ("feed.jsonl", "market.csv"):
        raise ValueError("Unauthorized history file")
    path = DATA / "history" / f"season-{season:03d}" / name
    if path.resolve() != path:
        raise ValueError("Unexpected symlink; refuse scope escape")
    raw = path.read_bytes()
    return raw, {
        "path": str(path.relative_to(DATA)),
        "bytes": len(raw),
        "sha256": hashlib.sha256(raw).hexdigest(),
    }


def report_regressions(messages):
    final = set()
    count = 0
    for msg in messages:
        if msg["type"] != "damage_report":
            continue
        key = msg["round"], msg.get("storm")
        if key in final and msg["stage"] != "final":
            count += 1
        if msg["stage"] == "final":
            final.add(key)
    return count


def scan_one(season):
    c = Counter({name: 0 for name in CHECKS})
    manifest = []
    raw, item = read_authorized(season, "market.csv")
    # Only round and timestamp are selected; no price string is converted.
    quotes = [
        {"round": int(row["round"]), "time": row["time"]}
        for row in csv.DictReader(io.StringIO(raw.decode()))
    ]
    item["records"] = len(quotes)
    manifest.append(item)
    quote_keys = [publication(row) for row in quotes]
    c["quote_chronology_regressions"] = sum(
        b < a for a, b in zip(quote_keys, quote_keys[1:])
    )
    c["duplicate_quote_times"] = len(quote_keys) - len(set(quote_keys))
    for r in (1, 2, 3):
        ticks = {key.second for key in quote_keys if key.round == r}
        expected = set(range(0, 780, 2))
        c["missing_quote_ticks"] += len(expected - ticks)
        c["unexpected_quote_ticks"] += len(ticks - expected)
        c["round_open_not_0930"] += not ticks or min(ticks) != 0

    raw, item = read_authorized(season, "feed.jsonl")
    messages = []
    seen = {}
    previous_seq = None
    for line in raw.splitlines():
        parsed = json.loads(line)
        msg = {key: parsed[key] for key in FIELDS if key in parsed}
        del parsed  # discard all weather, price, report-value and outlook payloads
        messages.append(msg)
        seq = msg["seq"]
        digest = hashlib.sha256(line).hexdigest()
        if seq in seen:
            c["duplicate_seq"] += 1
            c["same_seq_different_bytes"] += seen[seq] != digest
        seen[seq] = digest
        if previous_seq is not None:
            c["seq_regressions"] += seq < previous_seq
            c["seq_gaps"] += max(0, seq - previous_seq - 1)
        previous_seq = seq
    item["records"] = len(messages)
    manifest.append(item)
    feed_keys = [publication(msg) for msg in messages]
    c["feed_chronology_regressions"] = sum(
        b < a for a, b in zip(feed_keys, feed_keys[1:])
    )
    ages = defaultdict(list)
    stages = Counter()
    identities = defaultdict(set)
    for msg, key in zip(messages, feed_keys):
        if "storm" in msg:
            identities[key.round].add(msg["storm"])
        if msg["type"] == "storm":
            ages[key.round].append(msg["age"])
            c["storm_publication_not_event_time"] += key.second != 60 + msg["age"]
        if msg["type"] == "damage_report":
            stage = msg["stage"]
            stages[key.round, stage] += 1
            if stage in ("preliminary", "final"):
                c["report_publication_off_schedule"] += key.second != (
                    570 if stage == "preliminary" else 740
                )
            else:
                c["unexpected_report_stages"] += 1
    for r in (1, 2, 3):
        c["duplicate_observation_ages"] += len(ages[r]) - len(set(ages[r]))
        c["missing_observation_ages"] += len(set(range(0, 480, 2)) - set(ages[r]))
        c["unexpected_observation_ages"] += len(set(ages[r]) - set(range(0, 481, 2)))
        c["terminal_observations_age480"] += ages[r].count(480)
        c["round_storm_identity_conflicts"] += len(identities[r]) > 1
        for stage in ("preliminary", "final"):
            c["repeated_report_stages"] += max(0, stages[r, stage] - 1)
            c["missing_report_stages"] += stages[r, stage] == 0
    c["regressive_reports_file_order"] = report_regressions(messages)
    c["regressive_reports_publication_order"] = report_regressions(
        sorted(messages, key=lambda m: (publication(m), m["seq"]))
    )
    c.update(calendar_metadata_checks(quotes, messages))
    result = {
        "season": season,
        "quotes": len(quotes),
        "messages": len(messages),
        "message_types": dict(Counter(m["type"] for m in messages)),
        "report_stages": dict(
            Counter(m["stage"] for m in messages if m["type"] == "damage_report")
        ),
        "same_timestamp_feed_quote_publication_keys": len(
            set(feed_keys) & set(quote_keys)
        ),
        "checks": dict(c),
    }
    return result, manifest, {"season": season, "messages": messages, "quotes": quotes}


def main():
    totals = Counter({name: 0 for name in CHECKS})
    types, stages = Counter(), Counter()
    manifest, seasons = [], []
    with gzip.open(HERE / "metadata_only.jsonl.gz", "wt") as archive:
        for season in range(121, 601):
            result, entries, metadata = scan_one(season)
            archive.write(json.dumps(metadata, separators=(",", ":")) + "\n")
            seasons.append(result)
            manifest.extend(entries)
            totals.update(result["checks"])
            types.update(result["message_types"])
            stages.update(result["report_stages"])
    manifest_path = HERE / "input_manifest.csv"
    with manifest_path.open("w", newline="") as stream:
        writer = csv.DictWriter(
            stream, fieldnames=["path", "bytes", "sha256", "records"]
        )
        writer.writeheader()
        writer.writerows(sorted(manifest, key=lambda row: row["path"]))
    summary = {
        "scope": "Timing/identity metadata only: raw feed.jsonl and market.csv, explicit seasons 121..600",
        "seasons": len(seasons),
        "rounds": len(seasons) * 3,
        "files": len(manifest),
        "input_bytes": sum(row["bytes"] for row in manifest),
        "market_rows": sum(row["quotes"] for row in seasons),
        "feed_messages": sum(row["messages"] for row in seasons),
        "message_types": dict(types),
        "report_stages": dict(stages),
        "same_timestamp_feed_quote_publication_keys": sum(
            row["same_timestamp_feed_quote_publication_keys"] for row in seasons
        ),
        "checks": dict(totals),
        "manifest_sha256": hashlib.sha256(manifest_path.read_bytes()).hexdigest(),
        "metadata_archive_sha256": hashlib.sha256(
            (HERE / "metadata_only.jsonl.gz").read_bytes()
        ).hexdigest(),
        "per_season": seasons,
        "limitations": [
            "No network receipt timestamps in archive",
            "No within-timestamp quote/news arrival order",
            "No inference of real inter-round pause from fictional dates",
            "Sequence gaps alone are not an error",
        ],
    }
    (HERE / "scan_results.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps({k: v for k, v in summary.items() if k != "per_season"}, indent=2))


if __name__ == "__main__":
    main()
