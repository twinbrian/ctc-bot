"""Hash local audit sources and the supplied timing documentation only."""

import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
PROJECT = HERE.parents[2]
DATA = Path("/tmp/opencode/ctc-research/hurricane-season-research")


def main():
    paths = [
        Path("/tmp/files/b8ad-[External] CTC 2026 Case Packet.pdf"),
        DATA / "README.md",
        DATA / "starter_kit/README.md",
        DATA / "case.json",
        PROJECT / "predict_prefix.py",
        PROJECT / "prepare.py",
        *sorted(HERE.glob("*.py")),
        HERE / "PLAN.md",
        HERE / "INGESTION_ADDENDUM.md",
        HERE / "TIMING_SOURCES.md",
        HERE / "HANDOFF.md",
        HERE / "run_followup.sh",
        HERE / "input_manifest.csv",
        HERE / "scan_results.json",
        HERE / "equivalence_results.json",
        HERE / "equivalence_binding.json",
        HERE / "equivalence_progress.jsonl",
        HERE / "synthetic_tests.json",
    ]
    records = []
    for path in paths:
        raw = path.read_bytes()
        records.append(
            {
                "path": str(path),
                "bytes": len(raw),
                "sha256": hashlib.sha256(raw).hexdigest(),
            }
        )
    (HERE / "provenance_manifest.json").write_text(json.dumps(records, indent=2) + "\n")
    print("Recorded", len(records), "documentation/code/result provenance hashes")


if __name__ == "__main__":
    main()
