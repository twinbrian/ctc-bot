import unittest
import json
from pathlib import Path

from reference_adapter import DuplicateConflict, ReferenceAdapter


def stamp(second):
    value = 34200 + int(second * 30)
    return f"1900-01-01T{value // 3600:02d}:{value // 60 % 60:02d}:{value % 60:02d}"


def storm(seq, age, published=None, **values):
    return {
        "type": "storm",
        "seq": seq,
        "round": 1,
        "age": age,
        "time": stamp(60 + age if published is None else published),
        "x": 10,
        "y": 20,
        "vx": 0,
        "vy": 1,
        "radius": 80,
        "intensity": 1,
        **values,
    }


def report(seq, stage, published, damage):
    return {
        "type": "damage_report",
        "seq": seq,
        "round": 1,
        "storm": "invented",
        "time": stamp(published),
        "stage": stage,
        "damage_pct": {"PORT": damage},
    }


def view(adapter, second, received=None):
    return adapter.snapshot(
        round_number=1,
        second=second,
        received_through=second if received is None else received,
    )


class ReferenceTests(unittest.TestCase):
    def test_delayed_publication_does_not_backdate_storm(self):
        a = ReferenceAdapter()
        a.ingest(storm(1, 60, 124, intensity=2), received_at=124)
        self.assertNotIn((1, 60), view(a, 120)["observations"])
        self.assertTrue(view(a, 120)["observation_status"][1]["stale"])
        event = view(a, 124)["observations"][1, 60]
        self.assertEqual(event.event_age, 60)
        self.assertEqual(event.publication.second, 124)
        self.assertEqual(event.message["intensity"], 2)

    def test_receipt_and_publication_are_both_required(self):
        a = ReferenceAdapter()
        a.ingest(storm(1, 60, 124), received_at=500)
        self.assertFalse(view(a, 124, 499)["observations"])
        self.assertFalse(view(a, 120, 600)["observations"])
        self.assertIn((1, 60), view(a, 124, 500)["observations"])

    def test_reordered_reports_preserve_final_and_do_not_truncate_prefix(self):
        a = ReferenceAdapter()
        a.ingest(report(2, "final", 740, 20), received_at=740)
        a.ingest(report(1, "preliminary", 570, 10), received_at=570)
        self.assertEqual(
            view(a, 600)["reports"][1, "invented"].message["stage"], "preliminary"
        )
        self.assertEqual(
            view(a, 740)["reports"][1, "invented"].message["damage_pct"]["PORT"], 20
        )
        a.ingest(report(3, "preliminary", 750, 5), received_at=750)
        self.assertEqual(
            view(a, 760)["reports"][1, "invented"].message["damage_pct"]["PORT"], 20
        )

    def test_late_old_final_cannot_regress_revised_final(self):
        a = ReferenceAdapter()
        a.ingest(report(3, "final", 746, 22), received_at=747)
        a.ingest(report(2, "final", 740, 20), received_at=750)
        self.assertEqual(
            view(a, 760)["reports"][1, "invented"].message["damage_pct"]["PORT"], 22
        )

    def test_duplicate_idempotence_conflicts_and_earliest_receipt(self):
        a = ReferenceAdapter()
        msg = storm(1, 0)
        self.assertTrue(a.ingest(msg, received_at=64))
        self.assertFalse(a.ingest(msg, received_at=62))
        self.assertEqual(view(a, 62)["observations"][1, 0].received_at, 62)
        self.assertEqual(len(view(a, 70)["observations"]), 1)
        with self.assertRaises(DuplicateConflict):
            a.ingest({**msg, "intensity": 9}, received_at=70)

    def test_missing_interval_is_flagged_without_inventing_path(self):
        a = ReferenceAdapter()
        a.ingest(storm(1, 0), received_at=60)
        a.ingest(storm(3, 4), received_at=64)
        s = view(a, 64)
        self.assertEqual(s["observation_status"][1]["missing_ages"], [2])
        self.assertFalse(s["observation_status"][1]["trajectory_complete_asof"])
        self.assertFalse(s["observation_status"][1]["stale"])
        self.assertNotIn((1, 2), s["observations"])
        self.assertTrue(view(a, 66)["observation_status"][1]["stale"])

    def test_late_observation_does_not_rewrite_historical_knowledge(self):
        a = ReferenceAdapter()
        a.ingest(storm(1, 0), received_at=60)
        before = view(a, 62)
        a.ingest(storm(2, 2), received_at=70)
        self.assertEqual(before, view(a, 62))
        self.assertIn((1, 2), view(a, 70)["observations"])

    def test_snapshot_mutation_cannot_corrupt_state(self):
        a = ReferenceAdapter()
        a.ingest(storm(1, 0), received_at=60)
        view(a, 60)["observations"][1, 0].message["intensity"] = 999
        self.assertEqual(view(a, 60)["observations"][1, 0].message["intensity"], 1)

    def test_round_clock_is_not_a_wall_clock(self):
        a = ReferenceAdapter()
        a.ingest({**storm(1, 0), "round": 2}, received_at=2000)
        self.assertFalse(
            a.snapshot(round_number=2, second=60, received_through=1999)["observations"]
        )
        self.assertIn(
            (2, 0),
            a.snapshot(round_number=2, second=60, received_through=2000)[
                "observations"
            ],
        )

    def test_terminal_age480_does_not_replace_last_active_sample(self):
        a = ReferenceAdapter()
        for age in range(0, 480, 2):
            a.ingest(storm(age, age), received_at=60 + age)
        a.ingest(storm(480, 480, radius=None, intensity=None), received_at=540)
        s = view(a, 540)
        self.assertIn((1, 480), s["observations"])
        self.assertEqual(s["observation_status"][1]["latest"].event_age, 478)
        self.assertTrue(s["observation_status"][1]["storm_complete"])

    def test_unusable_payload_is_flagged_without_zero_imputation(self):
        a = ReferenceAdapter()
        a.ingest(storm(1, 0, x=None), received_at=60)
        status = view(a, 60)["observation_status"][1]
        self.assertEqual(status["missing_ages"], [])
        self.assertEqual(status["unusable_ages"], [0])
        self.assertFalse(status["trajectory_complete_asof"])
        self.assertTrue(status["stale"])


if __name__ == "__main__":
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(ReferenceTests)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    Path(__file__).with_name("synthetic_tests.json").write_text(
        json.dumps(
            {
                "tests": result.testsRun,
                "failures": len(result.failures),
                "errors": len(result.errors),
                "all_passed": result.wasSuccessful(),
                "data": "invented only",
            },
            indent=2,
        )
        + "\n"
    )
    raise SystemExit(not result.wasSuccessful())
