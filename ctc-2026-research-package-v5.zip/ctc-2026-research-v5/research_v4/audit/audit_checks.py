"""Independent numerical audit. Only synthetic data; never loads parent caches.

Run from this directory with all BLAS/OMP thread counts set to one. The parent
modules are imported read-only; interception only changes in-memory test code.
Known-defect checks assert the counterexample, so a passing audit suite is not a
claim that the baseline implementation is defect-free.
"""

import contextlib
import csv
import hashlib
import io
import json
import os
from pathlib import Path
import sys
import tempfile
import unittest

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent
sys.dont_write_bytecode = True
for name in ["OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"]:
    os.environ[name] = "1"
os.environ["MPLCONFIGDIR"] = str(HERE / ".mplconfig")
os.environ["XDG_CACHE_HOME"] = str(HERE / ".cache")
sys.path.insert(0, str(ROOT))

import numpy as np

from common import BASKETS, LIMITS, PHYSICAL, SYMBOLS, with_etfs
from etf_route_v3 import simulate_routes
from models import features
from pnl_v2_simulator import simulate
from pnl_v3_select import run
from predict_prefix import public_prefix
from prepare import prepare
from protocol import ActionLimiter, conversion_delta

OBSERVATIONS = {}


def fixture(n=1):
    stock = np.full((n, 3, 390, 10), 100.0)
    market = with_etfs(stock)
    truth = with_etfs(np.full((n, 10), 100.0))
    delta = np.zeros((n, 3, 78, 12))
    curve = market[0].copy()
    return [market, truth, delta, truth.copy(), curve]


def formation_fixture(n=1):
    args = fixture(n)
    args[0][:, :, 32:, :10] += np.array([4, 3, 2, 5, 2, -3, -2, -4, 3, 1])
    args[0][..., 10:] = args[0][..., :10] @ BASKETS.T
    args[4] = args[0][0].copy()
    args[1] = args[0][:, -1, -1].copy()
    args[3] = args[1].copy()
    return args


def global_rolling(counts):
    """Independent real-time oracle: contiguous 780-second rounds."""
    values = counts.reshape(len(counts), -1).astype(int)
    return np.array([np.convolve(x, np.ones(30, dtype=int), mode="full").max() for x in values])


def local_module(filename, replacements):
    """Use baseline source verbatim except explicit instrumentation, in memory."""
    source = (ROOT / filename).read_text()
    for before, after in replacements:
        assert source.count(before) == 1, before
        source = source.replace(before, after)
    namespace = {"__name__": "audit_instrumented", "__file__": str(ROOT / filename)}
    exec(compile(source, str(HERE / ("instrumented_" + filename)), "exec"), namespace)
    return namespace


def instrument_route(reverse=False, hook=None):
    replacements = [
        ("            for i, change, kind in queue[ti]:", "            for i, change, kind in " + ("reversed(queue[ti])" if reverse else "queue[ti]") + ":"),
        ("                pp[i] += np.maximum(change, 0)",
         "                audit_submit(r, ti, q.copy(), pp.copy(), pn.copy(), i.copy(), change.copy(), kind)\n                pp[i] += np.maximum(change, 0)"),
        ("                q[i] += change", "                audit_fill(r, ti, i.copy(), change.copy(), kind, price[i].copy())\n                q[i] += change"),
    ]
    module = local_module("etf_route_v3.py", replacements)
    submissions, fills = [], []
    module["audit_submit"] = lambda *x: submissions.append(x)
    module["audit_fill"] = hook if hook is not None else lambda *x: fills.append(x)
    return module["simulate_routes"], submissions, fills


def timestamp(second):
    clock = 34200 + 30 * second
    return f"2026-01-01T{clock // 3600:02d}:{clock // 60 % 60:02d}:{clock % 60:02d}"


def make_feed(root, delayed=False, reorder=False):
    """Entirely invented one-season feed; contains no research-data outcomes."""
    folder = root / "history" / "season-001"
    folder.mkdir(parents=True)
    companies = {}
    counts = [1, 3, 4, 5, 4]
    for symbol, count in zip(PHYSICAL, counts):
        companies[symbol] = {"sites": [{"x": 0, "y": 0, "weight": 1 / count} for _ in range(count)]}
    (root / "case.json").write_text(json.dumps({"companies": companies}))
    storms = [{"round": r, "damage_pct": dict.fromkeys(PHYSICAL, 0), "industry_loss_musd": 0,
               "pattern": "direct", "turned_erratic_at": None} for r in [1, 2, 3]]
    (root / "history" / "manifest.json").write_text(json.dumps({"seasons": [
        {"season": 1, "dir": "season-001", "storms": storms}]}))
    (folder / "settlement.json").write_text(json.dumps(dict(zip(SYMBOLS, with_etfs(np.full(10, 100.0))))))
    with (folder / "market.csv").open("w") as f:
        writer = csv.DictWriter(f, fieldnames=["round", "time", *SYMBOLS])
        writer.writeheader()
        for r in [1, 2, 3]:
            for t in range(0, 780, 2):
                writer.writerow({"round": r, "time": timestamp(t), **dict(zip(SYMBOLS, with_etfs(np.full(10, 100.0))))})
    messages = []
    for r in [1, 2, 3]:
        for age in range(0, 480, 2):
            t = 60 + age + (4 if delayed and r == 1 and age == 60 else 0)
            messages.append({"type": "storm", "round": r, "age": age, "time": timestamp(t),
                             "x": 0, "y": 0, "vx": 1, "vy": 1, "radius": 100,
                             "intensity": 2 if r == 1 and age == 60 else 1})
        for t, stage, damage in [(570, "preliminary", 10), (740, "final", 20)]:
            messages.append({"type": "damage_report", "round": r, "storm": str(r), "time": timestamp(t),
                             "stage": stage, "damage_pct": dict.fromkeys(PHYSICAL, damage), "industry_loss_musd": damage})
    messages.sort(key=lambda m: (m["round"], m["time"]))
    for seq, msg in enumerate(messages):
        msg["seq"] = seq
    if reorder:
        # A late/out-of-order preliminary is physically after the final in file.
        a = next(i for i, m in enumerate(messages) if m["round"] == 1 and m.get("stage") == "preliminary")
        b = next(i for i, m in enumerate(messages) if m["round"] == 1 and m.get("stage") == "final")
        messages[a], messages[b] = messages[b], messages[a]
    (folder / "feed.jsonl").write_text("".join(json.dumps(m) + "\n" for m in messages))
    return folder


class Audit(unittest.TestCase):
    def test_conversion_cash_and_coherent_value(self):
        rng = np.random.default_rng(1451)
        for _ in range(100):
            marks = with_etfs(rng.uniform(1, 200, 10))
            for name in ["ARCH", "REBLD"]:
                change = conversion_delta(name, int(rng.integers(1, 51)))
                self.assertAlmostEqual(float(change @ marks), 0, places=8)
                np.testing.assert_array_equal(change + conversion_delta(name, int(change[SYMBOLS.index(name)]), False), np.zeros(12))
        args = formation_fixture()
        args[0][:] = with_etfs(np.full(10, 100.0))
        result = simulate_routes(args[0], args[1], args[4], audit=True)
        self.assertGreater(result["conversion_actions"].sum(), 0)
        np.testing.assert_allclose(result["pnl"], -result["cost"], atol=1e-7)
        OBSERVATIONS["flat_coherent_marks"] = {"pnl": result["pnl"].tolist(), "cost": result["cost"].tolist()}

    def test_all_leg_reservations_and_reverse_arrival(self):
        args = formation_fixture()
        execute, submits, fills = instrument_route()
        baseline = execute(args[0], args[1], args[4], start=20, exit_at=80, latency=12, audit=True)
        rng = np.random.default_rng(20261019)
        for r, ti, q, pp, pn, ids, change, kind in submits:
            p = pp[ids] + np.maximum(change, 0)
            m = pn[ids] + np.maximum(-change, 0)
            self.assertTrue(np.all(q[ids] + p <= LIMITS))
            self.assertTrue(np.all(q[ids] - m >= -LIMITS))
            # An arbitrary subset/partial completion lies inside this orthotope.
            for _ in range(3):
                filled = rng.integers(0, p + 1) - rng.integers(0, m + 1)
                self.assertTrue(np.all(np.abs(q[ids] + filled) <= LIMITS))
        reverse, _, _ = instrument_route(reverse=True)
        reordered = reverse(args[0], args[1], args[4], start=20, exit_at=80, latency=12, audit=True)
        for key in ["pnl", "actions", "positions", "cost", "attribution"]:
            np.testing.assert_allclose(baseline[key], reordered[key], atol=1e-7)
        # Independent ledger reconstruction; conversion changes no cash.
        q = np.zeros(12, dtype=int)
        cash = 0.0
        usage = {}
        for r, ti, ids, change, kind, price in fills:
            if kind == "market":
                cash -= (change * price + np.abs(change) * (price * .0025 + .02)).sum()
                for j in np.flatnonzero(change[0]):
                    usage[r, ti, j] = usage.get((r, ti, j), 0) + abs(int(change[0, j]))
            q += change.sum(0)
            self.assertTrue(np.all(np.abs(q) <= LIMITS))
        self.assertLessEqual(max(usage.values()), 50)
        np.testing.assert_allclose(cash, baseline["pnl"][0], atol=1e-7)
        np.testing.assert_array_equal(q, np.zeros(12))
        OBSERVATIONS["route_reservations"] = {"submissions": len(submits), "fills": len(fills), "reversed_same_time_arrival": "pass", "cash_reconstruction": cash}

    def test_news_at_same_time_uses_arrival_quote(self):
        args = fixture()
        args[2][0, 0, 9, 0] = 20  # information becomes known at t=90
        args[0][0, 0, 46:51, 0] = 109  # t=92 arrival, t=102 exit
        args[0][0, 0, 51:, 0] = 110
        result = simulate(*args, ongoing={"cycle": 10, "top_k": 1, "threshold": 0}, cost_bps=0, fixed_cost=0, audit=True)
        self.assertEqual(result["pnl"][0], 50.0)  # 50*(110-109), not 50*(110-100)
        self.assertEqual(result["action_ticks"][0, 0, :45].sum(), 0)
        self.assertEqual(result["action_ticks"][0, 0, 45], 1)
        OBSERVATIONS["same_time_news_latency"] = {"decision_second": 90, "entry_second": 92, "exit_second": 102, "pnl": 50}

    def test_round_boundary_rate_counterexample(self):
        args = formation_fixture()
        args[2][:] = 10
        result = simulate(*args, formation={"start": 0, "exit": 80, "entry_budget": 60}, ongoing={"cycle": 10, "top_k": 8, "threshold": 0}, audit=True)
        within = int(result["max_rolling_actions"].max())
        across = int(global_rolling(result["action_ticks"]).max())
        self.assertLessEqual(within, 60)
        self.assertGreater(across, 60)
        OBSERVATIONS["round_boundary_rate_bug"] = {"reported_max": within, "contiguous_round_oracle_max": across, "assumption": "780 real seconds per round; no inter-round pause"}

    def test_v2_signed_pending_capacity_counterexample_at_22s(self):
        args = fixture()
        args[2][:, :, :, 10] = 100  # only ARCH, legal limit 50 shares
        module = local_module("pnl_v2_simulator.py", [
            ("                pending_qty[i, j] += quantity", "                pending_qty[i, j] += quantity\n                audit_pending(r, ti, q.copy(), queue)"),
        ])
        violations = []

        def inspect(r, ti, q, queue):
            buys = np.zeros_like(q)
            sells = np.zeros_like(q)
            for future in queue[ti + 1:]:
                for ids, symbols, requested, cap, engine in future:
                    np.add.at(buys, (ids, symbols), np.maximum(requested, 0))
                    np.add.at(sells, (ids, symbols), np.maximum(-requested, 0))
            if np.any(q + buys > LIMITS) or np.any(q - sells < -LIMITS):
                violations.append({"round": r + 1, "second": ti * 2, "ARCH_position": int(q[0, 10]), "ARCH_pending_buys": int(buys[0, 10]), "ARCH_pending_sells": int(sells[0, 10])})

        module["audit_pending"] = inspect
        result = module["simulate"](*args, ongoing={"cycle": 10, "top_k": 1, "threshold": 0}, latency=22, audit=True)
        self.assertTrue(violations)
        self.assertLessEqual(result["max_position_fraction"].max(), 1)
        self.assertEqual(violations[0]["second"], 20)
        self.assertEqual(violations[0]["ARCH_pending_buys"], 100)
        OBSERVATIONS["v2_signed_pending_bug"] = {"first_violation": violations[0], "ARCH_limit": 50, "nominal_fixed_order_positions_legal": True, "qualification": "22s latency is accepted by API but is outside published 2..12s stresses"}

    def test_routed_composition_independent_cash_and_round_rate(self):
        args = formation_fixture()
        args[2][:] = 10
        config = {"formation_route": {"start": 0, "exit_at": 80}, "ongoing": {"cycle": 10, "top_k": 8, "threshold": 0}}
        combined = run(args, config, {}, audit=True)
        route = simulate_routes(args[0], args[1], args[4], **config["formation_route"], audit=True)
        resume = np.ceil((route["flat_times"] + 60) / 10).astype(int) * 10
        delta = args[2].copy()
        delta[np.arange(0, 780, 10)[None, None, :] < resume[:, :, None]] = 0
        tail_args = [*args]
        tail_args[2] = delta
        tail = simulate(*tail_args, ongoing=config["ongoing"], audit=True)
        np.testing.assert_allclose(combined["pnl"], route["pnl"] + tail["pnl"], atol=1e-7)
        self.assertTrue(np.all(route["positions"] == 0))
        self.assertFalse(np.any((route["action_ticks"] > 0) & (tail["action_ticks"] > 0)))
        for r in range(3):
            route_times = np.flatnonzero(route["action_ticks"][0, r]) * 2
            tail_times = np.flatnonzero(tail["action_ticks"][0, r]) * 2
            self.assertGreaterEqual(tail_times.min() - route_times.max(), 60)
        self.assertGreater(int(global_rolling(combined["action_ticks"]).max()), 60)
        OBSERVATIONS["route_composition"] = {"pnl_additivity": "pass", "within_round_handover": "pass", "reported_max_actions": int(combined["max_rolling_actions"].max()), "contiguous_round_max_actions": int(global_rolling(combined["action_ticks"]).max())}

    def test_pending_orders_at_round_end_and_rejected_limits(self):
        args = fixture()
        args[3][0, 0] = 110
        args[1][0, 0] = 110
        # Arrival jumps beyond the limit; reservations must not be credited fills.
        args[0][0, 2, 371:, 0] = 120
        result = simulate(*args, end_margin=0, audit=True)
        self.assertEqual(result["pnl"][0], 0)
        self.assertTrue(np.all(result["positions"] == 0))
        # Every accepted submission fits in the round; last-minute unfilled limits
        # are reserved by simulator assertions, but are absent from return schema.
        for latency in [2, 12]:
            args = fixture()
            args[2][:] = 3
            result = simulate(*args, ongoing={"cycle": 10, "top_k": 5, "threshold": 0}, latency=latency, audit=True)
            self.assertTrue(np.all(result["positions"] == 0))
            last = np.flatnonzero(result["action_ticks"][0, 0])[-1] * 2
            self.assertLessEqual(last + latency, 778)
        OBSERVATIONS["round_end"] = {"scheduled_pending": "drained", "rejected_endgame_pnl": 0, "unfilled_resting_orders_returned": False}

    def test_preparation_ignores_storm_publication_counterexample(self):
        with tempfile.TemporaryDirectory(dir=HERE, prefix="synthetic-publication-") as folder:
            root = Path(folder)
            make_feed(root, delayed=True)
            output = root / "prepared.npz"
            with contextlib.redirect_stdout(io.StringIO()):
                prepare(root, output)
            with np.load(output) as arrays:
                full = dict(arrays)
            prefix = public_prefix(root, 1, 1, 120)
            # The age-60 observation is not published until real second 124.
            self.assertEqual(full["obs"][0, 0, 30, 5], 2)
            self.assertEqual(prefix["obs"][0, 0, 30, 5], 0)
            x = features(full, [120])[0][0, 0, 0]
            y = features(prefix, [120])[0][0, 0, 0]
            self.assertFalse(np.array_equal(x, y))
            OBSERVATIONS["storm_publication_bug"] = {"event_second": 120, "publication_second": 124, "replay_intensity_at_120": 2, "prefix_intensity_at_120": 0, "max_feature_difference": float(np.max(np.abs(x-y)))}

    def test_nominal_prefix_causality_and_odd_news_publication(self):
        comparisons = 0
        with tempfile.TemporaryDirectory(dir=HERE, prefix="synthetic-causality-") as folder:
            root = Path(folder)
            feed_folder = make_feed(root)
            # Odd real-second publication must be rounded upward, not revealed
            # on the immediately preceding two-second quote.
            messages = [json.loads(line) for line in (feed_folder / "feed.jsonl").read_text().splitlines()]
            for msg in messages:
                if msg["round"] == 1 and msg.get("stage") == "preliminary":
                    msg["time"] = timestamp(571)
            (feed_folder / "feed.jsonl").write_text("".join(json.dumps(m) + "\n" for m in messages))
            output = root / "prepared.npz"
            with contextlib.redirect_stdout(io.StringIO()):
                prepare(root, output)
            with np.load(output) as arrays:
                full = dict(arrays)
            self.assertEqual(full["stage"][0, 0, 285], 0)
            self.assertEqual(full["stage"][0, 0, 286], 1)
            self.assertEqual(full["stage"][0, 0, 369], 1)
            self.assertEqual(full["stage"][0, 0, 370], 2)
            for r in range(3):
                for t in [0, 60, 90, 180, 538, 540, 570, 572, 740]:
                    expected = features(full, [t])
                    prefix = public_prefix(root, 1, r + 1, t)
                    observed = features(prefix, [t])
                    for a, b in zip(expected, observed):
                        np.testing.assert_allclose(a[:, r], b[:, r], atol=1e-10)
                    poisoned = {name: value.copy() for name, value in full.items()}
                    poisoned["obs"][:, r, max(0, (t - 60) // 2 + 1):, :2] = 1e5
                    for name in ["damage", "loss", "stage", "probability", "cone"]:
                        poisoned[name][:, r, t // 2 + 1:] = 1e5
                    for name in ["report_truth", "loss_truth", "settlement_truth", "pattern_truth", "erratic_truth"]:
                        poisoned[name][:] = 999999
                    for a, b in zip(expected, features(poisoned, [t])):
                        np.testing.assert_allclose(a[:, r], b[:, r], atol=1e-10)
                    comparisons += 1
        OBSERVATIONS["nominal_prefix_causality"] = {"round_time_cases": comparisons, "full_cache_vs_public_prefix": "equal", "future_and_truth_poisoning": "unchanged", "news_at_571_visible_from": 572, "final_report_visible_from": 740}

    def test_reordered_report_replacement_counterexample(self):
        with tempfile.TemporaryDirectory(dir=HERE, prefix="synthetic-reorder-") as folder:
            root = Path(folder)
            make_feed(root, reorder=True)
            output = root / "prepared.npz"
            with contextlib.redirect_stdout(io.StringIO()):
                prepare(root, output)
            with np.load(output) as arrays:
                self.assertEqual(arrays["stage"][0, 0, 370], 1)
                self.assertEqual(arrays["damage"][0, 0, 370, 0], .1)
            prefix_600 = public_prefix(root, 1, 1, 600)
            prefix_740 = public_prefix(root, 1, 1, 740)
            self.assertEqual(prefix_600["stage"][0, 0, 300], 0)
            self.assertEqual(prefix_740["stage"][0, 0, 370], 1)
            OBSERVATIONS["feed_reordering_bug"] = {"expected_stage_at_740": 2, "prepared_stage_at_740": 1, "prefix_stage_at_740": 1, "expected_stage_at_600": 1, "prefix_stage_at_600": 0}

    def test_action_limiter_real_second_boundary(self):
        limiter = ActionLimiter(key_limit=60)
        for _ in range(60):
            self.assertTrue(limiter.take("one", 778))
        self.assertFalse(limiter.take("one", 780))
        self.assertFalse(limiter.take("one", 837.999))
        self.assertTrue(limiter.take("one", 838))


if __name__ == "__main__":
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(Audit)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    OBSERVATIONS["suite"] = {"run": result.testsRun, "failures": len(result.failures), "errors": len(result.errors)}
    OBSERVATIONS["source_sha256"] = {name: hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in [
        "etf_route_v3.py", "pnl_v2_simulator.py", "pnl_v3_select.py", "models.py", "prepare.py", "predict_prefix.py"]}
    (HERE / "checks.json").write_text(json.dumps(OBSERVATIONS, indent=2) + "\n")
    raise SystemExit(not result.wasSuccessful())
