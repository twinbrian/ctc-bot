"""Training-only price-timing diagnostic. No settlement labels or policy search.

Loads only season_ids and market from the explicitly permitted development NPZ,
then restricts measurements to fit seasons 361..600. The other development rows
are not evaluated. No parent cache, models or outcome artifacts are opened.
"""

import json

from audit_checks import HERE, BASKETS, SYMBOLS, np


def main():
    path = HERE.parent / "development.npz"
    with np.load(path, allow_pickle=False) as z:
        ids = z["season_ids"]
        assert ids.min() >= 121 and ids.max() <= 600
        mask = ids >= 361
        market = z["market"][mask]
        selected_ids = ids[mask]
    assert len(selected_ids) == 240
    records = []
    for second in [60, 62, 64, 66, 68, 70, 72, 80, 90]:
        change = market[:, :, second // 2] - market[:, :, 30]
        records.append({"second": second,
                        "mean_change_from_t60_by_symbol": dict(zip(SYMBOLS, change.mean((0, 1)).tolist())),
                        "fraction_exactly_unchanged_by_symbol": dict(zip(SYMBOLS, (change == 0).mean((0, 1)).tolist()))})
    # Consensus basis is a diagnostic, not executable arbitrage or depth.
    basis = market[..., 10:] - market[..., :10] @ BASKETS.T
    output = {"source": "../development.npz: season_ids and market only", "used_seasons": [int(selected_ids.min()), int(selected_ids.max())], "n_fit_seasons": len(selected_ids),
              "formation_response": records, "consensus_basis_mean_abs": dict(zip(SYMBOLS[10:], np.abs(basis).mean((0, 1, 2)).tolist())),
              "not_identified_from_this_data": ["bid/ask spread", "displayed or available depth", "replenishment", "order latency", "queue position", "conversion rejection probability", "inter-round real-time pause", "within-timestamp news/quote order"],
              "qualification": "Descriptive fit-period consensus timing only; neither out-of-sample evidence nor executable fills"}
    (HERE / "development_diagnostics.json").write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
