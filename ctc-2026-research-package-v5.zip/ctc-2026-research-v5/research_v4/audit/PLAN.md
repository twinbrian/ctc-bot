# Independent v3 replay audit

Started 2026-10-19 05:30 UTC; stop by 06:30 UTC.

Scope: read-only audit of completed parent v3 source/tests and qualitative reports.
No loading parent caches, raw histories, outer outcomes, or seasons 1–120. Only
`../development.npz` may be used for data diagnostics. No strategy optimization,
validation selection, child agents, external services, or parent-file edits.

1. Trace causal feature/publication handling and fit/selection provenance.
2. Independently test zero-cash ETF conversions, coherent-mark accounting,
   all-leg reservation and reordered/partial/rejected operations.
3. Check quote/news event ordering, two-second latency, rolling real-time actions,
   finite depth, end-of-round orders and strategy composition.
4. Use small synthetic adverse scenarios to expose assumptions about synchronized
   formation, latency and depth replenishment. No parameter search for profit.
5. Deliver `AUDIT.md`, executable independent repros, machine-readable checks,
   and a concise `HANDOFF.md`, with severity, exact line references and rerun scope.

Compute: one Python process at a time, BLAS/OMP threads set to one, bytecode/cache
outputs disabled outside this folder. Tests may construct synthetic local feeds.
