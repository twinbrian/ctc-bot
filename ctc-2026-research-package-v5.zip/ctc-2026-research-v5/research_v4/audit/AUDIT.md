# Independent skeptical audit of the completed v3 framework

**Conclusion:** no confirmed ETF cash-creation, duplicated market-fill, or nominal
two-second lookahead bug was found in the selected route implementation. Its
positive/negative reservations are sound under the tested reordered arrivals.
There are, however, **four reproducible implementation defects/unsupported input
cases**, including a cross-round rolling-action error if rounds are contiguous.
The larger limitation is unverified execution: the approximately USD 11,101
reported mean remains a conditional consensus-fill simulation result. This audit
does not establish attainable live profit or re-estimate that mean.

## Scope and evidence

- Read the research contract, completed parent source/tests and prior v3 report.
  No parent `cache.npz`, fitted models, outer-result files, or raw histories were
  opened. No strategy parameters were optimized; no validation policy was tested.
- The only real-data calculation reads `season_ids` and `market` from permitted
  `../development.npz`, and measures **fit seasons 361–600 only**. It computes
  timing diagnostics, not strategy PnL. Everything else below is synthetic.
- Access caveat: a whole-file read of `REPORT_V3.md` exposed its embedded aggregate
  fold-summary table, including a 1–120 aggregate. No underlying or season-level
  1–120 outcomes were opened, reproduced, or used in analysis. This was broader
  than the requested qualitative-only report access.
- All new files and generated fixtures are in this audit directory. Baseline
  files are unchanged. No sibling research-track code was analyzed. No external
  services, trades, child agents, branches or commits were used. BLAS/OMP = 1;
  no more than two Python processes ran concurrently.
- **39 original tests pass; 11 independent tests pass.** Several independent
  tests deliberately assert a defect's counterexample; passing them does **not**
  mean the defect is fixed. Results and source hashes are in `checks.json`.
- Source references below are relative to `/tmp/opencode/ctc-research/project`.

## 1. Severity-ranked confirmed findings

### H1 — Rolling action state is reset at round boundaries

**Confirmed under contiguous-round timing; historical impact unresolved.**

`pnl_v2_simulator.py:94–97` and `etf_route_v3.py:55–59` initialize a fresh history
and zero used-actions counter for every round. The combined v3 checker also
convolves each round separately (`pnl_v3_select.py:65–69,173–176`). A rolling real
minute does not reset merely because the round number changes.

**Repro:** `audit_checks.py::test_round_boundary_rate_counterexample` supplies
synthetic formation plus ongoing signals. The simulator reports a maximum of
60 actions; an independent 60-real-second convolution across contiguous
780-second rounds finds **95**. The routed composition test similarly reports
60 while the continuous oracle finds **84**. This is not a 30x-clock issue:
30 two-second samples correctly represent one real minute *within* each round.
`protocol.ActionLimiter` itself correctly retains actions across an arbitrary
round boundary (`protocol.py:108–120`); the simulators do not use it.

**Fix:** use one monotonic season/exchange-time action history, including the
measured inter-round gap, shared by routes and tail engines. Do not sum two
already-executed schedules and only inspect per-round counts. Record attempted
and rejected actions under the exchange's actual counting rule.

**Rerun bound:** if a verified pause clears every prior action, or a continuous
timestamp audit finds no overlap, existing numbers need no correction for this
issue. Otherwise rerun **joint v2/v3 policy selection and all joint execution
scenarios**: earlier tail actions can reduce next-round formation capacity.
Forecast models need not be refitted for an action-counter-only fix. Route-only
results with long idle intervals do not automatically inherit the defect.
No actual inter-round wall-clock gap is retained in the permitted market cube.

### H2 — Storm observations are keyed by age, not publication time

**Confirmed causal-ingestion defect for delayed or off-grid storm publication;
not demonstrated on the original canonical feed.**

`prepare.py:68–73` computes the publication tick but discards it for `storm`
messages, storing only `obs[..., age//2]`. `models.py:120–140` then reveals that
observation at nominal time `60 + age`. A message published later can therefore
enter historical features before it was available. `predict_prefix.py:54–64`
does filter publication time, so the replay and public-prefix adapter disagree.

**Repro:** `test_preparation_ignores_storm_publication_counterexample` creates an
invented age-60 observation published at real second 124. At decision time 120,
prepared features already contain intensity 2; the true public prefix does not.
No future prices or settlements are needed for the counterexample.

**Fix:** preserve event time **and** publication/receipt time, build as-of
observation state, and encode missing/stale observations explicitly. A model
trained on a fully populated age grid is not automatically valid when a live
observation is absent. Keep publication metadata in the cache so causality can be
audited after preparation.

**Rerun bound:** canonical feeds with observations always published exactly at
`60 + age` are unaffected. If not, rebuild affected features and refit/replay
dependent short-horizon/structural/aftermath paths. Pure formation curves based
only on training market prices are not directly contaminated by this bug. The
existing cube cannot establish whether delayed publications occurred.

### M1 — Reordered feed records can overwrite final reports or truncate a prefix

**Confirmed ingestion/adapter robustness defect; not evidence that canonical
sorted histories were wrong.**

`prepare.py:62–77` forward-fills in file order, with no chronological validation
or final-report precedence. `predict_prefix.py:52–69` additionally stops at the
first beyond-cutoff record. Its market reader has the same sorted-input premise
(`predict_prefix.py:46–50`). The safer final-over-preliminary rule exists in
`protocol.py:27–32` but is not used by these adapters.

**Repro:** `test_reordered_report_replacement_counterexample` places a final
report ahead of an older preliminary in an invented JSONL file. At t=740, both
prepared and prefix state incorrectly end with stage 1 and 10% damage instead
of stage 2 and 20%. At t=600, the prefix breaks at the future final and misses
the already-published preliminary entirely.

**Fix:** either reject nonmonotonic archives explicitly or sort/replay by the
appropriate publication/sequence key. A streaming adapter needs a receipt-time
event state, deduplication and monotonic report precedence; replacing `break`
with `continue` alone does not fix final-report regression.

**Rerun bound:** rebuild/replay only where out-of-order or regressive records
exist; the canonical sorted-prefix equivalence tests pass. Changing only the
live adapter does not by itself invalidate an otherwise verified sorted cache.

### M2 — v2's signed-net pending quantity can manufacture reservation capacity

**Confirmed for an accepted 22-second latency setting, outside the published
2–12-second stress range. No matching defect found in `simulate_routes`.**

The tail simulator stores one signed pending quantity (`pnl_v2_simulator.py:58,
141–142,185`), considers a symbol available when it nets to zero (`276–281`),
and clears its scheduled exit at submission (`233–235`). It does not track
worst-ordering positive/negative pending legs separately.

**Repro:** `test_v2_signed_pending_capacity_counterexample_at_22s` predicts only
ARCH. At t=0 it buys 50; at t=10 it sends the offsetting exit before the entry
arrives; at t=20 it submits another buy. Actual position is zero, but outstanding
buys total **100** against a **50**-share limit, with 50 pending sells. Fixed
FIFO arrivals keep realized positions legal and all original assertions pass;
another arrival order can put both buys ahead of the sell.

**Fix:** reserve each side separately for every live order, require explicit
order completion before reusing a symbol, and enforce capacity at submission
and after every execution/cancellation. Do not rely on future offsetting fills.

**Rerun bound:** latency/jitter/partial-fill extensions that permit overlapping
cycles must be rerun. This counterexample does not prove an error in the
published <=12-second results. A corrected tail ledger should be regression-
checked against those results before reuse.

## 2. Execution assumptions: material, but not disguised accounting bugs

### High materiality — full fills, successful conversions, and exact timing

The route executes every submitted market quantity and every conversion at one
fixed latency (`etf_route_v3.py:48,96–115,130`). The tail similarly fills market
requests in full (`pnl_v2_simulator.py:141–156`). There is no general partial-fill,
exchange-rejection, delayed-acknowledgment or cancellation-race state machine.
The assumptions are substantially disclosed in `REPORT_V3.md:143,178–180`.

`adverse_scenarios.py` injects faults **only into in-memory copies**, making the
changed premise explicit:

- Rejecting one entire atomic ARCH conversion is recovered in the tested case;
  positions eventually flatten. Do not generalize this to all rejection paths.
- Filling only 25 of the first requested 50 ARCH market shares, while retaining
  the other 25 as a live reservation, prevents the closing handover and ends in
  `Route portfolio must flatten each round`. The closing gate waits for all
  reservations (`etf_route_v3.py:138–147`), but no cancel/remainder lifecycle can
  resolve this case. It fails loudly rather than reporting fabricated profit.
- Bunching arrivals into ten-second buckets produces **250 market shares in one
  symbol at one arrival tick**. Original fixed-latency execution has no such
  duplicate depth in the independent trace. The failure arises because depth
  is throttled at **submission** (`etf_route_v3.py:181–193`;
  `pnl_v2_simulator.py:137,173–187`), equivalent to arrival throttling only under
  equal deterministic latency.

These fault results are scenario demonstrations, not measured probabilities or
estimates of actual slippage. They do not by themselves correct the historical
PnL figure. They establish missing requirements before execution-based promotion.

### Medium materiality — “no passive-fill credit” is not a worst-case loss bound

Noncrossing limits become `resting` (`pnl_v2_simulator.py:147–150`) and reserve
capacity, but never execute later. Aftermath cancel-all is delayed and counted
(`360–370`); final-round limits can remain through settlement. The returned
result omits resting-order state (`451–471`). The partial-fill unit test in
`tests/test_framework.py:122–135` exercises the separate **endgame** simulator,
not this v3 route/tail lifecycle.

An invented final-round example sends four 50-share buys capped at 110; each
misses at arrival price 120. The nominal replay reports zero PnL. If the retained
limits later receive 50 shares per tick at 100 before settlement at 90, PnL is
**-2,000**. Thus omitting passive fills can omit adverse fills as well as profits.
This is a limitation of the stated no-later-fill assumption, not proof that
those particular fills would occur in a real book.

**Required fix for expanded execution work:** expose filled, pending and resting
quantities and order IDs; process actual cancel acknowledgments and possible
fills before them; retain risk until resolution. Verify cancel-all semantics and
action cost rather than inferring them from `pnl_v3_select.py:283`.

## 3. Checks with no confirmed bug

| Question | Independent evidence / source | Finding |
|---|---|---|
| Does ETF conversion create cash? | 100 random coherent baskets; flat-market round trips; independent fill-ledger reconstruction. `etf_route_v3.py:99–115,197–200`. | **No confirmed bug.** Conversion itself changes no cash; coherent-mark value is invariant. A flat coherent market loses exactly execution costs. |
| Are all conversion legs reserved? | 309 traced submissions/fills; upper/lower reservation checks, randomized partial subsets, reversed same-time arrival order. `122–129,152–168`. | **No confirmed bug in routed reservations.** Financing markets and conversion legs cannot release capacity before their fills. |
| Is market depth charged twice? | Independent per-arrival-symbol quantity totals and cash ledger, fixed 12s latency. | **No confirmed bug under fixed latency.** Every traced market fill is <=50 shares/symbol/tick; conversions are transformations, not market depth. |
| Is news traded at the stale decision quote? | Known t=90 signal, entry quote t=92=109, exit t=102=110: 50-share PnL is 50, not 500. | **No confirmed bug.** The next arrival quote is used. Within-timestamp feed/quote order remains unobserved. |
| Are canonical prefix features causal? | 27 round/time cases compare fully prepared and public-prefix features; poison future observations/reports/truth. Odd publication at571 is visible at572; final report at740. `models.py:101–162`. | **No confirmed bug for on-schedule, ordered feed.** Future/truth poisoning leaves current features unchanged. |
| Are pending fills discarded at round end? | Synthetic 2s/12s tails close before last quote. Admission guards and assertions: `pnl_v2_simulator.py:200–202,440–449`; route `148–149,197–199`. | **No confirmed silent discard in supported scenarios.** Filled inventory is not reset; r1/r2 must actually flatten. Unresolved stress cases abort rather than carry. |
| Can route and tail PnL be added? | Independent additive cash check, flat routed positions and >=60s within-round handover. `pnl_v3_select.py:49–70`. | **No confirmed cash double count within this separation.** Cross-round rate state is H1. General concurrent strategies cannot use this composition shortcut. |

Further qualifications: conversion cost-basis attribution is booked at basket
parity, a reasonable zero-sum attribution convention, not actual separate stock
cash trades. The summed component drawdown is an upper bound, not a reconstructed
shared-account drawdown; this is disclosed in `REPORT_V3.md:159` and is not the
selection objective. `simulate_routes` requires flat inventory, so its unused
`truth` argument does not supply a future trading input.

The reservation result also has a simple order-independent proof. Write positive
pending legs as P and negative legs as N. On filling any reserved delta d,
`q' + P' = q + P - max(-d,0)` and
`q' - N' = q - N + max(d,0)`. Both bounds remain inside the original limits,
regardless of which reserved operation arrives first. This proof relies on
keeping unfilled remainders reserved; signed-net pending quantities do not suffice.

## 4. Calibration, selection and bootstrap audit

**No confirmed fold-level in-sample prediction bug in the selected v3 path.**

- `pnl_v2_train.py:19–23,62–109` makes disjoint whole-season fit/inner/outer masks.
  Formation curves are training means, not the evaluated season's future path.
  Fold-0 reuse matches the original >=241 training mask (`common.py:30–34`;
  `short_horizon.py:14–40`; `train.py:16–23`). Other fold models fit their own
  training mask. Earlier rounds' published final reports are valid inputs
  (`models.py:105–113`); current/future report truth arrays are not features.
- Aftermath full-path features are used at/after dissipation
  (`aftermath_v3_train.py:23–35`), and its targets remain labels (`43–68`). The
  v3 narrative says this family was rejected by all inner selections; it should
  not be retroactively credited with the selected route improvement.
- The staged 169-candidate search is explicit (`pnl_v3_select.py:90–145`), and
  normal `main` execution freezes all folds before evaluating them (`286–292`).
  That is not global optimality, an isolated routing treatment effect, or fresh
  out-of-sample evidence. Prior model-family/kernel/economic identification has
  already used this dataset; rotating folds does not undo researcher selection.
- `evaluate.py:24–27` resamples whole-season realized outcomes, correctly keeping
  storms together. It does **not** refit models, rerun selection, model overlapping
  training-fold dependence, or include execution uncertainty. Its interval is
  descriptive conditional uncertainty for the already-produced outcome vector,
  not a calibrated post-selection probability of future profit.
- The report expressly acknowledges these restrictions (`REPORT_V3.md:19–21,
  145,155`). **No confirmed misrepresentation in those qualifiers.** Preserve
  them wherever the bootstrap interval or mean is reused. Five outer policies
  are not one universally selected policy or a chronological forward test.

For any pipeline uncertainty exercise, resample whole seasons and refit/select
inside each resample using a frozen research protocol; even that cannot restore
a fresh holdout after the broader research history. Do not use an in-sample
reference forecast as honest validation evidence in v4.

## 5. Formation synchronization and execution stress

`development_diagnostics.json` uses only fit seasons361–600 (720 storms):

| Relative to t=60 | PORT mean change | HAVEN mean change | ARCH mean change |
|---|---:|---:|---:|
| t=62 | +0.0015 | -0.0011 | +0.0075 |
| t=64 | +1.8755 | +3.6115 | +0.0116 |
| t=70 | +1.9655 | +3.7660 | +9.2804 |

This corroborates a synchronized **house-price** response: stocks around +4s,
ETF around +10s. It does not estimate order latency. Observed consensus basis
also does not identify executable arbitrage, spread, depth or replenishment.

Seven predeclared synthetic stresses hold one policy fixed (start20/exit100).
They are not historical performance estimates:

| Synthetic premise | Net synthetic PnL | Flat time each round |
|---|---:|---:|
| Stock jump64, ETF jump70; baseline execution | 36,998.25 | 116 |
| Both jumps 20s later | 36,998.25 | 116 |
| Both jumps 60s later | -8,289.00 | 116 |
| Latency12s | 34,162.88 | 148 |
| Replenishment10s | 31,854.00 | 142 |
| Replenishment30s | 14,047.88 | 134 |
| Depth10, latency12s, replenishment10s | 5,436.45 | 152 |

Early positioning explains why modest deterministic latency or replenishment
stress can look benign: acquisition still precedes the scheduled jump. That
does not test a shifted/missing shock, failed financing leg, competitor depletion
at the event, stochastic tail latency, or adverse resting fills. The 60s shift
leaves only paid costs after the strategy has already exited. No probability is
assigned to any of these invented scenarios.

## 6. Conservative minimum execution model for candidate promotion

1. **One event-driven account on monotonic real time.** Carry cash, positions,
   both-sided pending/resting reservations, outstanding acknowledgments, rate
   history and liquidity state across rounds. Settle once at round3 end. Report
   residual risk rather than substituting an assertion for an execution outcome.
2. **Causal event visibility.** Preserve publication/receipt time independently
   of storm age; define same-time message/quote/arrival ordering. Decisions see
   only received information. Keep a >=2s decision-to-arrival floor and test an
   additional quote tick when within-timestamp order is ambiguous.
3. **Liquidity is consumed at execution.** One shared per-symbol arrival budget
   across all strategies; partial fills keep the remainder reserved. Depth must
   not automatically reset because another order, strategy or round begins.
   No orderbook means no positive guaranteed capacity can be inferred.
4. **Atomic zero-cash conversion, non-atomic financing.** Check all legs against
   worst-order pending capacity before accepting a conversion. Support rejected
   conversions, partial/rejected hedges, delayed acknowledgments and explicit
   recovery. Do not assume buying/selling the ETF and converting it are atomic.
5. **Explicit order lifecycle and price protection.** Keep failed/noncrossing
   limits live until actual cancellation acknowledgment or expiration; include
   adverse fills during that interval. Verify conversion permissions, lot sizes,
   cancel-all/action rules and any funding constraints against actual rules.
6. **Retain the contract baseline, require a joint adverse scenario as an
   additional provisional research hurdle:** unchanged decisions with another
   25bps unexpected cost per side, 2–12s variable arrivals, at most 10 executable
   shares/symbol per 10s, a conversion rejection and an unresolved partial hedge.
   Also test delayed/absent formation repricing and an ETF-price haircut toward
   contemporaneous basket parity adverse to the order side. These are explicit
   conservative assumptions, **not estimates** or proof of live attainability.
   Report each scenario's mean and residual inventory separately; assign no
   invented probabilities to combine them into an asserted expected return.
7. **Promote only incremental mean PnL in that shared account**, with fixed
   candidate choices and complete action/order traces. Do not add standalone
   backtests unless nonoverlap of positions, live orders, rate budget and depth
   is proved in real time. Obtain executable-book/acknowledgment evidence before
   interpreting any positive scenario mean as available execution capacity.

No defensible live-profit bound follows from consensus marks alone. The active
strategy can retain unhedged exposure when financing fails; zero market fills do
not imply zero risk after a conversion. Abstention is the only trivially known
zero-trading-PnL alternative, not a reason to treat the hypothetical mean as a
guaranteed or unbiased return.

## Reproduction and artifacts

From this directory, run `bash run_audit.sh`. It uses one process at a time and
writes only here. Individual commands are in the script.

- `audit_checks.py`, `checks.json`: nominal properties and four defect repros.
- `adverse_scenarios.py`, `adverse.json`: fixed invented paths and explicit fault
  injection; baseline files are never patched.
- `development_diagnostics.py`, `development_diagnostics.json`: fit-only timing.
- `PLAN.md`, `HANDOFF.md`: scope and concise parent-session handoff.

**Rerun priority:** first resolve actual round-boundary timing and H1, then
publication/ordering provenance, then implement the shared fault-aware ledger.
There is no reason to retrain forecasts solely because the zero-cash conversion
test or the nominal delayed-fill test passed; reruns should follow the dependency
bounds under each finding rather than become another unconstrained strategy search.
