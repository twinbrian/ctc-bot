# Nonlinear settlement inequalities — predeclared follow-up

New study; preserve completed C06 unchanged. Only `../../development.npz` and
permitted read-only source. Fit 361–600; inner selection 241–360; freeze at most
one size, refit the same economics on 241–600, then one **further retrospective
validation** on 121–240. Validation was already examined in C06 and is not fresh.
Retain every no-trade season and a zero-PnL no-trade comparison.

## Fixed family and two sizes

Exactly two configurations: **K=25** and **K=50** rebuilder shares. Each considers
RECON and MAT, at most one episode in each per season. Round 3 only, decision
seconds 540,550,...,730. Pick the highest strictly positive current estimated
complete-hedge floor among unused contracts/directions. One serial acquisition
at a time; finished positions are held to final settlement. No forecast fitting,
basis thresholds, parameter search, or damage forecast.

Fit affine physical settlements on cumulative training damage and reconstructed
outages. Fit positive concave exponential RECON economics on PORT/GRID/FERRY
damage. For MAT, fit insured-loss weights by training damage/loss regression,
then fit a positive saturating exponential of that aggregate. Fixed functional
forms from permitted source; all numerical coefficients fitted on allowed IDs.

Outages use observed site-weighted closure intervals through storm dissipation
(Gaussian wind, threshold .35, real seconds/120). At r3 t>=540 the full required
observation path is available. Earlier rounds' published final damage reports
bound cumulative damage before round 3. Assume each final storm increment is in
[0,1]; report this support assumption and any violations.

## Bounds, rounding, and calibration

For physical relation residuals, retain training min/max expanded by one quote
cent. Do the same for each rebuilder relation residual. Prior-report fraction
error bounds are training maximum absolute error plus .0001. These are fixed
empirical calibration envelopes, not distribution-free guarantees or tuned
profit thresholds; include coefficient/outage approximation in residual audits.

With b<0, physical residual bounds imply upper/lower shifted affine damage
inputs. The resulting upper rebuilder envelope is concave in terminal physical
prices. Its tangent at the **current observed** physical prices bounds it above.
Short K rebuilder, hedge K times its gradient, and round physical quantities to
nearest integers. Compute the minimum residual-rounding payoff over the full
feasible physical terminal-price rectangle, not at current marks.

Also consider the mathematically valid secant of the lower concave envelope over
its full feasible scalar aggregate interval. Long K rebuilder and the opposite
linear hedge. This is the second direction of the same two-size contract family,
not another parameter grid. Reject malformed/unsupported bounds.

Entry gate is simply a strictly positive current cost-and-rounding-adjusted floor.
Every market leg pays arrival consensus plus 25bps + $.02/share, 2s latency,
50-share/symbol/2s depth, one action per operation. Rebuilder first, then physical
symbols in published order; split larger legs and wait for each confirmation.
Reserve all legs, enforce published limits including pending legs and a shared
60-action rolling minute. Compute the **actual filled-cash floor only after all
legs arrive**. Finish an admitted hedge even if slippage erases its quoted floor.
No conversions or cost-basis transfers; settlement holdings are real inventories.

## Selection and required evidence

Choose the positive-inner-mean size with no actual terminal-PnL violations of its
calibrated filled floors; tie goes to K=25. If neither qualifies, keep no-trade as
the recommendation and freeze K=25 only as a diagnostic if a further validation
is useful. Never discard zero-trade seasons. No tuning on further validation.

Report every candidate, opportunity rejections, quoted/filled floors, costs,
integer rounding charges, actual terminal PnL, model-support/residual-envelope
violations, and all intermediate inventories. Fixed stresses: depth25, latency6,
and +10bps costs, without changing coefficients or admission thresholds. Provide
mathematical derivation, exact-ledger synthetic tests, tangent/secant inequalities,
rounding worst-case controls, a slippage-erased-floor control, and causal-input
checks. Parent owns shared-account evaluation/publication. Max two workers,
BLAS/OMP threads one. Initial pass <=35 minutes, finish before 06:30 UTC.
