"""Audit and summarize saved artifacts without another market-data evaluation."""

from nonlinear import ROOT, LIMITS, SYMBOLS, dump

import csv
import hashlib
import json
import platform
import sys

import numpy as np
import scipy


def main():
    frozen = json.loads((ROOT / "frozen.json").read_text())
    assert hashlib.sha256((ROOT / "frozen_economics.json").read_bytes()).hexdigest() == frozen["model_sha256"]
    assert hashlib.sha256((ROOT / "nonlinear.py").read_bytes()).hexdigest() == frozen["policy_source_sha256"]
    metrics = []
    for role, filename in [("inner", "all_candidate_results.json"), ("further_validation", "validation_results.json")]:
        metrics.extend(dict(role=role, **x) for x in json.loads((ROOT / filename).read_text()))
    with (ROOT / "all_metrics.csv").open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(metrics[0]))
        writer.writeheader()
        writer.writerows(metrics)
    season_rows = []
    for name in frozen["scenarios"]:
        with (ROOT / "validation" / name / "seasons.csv").open() as f:
            season_rows.extend(dict(scenario=name, **row) for row in csv.DictReader(f))
    with (ROOT / "validation_seasons.csv").open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(season_rows[0]))
        writer.writeheader()
        writer.writerows(season_rows)
    audited = []
    for path in sorted(ROOT.glob("**/audit.npz")):
        with np.load(path, allow_pickle=False) as z:
            q, pp, pn = z["inventory"], z["reserved_positive"], z["reserved_negative"]
            assert np.all(q + pp <= LIMITS) and np.all(q - pn >= -LIMITS)
            assert np.all(pp >= 0) and np.all(pn >= 0)
            assert np.all(pp[:, -1] + pn[:, -1] == 0)
            assert np.array_equal(q[:, -1], z["terminal_positions"])
            cs = np.pad(np.cumsum(z["action_ticks"], axis=1), ((0, 0), (1, 0)))
            rolling = cs[:, 30:] - cs[:, :-30]
            assert rolling.max() <= 60
            assert z["action_ticks"].max() <= 1
            assert len(z["season_ids"]) == 120 and len(np.unique(z["season_ids"])) == 120
            episodes = json.loads((path.parent / "episodes.json").read_text())
            assert len(episodes) == int(z["episode_count"].sum())
            assert np.all(z["episode_count"] <= 2)
            if not episodes:
                assert np.all(z["pnl"] == 0) and np.all(z["cash"] == 0) and np.all(q == 0)
            audited.append(str(path.relative_to(ROOT)))
    trace = json.loads((ROOT / "synthetic_sequential_trace.json").read_text())
    cash, inventory = 0.0, np.zeros(12, dtype=int)
    last_second = 540
    for fill in trace:
        j = SYMBOLS.index(fill["symbol"])
        quantity = fill["quantity"]
        assert fill["second"] >= last_second + 2
        assert abs(quantity) <= 50
        cost = abs(quantity) * (.0025 * fill["consensus"] + .02)
        assert abs(cost - fill["cost"]) < 1e-8
        cash -= quantity * fill["consensus"] + cost
        inventory[j] += quantity
        assert abs(cash - fill["cash"]) < 1e-8
        assert np.array_equal(inventory, fill["position"])
        assert np.all(inventory + fill["reserved_positive"] <= LIMITS)
        assert np.all(inventory - fill["reserved_negative"] >= -LIMITS)
        last_second = fill["second"]
    dump(ROOT / "artifact_audit.json", dict(passed=True, files=audited,
                                             synthetic_sequential_fills=len(trace),
                                             frozen_model_and_source_unchanged=True,
                                             zero_trade_seasons_retained=True))
    rows = []
    for role, k, folder in [("inner", 25, ROOT / "inner/K25/baseline"),
                            ("inner", 50, ROOT / "inner/K50/baseline"),
                            ("further_validation", frozen["k"], ROOT / "validation/baseline")]:
        with (folder / "quotations.csv").open() as f:
            quotes = list(csv.DictReader(f))
        for symbol in ["RECON", "MAT"]:
            for direction in ["upper", "lower"]:
                subset = [x for x in quotes if x["symbol"] == symbol and x["direction"] == direction]
                best = max(subset, key=lambda x: float(x["quoted_floor"]))
                rows.append(dict(role=role, k=k, symbol=symbol, direction=direction, observations=len(subset),
                                 best_quoted_floor=float(best["quoted_floor"]),
                                 best_floor_estimated_cost=float(best["estimated_cost"]),
                                 best_floor_rounding_charge=float(best["rounding_charge"]),
                                 max_nominal_quoted_floor=max(float(x["nominal_quoted_floor"]) for x in subset),
                                 max_continuous_quoted_floor=max(float(x["continuous_quoted_floor"]) for x in subset),
                                 positive_continuous_count=sum(float(x["continuous_quoted_floor"]) > 0 for x in subset),
                                 positive_integer_count=sum(float(x["quoted_floor"]) > 0 for x in subset),
                                 best_second=int(best["second"]),
                                 mean_rounding_charge=float(np.mean([float(x["rounding_charge"]) for x in subset]))))
    with (ROOT / "quote_diagnostics.csv").open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    sources = ["PLAN.md", "DERIVATION.md", "nonlinear.py", "report.py", "fit_economics.json", "frozen_economics.json", "frozen.json", "FURTHER_VALIDATION_OPENED.json"]
    dump(ROOT / "provenance.json", dict(
        python=sys.version, numpy=np.__version__, scipy=scipy.__version__, platform=platform.platform(),
        source_hashes={name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in sources},
        threads={"OMP_NUM_THREADS": 1, "OPENBLAS_NUM_THREADS": 1, "MKL_NUM_THREADS": 1},
        original_deadline="2026-10-19 06:30 UTC", restart_resumed="2026-10-19 13:32:56 UTC",
        note="User explicitly requested continuation after restart; original deadline had elapsed. Two identical inner invocations occurred around restart; no added configurations. Further validation opened only once."))
    print(json.dumps(rows, indent=2))
    print(f"Audited {len(audited)} saved paths and {len(trace)} sequential synthetic fills")


if __name__ == "__main__":
    main()
