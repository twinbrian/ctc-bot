"""Nonlinear settlement inequalities. No future-price forecasting or conversions."""

import os

for key in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ[key] = "1"

import argparse
import csv
import fcntl
import hashlib
import itertools
import json
import time
from pathlib import Path

import numpy as np
from scipy.optimize import least_squares

ROOT = Path(__file__).resolve().parent
DATA = ROOT.parent.parent / "development.npz"
SYMBOLS = ["PORT", "ISLE", "AQUA", "GRID", "FERRY", "RECON", "MAT", "GEN", "HAVEN", "REIN", "ARCH", "REBLD"]
LIMITS = np.array([200, 300, 500, 400, 800, 500, 700, 600, 250, 200, 50, 100])
SIZES = [25, 50]
SCENARIOS = {
    "baseline": dict(depth=50, latency=2, adverse_bps=0),
    "depth25": dict(depth=25, latency=2, adverse_bps=0),
    "latency6": dict(depth=50, latency=6, adverse_bps=0),
    "adverse10bps": dict(depth=50, latency=2, adverse_bps=10),
}


def dump(path, data):
    Path(path).write_text(json.dumps(data, indent=2, allow_nan=False) + "\n")


def load(role):
    bounds = {"fit": (361, 600), "inner": (241, 360), "refit": (241, 600), "validation": (121, 240)}
    with np.load(DATA, allow_pickle=False) as z:
        ids = z["season_ids"]
        lo, hi = bounds[role]
        mask = (ids >= lo) & (ids <= hi)
        d = {k: z[k][mask] for k in ["market", "obs", "damage", "report_truth", "loss_truth", "settlement_truth"]}
        d.update({k: z[k] for k in ["site_xy", "site_weight", "site_company"]})
        d["season_ids"] = ids[mask]
    return d


def observed_outages(d):
    """All inputs here are public by round 3 second 540; ignore obs index 240."""
    obs = d["obs"][:, :, :240]
    distance = np.linalg.norm(obs[..., None, :2] - d["site_xy"], axis=-1)
    wind = obs[..., None, 5] * np.exp(-(distance / obs[..., None, 4]) ** 2)
    weights = np.zeros((len(d["site_xy"]), 5))
    weights[np.arange(len(weights)), d["site_company"]] = d["site_weight"]
    closed = wind >= .35
    # Right-endpoint reconstruction, plus the final 478..480s interval.
    per_storm = (closed[:, :, 1:].sum(2) + closed[:, :, -1]) @ weights * (2 / 120)
    return per_storm.sum(1)


def f_rebuild(damage, r):
    return r["u"] + r["v"] * (1 - np.exp(-(damage @ np.asarray(r["w"]))))


def fit(d):
    damage = d["report_truth"].sum(1)
    outage = observed_outages(d)
    values = d["settlement_truth"]
    physical = np.zeros((5, 3))
    residual = np.zeros((len(values), 5))
    for j in range(5):
        columns = [np.ones(len(values)), damage[:, j]]
        if j in [0, 3, 4]:
            columns.append(outage[:, j])
        x = np.column_stack(columns)
        p = np.linalg.lstsq(x, values[:, j], rcond=None)[0]
        physical[j, :len(p)] = p
        residual[:, j] = values[:, j] - x @ p
    assert np.all(physical[:, 1] < 0)
    loss_weights = np.linalg.lstsq(damage, d["loss_truth"].sum(1), rcond=None)[0]
    assert np.all(loss_weights > 0)
    rebuild = []
    x = damage[:, [0, 3, 4]]
    fit_recon = least_squares(
        lambda p: p[0] + p[1] * (1 - np.exp(-x @ p[2:])) - values[:, 5],
        [32, 20, .5, .5, .5], bounds=(0, np.inf), max_nfev=2000,
        ftol=1e-12, xtol=1e-12, gtol=1e-12)
    w = np.zeros(5)
    w[[0, 3, 4]] = fit_recon.x[2:]
    rebuild.append(dict(symbol="RECON", index=5, u=float(fit_recon.x[0]), v=float(fit_recon.x[1]), w=w.tolist()))
    x = damage @ loss_weights / 1000
    fit_mat = least_squares(
        lambda p: p[0] + p[1] * (1 - np.exp(-x * p[2])) - values[:, 6],
        [32, 20, 1], bounds=(0, np.inf), max_nfev=2000,
        ftol=1e-12, xtol=1e-12, gtol=1e-12)
    rebuild.append(dict(symbol="MAT", index=6, u=float(fit_mat.x[0]), v=float(fit_mat.x[1]),
                        w=(fit_mat.x[2] * loss_weights / 1000).tolist()))
    for r in rebuild:
        error = values[:, r["index"]] - f_rebuild(damage, r)
        r.update(error_low=float(error.min() - .01), error_high=float(error.max() + .01),
                 fit_rmse=float(np.sqrt(np.mean(error ** 2))), fit_residual_range=[float(error.min()), float(error.max())])
    report_error = np.abs(d["damage"][:, :, -1] - d["report_truth"]).max((0, 1)) + .0001
    return dict(physical=physical.tolist(), physical_error_low=(residual.min(0) - .01).tolist(),
                physical_error_high=(residual.max(0) + .01).tolist(),
                physical_fit_rmse=np.sqrt(np.mean(residual ** 2, axis=0)).tolist(),
                physical_fit_residual_min=residual.min(0).tolist(), physical_fit_residual_max=residual.max(0).tolist(),
                rebuild=rebuild, prior_report_error=report_error.tolist(), loss_weights=loss_weights.tolist(),
                fit_ids=[int(d["season_ids"].min()), int(d["season_ids"].max())],
                calibration="Training one-sided residual extrema plus USD 0.01; prior report error max plus .0001 fraction")


def price_bounds(model, outage, prior):
    p = np.asarray(model["physical"])
    tol = 2 * np.asarray(model["prior_report_error"])
    damage_low = np.maximum(0, prior - tol)
    damage_high = np.minimum(3, prior + tol + 1)
    a = p[:, 0] + p[:, 2] * outage
    low = a + p[:, 1] * damage_high + model["physical_error_low"]
    high = a + p[:, 1] * damage_low + model["physical_error_high"]
    assert np.all(low <= high)
    return low, high


def affine_bound(model, rb, direction, p0, outage, low, high, calibrated=True):
    """Return c,g such that R<=c+gP (upper) or R>=c+gP (lower).

    These claims require fitted component residual/support envelopes to hold.
    Upper: tangent of concave upper envelope. Lower: scalar secant of the
    concave lower envelope over the full terminal-price rectangle.
    """
    physical = np.asarray(model["physical"])
    r = model["rebuild"][rb]
    w = np.asarray(r["w"])
    a = physical[:, 0] + physical[:, 2] * outage
    b = physical[:, 1]
    beta = w / b
    side = "high" if direction == "upper" else "low"
    e = np.asarray(model[f"physical_error_{side}"]) if calibrated else np.zeros(5)
    er = r[f"error_{side}"] if calibrated else 0.0
    alpha = w @ (-a / b + e / (-b))
    if direction == "upper":
        s0 = alpha + beta @ p0
        h0 = r["u"] + r["v"] * (1 - np.exp(-s0)) + er
        gradient = r["v"] * np.exp(-s0) * beta
        constant = h0 - gradient @ p0
    else:
        slo, shi = alpha + beta @ high, alpha + beta @ low
        assert shi >= slo - 1e-12
        f_lo = r["u"] + r["v"] * (1 - np.exp(-slo)) + er
        slope = r["v"] * np.exp(-slo) if shi - slo < 1e-12 else r["v"] * (np.exp(-slo) - np.exp(-shi)) / (shi - slo)
        gradient = slope * beta
        constant = f_lo - slope * slo + slope * alpha
    assert np.isfinite(constant) and np.isfinite(gradient).all()
    return float(constant), gradient


def residual_minimum(delta, low, high):
    return float(np.maximum(delta, 0) @ low + np.minimum(delta, 0) @ high)


def terminal_bound(quantity, k, direction, constant, gradient, low, high):
    if direction == "upper":
        delta = quantity[:5] - k * gradient
        intercept = -k * constant
    else:
        delta = quantity[:5] + k * gradient
        intercept = k * constant
    return float(intercept + residual_minimum(delta, low, high)), delta


def quote(model, rb, direction, k, price, outage, prior):
    low, high = price_bounds(model, outage, prior)
    constant, gradient = affine_bound(model, rb, direction, price[:5], outage, low, high)
    quantity = np.zeros(12, dtype=int)
    sign = -1 if direction == "upper" else 1
    quantity[model["rebuild"][rb]["index"]] = sign * k
    ideal = np.zeros(12)
    ideal[model["rebuild"][rb]["index"]] = sign * k
    ideal[:5] = -sign * k * gradient
    quantity[:5] = np.rint(ideal[:5]).astype(int)
    bound, delta = terminal_bound(quantity, k, direction, constant, gradient, low, high)
    nc, ng = affine_bound(model, rb, direction, price[:5], outage, low, high, calibrated=False)
    nominal_bound, _ = terminal_bound(quantity, k, direction, nc, ng, low, high)
    cost = float(np.abs(quantity) @ (.0025 * price + .02))
    cash = float(-quantity @ price - cost)
    ideal_cost = float(np.abs(ideal) @ (.0025 * price + .02))
    ideal_floor = float(-ideal @ price - ideal_cost + sign * k * constant)
    return dict(rb=rb, symbol=model["rebuild"][rb]["symbol"], direction=direction, k=k,
                quantity=quantity, terminal_bound=bound, nominal_terminal_bound=nominal_bound,
                quoted_floor=cash + bound, nominal_quoted_floor=cash + nominal_bound,
                continuous_quoted_floor=ideal_floor, estimated_cost=cost,
                rounding_charge=ideal_floor - (cash + bound),
                rounding_terminal_min=residual_minimum(delta, low, high),
                constant=constant, gradient=gradient, low=low, high=high)


def schedule(quantity, rb, depth):
    order = [5 + rb] + list(range(5))
    result = []
    for j in order:
        left = int(quantity[j])
        while left:
            qty = int(np.sign(left) * min(depth, abs(left)))
            result.append((j, qty))
            left -= qty
    return result


def public_inputs(d):
    # Deliberately excludes truth/settlement and current round's final report.
    return d["market"][:, 2], observed_outages(d), d["damage"][:, :2, -1].sum(1)


def simulate(d, model, k, depth=50, latency=2, adverse_bps=0):
    market, outage, prior = public_inputs(d)
    n = len(market)
    delay = max(1, int(np.ceil(latency / 2)))
    positions = np.zeros((n, 12), dtype=int)
    reserved_pos = np.zeros_like(positions)
    reserved_neg = np.zeros_like(positions)
    cash = np.zeros(n)
    costs = np.zeros(n)
    actions = np.zeros((n, 390), dtype=np.int8)
    inventory = np.zeros((n, 390, 12), dtype=np.int16)
    pp_trace = np.zeros_like(inventory)
    pn_trace = np.zeros_like(inventory)
    episodes, quotations, fills = [], [], []
    for i in range(n):
        used_contracts = set()
        active = None
        due = -1
        submitted = None
        current_index = 0
        last_arrival = np.full(12, -1000)
        for ti in range(270, 390):
            price = market[i, ti]
            if ti == due:
                j, signed = submitted
                assert ti - last_arrival[j] >= 1 and abs(signed) <= depth
                last_arrival[j] = ti
                unit_cost = price[j] * (.0025 + adverse_bps / 10000) + .02
                debit = signed * price[j] + abs(signed) * unit_cost
                cash[i] -= debit
                costs[i] += abs(signed) * unit_cost
                positions[i, j] += signed
                reserved_pos[i, j] -= max(signed, 0)
                reserved_neg[i, j] -= max(-signed, 0)
                fills.append(dict(season_id=int(d["season_ids"][i]), second=2 * ti, symbol=SYMBOLS[j],
                                  quantity=int(signed), consensus=float(price[j]), cost=float(abs(signed) * unit_cost),
                                  cash_change=float(-debit), cash=float(cash[i]), position=positions[i].tolist(),
                                  reserved_positive=reserved_pos[i].tolist(), reserved_negative=reserved_neg[i].tolist()))
                due = -1
                submitted = None
                assert np.all(np.abs(positions[i]) <= LIMITS)
                if current_index == len(active["schedule"]):
                    active["filled_second"] = 2 * ti
                    active["entry_cash"] = float(cash[i] - active["cash_before"])
                    active["cost"] = float(costs[i] - active["cost_before"])
                    active["filled_floor"] = active["entry_cash"] + active["terminal_bound"]
                    active["nominal_filled_floor"] = active["entry_cash"] + active["nominal_terminal_bound"]
                    episodes.append(active)
                    active = None
            if 2 * ti <= 730 and 2 * ti % 10 == 0:
                choices = []
                for rb in range(2):
                    for direction in ["upper", "lower"]:
                        offer = quote(model, rb, direction, k, price, outage[i], prior[i])
                        seq = schedule(offer["quantity"], rb, depth)
                        used_actions = int(actions[i, max(0, ti - 29):ti + 1].sum())
                        capacity = (np.all(positions[i] + reserved_pos[i] + np.maximum(offer["quantity"], 0) <= LIMITS)
                                    and np.all(positions[i] - reserved_neg[i] - np.maximum(-offer["quantity"], 0) >= -LIMITS))
                        reason = "eligible"
                        if offer["quoted_floor"] <= 0:
                            reason = "nonpositive_floor"
                        elif rb in used_contracts:
                            reason = "contract_already_used"
                        elif active is not None:
                            reason = "serial_acquisition_active"
                        elif not capacity:
                            reason = "inventory_capacity"
                        elif used_actions + len(seq) > 60:
                            reason = "action_budget"
                        elif ti + len(seq) * delay >= 390:
                            reason = "late_completion"
                        quotations.append(dict(season_id=int(d["season_ids"][i]), second=2 * ti,
                                               symbol=offer["symbol"], direction=direction, reason=reason,
                                               quoted_floor=float(offer["quoted_floor"]),
                                               nominal_quoted_floor=float(offer["nominal_quoted_floor"]),
                                               continuous_quoted_floor=float(offer["continuous_quoted_floor"]),
                                               estimated_cost=offer["estimated_cost"], rounding_charge=offer["rounding_charge"]))
                        if reason == "eligible":
                            offer["schedule"] = seq
                            choices.append(offer)
                if choices:
                    active = max(choices, key=lambda x: x["quoted_floor"])
                    active.update(row=i, season_id=int(d["season_ids"][i]), decision_second=2 * ti,
                                  cash_before=float(cash[i]), cost_before=float(costs[i]))
                    used_contracts.add(active["rb"])
                    reserved_pos[i] += np.maximum(active["quantity"], 0)
                    reserved_neg[i] += np.maximum(-active["quantity"], 0)
                    current_index = 0
            if active is not None and due < 0:
                submitted = active["schedule"][current_index]
                current_index += 1
                due = ti + delay
                assert due < 390
                actions[i, ti] += 1
                assert actions[i, max(0, ti - 29):ti + 1].sum() <= 60
            assert np.all(reserved_pos[i] >= 0) and np.all(reserved_neg[i] >= 0)
            assert np.all(positions[i] + reserved_pos[i] <= LIMITS)
            assert np.all(positions[i] - reserved_neg[i] >= -LIMITS)
            inventory[i, ti] = positions[i]
            pp_trace[i, ti] = reserved_pos[i]
            pn_trace[i, ti] = reserved_neg[i]
        assert active is None and submitted is None and due < 0
        assert np.all(reserved_pos[i] + reserved_neg[i] == 0)
    # Truth is used only after every trading decision and fill has completed.
    pnl = cash + np.sum(positions * d["settlement_truth"], axis=1)
    floor = np.zeros(n)
    nominal_floor = np.zeros(n)
    counted_pnl = np.zeros(n)
    episode_count = np.zeros(n, dtype=int)
    violations = np.zeros(n, dtype=int)
    nominal_violations = np.zeros(n, dtype=int)
    for ep in episodes:
        i = ep["row"]
        ep["terminal_pnl"] = float(ep["entry_cash"] + ep["quantity"] @ d["settlement_truth"][i])
        ep["floor_violation"] = ep["terminal_pnl"] < ep["filled_floor"] - 1e-8
        ep["nominal_floor_violation"] = ep["terminal_pnl"] < ep["nominal_filled_floor"] - 1e-8
        ep["physical_price_bound_violation"] = bool(np.any(d["settlement_truth"][i, :5] < ep["low"] - 1e-8) or np.any(d["settlement_truth"][i, :5] > ep["high"] + 1e-8))
        floor[i] += ep["filled_floor"]
        nominal_floor[i] += ep["nominal_filled_floor"]
        counted_pnl[i] += ep["terminal_pnl"]
        episode_count[i] += 1
        violations[i] += ep["floor_violation"]
        nominal_violations[i] += ep["nominal_floor_violation"]
    assert np.allclose(pnl, counted_pnl, atol=1e-8)
    assert np.all(episode_count <= 2)
    ledger = np.zeros(n)
    id_index = {int(sid): i for i, sid in enumerate(d["season_ids"])}
    for fill in fills:
        ledger[id_index[fill["season_id"]]] += fill["cash_change"]
    assert np.allclose(cash, ledger, atol=1e-8)
    return dict(pnl=pnl, filled_floor=floor, nominal_filled_floor=nominal_floor, cash=cash, cost=costs,
                episode_count=episode_count, floor_violations=violations, nominal_floor_violations=nominal_violations,
                terminal_positions=positions, action_ticks=actions, inventory=inventory,
                reserved_positive=pp_trace, reserved_negative=pn_trace,
                episodes=episodes, quotations=quotations, fills=fills)


def diagnostics(d, model):
    damage = d["report_truth"].sum(1)
    outage = observed_outages(d)
    p = np.asarray(model["physical"])
    errors = d["settlement_truth"][:, :5] - (p[:, 0] + p[:, 1] * damage + p[:, 2] * outage)
    outside = (errors < model["physical_error_low"]) | (errors > model["physical_error_high"])
    reb = []
    direct = []
    dhat = (d["settlement_truth"][:, :5] - p[:, 0] - p[:, 2] * outage) / p[:, 1]
    for r in model["rebuild"]:
        e = d["settlement_truth"][:, r["index"]] - f_rebuild(damage, r)
        reb.append(dict(symbol=r["symbol"], residual_min=float(e.min()), residual_max=float(e.max()),
                        rmse=float(np.sqrt(np.mean(e ** 2))), outside_calibration=int(np.sum((e < r["error_low"]) | (e > r["error_high"])))))
        re = d["settlement_truth"][:, r["index"]] - f_rebuild(dhat, r)
        direct.append(dict(symbol=r["symbol"], min=float(re.min()), max=float(re.max()), rmse=float(np.sqrt(np.mean(re ** 2)))))
    prior_error = np.abs(d["damage"][:, :2, -1] - d["report_truth"][:, :2])
    return dict(n=len(damage), physical_residual_min=errors.min(0).tolist(), physical_residual_max=errors.max(0).tolist(),
                physical_rmse=np.sqrt(np.mean(errors ** 2, axis=0)).tolist(),
                physical_envelope_exceedances_by_symbol=outside.sum(0).tolist(),
                physical_envelope_exceedance_seasons=int(outside.any(1).sum()),
                rebuild=reb, direct_cross_sectional_relation=direct,
                per_storm_damage_support_violations=int(np.sum((d["report_truth"] < 0) | (d["report_truth"] > 1))),
                prior_report_envelope_exceedances=int(np.sum(prior_error > model["prior_report_error"])))


def summary(result):
    pnl = result["pnl"]
    quotes = result["quotations"]
    eps = result["episodes"]
    positive = [x for x in quotes if x["quoted_floor"] > 0]
    return dict(n=len(pnl), mean_pnl=float(pnl.mean()), se=float(pnl.std(ddof=1) / np.sqrt(len(pnl))) if len(pnl) > 1 else 0,
                min_pnl=float(pnl.min()), max_pnl=float(pnl.max()), mean_cost=float(result["cost"].mean()),
                trade_seasons=int(np.sum(result["episode_count"] > 0)), episodes=len(eps),
                mean_filled_floor=float(result["filled_floor"].mean()), mean_nominal_filled_floor=float(result["nominal_filled_floor"].mean()),
                floor_violations=int(result["floor_violations"].sum()), nominal_floor_violations=int(result["nominal_floor_violations"].sum()),
                positive_quoted_opportunities=len(positive), total_quotations=len(quotes),
                max_quoted_floor=float(max(x["quoted_floor"] for x in quotes)),
                max_continuous_quoted_floor=float(max(x["continuous_quoted_floor"] for x in quotes)),
                min_acquired_filled_floor=min([x["filled_floor"] for x in eps], default=None),
                filled_floor_nonpositive=int(sum(x["filled_floor"] <= 0 for x in eps)),
                physical_bound_violations=int(sum(x["physical_price_bound_violation"] for x in eps)),
                mean_actions=float(result["action_ticks"].sum(1).mean()),
                max_position_fraction=float((np.abs(result["terminal_positions"]) / LIMITS).max()))


def clean(value):
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, dict):
        return {k: clean(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [clean(v) for v in value]
    return value


def write_result(path, d, result):
    path.mkdir(parents=True, exist_ok=True)
    dump(path / "summary.json", summary(result))
    arrays = {k: v for k, v in result.items() if isinstance(v, np.ndarray)}
    np.savez_compressed(path / "audit.npz", season_ids=d["season_ids"], **arrays)
    with (path / "seasons.csv").open("w", newline="") as f:
        fields = ["season_id", "pnl", "filled_floor", "nominal_filled_floor", "cash", "cost", "episode_count", "floor_violations", "nominal_floor_violations"]
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for i, sid in enumerate(d["season_ids"]):
            writer.writerow(dict(season_id=int(sid), **{key: result[key][i].item() for key in fields[1:]}))
    for name in ["quotations", "fills"]:
        rows = result[name]
        if rows:
            with (path / f"{name}.csv").open("w", newline="") as f:
                writer = csv.DictWriter(f, fieldnames=list(rows[0]))
                writer.writeheader()
                writer.writerows(rows)
    dump(path / "episodes.json", clean(result["episodes"]))


def tune():
    if (ROOT / "frozen.json").exists():
        raise RuntimeError("Already frozen; no retuning")
    existing = ROOT / "all_candidate_results.json"
    if existing.exists() and len(json.loads(existing.read_text())) == len(SIZES) * len(SCENARIOS):
        print("Complete inner grid already saved; no repeat scoring", flush=True)
        return
    model = fit(load("fit"))
    dump(ROOT / "fit_economics.json", model)
    d = load("inner")
    dump(ROOT / "inner_relation_diagnostics.json", diagnostics(d, model))
    metrics = []
    for k in SIZES:
        for name, scenario in SCENARIOS.items():
            result = simulate(d, model, k, **scenario)
            write_result(ROOT / "inner" / f"K{k}" / name, d, result)
            row = dict(k=k, scenario=name, **summary(result))
            metrics.append(row)
            dump(ROOT / "all_candidate_results.json", metrics)
            print(k, name, json.dumps(row), flush=True)


def freeze():
    if (ROOT / "frozen.json").exists():
        raise RuntimeError("Already frozen")
    metrics = json.loads((ROOT / "all_candidate_results.json").read_text())
    eligible = [x for x in metrics if x["scenario"] == "baseline" and x["mean_pnl"] > 0 and x["floor_violations"] == 0]
    selected = max(eligible, key=lambda x: (x["mean_pnl"], -x["k"]))["k"] if eligible else 25
    model = fit(load("refit"))
    dump(ROOT / "frozen_economics.json", model)
    config = dict(k=selected, diagnostic_only=not bool(eligible), no_trade_comparator_mean=0,
                  frozen_utc=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                  model_sha256=hashlib.sha256((ROOT / "frozen_economics.json").read_bytes()).hexdigest(),
                  policy_source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  further_validation="121..240 already examined in prior C06; not fresh",
                  decision_seconds=list(range(540, 731, 10)), scenarios=SCENARIOS)
    dump(ROOT / "frozen.json", config)
    print(json.dumps(config, indent=2), flush=True)


def validate():
    if (ROOT / "FURTHER_VALIDATION_OPENED.json").exists():
        raise RuntimeError("Further validation already opened")
    frozen = json.loads((ROOT / "frozen.json").read_text())
    assert hashlib.sha256((ROOT / "frozen_economics.json").read_bytes()).hexdigest() == frozen["model_sha256"]
    with (ROOT / "FURTHER_VALIDATION_OPENED.json").open("x") as handle:
        json.dump(dict(opened_utc=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                       label="Further retrospective validation; same rows previously examined in C06"), handle, indent=2)
        handle.write("\n")
    d = load("validation")
    model = json.loads((ROOT / "frozen_economics.json").read_text())
    dump(ROOT / "validation_relation_diagnostics.json", diagnostics(d, model))
    metrics = []
    for name, scenario in frozen["scenarios"].items():
        result = simulate(d, model, frozen["k"], **scenario)
        write_result(ROOT / "validation" / name, d, result)
        row = dict(k=frozen["k"], scenario=name, **summary(result))
        metrics.append(row)
        dump(ROOT / "validation_results.json", metrics)
        print(json.dumps(row), flush=True)


def synthetic_data():
    model = dict(physical=[[100, -55, -2.4], [60, -38, 0], [35, -20, 0], [50, -24, -6], [25, -5, -7.2]],
                 physical_error_low=[0] * 5, physical_error_high=[0] * 5, prior_report_error=[0] * 5,
                 rebuild=[dict(symbol="RECON", index=5, u=40, v=24, w=[.9, 0, 0, .7, .12], error_low=0, error_high=0),
                          dict(symbol="MAT", index=6, u=28, v=14, w=[.75, .5, 250 / 1200, 700 / 1200, .1], error_low=0, error_high=0)])
    # Calm synthetic observation paths give exactly zero outages.
    obs = np.zeros((1, 3, 241, 6))
    obs[..., 4] = 1
    prior = np.ones(5) * .2
    true_damage = prior + .25
    p = np.asarray(model["physical"])
    value = np.ones(12) * 50
    value[:5] = p[:, 0] + p[:, 1] * true_damage
    for r in model["rebuild"]:
        value[r["index"]] = f_rebuild(true_damage, r)
    reports = np.zeros((1, 3, 390, 5))
    reports[:, :2] = .1
    reports[:, 2] = .25
    d = dict(market=np.broadcast_to(value, (1, 3, 390, 12)).copy(), obs=obs,
             damage=reports, report_truth=np.array([[[.1] * 5, [.1] * 5, [.25] * 5]]),
             settlement_truth=value[None], season_ids=np.array([999999]),
             site_xy=np.zeros((5, 2)), site_weight=np.ones(5), site_company=np.arange(5))
    return d, model


def controls():
    d, model = synthetic_data()
    price, outage, prior = public_inputs(d)
    p0 = price[0, 270]
    low, high = price_bounds(model, outage[0], prior[0])
    rng = np.random.default_rng(431)
    terminal = rng.uniform(low, high, (5000, 5))
    p = np.asarray(model["physical"])
    damage = (terminal - p[:, 0]) / p[:, 1]
    for rb in range(2):
        truth = f_rebuild(damage, model["rebuild"][rb])
        for direction in ["upper", "lower"]:
            c, g = affine_bound(model, rb, direction, p0[:5], outage[0], low, high)
            line = c + terminal @ g
            assert np.all(truth <= line + 1e-8) if direction == "upper" else np.all(truth >= line - 1e-8)
            offer = quote(model, rb, direction, 25, p0, outage[0], prior[0])
            payoff = offer["quantity"][:5] @ terminal.T + offer["quantity"][5 + rb] * truth
            assert np.all(payoff >= offer["terminal_bound"] - 1e-8)
            _, delta = terminal_bound(offer["quantity"], 25, direction, c, g, low, high)
            corners = np.array(list(itertools.product([0, 1], repeat=5))) * (high - low) + low
            assert abs(residual_minimum(delta, low, high) - (corners @ delta).min()) < 1e-8
    flat = simulate(d, model, 25)
    assert summary(flat)["episodes"] == 0 and flat["pnl"][0] == 0
    # A persistent overpriced rebuilder supports an upper hedge with paid legs.
    overpriced = {**d, "market": d["market"].copy()}
    overpriced["market"][0, 2, :, 5] += 10
    upper = simulate(overpriced, model, 25)
    assert len(upper["episodes"]) == 1 and upper["episodes"][0]["direction"] == "upper"
    assert upper["pnl"][0] > 0 and upper["floor_violations"][0] == 0
    # A quote-only opportunity disappears before the first market arrival.
    transient = {**d, "market": d["market"].copy()}
    transient["market"][0, 2, 270, 5] += 10
    vanished = simulate(transient, model, 25)
    assert len(vanished["episodes"]) == 1
    assert vanished["episodes"][0]["quoted_floor"] > 0
    assert vanished["episodes"][0]["filled_floor"] < 0
    assert np.allclose(vanished["pnl"], -vanished["cost"], atol=1e-8)
    # Lower-secant hedge with an underpriced rebuilder.
    underpriced = {**d, "market": d["market"].copy()}
    lc, lg = affine_bound(model, 0, "lower", p0[:5], outage[0], low, high)
    underpriced["market"][0, 2, :, 5] = lc + lg @ p0[:5] - 10
    lower = simulate(underpriced, model, 25)
    assert len(lower["episodes"]) == 1 and lower["episodes"][0]["direction"] == "lower"
    assert lower["pnl"][0] > 0 and lower["floor_violations"][0] == 0
    # Deliberately violate the economic envelope; the violation audit must fire.
    broken = {**overpriced, "settlement_truth": overpriced["settlement_truth"].copy()}
    broken["settlement_truth"][0, 5] += 100
    failure = simulate(broken, model, 25)
    assert failure["floor_violations"][0] == 1
    # Truth labels/current-round final reports cannot affect a decision path.
    changed = {**overpriced, "report_truth": np.ones_like(d["report_truth"]) * .99,
               "damage": d["damage"].copy(), "obs": d["obs"].copy()}
    changed["damage"][:, 2] = .99
    changed["obs"][:, :, 240] = 9999
    causal = simulate(changed, model, 25)
    assert np.array_equal(causal["action_ticks"], upper["action_ticks"])
    assert np.array_equal(causal["terminal_positions"], upper["terminal_positions"])
    assert np.array_equal(causal["cash"], upper["cash"])
    dump(ROOT / "controls.json", dict(passed=True, random_terminal_points=5000, rounding_corners=32,
                                       parity_flat=summary(flat), persistent_upper=summary(upper),
                                       transient_opportunity=summary(vanished), lower_secant=summary(lower),
                                       deliberate_model_failure_detected=True, causal_label_perturbation_passed=True))
    dump(ROOT / "synthetic_sequential_trace.json", clean(vanished["fills"]))
    print("synthetic inequality, rounding, cash, sequential timing, envelope-failure and causal controls passed", flush=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("command", choices=["controls", "tune", "freeze", "validate"])
    args = parser.parse_args()
    with (ROOT / ".run.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        {"controls": controls, "tune": tune, "freeze": freeze, "validate": validate}[args.command]()


if __name__ == "__main__":
    main()
