# Nonlinear settlement inequalities — no executable signal

## Conclusion

**Retain no-trade.** Neither predeclared size, 25 or 50 rebuilder shares, finds a
positive calibrated, cost-adjusted, integer-hedged payoff floor on inner seasons.
The frozen 25-share diagnostic also finds none on the further retrospective
validation. Incremental realized PnL, actions, and inventories are all zero.

The mathematical construction is valid **conditional on recovered economics,
residual envelopes, and damage support**. The historical quotes do not offer a
profitable lock under those conservative conditions. Do not loosen buffers,
ignore rounding, or enlarge the grid in response to this result.

C06 and all previous relative-value artifacts were preserved. This study is
confined to `relative/nonlinear`. The original 06:30 UTC deadline elapsed during
the server restart; work resumed on the user's continuation instruction at
13:32 UTC. No on-time-completion claim is made.

## Protocol and results

The plan preceded scoring. Fit: season IDs 361–600. Inner: 241–360. Exactly two
size configurations, each including the upper tangent and the justified lower
secant for RECON and MAT. All 120 seasons, including no-trade seasons, are kept.
Each baseline evaluates 9,600 quoted opportunities: 120 seasons × 20 decision
times × two rebuilders × two directions. These are overlapping diagnostic quotes,
not trades or independent statistical samples.

All monetary values below are USD.

| Partition/configuration | Best calibrated integer floor | Best continuous-share floor after costs | Episodes | Mean terminal PnL |
|---|---:|---:|---:|---:|
| Inner, K=25 | -0.5581 | +0.5888 | 0 | 0.00 |
| Inner, K=50 | -1.1162 | +1.1776 | 0 | 0.00 |
| Further validation, frozen K=25 | -2.4614 | -0.3722 | 0 | 0.00 |

Only one inner quote per size has a positive continuous-share floor. It is the
same RECON lower-secant opportunity. For K=25 its USD 0.5888 continuous surplus
loses USD 1.1469 to the integer hedge's exact worst-case rounding adjustment,
leaving USD -0.5581. Its estimated entry costs are USD 4.5360. K=50 doubles those
particular amounts and remains untradeable.

Nominal, unbuffered floors can look slightly positive: the best K=25 RECON lower
quote is USD +0.8129; the K=50 counterpart is USD +1.6259. Once coefficient/outage
approximation is respected, both are negative. These unbuffered values were
diagnostics only, never additional traded configurations.

By construction, neither size qualifies for integration. The plan's fallback
freezes K=25 **diagnostic-only**, with no-trade retained as the recommendation.
Economics were refitted unchanged on 241–600; the configuration/model were frozen
at **13:37:41 UTC**. A single further validation command opened 121–240 at
**13:37:56 UTC**, evaluating baseline, depth25, latency6, and +10bps cost scenarios.
No validation-driven tuning followed.

All four scenarios have zero trades and zero PnL. That does **not** demonstrate
execution robustness: there are no real-data acquisitions to stress. Synthetic
controls separately exercise delayed and split fills.

These validation seasons had already been examined in C06, and the full dataset
in earlier research. This is **further retrospective validation, not a fresh or
unbiased holdout**.

## Mathematical construction

See `DERIVATION.md` for the full proof and all error terms. In brief:

1. Fit `P_j=A_j+b_j D_j+e_j`, with `A_j=a_j+c_j O_j`, `b_j<0`.
2. Fit `R=u+v(1-exp(-w'D))+e_R`, with `v>0`, `w>=0`.
3. Substitute physical prices into damage, incorporating the fitted one-sided
   error bounds. This gives concave envelopes `h_-(P)<=R<=h_+(P)`.
4. The tangent to `h_+` at the **current observed physical prices** is
   `R<=c+g'P`. Short K rebuilder shares and hold `n=round(Kg)` physical shares.
   The physical quantities are generally short too.
5. If physical terminal prices lie in `[L,U]`, set
   `m(delta)=sum(delta>=0)*delta*L + sum(delta<0)*delta*U`.
   The filled-cash floor is
   `Cfill-Kc+m(n-Kg)`.
6. A scalar secant of `h_-` over its entire feasible aggregate interval gives
   `R>=c_L+g_L'P`. Long K rebuilder and hold `n=round(-Kg_L)`, with floor
   `Cfill+Kc_L+m(n+Kg_L)`.

Both are fundamental cross-sectional inequalities, not future-price forecasts.
The constant liability/asset and the worst-case integer residual are fully
included. Short-sale cash is never mistaken for profit.

The damage interval uses only previous rounds' published final reports, with
training-calibrated report error, plus an assumed final-storm increment in `[0,1]`.
There is no current-storm damage estimate or hindsight tightening. Conservative
model-price intervals are retained even if a lower endpoint is negative.

## Recovered economics and calibration

All numerical coefficients were fitted only on allowed fit IDs before selection.
Rounded fit-only estimates are:

```
PORT  = 100.0023 - 55.0109 D_PORT  - 2.3950 O_PORT
ISLE  =  60.0001 - 37.9998 D_ISLE
AQUA  =  34.9999 - 19.9997 D_AQUA
GRID  =  50.0038 - 24.0124 D_GRID  - 5.9984 O_GRID
FERRY =  25.0074 -  5.0287 D_FERRY - 7.1948 O_FERRY

RECON = 39.9982 + 24.0033 [1-exp(-(.899868 D_PORT
                                  +.700133 D_GRID+.120039 D_FERRY))]
MAT   = 27.9989 + 14.0040 [1-exp(-w'D)]
w     = [.749776,.499879,.208241,.583158,.099963]
```

MAT weights are obtained through training insured-loss regression and a fitted
saturation coefficient, rather than independent policy parameters. Exact fit and
refit coefficients are in `fit_economics.json` and `frozen_economics.json`.

Physical and rebuilder residual minima/maxima are expanded by one quote cent,
USD 0.01. No profit threshold is optimized. Prior-report error is its training
maximum plus .0001 damage fraction. Outages are reconstructed from the observed
Gaussian wind/closure path, threshold .35, market-hour divisor 120, including the
final interval. At round 3 second 540 all required observations are available;
the possibly invalid observation at index 240 is ignored.

### Approximation violations must not be hidden

| Diagnostic | Inner | Further validation |
|---|---:|---:|
| Seasons exceeding a physical component residual envelope | 1 / 120 | 1 / 120 |
| Rebuilder component-envelope exceedances | 0 | 0 |
| Prior-report envelope exceedances | 0 | 0 |
| Per-storm damage outside assumed [0,1] support | 0 | 0 |
| Acquired nominal/calibrated floor violations | No acquired hedges | No acquired hedges |

The inner exceedance is FERRY: residual USD +0.09038 versus upper calibration
USD +0.07680. After the planned refit, further validation has one GRID exceedance:
USD +0.07508 versus upper calibration USD +0.06636. Thus training-extreme buffers
are demonstrably **not universal guarantees**, despite small average relation
errors. Direct substituted-relation RMSE is USD 0.00910/0.00480 for RECON/MAT on
inner and USD 0.00985/0.00529 on further validation.

Zero recorded traded-floor violations are vacuous because there were no trades.
We report both nominal and calibrated floor fields in all season outputs, with
zeros for the actual no-trade portfolio and empty acquired-episode lists. We do
not invent terminal performance for rejected opportunities.

## Execution assumptions and synthetic evidence

- Round 3 only; decisions at 540,550,...,730 seconds. At most one RECON and one MAT
  episode per season, one serial acquisition active at a time.
- Rebuilder first, then physical symbols in published order. Each next market
  order waits for the prior confirmation. Baseline latency is 2 seconds; maximum
  50 shares/symbol/2 seconds. Larger legs are split under reduced depth.
- Arrival-time consensus plus adverse side × (25bps + USD 0.02/share) for every
  market fill. No midpoint executions, passive fills, free hedges, conversions,
  cash resets, or moving cost basis.
- All planned legs reserve separate positive/negative inventory capacity from
  admission; every arrival checks remaining reservations and actual positions.
  All actions share the 60-action rolling-minute budget and published limits.
- Once begun, an episode completes even if slippage removes its quoted advantage.
  The actual floor is computed **after the last fill** from actual net cash.
  Positions then carry to the genuine final settlement; there is no intermediate
  liquidation or assumed market exit.

Passed controls include both inequality directions, 5,000 feasible terminal
points, all 32 rounding-box corners, nonzero component errors and outage offsets,
exact cash ledgers, a deliberately violated economic envelope, and causal
perturbation of truth/current-round final-report fields.

Particularly important synthetic outcomes (all USD):

| Control | Quoted floor | Filled floor | Actual terminal PnL |
|---|---:|---:|---:|
| Persistent overpriced RECON, K=25 | 234.84 | 234.84 | 243.04 |
| Same opportunity disappears before first arrival | 234.84 | **-14.54** | **-6.33** |
| Lower-secant underpriced RECON, K=25 | 238.93 | 238.93 | 306.61 |

The disappearing-opportunity PnL equals negative charged costs, not the optimistic
decision quote. Flat coherent prices admit no trade. A deliberately broken
rebuilder settlement relation triggers the expected floor-violation flag.

Synthetic K=50 execution completes in 10 seconds at depth25/latency2, 24 seconds
at depth50/latency6, and 30 seconds at depth25/latency6. The split rebuilder leg
uses two separately charged actions. `supplemental_controls.json` records these.

## Incremental assessment and interface

**Observed incremental potential: USD 0, no integration recommended.** This does
not compete with the formation sibling's goal execution: no order is submitted.
If a later authorized study finds positive bounds, both upper and lower hedges
hold physical inventory through settlement and would compete with endgame goals;
the standalone no-inventory starting assumption cannot be carried into a shared
account without checking existing positions and pending orders.

The reusable, causal interface is:

```
quote(model, rebuilder_index, direction, K, current_prices,
      observed_total_outages, prior_published_damage)
```

It returns exact integer quantities, quoted floor, nominal diagnostic floor,
terminal bound, feasible price interval, and rounding charge. A central scheduler
would own admission/positions and compute `actual_entry_cash + terminal_bound`
only after all legs confirm. This study supplies no authority to trade and no
recommendation to bypass the negative entry gate.

## Reproduction and artifacts

Run from `research_v4/relative/nonlinear`; Python, NumPy, and SciPy are required.

```bash
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
python nonlinear.py controls
python nonlinear.py tune > tune.log 2>&1
python nonlinear.py freeze > freeze.log 2>&1
python nonlinear.py validate > validation.log 2>&1
python supplemental_controls.py
python report.py > report.log 2>&1
```

Completed inner scoring is not repeated by the CLI; freeze/validation guards and
a process lock preserve the research record. The model/source hashes are frozen.
Two identical inner invocations occurred around the restart, with the same two
configurations and same saved results; no added configuration or validation rerun.

- `PLAN.md`, `DERIVATION.md`: predeclared protocol and mathematical argument.
- `nonlinear.py`: fitted economics, empirical calibration, quote bounds, sequential
  simulator, synthetic controls, and freeze/one-opening validation CLI.
- `all_candidate_results.json`, `all_metrics.csv`: both sizes and every scenario.
- `inner/K*/...`: all inner season CSVs, quotations, and account arrays.
- `validation_results.json`, `validation_seasons.csv`: all 120 further-validation
  seasons × four scenarios, including zero-trade seasons.
- `quote_diagnostics.csv`: separate upper/lower, RECON/MAT, rounding/fee diagnostics.
- `*_relation_diagnostics.json`: coefficient/outage residual and support violations.
- `controls.json`, `supplemental_controls.json`, `synthetic_sequential_trace.json`:
  nonvacuous mathematical/execution controls.
- `artifact_audit.json`: all 12 saved account paths and synthetic cash trace audited.
- `frozen.json`, `frozen_economics.json`, `provenance.json`: configuration, fitted
  parameters, hashes, versions, and restart chronology.

Only supplied development rows and permitted read-only sources were used; no
outer outcomes, raw seasons 1–120, shared-file changes, external trading, paid
services, or subagents. Parent owns final shared-account work and publication.
