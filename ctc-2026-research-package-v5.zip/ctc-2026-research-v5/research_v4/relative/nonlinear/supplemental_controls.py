"""Exercise nonzero approximation envelopes and execution stresses on synthetic data.

Real candidates made no trades, so real-data stresses alone cannot test partial
hedges or depth splitting. This script does not load any historical data.
"""

from nonlinear import (ROOT, affine_bound, dump, f_rebuild, price_bounds, quote,
                       simulate, synthetic_data)

import copy

import numpy as np


def main():
    d, model = synthetic_data()
    model = copy.deepcopy(model)
    model["physical_error_low"] = [-.1, -.02, -.02, -.08, -.14]
    model["physical_error_high"] = [.07, .02, .02, .07, .1]
    for r in model["rebuild"]:
        r["error_low"], r["error_high"] = -.02, .02
    prior = np.full(5, .2)
    outage = np.array([.3, 0, 0, .25, .1])
    p = np.asarray(model["physical"])
    a = p[:, 0] + p[:, 2] * outage
    low, high = price_bounds(model, outage, prior)
    rng = np.random.default_rng(8413)
    damage = rng.uniform(prior, prior + 1, (5000, 5))
    error = rng.uniform(model["physical_error_low"], model["physical_error_high"], (5000, 5))
    terminal = a + p[:, 1] * damage + error
    assert np.all(terminal >= low) and np.all(terminal <= high)
    p0 = np.full(12, 50.)
    p0[:5] = a + p[:, 1] * (prior + .25)
    for rb, r in enumerate(model["rebuild"]):
        r_true = f_rebuild(damage, r) + rng.uniform(r["error_low"], r["error_high"], 5000)
        for direction in ["upper", "lower"]:
            c, g = affine_bound(model, rb, direction, p0[:5], outage, low, high)
            line = c + terminal @ g
            assert np.all(r_true <= line + 1e-8) if direction == "upper" else np.all(r_true >= line - 1e-8)
            for k in [25, 50]:
                offer = quote(model, rb, direction, k, p0, outage, prior)
                payoff = terminal @ offer["quantity"][:5] + r_true * offer["quantity"][5 + rb]
                assert np.all(payoff >= offer["terminal_bound"] - 1e-8)
    d, model = synthetic_data()
    d["market"][0, 2, :, 5] += 10
    cases = []
    for depth, latency in [(25, 2), (50, 6), (25, 6)]:
        result = simulate(d, model, 50, depth=depth, latency=latency)
        assert len(result["episodes"]) == 1
        ep = result["episodes"][0]
        assert ep["filled_second"] == ep["decision_second"] + len(ep["schedule"]) * latency
        assert all(abs(fill["quantity"]) <= depth for fill in result["fills"])
        assert result["pnl"][0] >= result["filled_floor"][0]
        assert np.all(result["reserved_positive"][:, -1] + result["reserved_negative"][:, -1] == 0)
        cases.append(dict(depth=depth, latency=latency, actions=len(ep["schedule"]),
                          complete_second=ep["filled_second"], pnl=float(result["pnl"][0]),
                          filled_floor=float(result["filled_floor"][0]), cost=float(result["cost"][0])))
    dump(ROOT / "supplemental_controls.json", dict(passed=True, nonzero_error_and_outage_terminal_points=5000,
                                                   tested_sizes=[25, 50], both_inequality_directions=True,
                                                   synthetic_execution_stresses=cases))
    print("nonzero economics envelopes, outage offsets, split depth, and delayed-leg controls passed")


if __name__ == "__main__":
    main()
