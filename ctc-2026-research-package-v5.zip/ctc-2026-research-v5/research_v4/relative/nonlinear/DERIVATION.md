# Settlement-payoff bounds, with empirical economics envelopes

All amounts are USD. Let terminal physical prices be `P`, cumulative damage be
`D`, and reconstructed observed outages be `O`. The fitted component relations are

```
P_j = A_j + b_j D_j + e_j,     A_j = a_j + c_j O_j, b_j < 0
R   = f(w'D) + e_R,           f(s) = u + v (1-exp(-s)), v>0, w_j>=0.
```

RECON uses PORT/GRID/FERRY; MAT uses a fitted insured-loss aggregate of all five
physical companies. Fitted coefficients use only the prescribed training IDs.
The error `e_j` jointly includes coefficient error, outage-integration error,
damage/report precision, and terminal-price rounding. It is not assumed zero.

## Calibration is a model condition, not an unconditional guarantee

Define `e_j^-`, `e_j^+` as the training minimum/maximum component residual,
expanded outward by USD 0.01. Do the same for `e_R^-`, `e_R^+`. These fixed
empirical envelopes are **not** distribution-free bounds. Every subsequent
envelope exceedance is reported, even when the strategy has no trades.

Because `b_j<0`, the true damage can be written

```
D_j = (P_j-A_j)/b_j + e_j/(-b_j).
```

Monotonicity of `f(w'D)` then implies

```
h_-(P) <= R <= h_+(P)
h_±(P) = f(alpha_± + beta'P) + e_R^±
beta_j = w_j / b_j
alpha_± = sum_j w_j[-A_j/b_j + e_j^±/(-b_j)].
```

This statement holds whenever the calibrated component-error bounds hold. There
is no forecast of future damage or prices in this substitution.

## Upper tangent and short-rebuilder hedge

For either envelope,

```
gradient h(P) = v exp(-(alpha+beta'P)) beta
Hessian h(P) = -v exp(-(alpha+beta'P)) beta beta' <= 0.
```

Thus at the currently observed physical quote `P0`,

```
R <= h_+(P) <= c + g'P
g = gradient h_+(P0),  c = h_+(P0)-g'P0.
```

Every component of `g` is nonpositive. Short `K` rebuilder shares and hold
integer physical shares `n=round(Kg)`. These physical positions are also usually
short. With `delta=n-Kg`, terminal security value satisfies

```
-K R + n'P >= -K c + delta'P.
```

The constant liability `Kc` is essential. Short-sale cash by itself is not PnL.

## Physical terminal-price rectangle and exact integer-rounding bound

Before round 3, prior final reports are already public. If their summed damage is
`Dprior`, use `Dlo=max(0,Dprior-2e_report)` and
`Dhi=min(3,Dprior+2e_report+1)`. Here `e_report` is the training maximum absolute
per-report fraction error plus `.0001`. The assumed final storm increment lies
in `[0,1]`; this support is audited, rather than inferred from current quotes.

Since `b<0`, feasible component terminal prices lie in

```
L_j = A_j+b_j Dhi_j+e_j^-
U_j = A_j+b_j Dlo_j+e_j^+.
```

The rectangle may include negative model prices; they are deliberately retained
as a conservative outer bound rather than clipped away to improve the result.
No current-price or future-truth shortcut tightens this interval.

For any rounding residual, the exact rectangular worst case is

```
m(delta) = min_{L<=P<=U} delta'P
         = sum_{delta_j>=0} delta_j L_j + sum_{delta_j<0} delta_j U_j.
```

Consequently, after all entry legs have actually filled with net cash `Cfill`,

```
upper-hedge terminal PnL >= Cfill - Kc + m(n-Kg).
```

This bound includes nonzero fractional-share rounding risk over the full support.
The bound can be conservative because it separately bounds curvature and linear
rounding error; it never treats integer quantities as exact derivative shares.

## Optional lower secant and long-rebuilder hedge

For `h_-(P)`, set `s=alpha_-+beta'P`. As `beta<=0`, the feasible scalar interval is
`slo=alpha_-+beta'U`, `shi=alpha_-+beta'L`. Concavity makes its secant a lower
bound over that **entire** interval:

```
m = [f(shi)-f(slo)]/(shi-slo)
c_L = f(slo)+e_R^- - m*slo + m*alpha_-
g_L = m*beta
R >= h_-(P) >= c_L + g_L'P.
```

Use the derivative limit if the interval collapses. Long `K` rebuilder shares and
integer physical shares `n=round(-Kg_L)` gives

```
lower-hedge terminal PnL >= Cfill + Kc_L + m(n+Kg_L),
```

where the final `m(delta)` denotes the rectangular minimum above, not the secant
slope. This hedge uses no secant outside its justified scalar support.

## Execution and nominal versus calibrated floors

At decision time, substitute estimated same-quote *adverse-cost* proceeds for
`Cfill` only to decide whether to begin. This is an estimate, **not a lock**.
Rebuilder and physical orders fill serially, after latency, at each arrival mark
plus adverse side times `(25bps + USD 0.02/share)`. The actual floor is computed
only once all legs arrive. It may be negative despite a positive decision estimate.
All entry costs are charged; final settlement is an inventory cash flow, not a
fictional second market trade. No conversion or moving cost basis is used.

For diagnostic nominal floors, set component relation-error shifts to zero,
derive the corresponding tangent/secant, and apply it to the **same actual integer
portfolio**, retaining the physical support rectangle. Report nominal and
calibrated filled floors against terminal PnL. Neither is an unconditional
guarantee when the underlying recovered economics/support assumptions fail.

The synthetic controls cover both directions, 5,000 feasible terminal points,
all 32 corners for the rounding term, paid sequential fills, a vanishing entry
opportunity, and a deliberately broken economic relation that must trigger a
floor violation. The random checks support the implementation; the inequalities
above supply the mathematical argument.
