"""Regenerate descriptive tables/provenance from saved results; no new policies."""

from relative import ROOT, CONFIGS, load_models, load_partition, predict, signals

import csv
import hashlib
import json
import platform
import sys

import numpy as np


def write(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")


def run():
    metrics = json.loads((ROOT / "all_candidate_results.json").read_text())
    fields = ["candidate", "scenario", "mean", "se", "p05", "min", "mean_cost", "mean_cycles", "mean_actions", "max_rolling_actions", "max_position_fraction"]
    with (ROOT / "all_candidate_results.csv").open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows({k: x[k]["id"] if k == "candidate" else x[k] for k in fields} for x in metrics)
    for role in ["inner", "validation"]:
        groups = {}
        with (ROOT / role / "C06" / "baseline" / "trades.csv").open() as f:
            for trade in csv.DictReader(f):
                basket = ["ARCH", "REBLD"][int(trade["instrument"])]
                rec = groups.setdefault(basket, dict(cycles=0, pnl=0., gross=0., cost=0., durations=[]))
                rec["cycles"] += 1
                for key in ["pnl", "gross", "cost"]:
                    rec[key] += float(trade[key])
                rec["durations"].append(int(trade["end_second"]) - int(trade["start_second"]))
        for rec in groups.values():
            durations = rec.pop("durations")
            rec["duration_range"] = [min(durations), max(durations)]
            for key in ["cycles", "pnl", "gross", "cost"]:
                rec["mean_" + key] = rec.pop(key) / 120
        write(role + "_basket_attribution.json", groups)
    with np.load(ROOT / "inner/C06/baseline/audit.npz") as z:
        loop = z["pnl"]
    with np.load(ROOT / "inner/C10/baseline/audit.npz") as z:
        directional = z["pnl"]
    difference = directional - loop
    write("inner_directional_comparison.json", dict(
        mean_directional_minus_loop=float(difference.mean()),
        paired_se=float(difference.std(ddof=1) / np.sqrt(len(difference))),
        correlation=float(np.corrcoef(loop, directional)[0, 1])))
    # C12 rejection is a frozen-fit forecast diagnostic on inner rows only.
    ids, market = load_partition("inner")
    models = load_models(ROOT / "fit_models.npz")
    config = CONFIGS[-1]
    predictions = predict(models, market, [config])
    score, _, net = signals(market, config, predictions)
    write("pair_rejection_diagnostic.json", dict(
        role="inner", season_ids=[int(ids.min()), int(ids.max())], candidate="C12",
        after120_max_forecast_net_dollars=float(net[:, :, 60:].max()),
        after120_max_margin_adjusted_score=float(score[:, :, 60:].max()),
        after120_net_quantiles=np.quantile(net[:, :, 60:], [0, .5, .95, .99, 1]).tolist(), trades=0))
    files = ["PLAN.md", "HANDOFF.md", "relative.py", "integration.py", "diagnostics.py",
             "report_artifacts.py", "audit_artifacts.py", "export_interfaces.py", "frozen.json",
             "frozen_models.npz", "fit_models.npz", "VALIDATION_OPENED.json"]
    write("provenance.json", dict(
        python=sys.version, numpy=np.__version__, platform=platform.platform(),
        thread_limits={"OMP_NUM_THREADS": 1, "OPENBLAS_NUM_THREADS": 1, "MKL_NUM_THREADS": 1},
        workers_used_max=2, data="../development.npz",
        data_sha256=hashlib.sha256((ROOT.parent / "development.npz").read_bytes()).hexdigest(),
        files_sha256={x: hashlib.sha256((ROOT / x).read_bytes()).hexdigest() for x in files},
        evaluation_scope="Development IDs 121..600 only; no globally fresh holdout; no data beyond supplied development file."))
    print("Regenerated tables/provenance; validation inputs were not reopened")


if __name__ == "__main__":
    run()
