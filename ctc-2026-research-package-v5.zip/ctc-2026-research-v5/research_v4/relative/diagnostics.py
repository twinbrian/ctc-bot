"""Fit-partition lead/lag diagnostics, not additional policy configurations."""

import csv
import json
from pathlib import Path

import numpy as np

from relative import BASKETS, CONFIGS, ROOT, load_partition, schedules, targets


def run():
    ids, market = load_partition("fit")
    output = []
    t = np.arange(390) * 2
    phases = {"preformation": t < 60, "formation": (t >= 60) & (t < 90),
              "storm": (t >= 90) & (t < 550), "preliminary": (t >= 550) & (t < 590),
              "late": (t >= 590) & (t < 730), "final": t >= 730}
    for b in range(2):
        e = market[..., 10 + b]
        stock = market @ BASKETS[b]
        basis = e - stock
        cost = .0025 * (e + stock) + .02 * (1 + BASKETS[b].sum())
        for route in ["etf_first", "convert_first"]:
            gross, valid = targets(market, "loop", route, b)
            cfg = dict(family="loop", route=route, lot=1, hold_seconds=10)
            seq = schedules(cfg, b, 1, market[0, 0, 0])
            realized_cost = np.zeros_like(gross)
            arrival = 0
            for kind, change, wait in seq:
                arrival += wait + 1
                if kind == "market":
                    realized_cost += (.0025 * market[:, :, arrival:arrival + valid] + .02) @ np.abs(change)
            signed_gross = -np.sign(basis[..., :valid]) * gross
            for phase, time_mask in phases.items():
                mask = np.broadcast_to(time_mask[:valid], gross.shape)
                selected = mask & (np.abs(basis[..., :valid]) > 1.5 * cost[..., :valid])
                def average(x):
                    return float(x[selected].mean()) if selected.any() else None
                output.append(dict(basket=["ARCH", "REBLD"][b], route=route, phase=phase,
                                   n_observations=int(mask.sum()), n_large_basis=int(selected.sum()),
                                   fraction_large_basis=float(selected.sum() / mask.sum()),
                                   mean_cost=float(cost[..., :valid][mask].mean()),
                                   median_abs_basis=float(np.median(np.abs(basis[..., :valid][mask]))),
                                   p99_abs_basis=float(np.quantile(np.abs(basis[..., :valid][mask]), .99)),
                                   large_basis_quoted_paper_net=average(np.abs(basis[..., :valid]) - cost[..., :valid]),
                                   large_basis_sequential_gross=average(signed_gross),
                                   large_basis_sequential_cost=average(realized_cost),
                                   large_basis_sequential_net=average(signed_gross - realized_cost),
                                   large_basis_timing_component=average(signed_gross - np.abs(basis[..., :valid]))))
    with (ROOT / "fit_basis_diagnostics.csv").open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(output[0]))
        writer.writeheader()
        writer.writerows(output)
    # Fine formation curve is descriptive, averaged over training seasons only.
    curve = []
    for ti in range(25, 46):
        for b in range(2):
            e = market[..., 10 + b]
            s = market @ BASKETS[b]
            curve.append(dict(second=ti * 2, basket=["ARCH", "REBLD"][b],
                              mean_etf_change_from_60=float((e[:, :, ti] - e[:, :, 30]).mean()),
                              mean_basket_change_from_60=float((s[:, :, ti] - s[:, :, 30]).mean()),
                              mean_basis=float((e[:, :, ti] - s[:, :, ti]).mean())))
    with (ROOT / "fit_formation_leadlag.csv").open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(curve[0]))
        writer.writeheader()
        writer.writerows(curve)
    (ROOT / "diagnostic_scope.json").write_text(json.dumps(dict(
        fit_ids=[int(ids.min()), int(ids.max())],
        warning="Conditional overlapping observations, not implementable strategy PnL. No thresholds selected from these diagnostics."
    ), indent=2) + "\n")


if __name__ == "__main__":
    run()
