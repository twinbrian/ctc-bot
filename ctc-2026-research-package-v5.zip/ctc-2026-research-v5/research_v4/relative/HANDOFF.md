# Relative value: useful 2-second lead–lag, no robust arbitrage recommendation

## Decision

**Do not add an unconditional relative-value sleeve.** The predeclared
post-formation conversion candidate C06 earns **$920/season** in the one-time
development validation at baseline execution, but **loses $346/season at 6-second
latency**. Reduced depth alone is tolerable. Timing, rather than a durable
stock/ETF valuation discrepancy, supplies the edge.

Return **one frozen candidate, C06, diagnostic-only**. No candidate passed the
predeclared inner requirement of positive baseline and combined 25-share-depth /
6-second-latency mean. C06 was frozen under the plan's negative-result fallback;
the favorable baseline validation does not override that decision.

All numbers are hypothetical consensus-fill results on development partitions.
The whole 600-season universe informed earlier work; this is **not fresh global
out-of-sample proof**. No shared-account incremental PnL is claimed.

## Hypothesis and causal evidence

Static parity is:

- ARCH = PORT + ISLE + 2 AQUA + GRID + 2 FERRY + HAVEN.
- REBLD = 2 RECON + 2 MAT + GEN.

Let `basis = ETF - basket`. Negative basis can suggest buying the ETF, redeeming
it, and selling constituents. Positive basis can suggest shorting the ETF,
creating it from short constituents, and covering constituents. Both are legal
signed-inventory transformations under the supplied contract.

**Observable basis is not executable cash.** In the fit partition, at second 64
ARCH's basket has risen $9.27 from second 60, while its ETF has risen only $0.01.
At second 70 the ETF has risen $9.28. REBLD shows the opposite-signed counterpart:
its basket falls $2.64 at second 64, with ETF catch-up at second 70. That formation
effect is already economically shared with v3's directional positioning.

The post-formation opportunity is repeated transient ARCH lag. Among overlapping
fit-period ARCH storm observations with absolute basis above 1.5 times estimated
loop cost, the immediate same-quote paper net is $3.20/ETF. Actual serialized
ETF-first labels average only $1.37/ETF; conversion-first labels average
**-$0.15/ETF**. These are diagnostic overlapping observations, not achievable
strategy totals. `fit_basis_diagnostics.csv` preserves all regimes and both ETFs.

C06's validation gross cash is $1,749/season, charged cost $829, net $920. Its
decision-quote signed basis sum is $1,703 and its realized timing contribution is
+$46. At 6-second latency the corresponding observed-basis sum is still $882,
but timing removes $785, leaving only $97 gross before $443 costs. This directly
separates a signal available now from later executable proceeds.

## All twelve candidates: inner selection only

IDs 361–600 fit the fixed estimators; IDs 241–360 select candidates. Dollars are
arithmetic mean net PnL per complete three-round season. The stress column uses
both 25-share market depth and 6-second latency, with fixed policy/forecasts.

| ID | Policy | Baseline mean | Season SE | Combined stress |
|---|---|---:|---:|---:|
| C01 | Raw basis, ETF first, all times, 1.0× cost | 1,369 | 69 | -487 |
| C02 | Raw basis, ETF first, after 120s, 1.5× cost | 751 | 41 | -360 |
| C03 | Raw basis, conversion first, all times, 1.5× cost | 1,061 | 58 | -424 |
| C04 | Raw basis, ETF first, after 120s, 2.5× cost | 677 | 43 | -243 |
| C05 | Learned loop, ETF first, all times, $0.25 margin | 1,652 | 67 | 14 |
| **C06** | **Learned loop, ETF first, after 120s, $0.25 margin** | **886** | **50** | **-329** |
| C07 | Same post-120 loop, $0.75 margin | 874 | 50 | -357 |
| C08 | Learned loop, conversion first, after 120s | 658 | 44 | -317 |
| C09 | Learned directional ETF, all times | 1,911 | 70 | -350 |
| C10 | Learned directional ETF, after 120s | 993 | 51 | -716 |
| C11 | Market-hedged ETF/basket, two paid sweeps, after 120s | 271 | 31 | -365 |
| C12 | Dollar-neutral stock-pair residual model, after 120s | 0 | 0 | 0 |

`all_candidate_results.json` / `.csv` and `inner/C*/{scenario}/seasons.csv` contain
every evaluated configuration, complete season results, costs, and audit arrays.
No additional configurations were evaluated after this grid.

### Rejected ideas and distinctions

- **Pure directional ETF is a serious comparator.** C10 exceeds C06 by $107/season
  on inner data (paired season SE $33, correlation 0.788). It needs only two
  actions per trade instead of ARCH's eight. Conversion is not an independent
  source of free cash, nor does it beat the same lead–lag bet outright. Both fail
  the latency gate; C10 was not frozen or opened on validation.
- **Formation-inclusive headline is not incremental alpha.** C05's $1,652 is
  materially helped by the same formation window v3 already occupies. Its small
  positive combined-stress mean ($14, SE $51) does not establish robustness or
  shared-account benefit.
- **Higher basis thresholds do not repair latency.** C04 and C07 remain negative
  in the predeclared combined stress. C06/C07 baseline proximity is modest
  threshold stability, not execution stability.
- **Conversion-first loses acquisition priority.** It delays the important ETF
  fill another two seconds. Its hedge is not secured at the decision quote.
- **Fully market-hedged round trips pay two sweeps.** C11 earns much less than the
  conversion loop and fails the stress; it is neither a free hedge nor a riskless
  lock at the observed basis.
- **Within-basket dollar-neutral pairs do not clear fees in this fixed model.**
  C12 considers all 18 stock pairs, with no pair-specific tuning. Its best
  post-120 inner forecast is still -$2.53 after estimated costs, before its margin.
  It places no trades. This rejects this model/size/cost combination, not all
  conceivable cross-sectional signals.

## Frozen one-time validation

C06 and its estimator were fixed before validation. Identical ridge models were
refitted on IDs 241–600. `frozen.json` was written at **05:35:42 UTC**; validation
IDs 121–240 were opened once at **05:35:54 UTC**, with all six predefined scenarios
in the same evaluation command. No validation-driven parameter or model changes.

| Scenario | Mean net/season | Season SE | Mean cycles | Mean actions |
|---|---:|---:|---:|---:|
| 2s latency, 50-share depth, 25bps + $0.02 | **920.20** | 52.50 | 20.23 | 160.35 |
| 25-share depth; same 25-ETF lot, split stock legs | 859.75 | 48.33 | 18.41 | 182.91 |
| 6s latency | **-346.04** | 40.37 | 10.83 | 85.78 |
| 25-share depth + 6s latency | **-312.26** | 41.89 | 9.81 | 97.46 |
| 12s latency | -227.71 | 39.96 | 7.68 | 60.93 |
| Additional 10bps adverse execution cost | 624.75 | 48.24 | 20.23 | 160.35 |

Baseline median is $875, fifth percentile $111, minimum -$133. These tail and
win-rate diagnostics do not replace the arithmetic-mean objective. Less-negative
12-second performance reflects fewer completed opportunities/costs, not repaired
arbitrage. Stresses retain the baseline forecast and threshold; they do not refit
to slow execution. Entry stops when a complete paid cycle cannot finish by 778s.

ARCH contributes **$913.84** of the $920.20 mean; REBLD contributes **$6.37**.
Baseline averages 19.74 ARCH loops and 0.48 REBLD loops per season. About $751 is
attributed to entries from 120–548s and $169 to entries at/after 550s. None is
attributed to entries before 120s. There is no suggested post-validation
ARCH-only retuning.

`validation_seasons.csv` contains all 120 seasons × six scenarios; detailed trade
lists, summaries, and account arrays live under `validation/C06/`.

## Exact executable assumptions

- **25 ETF units; one active cycle per account/sleeve.** No pyramiding. Highest
  current predicted net cash wins among the two ETFs.
- **Strictly sequential actions.** Every next action waits for confirmation of
  its predecessor. Baseline ARCH ETF-first timing, relative to decision:
  ETF market fill +2s; zero-cash redemption/creation +4s; PORT +6s; ISLE +8s;
  AQUA +10s; GRID +12s; FERRY +14s; HAVEN +16s. REBLD completes in 10s.
- **No instantaneous hedge.** The ETF position is directional before conversion;
  afterward the constituent inventory remains directional while being unwound.
  A closed terminal loop is not a continuously risk-neutral portfolio.
- Every market action is one symbol, maximum 50 shares per 2s at baseline.
  The 25-share-depth stress splits 50-share constituent legs into additional
  actions, rather than scaling size down or silently filling excess depth.
- Fills use the **arrival-time consensus**, adverse side × (25bps + $0.02/share).
  No midpoint, passive-fill, uncharged leg, or current-quote fill credit.
- Conversions consume one action, arrive after the same latency, atomically
  transform signed inventory, and change cash by **exactly zero**. Signed stock
  positions may be created, subject to all intermediate limits.
- Positive and negative pending quantities separately reserve capacity. Submission
  and every fill assert limits. All remaining cycle actions are conservatively
  reserved against the rolling key budget on admission. No extra API key.
- Actual baseline maximum is **27 actions in a rolling real minute** and **50%
  of a symbol limit** (25 of ARCH's 50). The reduced-depth maximum is 28 actions.
- All positions close through paid fills before the last quote of each round.
  Cash carries across rounds; there is no inventory reset or intermediate
  settlement. No final-settlement label is needed or loaded.
- Capacity is an assumption about hypothetical consensus executions, not observed
  order-book depth. Known stress latency changes the feasible end-of-round entry
  cutoff; no late unfilled legs are forgiven.

## Model specification and causal inputs

Fixed standardized ridge penalty **0.01**, one regression per ETF and execution
target. No penalty search. C06 predicts the signed gross cash from the complete
ETF-first baseline schedule, per ETF unit. It chooses the predicted sign and
requires absolute expected gross above the current estimated loop cost + $0.25.

Inputs: current ETF price, basket value, basis and estimated cost; causal 2/4/10s
changes of ETF, basket, and basis; absolute and signed-magnitude basis transforms;
10s constituent return dispersion/max magnitude; public clock regime indicators
and basis interactions. Exact phase boundaries and feature order are in
`relative.py` and `frozen_models.json`. No season ID, storm truth, unpublished
report, future settlement, or future quote is a trading input. Future fit quotes
are training labels only; later execution quotes are fill outcomes only.

`integration.check_prefix_causality` matched prefix-only signals to full-batch
signals for all 12 candidates, including short prefixes and publication windows.
`causality_checks.json` records this check.

## Conservation and timing checks

`controls.json`, `control_sequential_trace.json`, and `artifact_audit.json` pass:

1. Forced flat-parity loops have zero gross cash and strictly negative net cost;
   two ARCH conversion loops lose exactly **$80.25**, not earn a conversion credit.
2. A synthetic $250 observed basis which vanishes before the delayed ETF fill
   produces zero gross proceeds and a cost loss. Persistent mispricing gives the
   expected $250 gross, validating signs and quantities.
3. Training-label arrival schedules reconcile with independently executed
   synthetic market paths for both conversion routes, directional ETFs,
   market-hedged baskets, and stock pairs.
4. Every saved account reconciles cash to market debits/credits, gross less costs,
   phase PnL, and the sum of closed-cycle PnL. All final positions are zero.
5. Actual/pending limits and per-symbol depth are checked at every operation.
   Independent artifact audit checks rolling actions across round boundaries too.
6. All **30** saved candidate/scenario account paths pass the artifact audit.

## Incremental potential and parent integration interface

The $920 baseline is **standalone post-120 potential, not $920 to add to v3's
reported mean**. It avoids opening formation positions, but formation liquidation
or other engines may still consume inventory, depth, and action capacity.

Important conflicts:

- ARCH requires 25 ETF shares of headroom, half its entire published limit, plus
  up to 25 PORT/ISLE/GRID/HAVEN and 50 AQUA/FERRY shares during conversion/unwind.
- Eight serial actions per ARCH loop and bursts of 27/minute compete with the
  existing key. Admission can displace more valuable formation exits or endgame
  orders. Slower shared scheduling is economically similar to the failed latency
  stress; independently adding PnLs is invalid.
- Final-report loops overlap endgame activity. No separate cash/inventory account
  is justified by this research implementation.
- The underlying lag information also supports cheaper-action directional ETF
  trades. A new conversion sleeve should not double-count the same opportunity.

`integration.propose(history, config, models, depth=50, latency=2)` returns an
**intent only**, with expected net cash, instrument/side, exact serial operations,
required action reserve, expected completion time, and min/max relative inventory
envelope. Input `history` is only current-round quotes observed so far. The parent
owns all shared-account admission and execution. It must account for existing
inventory, both signs of pending orders, all engines' depth, rolling key budget,
and guaranteed timely servicing of remaining legs. If timing cannot be preserved,
the current evidence supports rejecting the intent.

`inventory_timeline.npz` exports positions and separate positive/negative pending
reservations for every 2s tick of C06's inner and validation paths. They were
reconstructed from saved trade schedules **without rereading validation prices or
rerunning validation**. These can screen conflicts, but the parent still needs
one actual shared-account simulation because suppressing or delaying a cycle
changes subsequent decisions. `audit.npz` also contains action ticks.

## Reproduction and artifact map

Run from `/tmp/opencode/ctc-research/project/research_v4/relative` with Python and
NumPy. These are the exact research-stage commands, in order:

```bash
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
python relative.py controls
python relative.py tune > tune.log 2>&1
python diagnostics.py
python relative.py freeze > freeze.log 2>&1
python relative.py validate > validation.log 2>&1
python audit_artifacts.py
python export_interfaces.py
python report_artifacts.py
```

The saved directory intentionally refuses retuning after `frozen.json` and refuses
a second validation after `VALIDATION_OPENED.json`. Controls and artifact audits
can be rerun independently. Parent audits can import the simulator and frozen
model rather than alter this one-opening research record.

- `PLAN.md`: predeclared 12 configurations, split rules, selection/stress protocol.
- `relative.py`: model, labels, complete simulator, controls, fit/freeze/validation CLI.
- `integration.py`: causal online-prefix intent adapter.
- `fit_models.npz` / `.json`: all fit-only regressions and feature diagnostics.
- `frozen.json`, `frozen_models.npz` / `.json`: only C06; refit IDs 241–600.
- `all_candidate_results.*`, `candidate_configs.json`, `inner/`: every candidate.
- `validation_results.json`, `validation_seasons.csv`, `validation/`: sealed results.
- `diagnostics.py`, `fit_basis_diagnostics.csv`, `fit_formation_leadlag.csv`: fit-only
  descriptive evidence; no extra policy configurations.
- `export_interfaces.py`, `inventory_exports.json`: saved-schedule inventory export.
- `audit_artifacts.py`, `artifact_audit.json`, `controls.json`: accounting evidence.
- `report_artifacts.py`: reproducible CSV, basket attribution, comparator, and
  forecast-rejection summaries from existing results / inner rows only.
- `provenance.json`: input/model/source hashes, Python/NumPy versions, thread limits.

Only supplied development data and permitted parent source were read. At most two
worker processes and one BLAS/OMP thread per process were used. No shared files,
parent cache, raw seasons 1–120, old outer outcomes, external services, subagents,
trades, branches, commits, or publication were involved. Parent owns final
shared-account validation and artifact publication.
