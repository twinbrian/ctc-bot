"""Export frozen-candidate inventories from saved trades, without market access.

This is deterministic accounting post-processing, not another validation run.
"""

import csv
import json

import numpy as np

from relative import LIMITS, ROOT, schedules


def export(directory, config, scenario):
    with np.load(directory / "audit.npz", allow_pickle=False) as z:
        ids = z["season_ids"]
        expected_actions = z["action_ticks"]
        expected_max = z["max_position_by_symbol"]
        expected_reserved = z["max_reserved_by_symbol"]
    shape = (len(ids), 3, 390, 12)
    change_at_arrival = np.zeros(shape, dtype=np.int16)
    positive_change = np.zeros(shape, dtype=np.int16)
    negative_change = np.zeros(shape, dtype=np.int16)
    action_ticks = np.zeros(shape[:3], dtype=np.int8)
    index = {int(sid): i for i, sid in enumerate(ids)}
    delay = max(1, int(np.ceil(scenario["latency"] / 2)))
    with (directory / "trades.csv").open() as f:
        for trade in csv.DictReader(f):
            i = index[int(trade["season_id"])]
            r = int(trade["round"]) - 1
            ti = int(trade["start_second"]) // 2
            seq = schedules(config, int(trade["instrument"]), int(trade["side"]), np.ones(12), **{k: scenario[k] for k in ["depth", "latency"]})
            for kind, change, wait in seq:
                ti += wait
                due = ti + delay
                pos, neg = np.maximum(change, 0), np.maximum(-change, 0)
                positive_change[i, r, ti] += pos
                negative_change[i, r, ti] += neg
                positive_change[i, r, due] -= pos
                negative_change[i, r, due] -= neg
                change_at_arrival[i, r, due] += change
                action_ticks[i, r, ti] += 1
                ti = due
            assert 2 * ti == int(trade["end_second"])
    position = np.cumsum(change_at_arrival, axis=2, dtype=np.int16)
    pp = np.cumsum(positive_change, axis=2, dtype=np.int16)
    pn = np.cumsum(negative_change, axis=2, dtype=np.int16)
    assert np.array_equal(action_ticks, expected_actions)
    assert np.array_equal(np.abs(position).max((1, 2)), expected_max)
    assert np.array_equal(np.maximum(np.abs(position + pp), np.abs(position - pn)).max((1, 2)), expected_reserved)
    assert np.all(position + pp <= LIMITS) and np.all(position - pn >= -LIMITS)
    assert np.all(pp >= 0) and np.all(pn >= 0)
    assert np.all(position[:, :, -1] == 0)
    np.savez_compressed(directory / "inventory_timeline.npz", season_ids=ids,
                        inventory=position, pending_positive=pp, pending_negative=pn,
                        action_ticks=action_ticks)


def run():
    frozen = json.loads((ROOT / "frozen.json").read_text())
    exported = []
    for config in frozen["selected"]:
        assert config["family"] in ("loop", "raw", "directional", "hedged"), "Pair sizing needs decision prices"
        for role in ("inner", "validation"):
            for name, scenario in frozen["scenarios"].items():
                directory = ROOT / role / config["id"] / name
                if not directory.exists():
                    continue
                export(directory, config, scenario)
                exported.append(str(directory.relative_to(ROOT) / "inventory_timeline.npz"))
    (ROOT / "inventory_exports.json").write_text(json.dumps(dict(
        files=exported,
        source="Saved trade schedules only; no validation market reread/replay",
        clock="round index, 2-second real-time quote; inventory after arrivals, pending after submissions",
        capacity="check base_inventory+inventory+all_positive_pending <= limits and base_inventory+inventory-all_negative_pending >= -limits",
    ), indent=2) + "\n")
    print(f"exported {len(exported)} inventory timelines without market access")


if __name__ == "__main__":
    run()
