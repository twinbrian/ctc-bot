"""Independent audit of saved output; no market replay or policy selection."""

import csv
import hashlib
import json

import numpy as np

from relative import LIMITS, ROOT


def run():
    checked = []
    for path in sorted(ROOT.glob("**/audit.npz")):
        with np.load(path, allow_pickle=False) as z:
            pnl = z["pnl"]
            assert np.allclose(pnl, z["gross"] - z["cost"], atol=1e-8)
            assert np.allclose(pnl, z["phase_pnl"].sum(1), atol=1e-8)
            assert np.all(z["positions"] == 0)
            assert np.all(z["max_position_by_symbol"] <= LIMITS)
            assert np.all(z["max_reserved_by_symbol"] <= LIMITS)
            actions = z["action_ticks"].reshape(len(pnl), -1).astype(int)
            assert np.all(actions.sum(1) == z["actions"])
            assert actions.max() <= 1
            # Preserve real-time rolling windows across round boundaries too.
            cs = np.pad(np.cumsum(actions, axis=1), ((0, 0), (1, 0)))
            rolling = cs[:, 30:] - cs[:, :-30]
            exact_max = rolling.max(1)
            assert np.all(exact_max <= 60)
            assert np.all(exact_max == z["max_rolling_actions"])
            ledger = np.zeros(len(pnl))
            season_index = {int(sid): i for i, sid in enumerate(z["season_ids"])}
            cycles = np.zeros(len(pnl), dtype=int)
            trade_file = path.parent / "trades.csv"
            if trade_file.exists():
                with trade_file.open() as f:
                    for trade in csv.DictReader(f):
                        i = season_index[int(trade["season_id"])]
                        ledger[i] += float(trade["pnl"])
                        cycles[i] += 1
                        assert int(trade["end_second"]) > int(trade["start_second"])
                        assert int(trade["end_second"]) <= 778
            assert np.allclose(ledger, pnl, atol=1e-8)
            assert np.all(cycles == z["cycles"])
            checked.append(str(path.relative_to(ROOT)))
    frozen = json.loads((ROOT / "frozen.json").read_text())
    assert hashlib.sha256((ROOT / "frozen_models.npz").read_bytes()).hexdigest() == frozen["model_sha256"]
    assert len(frozen["selected"]) <= 2
    assert len(json.loads((ROOT / "candidate_configs.json").read_text())) == 12
    result = dict(passed=True, audited_files=checked, checks=[
        "season cash = gross less charged costs = sum of closed-cycle cash",
        "flat terminal inventory; actual and pending reservations within every limit",
        "one action per tick; 60-action rolling minute includes round boundaries",
        "every saved cycle closes by last quote; no free inventory reset",
        "frozen model SHA256 unchanged; 12 configurations, at most 2 frozen",
    ])
    (ROOT / "artifact_audit.json").write_text(json.dumps(result, indent=2) + "\n")
    print(f"passed: {len(checked)} saved account paths audited")


if __name__ == "__main__":
    run()
