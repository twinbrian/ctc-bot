# Relative-value research — predeclared plan

Declared 2026-10-19, before any policy-PnL evaluation. Work is confined to this
directory. Input is `../development.npz`; read-only parent source supplies symbol,
basket, limit, and execution conventions. No reference forecasts or outer data.

## Hypothesis and estimand

ARCH and REBLD consensus prices sometimes lag their stock baskets. An observable
basis is not executable arbitrage: ETF acquisition, conversion, and constituent
unwinds happen later. Predict **the actual sequential-leg cash result**, then
compare it with a directional ETF trade and stock-pair relative-value trade.
Repeated loops after second 120 are the primary incremental opportunity, because
v3 already uses the formation window and its action/inventory capacity.

Fit/calibrate: IDs 361–600. Inner selection: 241–360. Freeze up to two candidates,
refit the identical estimator on 241–600, and open 121–240 once. These are
retrospective development partitions, not fresh global out-of-sample evidence.
Entire seasons are kept together. No true storm state, season ID, future quote,
or unpublished report is an input.

## Fixed model and causal inputs

Fixed ridge penalty 0.01 after feature standardization; no hyperparameter search.
Separate ETF/basket models use current dollar basis, its 2/4/10-second changes,
ETF and basket 2/4/10-second changes, 10-second constituent dispersion, current
prices/costs, and public clock regimes (preformation, formation, ongoing,
preliminary-report, final-report). Linear and signed-magnitude transforms allow
transient basis effects without fitting season identities. Clock is real time.
Targets use deterministic baseline sequential arrival times. Models forecast
gross execution cash; current estimated costs and the declared margin gate entry.
The stock-pair model uses the same causal price differences for both members and
their equal-weight peer return, and forecasts delayed dollar-neutral spread cash.
All model scaling and coefficients are fitted on fit IDs only before selection.

## Twelve policy configurations (all tried configurations will be logged)

All baseline ETF lots are 25 units, one active trade at a time globally; choose
the highest forecast net cash among eligible baskets/pairs. No pyramiding.
Market legs are serialized, each submitted only after the previous leg confirms.
Stock legs are in published symbol order. A cycle must have time to finish before
the last quote; no free round reset. A completed cycle may be followed by another
on a later quote. A 60-action rolling-minute cap and per-symbol depth are enforced.

| ID | Family | First action / entry window | Entry rule |
|---|---|---|---|
| C01 | raw closed loop | ETF first / t>=0 | abs(basis)>1.0×one-loop estimated cost |
| C02 | raw closed loop | ETF first / t>=120 | abs(basis)>1.5×cost |
| C03 | raw closed loop | conversion first / t>=0 | abs(basis)>1.5×cost |
| C04 | raw closed loop | ETF first / t>=120 | abs(basis)>2.5×cost |
| C05 | learned closed loop | ETF first / t>=0 | expected gross>cost+$0.25/ETF |
| C06 | learned closed loop | ETF first / t>=120 | expected gross>cost+$0.25/ETF |
| C07 | learned closed loop | ETF first / t>=120 | expected gross>cost+$0.75/ETF |
| C08 | learned closed loop | conversion first / t>=120 | expected gross>cost+$0.25/ETF |
| C09 | directional ETF comparator | ETF only / t>=0 | 10-second holding target; expected gross>round-trip cost+$0.25/ETF |
| C10 | directional ETF comparator | ETF only / t>=120 | same as C09 |
| C11 | market-hedged basis comparator | ETF then stock entries / t>=120 | forecast sequential two-sweep spread cash>all-leg cost+$0.25/ETF; 10-second hold after all entries |
| C12 | cross-sectional stock pairs | two sequential stock legs / t>=120 | forecast dollar-neutral spread cash>all-leg cost+$0.05 per $100 long notional; $1,000 each side, 10-second hold after entries |

C11 is fully market-hedged before its holding period and closes all legs with
market orders; it pays two complete sweeps rather than claiming free conversion
profit. C12 considers unordered stock pairs within each basket (HAVEN included;
REIN excluded), chooses direction from its fitted spread forecast, and rounds
shares down. The common dollar notional is reduced below $1,000 when necessary
to keep each baseline leg at or below 50 shares. Integer rounding residual is
reported. These are single predeclared
algorithms, not independently tuned pair configurations.

## Selection and validation

Primary metric is season arithmetic mean net terminal cash/PnL. Save all inner
season results, standard errors, tails, costs, action counts, timing, and inventory
usage. Choose the highest-mean post-120 conversion candidate with positive inner
mean under baseline and combined 25-share depth/6-second latency. Optionally
choose the best positive C10–C12 candidate under the same rule if its inner PnL
correlation with the first is below 0.90. If none qualifies, freeze the best
post-120 loop solely as a negative-result validation diagnostic, explicitly not
recommended for integration. No threshold or family added after these results.

Validation runs the frozen candidates and predefined stresses together in one
sealed evaluation command: depth 25; latency 6s; combined depth 25/latency 6s;
latency 12s; +10bps adverse cost. Frozen models/configs are saved before results
are opened. No validation-driven model changes or policy tuning.

## Execution and verification

Baseline arrivals: 2s after decisions. Every market fill pays arrival consensus
plus adverse side*(25bps + $0.02/share). Conversion has exactly zero cash, one
action, and atomically changes signed basket/ETF inventory after latency. It can
create shorts only within published limits. Each market action is one symbol,
max 50 shares/symbol/2s; large legs are split under reduced depth. Pending positive
and negative quantities separately reserve capacity. Every arrival and submission
checks limits. All legs finish in the round; end-round flattening is by paid
market actions, never an accounting reset. No terminal holdings are planned.

Required controls: cash ledger reconciliation; forced parity-flat loops have
strictly negative costs and zero gross profit; conversion alone has no cash;
explicit sequential arrival trace; lagged execution versus a clearly labeled
unexecutable same-quote basis diagnostic; reduced depth and latency stresses.
Record phase attribution and action ticks for parent shared-account integration.
At most two workers; OMP/OpenBLAS/MKL threads set to one.
