"""Causal ETF/basket and stock-pair research with sequential, paid execution.

All future indexing is confined to fit labels and arrival-time execution. The
strategy sees only current/past quotes, public clock, and frozen coefficients.
"""

import os

for _key in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ[_key] = "1"

import argparse
import csv
import hashlib
import itertools
import json
import time
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent
DATA = ROOT.parent / "development.npz"
SYMBOLS = ["PORT", "ISLE", "AQUA", "GRID", "FERRY", "RECON", "MAT", "GEN", "HAVEN", "REIN", "ARCH", "REBLD"]
LIMITS = np.array([200, 300, 500, 400, 800, 500, 700, 600, 250, 200, 50, 100])
BASKETS = np.zeros((2, 12), dtype=int)
BASKETS[0, [0, 1, 2, 3, 4, 8]] = [1, 1, 2, 1, 2, 1]
BASKETS[1, [5, 6, 7]] = [2, 2, 1]
VECTORS = BASKETS.copy()
VECTORS[0, 10] = -1
VECTORS[1, 11] = -1
STOCKS = [np.where(x)[0].tolist() for x in BASKETS]
PAIRS = [p for group in STOCKS for p in itertools.combinations(group, 2)]
RIDGE = 0.01
CONFIGS = [
    dict(id="C01", family="raw", route="etf_first", start=0, multiplier=1.0),
    dict(id="C02", family="raw", route="etf_first", start=120, multiplier=1.5),
    dict(id="C03", family="raw", route="convert_first", start=0, multiplier=1.5),
    dict(id="C04", family="raw", route="etf_first", start=120, multiplier=2.5),
    dict(id="C05", family="loop", route="etf_first", start=0, margin=0.25),
    dict(id="C06", family="loop", route="etf_first", start=120, margin=0.25),
    dict(id="C07", family="loop", route="etf_first", start=120, margin=0.75),
    dict(id="C08", family="loop", route="convert_first", start=120, margin=0.25),
    dict(id="C09", family="directional", route="etf_first", start=0, margin=0.25),
    dict(id="C10", family="directional", route="etf_first", start=120, margin=0.25),
    dict(id="C11", family="hedged", route="etf_first", start=120, margin=0.25),
    dict(id="C12", family="pair", route="pair", start=120, margin=0.05),
]
for _config in CONFIGS:
    _config.update(lot=25, hold_seconds=10)
SCENARIOS = {
    "baseline": dict(depth=50, latency=2, adverse_bps=0),
    "depth25": dict(depth=25, latency=2, adverse_bps=0),
    "latency6": dict(depth=50, latency=6, adverse_bps=0),
    "depth25_latency6": dict(depth=25, latency=6, adverse_bps=0),
    "latency12": dict(depth=50, latency=12, adverse_bps=0),
    "adverse10bps": dict(depth=50, latency=2, adverse_bps=10),
}


def dump(path, value):
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")


def load_partition(role):
    """Immediately select the allowed rows; no validation summaries in fit/tune."""
    ranges = {"fit": (361, 600), "inner": (241, 360), "refit": (241, 600), "validation": (121, 240)}
    with np.load(DATA, allow_pickle=False) as z:
        ids = z["season_ids"]
        low, high = ranges[role]
        mask = (ids >= low) & (ids <= high)
        market = z["market"][mask].astype(np.float64)
        # No settlement labels are needed: every strategy closes its inventory.
        return ids[mask], market


def lag(x, steps):
    return x[:, :, np.maximum(np.arange(x.shape[2]) - steps, 0)]


def phase_features(shape):
    t = np.broadcast_to(np.arange(shape[2])[None, None, :] * 2, shape)
    return [(t < 60), ((t >= 60) & (t < 90)), ((t >= 90) & (t < 550)),
            ((t >= 550) & (t < 590)), ((t >= 590) & (t < 730)), (t >= 730)]


def etf_features(market, b):
    e = market[..., 10 + b]
    s = market @ BASKETS[b]
    basis = e - s
    cost = (e + s) * 0.0025 + 0.02 * (1 + BASKETS[b].sum())
    features = [basis, np.abs(basis), basis * np.abs(basis), e, s, cost]
    names = ["basis", "abs_basis", "basis_x_abs", "etf_price", "basket_price", "estimated_loop_cost"]
    for k, seconds in [(1, 2), (2, 4), (5, 10)]:
        for x, name in [(e, "etf"), (s, "basket"), (basis, "basis")]:
            features.append(x - lag(x, k))
            names.append(f"{name}_change_{seconds}s")
    stocks = market[..., STOCKS[b]]
    returns = stocks / np.maximum(lag(stocks, 5), 0.01) - 1
    features.extend([returns.std(axis=-1), np.abs(returns).max(axis=-1)])
    names.extend(["stock_return_dispersion_10s", "stock_max_abs_return_10s"])
    phases = phase_features(e.shape)
    for i, phase in enumerate(phases):
        features.append(phase)
        names.append(f"phase_{i}")
    for i in (1, 2, 3, 5):
        features.append(basis * phases[i])
        names.append(f"basis_x_phase_{i}")
    return np.stack(features, axis=-1), names


def pair_quantities(price, pair):
    i, j = pair
    notional = np.minimum(1000.0, 50 * np.minimum(price[..., i], price[..., j]))
    qi = np.floor(notional / price[..., i]).astype(int)
    qj = np.floor(notional / price[..., j]).astype(int)
    return qi, qj, notional


def pair_features(market, pair):
    i, j = pair
    a, b = market[..., i], market[..., j]
    group = STOCKS[0] if i in STOCKS[0] else STOCKS[1]
    features = [a, b, a / np.maximum(b, .01)]
    names = ["price_a", "price_b", "price_ratio"]
    for k, seconds in [(1, 2), (2, 4), (5, 10)]:
        ra = a / np.maximum(lag(a, k), .01) - 1
        rb = b / np.maximum(lag(b, k), .01) - 1
        peers = market[..., group]
        rp = (peers / np.maximum(lag(peers, k), .01) - 1).mean(axis=-1)
        features.extend([ra, rb, ra - rb, rp, ra - rp, rb - rp])
        names.extend([f"{n}_{seconds}s" for n in ["return_a", "return_b", "return_spread", "peer_return", "a_residual", "b_residual"]])
    for k, phase in enumerate(phase_features(a.shape)):
        features.append(phase)
        names.append(f"phase_{k}")
    return np.stack(features, axis=-1), names


def schedules(config, instrument, side, price, depth=50, latency=2):
    """Return [(kind, vector, hold-before-submit ticks), ...].

    Only one action can be outstanding. The next action is submitted at or after
    confirmation of the previous, never at its original decision quote.
    """
    family, lot = config["family"], config["lot"]
    out = []

    def market(j, qty, wait=0):
        first = True
        while qty:
            chunk = int(np.sign(qty) * min(depth, abs(qty)))
            change = np.zeros(12, dtype=int)
            change[j] = chunk
            out.append(("market", change, wait if first else 0))
            qty -= chunk
            first = False

    def convert(b, direction):
        out.append(("convert", direction * lot * VECTORS[b], 0))

    if family in ("raw", "loop"):
        b = instrument
        if config["route"] == "convert_first":
            convert(b, side)
            market(10 + b, side * lot)
        else:
            market(10 + b, side * lot)
            convert(b, side)
        for j in STOCKS[b]:
            market(j, -side * lot * BASKETS[b, j])
    elif family == "directional":
        market(10 + instrument, side * lot)
        market(10 + instrument, -side * lot, config["hold_seconds"] // 2)
    elif family == "hedged":
        b = instrument
        market(10 + b, side * lot)
        for j in STOCKS[b]:
            market(j, -side * lot * BASKETS[b, j])
        market(10 + b, -side * lot, config["hold_seconds"] // 2)
        for j in STOCKS[b]:
            market(j, side * lot * BASKETS[b, j])
    elif family == "pair":
        i, j = PAIRS[instrument]
        qi, qj, _ = pair_quantities(price, (i, j))
        market(i, side * int(qi))
        market(j, -side * int(qj))
        market(i, -side * int(qi), config["hold_seconds"] // 2)
        market(j, side * int(qj))
    else:
        raise ValueError(family)
    assert out
    assert np.all(np.sum([x[1] for x in out], axis=0) == 0)
    return out


def duration_ticks(schedule, latency):
    return len(schedule) * max(1, int(np.ceil(latency / 2))) + sum(x[2] for x in schedule)


def targets(market, family, route, instrument):
    """Training labels, never called by the live decision path."""
    if family == "pair":
        i, j = PAIRS[instrument]
        qi, qj, notional = pair_quantities(market, (i, j))
        # Submit A now -> +2s; B after A -> +4s. Hold ten seconds
        # after B confirms, then close A at +16s and B at +18s.
        max_offset = 9
        valid = 390 - max_offset
        y = qi[..., :valid] * (market[:, :, 8:8 + valid, i] - market[:, :, 1:1 + valid, i])
        y -= qj[..., :valid] * (market[:, :, 9:9 + valid, j] - market[:, :, 2:2 + valid, j])
        y *= 100.0 / np.maximum(notional[..., :valid], 1)
        return y, valid
    cfg = dict(family=family, route=route, lot=1, hold_seconds=10)
    schedule = schedules(cfg, instrument, 1, market[0, 0, 0])
    valid = 390 - duration_ticks(schedule, 2)
    y = np.zeros(market.shape[:2] + (valid,))
    arrival = 0
    for kind, change, wait in schedule:
        arrival += 1 + wait
        if kind == "market":
            y -= market[:, :, arrival:arrival + valid] @ change
    return y, valid


def fit_ridge(x, y):
    x = x.reshape(-1, x.shape[-1])
    y = y.reshape(-1)
    mean, std = x.mean(0), x.std(0)
    std = np.where(std < 1e-8, 1.0, std)
    z = (x - mean) / std
    ym = y.mean()
    coef = np.linalg.solve(z.T @ z / len(y) + RIDGE * np.eye(z.shape[1]), z.T @ (y - ym) / len(y))
    err = y - (ym + z @ coef)
    return dict(mean=mean, std=std, coef=coef, intercept=np.array(ym)), {
        "n_labels": int(len(y)), "label_mean": float(ym), "label_std": float(y.std()),
        "fit_rmse": float(np.sqrt(np.mean(err ** 2))), "fit_r2": float(1 - np.mean(err ** 2) / max(np.var(y), 1e-12)),
    }


def model_key(family, route, instrument):
    return f"{family}_{route}_{instrument}"


def fit_models(market, out, configs=CONFIGS):
    models, metadata = {}, {}
    requests = set()
    for c in configs:
        if c["family"] == "raw":
            continue
        for b in range(len(PAIRS) if c["family"] == "pair" else 2):
            requests.add((c["family"], c["route"], b))
    # Reuse features for the four ETF targets without duplicating large arrays.
    for pair_mode in (False, True):
        for b in range(len(PAIRS) if pair_mode else 2):
            relevant = sorted(r for r in requests if (r[0] == "pair") == pair_mode and r[2] == b)
            if not relevant:
                continue
            x, names = pair_features(market, PAIRS[b]) if pair_mode else etf_features(market, b)
            for family, route, instrument in relevant:
                key = model_key(family, route, instrument)
                y, valid = targets(market, family, route, instrument)
                models[key], meta = fit_ridge(x[:, :, :valid], y)
                metadata[key] = dict(meta, features=names, pair=PAIRS[b] if pair_mode else None)
    payload = {f"{k}__{field}": value for k, model in models.items() for field, value in model.items()}
    np.savez_compressed(out, **payload)
    dump(Path(out).with_suffix(".json"), metadata)
    return models


def load_models(path):
    models = {}
    with np.load(path, allow_pickle=False) as z:
        for key in z.files:
            name, field = key.split("__")
            models.setdefault(name, {})[field] = z[key]
    return models


def predict(models, market, configs=CONFIGS):
    result = {}
    for pair_mode in (False, True):
        for b in range(len(PAIRS) if pair_mode else 2):
            keys = {model_key(c["family"], c["route"], b) for c in configs if c["family"] != "raw" and (c["family"] == "pair") == pair_mode}
            if not keys:
                continue
            x, _ = pair_features(market, PAIRS[b]) if pair_mode else etf_features(market, b)
            for key in keys:
                model = models[key]
                result[key] = model["intercept"] + (x - model["mean"]) @ (model["coef"] / model["std"])
    return result


def signals(market, config, predictions):
    family = config["family"]
    if family == "pair":
        pred = np.stack([predictions[model_key(family, "pair", p)] for p in range(len(PAIRS))], axis=-1)
        net, score = [], []
        for k, pair in enumerate(PAIRS):
            i, j = pair
            qi, qj, notional = pair_quantities(market, pair)
            cost = 2 * (qi * (.0025 * market[..., i] + .02) + qj * (.0025 * market[..., j] + .02))
            dollars = np.abs(pred[..., k]) * notional / 100
            net.append(dollars - cost)
            score.append(dollars - cost - config["margin"] * notional / 100)
        return np.stack(score, -1), np.sign(pred).astype(int), np.stack(net, -1)
    e = market[..., 10:]
    s = market @ BASKETS.T
    basis = e - s
    cost = (e + s) * .0025 + .02 * (1 + BASKETS.sum(1))
    if family == "raw":
        side = -np.sign(basis).astype(int)
        score = np.abs(basis) - config["multiplier"] * cost
        net = np.abs(basis) - cost
    else:
        pred = np.stack([predictions[model_key(family, config["route"], b)] for b in range(2)], axis=-1)
        if family == "directional":
            cost = 2 * (.0025 * e + .02)
        elif family == "hedged":
            cost *= 2
        side = np.sign(pred).astype(int)
        net = np.abs(pred) - cost
        score = net - config["margin"]
    return score * config["lot"], side, net * config["lot"]


def simulate(market, config, predictions=None, *, depth=50, latency=2, adverse_bps=0,
             forced=None, trace_season=None):
    """All inventories/pending legs audited. Strictly serialized per account.

    `forced` exists only for synthetic unit controls, never research selection.
    It maps (round,tick) -> (instrument,side) and bypasses signal thresholds.
    """
    n = len(market)
    delay = max(1, int(np.ceil(latency / 2)))
    if forced is None:
        scores, sides, expected_net = signals(market, config, predictions or {})
    q = np.zeros((n, 12), dtype=int)
    pp, pn = np.zeros_like(q), np.zeros_like(q)
    cash = np.zeros(n)
    costs = np.zeros(n)
    market_ledger = np.zeros(n)
    actions = np.zeros(n, dtype=int)
    conversions = np.zeros(n, dtype=int)
    turnover = np.zeros(n)
    max_pos = np.zeros_like(q)
    max_reserved = np.zeros_like(q)
    max_window = np.zeros(n, dtype=int)
    action_ticks = np.zeros((n, 3, 390), dtype=np.int8)
    gross_basis = np.zeros(n)
    mark_capture = np.zeros(n)
    unmatched_basis = np.zeros(n, dtype=int)
    max_rounding_residual = np.zeros(n)
    cycles_count = np.zeros(n, dtype=int)
    phase_pnl = np.zeros((n, 4))
    phase_count = np.zeros((n, 4), dtype=int)
    peak, dd = np.zeros(n), np.zeros(n)
    trades, trace = [], []
    last_market_arrival = np.full((n, 12), -10000, dtype=int)
    for r in range(3):
        history = np.zeros((n, 30), dtype=int)
        used = np.zeros(n, dtype=int)
        active = [None] * n
        arrival = np.full(n, -1, dtype=int)
        ready = np.zeros(n, dtype=int)
        next_index = np.zeros(n, dtype=int)
        for ti in range(390):
            t = 2 * ti
            slot = ti % 30
            used -= history[:, slot]
            history[:, slot] = 0
            price = market[:, r, ti]
            for i in np.flatnonzero(arrival == ti):
                cycle = active[i]
                kind, change, _ = cycle["schedule"][next_index[i] - 1]
                pp[i] -= np.maximum(change, 0)
                pn[i] -= np.maximum(-change, 0)
                before_cash = cash[i]
                if kind == "market":
                    j = int(np.flatnonzero(change)[0])
                    assert np.count_nonzero(change) == 1 and abs(change[j]) <= depth
                    assert (r * 390 + ti) - last_market_arrival[i, j] >= 1
                    last_market_arrival[i, j] = r * 390 + ti
                    fee = abs(change[j]) * (price[i, j] * (.0025 + adverse_bps / 10000) + .02)
                    payment = change[j] * price[i, j] + fee
                    cash[i] -= payment
                    market_ledger[i] -= payment
                    costs[i] += fee
                    turnover[i] += abs(change[j])
                else:
                    # Exactly zero cash; no mark-based transfer booking.
                    assert cash[i] == before_cash
                q[i] += change
                assert np.all(np.abs(q[i]) <= LIMITS)
                assert np.all(q[i] + pp[i] <= LIMITS) and np.all(q[i] - pn[i] >= -LIMITS)
                if i == trace_season:
                    trace.append(dict(event="arrival", round=r + 1, second=t, kind=kind,
                                      change=change.tolist(), position=q[i].tolist(),
                                      pending_positive=pp[i].tolist(), pending_negative=pn[i].tolist(),
                                      cash=float(cash[i]), cycle=cycle["number"]))
                arrival[i] = -1
                if next_index[i] == len(cycle["schedule"]):
                    assert np.all(q[i] == 0) and np.all(pp[i] + pn[i] == 0)
                    pnl = cash[i] - cycle["cash"]
                    fee = costs[i] - cycle["cost"]
                    phase = cycle["phase"]
                    phase_pnl[i, phase] += pnl
                    phase_count[i, phase] += 1
                    cycles_count[i] += 1
                    gross_basis[i] += pnl + fee
                    trades.append(dict(row=int(i), round=r + 1, start_second=cycle["start"] * 2,
                                       end_second=t, instrument=int(cycle["instrument"]), side=int(cycle["side"]),
                                       pnl=float(pnl), cost=float(fee), gross=float(pnl + fee),
                                       signal_basis=float(cycle["basis"]),
                                       signal_mark_capture=float(cycle["mark_capture"]),
                                       expected_net=float(cycle["expected_net"]), actions=len(cycle["schedule"])))
                    active[i] = None
                    ready[i] = ti + 1  # No same-quote restart after a completion.
                else:
                    ready[i] = ti + cycle["schedule"][next_index[i]][2]
            max_pos = np.maximum(max_pos, np.abs(q))
            assert np.all(pp >= 0) and np.all(pn >= 0)
            assert np.all(q + pp <= LIMITS) and np.all(q - pn >= -LIMITS)
            wealth = cash + (q * price).sum(1)
            peak = np.maximum(peak, wealth)
            dd = np.maximum(dd, peak - wealth)
            for i in range(n):
                if arrival[i] >= 0 or ti < ready[i]:
                    continue
                if active[i] is None:
                    if t < config["start"]:
                        continue
                    if forced is None:
                        instrument = int(np.argmax(scores[i, r, ti]))
                        if scores[i, r, ti, instrument] <= 0:
                            continue
                        side = int(sides[i, r, ti, instrument])
                        forecast = expected_net[i, r, ti, instrument]
                    else:
                        if (r, ti) not in forced:
                            continue
                        instrument, side = forced[(r, ti)]
                        forecast = 0.0
                    schedule = schedules(config, instrument, side, price[i], depth, latency)
                    if ti + duration_ticks(schedule, latency) >= 390:
                        continue
                    # Reserve all future actions up front; no halfway budget trap.
                    if used[i] + len(schedule) > 60:
                        continue
                    if config["family"] != "pair":
                        basis = price[i, 10 + instrument] - price[i] @ BASKETS[instrument]
                        capture = -side * basis * config["lot"] if config["family"] in ("raw", "loop") else 0.0
                        unmatched_basis[i] += int(side * basis > 0) if config["family"] in ("raw", "loop") else 0
                    else:
                        basis, capture = 0.0, 0.0
                        a, b = PAIRS[instrument]
                        qa, qb, _ = pair_quantities(price[i], PAIRS[instrument])
                        max_rounding_residual[i] = max(max_rounding_residual[i], abs(qa * price[i, a] - qb * price[i, b]))
                    phase = 0 if t < 60 else 1 if t < 120 else 2 if t < 550 else 3
                    active[i] = dict(schedule=schedule, cash=cash[i], cost=costs[i], phase=phase,
                                     start=ti, instrument=instrument, side=side, basis=basis,
                                     mark_capture=capture, expected_net=forecast, number=int(cycles_count[i]) + 1)
                    mark_capture[i] += capture
                    next_index[i] = 0
                cycle = active[i]
                assert used[i] < 60
                kind, change, _ = cycle["schedule"][next_index[i]]
                assert ti + delay < 390
                assert np.all(q[i] + pp[i] + np.maximum(change, 0) <= LIMITS)
                assert np.all(q[i] - pn[i] - np.maximum(-change, 0) >= -LIMITS)
                pp[i] += np.maximum(change, 0)
                pn[i] += np.maximum(-change, 0)
                max_reserved[i] = np.maximum(max_reserved[i], np.maximum(np.abs(q[i] + pp[i]), np.abs(q[i] - pn[i])))
                arrival[i] = ti + delay
                next_index[i] += 1
                actions[i] += 1
                conversions[i] += kind == "convert"
                used[i] += 1
                history[i, slot] += 1
                action_ticks[i, r, ti] += 1
                if i == trace_season:
                    trace.append(dict(event="submit", round=r + 1, second=t, arrival_second=2 * (ti + delay),
                                      kind=kind, change=change.tolist(), position=q[i].tolist(),
                                      pending_positive=pp[i].tolist(), pending_negative=pn[i].tolist(),
                                      cash=float(cash[i]), cycle=cycle["number"]))
            max_window = np.maximum(max_window, used)
            assert np.all(used <= 60)
            assert np.all(q + pp <= LIMITS) and np.all(q - pn >= -LIMITS)
        assert all(x is None for x in active)
        assert np.all(q == 0) and np.all(pp + pn == 0) and np.all(arrival == -1)
    assert np.allclose(cash, market_ledger, atol=1e-8)
    assert np.allclose(phase_pnl.sum(1), cash, atol=1e-8)
    assert np.allclose(gross_basis - costs, cash, atol=1e-8)
    return dict(pnl=cash, cost=costs, gross=gross_basis, signal_mark_capture=mark_capture,
                timing_component=gross_basis - mark_capture, actions=actions,
                conversion_actions=conversions, turnover_shares=turnover, cycles=cycles_count,
                max_rolling_actions=max_window, max_position_by_symbol=max_pos,
                max_reserved_by_symbol=max_reserved, positions=q,
                max_position_fraction=(max_pos / LIMITS).max(1), drawdown=dd,
                phase_pnl=phase_pnl, phase_count=phase_count, action_ticks=action_ticks,
                side_against_current_basis=unmatched_basis, max_pair_rounding_residual=max_rounding_residual,
                trades=trades, trace=trace)


def summarize(result):
    pnl = result["pnl"]
    return dict(n=len(pnl), mean=float(pnl.mean()), se=float(pnl.std(ddof=1) / np.sqrt(len(pnl))) if len(pnl) > 1 else 0,
                median=float(np.median(pnl)), p05=float(np.quantile(pnl, .05)), min=float(pnl.min()),
                max=float(pnl.max()), win_fraction=float((pnl > 0).mean()),
                mean_cost=float(result["cost"].mean()), mean_gross=float(result["gross"].mean()),
                mean_signal_mark_capture=float(result["signal_mark_capture"].mean()),
                mean_timing_component=float(result["timing_component"].mean()),
                mean_cycles=float(result["cycles"].mean()), mean_actions=float(result["actions"].mean()),
                mean_conversion_actions=float(result["conversion_actions"].mean()),
                mean_turnover_shares=float(result["turnover_shares"].mean()),
                max_rolling_actions=int(result["max_rolling_actions"].max()),
                max_position_fraction=float(result["max_position_fraction"].max()),
                max_drawdown=float(result["drawdown"].max()),
                mean_phase_pnl=result["phase_pnl"].mean(0).tolist(),
                mean_phase_count=result["phase_count"].mean(0).tolist(),
                against_basis_fraction=float(result["side_against_current_basis"].sum() / max(result["cycles"].sum(), 1)),
                max_pair_rounding_residual=float(result["max_pair_rounding_residual"].max()))


def save_result(directory, ids, result):
    directory.mkdir(parents=True, exist_ok=True)
    dump(directory / "summary.json", summarize(result))
    payload = {k: v for k, v in result.items() if isinstance(v, np.ndarray)}
    np.savez_compressed(directory / "audit.npz", season_ids=ids, **payload)
    with (directory / "seasons.csv").open("w", newline="") as f:
        fields = ["season_id", "pnl", "cost", "gross", "signal_mark_capture", "timing_component", "cycles", "actions", "conversion_actions", "max_rolling_actions", "max_position_fraction", "drawdown"]
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for i, sid in enumerate(ids):
            writer.writerow(dict(season_id=int(sid), **{k: result[k][i].item() for k in fields[1:]}))
    if result["trades"]:
        with (directory / "trades.csv").open("w", newline="") as f:
            fields = ["season_id"] + [k for k in result["trades"][0] if k != "row"]
            writer = csv.DictWriter(f, fieldnames=fields)
            writer.writeheader()
            for trade in result["trades"]:
                writer.writerow(dict(season_id=int(ids[trade["row"]]), **{k: v for k, v in trade.items() if k != "row"}))
    if result["trace"]:
        dump(directory / "trace_first_season.json", result["trace"])


def controls():
    flat = np.ones((1, 3, 390, 12)) * np.array([70, 50, 25, 35, 20, 55, 35, 40, 40, 90, 1, 1])
    flat[..., 10:] = flat @ BASKETS.T
    summaries = {}
    for cid in ("C01", "C03", "C09", "C11", "C12"):
        c = next(x for x in CONFIGS if x["id"] == cid).copy()
        c["start"] = 0
        result = simulate(flat, c, forced={(0, 0): (0, 1), (1, 0): (0, -1)}, trace_season=0)
        assert np.allclose(result["gross"], 0, atol=1e-9)
        assert np.all(result["pnl"] < 0)
        assert np.allclose(result["pnl"], -result["cost"], atol=1e-9)
        last_arrival = None
        for event in result["trace"]:
            if event["event"] == "submit":
                assert event["arrival_second"] >= event["second"] + 2
                if last_arrival is not None and event["round"] == last_arrival[0]:
                    assert event["second"] >= last_arrival[1]
            else:
                last_arrival = (event["round"], event["second"])
        summaries[cid] = summarize(result)
    # Construct a known temporary ETF mispricing that vanishes before delayed
    # acquisition. Conversion cannot create cash or rescue a disappearing basis.
    transient = flat.copy()
    transient[0, 0, 0, 10] -= 10
    c = CONFIGS[0]
    result = simulate(transient, c, forced={(0, 0): (0, 1)}, trace_season=0)
    assert np.allclose(result["gross"], 0, atol=1e-9)
    assert result["signal_mark_capture"][0] == 250
    summaries["vanishing_basis"] = summarize(result)
    # Basis persists until ETF acquisition; subsequent stock prices stay flat.
    persistent = flat.copy()
    persistent[0, 0, :2, 10] -= 10
    result = simulate(persistent, c, forced={(0, 0): (0, 1)}, trace_season=0)
    assert abs(result["gross"][0] - 250) < 1e-8
    summaries["persistent_basis"] = summarize(result)
    # Label scheduler and independent simulator must give identical signed gross.
    rng = np.random.default_rng(913)
    varying = flat + np.cumsum(rng.normal(0, .1, flat.shape), axis=2)
    for cid in ("C01", "C03", "C09", "C11", "C12"):
        c = next(x for x in CONFIGS if x["id"] == cid).copy()
        c["start"] = 0
        result = simulate(varying, c, forced={(0, 0): (0, 1)})
        family = "loop" if c["family"] == "raw" else c["family"]
        y, _ = targets(varying, family, c["route"], 0)
        scale = c["lot"] if family != "pair" else pair_quantities(varying[0, 0, 0], PAIRS[0])[2] / 100
        assert abs(result["gross"][0] - y[0, 0, 0] * scale) < 1e-8, (cid, result["gross"], y[0, 0, 0] * scale)
    dump(ROOT / "controls.json", dict(passed=True, controls=summaries))
    dump(ROOT / "control_sequential_trace.json", simulate(persistent, CONFIGS[0], forced={(0, 0): (0, 1)}, trace_season=0)["trace"])
    print("controls passed", flush=True)


def train_and_tune():
    if (ROOT / "frozen.json").exists():
        raise RuntimeError("Frozen selection exists; refuse to retune")
    ids, fit = load_partition("fit")
    print("fit", ids.min(), ids.max(), flush=True)
    models = fit_models(fit, ROOT / "fit_models.npz")
    del fit
    ids, market = load_partition("inner")
    pred = predict(models, market)
    metrics = []
    for c in CONFIGS:
        for scenario in ("baseline", "depth25_latency6"):
            start = time.monotonic()
            result = simulate(market, c, pred, **SCENARIOS[scenario], trace_season=0 if scenario == "baseline" else None)
            save_result(ROOT / "inner" / c["id"] / scenario, ids, result)
            summary = summarize(result)
            metrics.append(dict(candidate=c, scenario=scenario, **summary))
            dump(ROOT / "all_candidate_results.json", metrics)
            print(c["id"], scenario, "mean", round(summary["mean"], 3), "SE", round(summary["se"], 3), "cycles", round(summary["mean_cycles"], 2), "elapsed", round(time.monotonic() - start, 1), flush=True)
    dump(ROOT / "candidate_configs.json", CONFIGS)


def freeze():
    if (ROOT / "frozen.json").exists():
        raise RuntimeError("Selection already frozen")
    metrics = json.loads((ROOT / "all_candidate_results.json").read_text())
    means = {(x["candidate"]["id"], x["scenario"]): x["mean"] for x in metrics}
    assert len(means) == 24
    eligible = [c for c in CONFIGS if c["start"] == 120 and c["family"] in ("raw", "loop")
                and means[c["id"], "baseline"] > 0 and means[c["id"], "depth25_latency6"] > 0]
    diagnostic_only = not bool(eligible)
    if not eligible:
        eligible = [c for c in CONFIGS if c["start"] == 120 and c["family"] in ("raw", "loop")]
    first = max(eligible, key=lambda c: means[c["id"], "baseline"])
    selected = [first]
    first_pnl = np.load(ROOT / "inner" / first["id"] / "baseline" / "audit.npz")["pnl"]
    other = []
    correlations = {}
    for c in CONFIGS[-3:]:
        p = np.load(ROOT / "inner" / c["id"] / "baseline" / "audit.npz")["pnl"]
        correlation = float(np.corrcoef(first_pnl, p)[0, 1]) if p.std() > 0 and first_pnl.std() > 0 else 1.0
        correlations[c["id"]] = correlation
        if means[c["id"], "baseline"] > 0 and means[c["id"], "depth25_latency6"] > 0 and correlation < .9:
            other.append(c)
    if other:
        selected.append(max(other, key=lambda c: means[c["id"], "baseline"]))
    ids, market = load_partition("refit")
    fit_models(market, ROOT / "frozen_models.npz", selected)
    checksum = hashlib.sha256((ROOT / "frozen_models.npz").read_bytes()).hexdigest()
    config = dict(selected=selected, diagnostic_only_first=diagnostic_only,
                  estimator=dict(ridge=RIDGE, fit_ids=[241, 600], features="relative.py"),
                  model_sha256=checksum, correlations=correlations,
                  validation_ids=[121, 240], scenarios=SCENARIOS,
                  selection_rule="PLAN.md", frozen_utc=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()))
    dump(ROOT / "frozen.json", config)
    print(json.dumps(config, indent=2), flush=True)


def validation():
    lock = ROOT / "VALIDATION_OPENED.json"
    if lock.exists():
        raise RuntimeError("Validation has already been opened; no second evaluation")
    frozen = json.loads((ROOT / "frozen.json").read_text())
    assert hashlib.sha256((ROOT / "frozen_models.npz").read_bytes()).hexdigest() == frozen["model_sha256"]
    dump(lock, dict(opened_utc=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), candidates=[c["id"] for c in frozen["selected"]]))
    ids, market = load_partition("validation")
    models = load_models(ROOT / "frozen_models.npz")
    pred = predict(models, market, frozen["selected"])
    metrics = []
    for c in frozen["selected"]:
        for name, scenario in frozen["scenarios"].items():
            result = simulate(market, c, pred, **scenario, trace_season=0 if name == "baseline" else None)
            save_result(ROOT / "validation" / c["id"] / name, ids, result)
            summary = summarize(result)
            metrics.append(dict(candidate=c["id"], scenario=name, **summary))
            dump(ROOT / "validation_results.json", metrics)
            print(c["id"], name, "mean", round(summary["mean"], 3), "SE", round(summary["se"], 3), flush=True)
    with (ROOT / "validation_seasons.csv").open("w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["season_id", "candidate", "scenario", "pnl", "cost", "actions", "cycles"])
        for c in frozen["selected"]:
            for name in frozen["scenarios"]:
                with np.load(ROOT / "validation" / c["id"] / name / "audit.npz") as z:
                    for i, sid in enumerate(ids):
                        writer.writerow([int(sid), c["id"], name, *[z[key][i] for key in ["pnl", "cost", "actions", "cycles"]]])


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("command", choices=["controls", "tune", "freeze", "validate"])
    args = parser.parse_args()
    {"controls": controls, "tune": train_and_tune, "freeze": freeze, "validate": validation}[args.command]()


if __name__ == "__main__":
    main()
