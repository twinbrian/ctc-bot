"""Read-only integration adapter: propose an intent, never submit an order.

The parent shared-account scheduler owns admission, all fills, positions, pending
orders, rolling key budget, and competing engines. It must honor confirmation
dependencies in the supplied serial schedule. This adapter assumes a flat sleeve
and cannot prove shared-account feasibility from sleeve-local inventory alone.
"""

import numpy as np

from relative import BASKETS, PAIRS, duration_ticks, predict, schedules, signals


def propose(history, config, models, *, depth=50, latency=2):
    """history: current round's observed quotes, shape [t//2+1,12].

    Uses only the passed prefix. Return the best complete-cycle intent or None.
    Call only when this sleeve has no live cycle. Models must be frozen/refit
    coefficients; no current-session fitting is performed.
    """
    history = np.asarray(history, dtype=float)
    assert history.ndim == 2 and history.shape[1] == 12 and 1 <= len(history) <= 390
    ti = len(history) - 1
    if 2 * ti < config["start"]:
        return None
    market = history[None, None]
    pred = predict(models, market, [config]) if config["family"] != "raw" else {}
    score, sides, net = signals(market, config, pred)
    instrument = int(np.argmax(score[0, 0, -1]))
    if score[0, 0, -1, instrument] <= 0:
        return None
    side = int(sides[0, 0, -1, instrument])
    sequence = schedules(config, instrument, side, history[-1], depth, latency)
    duration = duration_ticks(sequence, latency)
    if ti + duration >= 390:
        return None
    position = np.zeros(12, dtype=int)
    high, low = position.copy(), position.copy()
    for _, change, _ in sequence:
        position += change
        high = np.maximum(high, position)
        low = np.minimum(low, position)
    assert np.all(position == 0)
    return dict(candidate=config["id"], instrument=instrument, side=side,
                decision_second=2 * ti, expected_net=float(net[0, 0, -1, instrument]),
                admission_score=float(score[0, 0, -1, instrument]),
                actions_to_reserve=len(sequence), expected_duration_seconds=2 * duration,
                minimum_relative_inventory=low.tolist(), maximum_relative_inventory=high.tolist(),
                dependency="Submit next action only after previous confirmation plus hold_before_submit_seconds; no immediate repricing/reselection mid-cycle.",
                sequence=[dict(kind=kind, change=change.tolist(), hold_before_submit_seconds=2 * wait)
                          for kind, change, wait in sequence])


def check_prefix_causality(market, config, models):
    """Integration regression check: prefix and full-batch signals agree."""
    full = market[:1, :1]
    pred = predict(models, full, [config]) if config["family"] != "raw" else {}
    expected = signals(full, config, pred)
    for ti in [0, 1, 4, 30, 32, 60, 120, 285, 370]:
        prefix = full[:, :, :ti + 1]
        p = predict(models, prefix, [config]) if config["family"] != "raw" else {}
        actual = signals(prefix, config, p)
        for a, b in zip(actual, expected):
            assert np.allclose(a[:, :, -1], b[:, :, ti], atol=1e-8)
    return True
