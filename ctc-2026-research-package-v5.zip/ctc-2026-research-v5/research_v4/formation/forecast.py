"""Small causal forecasts; no truth arrays, settlement values or season IDs as features."""

import numpy as np

from contracts import BASKETS


def prior_state(d):
    n = len(d["market"])
    damage = np.zeros((n, 3, 5))
    loss = np.zeros((n, 3))
    outage = np.zeros((n, 3, 5))
    weights = np.zeros((len(d["site_xy"]), 5))
    weights[np.arange(len(weights)), d["site_company"].astype(int)] = d["site_weight"]
    for r in (1, 2):
        # Only finished prior rounds; all their final reports are now public.
        damage[:, r] = d["damage"][:, :r, -1].sum(1)
        loss[:, r] = d["loss"][:, :r, -1].sum(1)
        o = d["obs"][:, :r, :240]
        distance = np.linalg.norm(o[..., None, :2] - d["site_xy"], axis=-1)
        wind = o[..., None, 5] * np.exp(-(distance / o[..., None, 4]) ** 2)
        # Matches models.py: t0 no elapsed interval, final published observation
        # also closes the final two-second interval at dissipation.
        elapsed = np.full(240, 2 / 120)
        elapsed[0] = 0
        elapsed[-1] += 2 / 120
        outage[:, r] = (((wind >= .35) * elapsed[None, None, :, None]).sum((1, 2)) @ weights)
    return damage, loss, outage


def relevant(x):
    """One relevant physical exposure per stock/ETF, with bounded basket weights."""
    y = np.empty((*x.shape[:-1], 10))
    y[..., :5] = x
    y[..., 5] = x[..., [0, 3, 4]].mean(-1)
    y[..., 6] = x.mean(-1)
    y[..., 7] = x[..., 3]
    y[..., 8:] = x.mean(-1)[..., None]
    return np.concatenate([y, y @ BASKETS.T / BASKETS.sum(1)], axis=-1)


def formation_features(d, quote=True, at=0):
    damage, loss, outage = prior_state(d)
    shape = (*loss.shape, 12)
    shared = lambda a: np.broadcast_to(a[..., None], shape)
    features = [relevant(damage), shared(damage.mean(-1)), relevant(outage),
                shared(loss / 1300), shared(np.clip((loss - 400) / 900, 0, 1)),
                shared(np.maximum(loss - 1300, 0) / 1300)]
    if quote:
        features.append(d["market"][:, :, at // 2])
    return np.stack(features, axis=-1)


def local_wind(d, o, project=0):
    xy = o[..., :2] + project * o[..., 2:4]
    distance = np.linalg.norm(xy[..., None, :] - d["site_xy"], axis=-1)
    ratio = distance / o[..., None, 4]
    wind = o[..., None, 5] * np.exp(-ratio ** 2) * (ratio <= 2)
    weights = np.zeros((len(d["site_xy"]), 5))
    weights[np.arange(len(weights)), d["site_company"].astype(int)] = d["site_weight"]
    return relevant(wind @ weights)


def exit_features(d, at=70, advisory=False):
    assert at >= 60
    initial = d["obs"][:, :, 0]
    current = d["obs"][:, :, min((at - 60) // 2, 239)]
    shape = (*current.shape[:2], 12)
    shared = lambda a: np.broadcast_to(a[..., None], shape)
    price = d["market"][:, :, at // 2]
    features = [shared(initial[..., k]) for k in range(6)]
    features += [shared(current[..., k]) for k in range(6)]
    features += [local_wind(d, current), local_wind(d, current, 30),
                 price - d["market"][:, :, 30], price - d["market"][:, :, 0]]
    damage, loss, _ = prior_state(d)
    features += [relevant(damage), shared(loss / 1300),
                 shared(np.clip((loss - 400) / 900, 0, 1))]
    if advisory:
        official = d["official"][:, :, at // 2]
        features += [shared((official == k).astype(float)) for k in range(6)]
        probability = d["probability"][:, :, at // 2]
        features += [shared(probability.mean(-1)), shared(probability.max(-1))]
        cone = d["cone"][:, :, at // 2]
        features += [shared(cone[..., k]) for k in range(3)]
    return np.stack(features, axis=-1)


def window(market, at):
    return market[:, :, (at + 2) // 2:(at + 14) // 2].mean(2)


class RoundRidge:
    """Round fixed effects plus strongly regularized, pooled within-round slopes."""

    def __init__(self, alpha, blend=.75):
        self.alpha, self.blend = alpha, blend

    def fit(self, x, y):
        self.center = x.mean(0)
        z = x - self.center
        self.scale = np.maximum(np.sqrt((z * z).mean((0, 1))), 1e-8)
        z = np.clip(z / self.scale, -5, 5)
        self.base = y.mean(0)
        residual = y - self.base
        self.sigma = residual.std((0, 1))
        self.bounds = np.stack([residual.min((0, 1)), residual.max((0, 1))])
        self.coef = np.zeros((12, x.shape[-1]))
        for j in range(12):
            a = z[:, :, j].reshape(-1, x.shape[-1])
            b = residual[:, :, j].ravel()
            self.coef[j] = np.linalg.solve(a.T @ a + self.alpha * np.eye(a.shape[1]), a.T @ b)
        return self

    def predict(self, x, residual_scale=1., perturb=0.):
        z = np.clip((x - self.center) / self.scale, -5, 5)
        residual = np.einsum("nrjk,jk->nrj", z, self.coef)
        residual = np.clip(residual, self.bounds[0], self.bounds[1])
        prediction = self.base + self.blend * residual_scale * residual
        if perturb:
            # Fixed symbol-level signs: persistent misspecification, no outcomes.
            signs = np.random.default_rng(20261019).choice([-1., 1.], size=12)
            prediction = prediction + perturb * self.sigma * signs
        return prediction


def fit_models(d):
    models = {"curve": d["market"].mean(0)}
    for at in (70, 100):
        y = window(d["market"], at) - window(d["market"], 0)
        for kind in ("state", "quote"):
            models[f"{kind}{at}"] = RoundRidge(200).fit(formation_features(d, kind == "quote"), y)
    for at in (70, 90):
        y = window(d["market"], 120) - window(d["market"], at)
        models[f"exit{at}"] = RoundRidge(300).fit(exit_features(d, at, at == 90), y)
    return models
