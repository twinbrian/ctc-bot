"""Read-only parent common.py contract, copied locally for self-contained runs."""

import numpy as np

SYMBOLS = ["PORT", "ISLE", "AQUA", "GRID", "FERRY", "RECON", "MAT", "GEN", "HAVEN", "REIN", "ARCH", "REBLD"]
LIMITS = np.array([200, 300, 500, 400, 800, 500, 700, 600, 250, 200, 50, 100])
BASKETS = np.zeros((2, 10), dtype=int)
BASKETS[0, [0, 1, 2, 3, 4, 8]] = [1, 1, 2, 1, 2, 1]
BASKETS[1, [5, 6, 7]] = [2, 2, 1]


def with_etfs(x):
    return np.concatenate([x, x @ BASKETS.T], axis=-1)
