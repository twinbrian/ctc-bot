# Conditional formation inventory / causal exits

All outcomes come from `../development.npz`. Parent files are read-only.
This directory is self-contained apart from that input and a parity test that
imports the read-only parent route simulator.

## Commands

From `/tmp/opencode/ctc-research/project/research_v4/formation`:

```bash
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1
export PYTHONDONTWRITEBYTECODE=1
python -m pytest -q test_research.py
python research.py freeze
python research.py validate
python verify_saved.py
python summarize_saved.py
```

`freeze` scores the 12 declared candidates on seasons 241–360 using models fit
on 361–600, writes `frozen_config.json`, then refits on 241–600. `validate`
opens seasons 121–240 once and computes the already-frozen comparisons and
stress cases. It refuses a second invocation, and `freeze` refuses to reselect
after validation has started. Existing result artifacts should be inspected
rather than rerunning validation. Reproduction from scratch uses a clean copy
of this directory under the parent research lead's evaluation protocol.

## Files

- `contracts.py`: copied symbol/basket/limit contract.
- `forecast.py`: public prior-state features, small ridge forecasts, causal exits.
- `simulator.py`: local v3 execution adaptation; fixed-route parity is tested.
- `research.py`: split loading, finite selection, freeze, single validation pass.
- `candidate_metrics.csv`: every declared candidate's inner-tune metrics.
- `candidate_tune_seasons.csv`: inner-tune season PnL for every candidate.
- `frozen_models.pkl`: refit, frozen ridge coefficients and training mean curves.
- `model_manifest.json`: hashes linking models and frozen configuration.
- `validation_metrics.csv`: frozen policies, comparators and stress summaries.
- `validation_seasons.csv`: all single-pass validation season results.
- `validation_results.npz`: full accounting, attribution, goals and timing arrays.
- `validation_paired.csv`: paired season-mean differences, conditional bootstrap CIs.
- `HANDOFF.md`: findings, limitations, economic attribution and integration notes.

## Live-policy integration contract

`run(data, models, config)` is the offline replay interface. At formation, compute
the matching ridge prediction using only the current quote and finished prior
rounds' public reports/observations. Do not pass current-storm observations into
entry decisions. Apply the same goal, conversion planning, pending reservations,
latency and fee logic as `simulator.py` in the shared account.

Dynamic exits evaluate the *current net pending-inclusive inventory* at t70:
hold only when `sum(inventory * forecast_70_to_120) > hurdle`; otherwise begin
actual liquidation. The advisory variant reassesses at t90 using only that
tick's published official information. All retained inventory starts closing
by t120. These checks retain or close existing exposure; they do not open a new
post-formation directional trade.

Consume `action_ticks` and `flat_times` when combining engines. The parent's v3
combiner conservatively resumes other trading at the next 10-second boundary
after `flat_time + 60`; retain that constraint, or enforce one shared rolling
action ledger directly. Standalone formation profits must not simply be added
to another engine that already uses the same positions/actions. Headline
formation PnL here excludes the parent's short-horizon and endgame engines.
