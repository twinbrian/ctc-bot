# Formation inventory and causal exits — handoff

## Bottom line

**No substantial new mean-PnL alpha established.** The conditional inventory
policy adds a small fee-saving improvement at a matched exit time. The causal
exit improves substantially over an early fixed t70 exit, but not over a fixed
t100 exit with identical starting inventory. Neither challenger beat the best
unconditional comparator on the inner mean-PnL selection sample.

The two predeclared family winners were frozen before validation:

- **Q100:** state/current-quote ridge inventory, fixed t100 exit.
- **X70advisory:** state/current-quote inventory; decide at t70 whether to retain
  until t120, reassess using the first official advisory at t90, and close by t120.

All figures below are **formation-engine-only, hypothetical-fill net USD per
three-round season**. They are not the combined v3 strategy's PnL. The full
dataset informed earlier research, so this is post-selection development
validation, not a fresh/unbiased global holdout.

## Protocol and complete candidate record

`PLAN.md` declared exactly 12 candidates before inner scoring. Models were fit
on 361–600, candidates scored on 241–360, the two family winners frozen, and
models refit on 241–600. One validation pass evaluated 121–240 and all previously
specified diagnostics. There was no validation-driven policy revision.

| Candidate | Inner mean | Inner p05 |
|---|---:|---:|
| B70 unconditional / exit70 | 10,106.00 | -342.83 |
| B100 unconditional / exit100 | 10,829.65 | -3,285.74 |
| B120 unconditional / exit120 | **11,073.05** | -5,844.07 |
| S70 prior-state ridge / exit70 | 10,139.54 | 598.50 |
| S100 prior-state ridge / exit100 | 10,870.00 | -3,384.42 |
| Q70 state+quote ridge / exit70 | 10,138.65 | 638.22 |
| **Q100** state+quote ridge / exit100 | **10,894.48** | -3,168.18 |
| Q70soft bounded soft sizing | 9,233.16 | 773.16 |
| X70 conditional t70 hold/exit | 10,669.21 | -2,919.93 |
| X70hurdle hold only above $250 | 10,594.39 | 891.77 |
| A70 unconditional entry + conditional exit | 10,681.15 | -1,699.27 |
| **X70advisory** t70 and t90 checks | **10,864.26** | -1,072.57 |

`candidate_metrics.csv` includes every candidate's mean, median, minimum, p05,
standard deviation, conditional mean CI, cost, turnover, actions, conversions,
drawdown, limits and timing metrics. `candidate_tune_seasons.csv` contains all
1,440 candidate-season PnLs; `inner_results.npz` preserves the full accounting.

## Frozen validation results

| Policy | Mean | p05 | Minimum | Mean cost | Mean drawdown |
|---|---:|---:|---:|---:|---:|
| B70 | 9,329.16 | 191.90 | -5,699.35 | 3,150.05 | 3,696.51 |
| B100 | 10,483.03 | -5,265.89 | -7,396.97 | 3,151.39 | 7,561.10 |
| B120 | 10,123.30 | -6,479.05 | -9,198.14 | 3,150.58 | 8,805.26 |
| **Q100** | **10,506.72** | -5,260.51 | -6,945.68 | 3,125.24 | 7,555.14 |
| **X70advisory** | **10,474.69** | -3,970.80 | -5,699.35 | 3,111.90 | 4,924.51 |

Paired season-bootstrap 95% intervals are conditional diagnostics, without a
multiple-search/global-selection correction:

- Q100 minus same-time B100: **+$23.68**, interval **[$1.88, $49.56]**.
- Q100 minus inner-selected B120: +$383.42, interval [-$224.25, $996.65].
- X70advisory minus B70: **+$1,145.53**, interval [$338.25, $1,949.90].
- X70advisory minus B100: -$8.34, interval [-$1,152.60, $1,082.14].
- X70advisory minus B120: +$351.39, interval [-$1,007.15, $1,649.75].

Risk improvements do not replace the mean-PnL objective. The inner-selected
unconditional timing was B120; B100's better validation result is reported as
the predeclared timing comparator, not a newly selected policy.

## What is alpha, and what is sizing or capacity?

### Conditional inventory: small cost saving, not new direction alpha

Q100 saves **$26.15 in transaction costs** versus B100, while gross price capture
decreases about **$2.47**, explaining its net +$23.68. Mean absolute target
inventory falls from 4,400 to 4,355.83 shares per round. There are no direction
reversals. The quantity-matched unconditional-direction control produces exactly
the same validation PnL.

In the 360 validation storms, Q100 skips RECON in 18, MAT in 13, PORT in one,
and REBLD in two; it adds a fee-clearing REIN position in 13 storms where the
unconditional rule stays flat. HAVEN inventory never changes. Thus the tested
HAVEN exhaustion hypothesis did not produce an actionable inventory improvement.
Most action is suppression of marginal reconstruction exposure plus occasional
REIN participation, rather than a broad new conditional formation effect.

Targets are slightly smaller, yet market-share turnover rises from 12,000 to
12,107.5 per season: breaking common basket components can reduce conversion
efficiency. Mean conversion actions fall from 51 to 49.36. Capacity assumptions,
limits and key count are identical. This is not a gain from raising depth or
inventing more capacity.

### Causal exit: timing effect, but not better than a simple longer hold

Hold the X70advisory starting inventory and trade priority fixed, varying only
its exit rule:

| Same-goal exit control | Mean | Dynamic minus control | Paired 95% interval |
|---|---:|---:|---:|
| Fixed70 | 9,349.01 | +1,125.68 | [318.84, 1,933.15] |
| Fixed100 | 10,493.53 | **-18.83** | [-1,158.65, 1,071.09] |
| Fixed120 | 10,146.90 | +327.79 | [-1,029.30, 1,625.69] |

The t70/t90 checks choose exits at 70/90/120 in 204/70/86 of the 360 validation
storms, with mean exit decision 85.83 seconds. Its lower drawdown and less-bad
p05 relative to B100 are real diagnostics, but they do not establish a larger
expected dollar return. Much of its improvement over B70 is simply allowing
longer exposure to formation repricing.

Symbol-level attribution in `goal_diagnostics.csv` is conversion-cost-basis
bookkeeping at basket parity; it is not an independently executable stock-level
alpha decomposition. The same-goal exit controls are the cleaner causal ablation.

## Predeclared sensitivity: mean validation PnL

| Scenario | Q100 | X70advisory |
|---|---:|---:|
| Base: 25bps+$0.02, depth50, latency2 | 10,506.72 | 10,474.69 |
| Costs40bps+$0.02 | 8,765.96 | 8,775.67 |
| Costs50bps+$0.02 | 7,684.99 | 7,659.13 |
| Additional adverse fill10bps | 9,353.48 | 9,326.65 |
| Depth25 shares/symbol/2s | 7,151.18 | 6,976.87 |
| Depth10 shares/symbol/2s | 3,188.29 | 3,005.33 |
| Latency4 seconds | 10,395.93 | 10,312.26 |
| Entry and exit schedules delayed4s | 10,413.07 | 10,617.74 |
| Exit checks4s earlier | 10,366.39 | 8,765.23 |
| Conditional forecast residuals shrunk50% | 10,515.14 | 10,100.28 |
| Forecast bias +0.25 residual sigma, fixed symbol signs | 9,523.66 | 9,478.70 |
| Opposite forecast bias | 10,382.06 | 10,972.03 |
| Half inventory | 5,263.95 | 5,401.81 |

The earlier advisory check falls at t86, before the t90 publication, and correctly
receives no official advisory. This is an information-boundary stress, not just
a smooth four-second timing perturbation. Forecast-bias signs are deterministic
and independent of outcomes; the more profitable perturbations were not adopted.
The pronounced depth sensitivity confirms that displayed consensus marks plus
assumed executable volume remain a central limitation.

## Models, causality and execution

- Formation: per-symbol 6/7-feature round-fixed-effect ridge, alpha200, 75%
  conditional residual blend; prior reported damage/loss, prior observed outage,
  fixed HAVEN/REIN layer transforms, and optionally the current quote. Round
  intercepts encode remaining storm count. No current-storm x/y exists in the
  entry feature vector.
- Exit: 19-feature t70 ridge / 30-feature t90 ridge, alpha300. Current/initial
  observations, quote changes, short straight-line wind projection and prior
  state; t90 adds published official outlook/probability/cone information.
- Labels use future exit-window prices only during fitting. Validation price
  paths enter as actual delayed fills and marks, never as order-decision inputs.
- All trades use one key, real rolling60 actions, 2s latency, depth50, 25bps plus
  $0.02 per share per side. Atomic conversions have zero cash and no conversion
  fee; worst-order positive/negative pending quantities reserve every leg.
- Inventory is actually liquidated each round, including charged closing trades.
  No settlement truth array is loaded or needed. Maximum base validation rolling
  actions are 60 for Q100 and 58 for X70advisory; maximum position fraction is 1.
- Eight synthetic tests passed, including exact v3 accounting/action parity,
  zero-cash conversion tests under execution stress, and publication/causality
  checks. `verify_saved.py` also checks frozen hashes, all saved accounting,
  season partitions, zero terminal inventory and rolling counts across rounds.

## Integration recommendation

Treat both frozen policies as research challengers. **Do not replace v3 on the
strength of these standalone numbers.** Q100's ~$24/season matched-time gain is
small enough that shared-account timing can easily erase it. Its latest base
validation flattening is t162 versus t116 for B100, due to disrupted ETF routing.
X70advisory's latest flattening is t148; late-exit stress can reach t184.

The parent's shared-account evaluation must use `action_ticks`, `flat_times` and
the actual route ledger. If retaining the existing conservative v3 integration,
resume other engines only at `ceil((flat_time+60)/10)*10`. Do not add standalone
PnL to overlapping short-horizon exposure or reuse its actions. Q100 can push
that conservative resume time to t230 versus t180 for B100. The lead owns combined
policy/outer auditing; this track used only development seasons 121–600.

For an offline parent integration, prepend this directory to `sys.path`, load
`frozen_models.pkl`, then call `research.run(data, models, selected_config,
audit=True)`. Inputs follow `research.load`'s public-array schema. A live adapter
should compute each round's entry features at the actual entry decision, then
the exit forecasts only when t70/t90 information has arrived. The offline helper
precomputes causal per-round features for replay; it is not an executable broker.

## Artifacts and exact commands

Everything is under:
`/tmp/opencode/ctc-research/project/research_v4/formation`

Key deliverables: `PLAN.md`, readable local source, `candidate_metrics.csv`,
`candidate_tune_seasons.csv`, `frozen_config.json`, `frozen_models.pkl`, portable
`frozen_models.json`, `model_manifest.json`, `validation_seasons.csv` (4,080 rows),
`validation_metrics.csv`, `validation_results.npz`, `validation_paired.csv`,
`exit_alpha_paired.csv`, `goal_diagnostics.csv`, `round_attribution.csv`, and
`exit_decisions.csv`. `validation_complete.json` records all 34 scenarios passing
accounting assertions. `inner_run.log` and `validation_run.log` retain run output.

From this directory:

```bash
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1
export PYTHONDONTWRITEBYTECODE=1
python -m pytest -q test_research.py
python verify_saved.py
python summarize_saved.py
```

The already-completed evaluation sequence was:

```bash
python research.py freeze > inner_run.log 2>&1
python research.py validate > validation_run.log 2>&1
```

`validate` is deliberately single-use, and `freeze` refuses reselection after
validation starts. For independent reproduction, the lead can use a clean local
copy of the source/plan beside the same approved development input and follow
its own evaluation protocol. The saved-validation diagnostics above require no
policy reruns.

Only this assigned directory was written. No parent source, Ramp repository,
branches/commits, external services, trades or child agents were used. One worker
process and BLAS/OMP1 were used for each evaluation.
