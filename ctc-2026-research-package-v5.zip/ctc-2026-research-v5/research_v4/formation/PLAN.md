# Conditional formation inventory and exit — predeclared plan

Declared 2026-10-19 before any inner-tune scores. Only `../development.npz`
supplies outcomes. Fit IDs 361–600; tune 241–360; freeze at most two policies,
refit on 241–600; evaluate 121–240 once. No validation-driven revision. This
dataset has informed earlier research and is not a fresh global holdout.

## Hypotheses and models

1. Prior published damage/outages and insurance attachment/exhaustion condition
   the marginal formation repricing. A heavily exhausted insurer or already
   damaged asset need not have the unconditional round-average drift.
2. Current quotes contain both priced-in damage and deviations from that state.
   A tiny regularized residual forecast can suppress or reverse unprofitable
   formation inventory. All entry features are available at the entry decision;
   there are **no current-storm coordinates before t60**.
3. At t70, the observed storm position/motion and realized repricing can indicate
   whether retaining the existing formation inventory until t120 has positive
   expected incremental dollars. One candidate reassesses at the first official
   advisory t90. These are causal hold/exit decisions, never hindsight exits.

Formation models: separate per-symbol ridge residual forecasts around unpenalized
round intercepts, alpha=200 after within-round standardization; per-symbol public
prior damage, weighted outage, insurance layer used/headroom, own quote optional.
Predict average exit prices at exit+2 through exit+12 minus average early entry
prices at t2 through t12. State/quote forecasts are clipped to training residual
range and blended 75% with the round-average target. Full sizing trades only
positive predicted round-trip net edge, up to existing limits. Soft sizing uses
`clip(net_edge / (0.5*abs(unconditional_delta)+roundtrip_cost), 0, 1)`.
The B comparators exactly retain v3's mean-curve exit-window minus t0 forecast;
the conditional models use the early-arrival-window label stated above.

Exit models: ridge alpha=300, current quote change, initial/current storm
position/motion/radius/intensity, coarse near-site projected exposure, prior
damage/loss and round indicators; t90 additionally uses the published official
advisory, probabilities and cone. Targets are price differences between actual
future exit windows. A portfolio is retained only if its predicted incremental
PnL exceeds the stated dollar hurdle; no new exposure is opened after t60.

## Exactly 12 candidates

| ID | Entry forecast | Sizing | Exit |
|---|---|---|---|
| B70 | unconditional | full | 70 |
| B100 | unconditional | full | 100 |
| B120 | unconditional | full | 120 |
| S70 | state ridge | full | 70 |
| S100 | state ridge | full | 100 |
| Q70 | state+quote ridge | full | 70 |
| Q100 | state+quote ridge | full | 100 |
| Q70soft | state+quote ridge | soft | 70 |
| X70 | state+quote ridge | full | t70 hold to120 if predicted gain >0 |
| X70hurdle | state+quote ridge | full | same, gain >250 USD |
| A70 | unconditional | full | t70 hold to120 if predicted gain >0 |
| X70advisory | state+quote ridge | full | t70 hold; reassess at90; hard exit120 |

All start at t0, all use the unchanged symbol limits, single-key rolling 60-action
budget, 50 shares/symbol/2s, 2s latency, 25bps + $0.02/share/side, zero-cash ETF
conversion, worst-order pending reserves and actual closing trades. Local
simulator adapts read-only `../../etf_route_v3.py` with per-season goals and exits.

## Selection and diagnostics

Rank by arithmetic mean net season PnL only. Freeze the highest-mean entry-only
conditional policy (S/Q family) and highest-mean dynamic-exit policy (X/A family).
Report honestly if either fails to beat the best unconditional comparator. Save
every candidate metric and tune season PnL. Risk statistics are diagnostics only.

Before validation, freeze these sensitivity cases: execution costs 40bps and
50bps; adverse fill 10bps; depth25 and depth10; latency4; entry/exit schedules
delayed4 seconds; exit decision4 seconds earlier; forecast residuals shrunk50%;
forecast perturbation +/-25% of training residual standard deviation (fixed
seed, independent of outcomes); half inventory. All are diagnostic perturbations,
not selection candidates. Compare frozen policies with B70/B100/B120, and with
quantity-matched unconditional directions to distinguish forecast alpha from
inventory/capacity changes. Save season validation CSV, frozen model/config,
execution audits and integration/reproduction instructions in HANDOFF.md.

Single process; OMP/BLAS threads=1. No child agents, external services, parent
changes, raw data or prior outcome files. Finish by 2026-10-19 06:30 UTC.
