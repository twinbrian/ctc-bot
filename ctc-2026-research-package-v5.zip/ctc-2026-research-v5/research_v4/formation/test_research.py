"""Meaningful accounting/parity and information-timing checks, without outcomes."""

import importlib.util
from pathlib import Path
import sys

import numpy as np
import pytest

from contracts import with_etfs
from forecast import formation_features, exit_features
from simulator import simulate


def synthetic():
    rng = np.random.default_rng(16)
    stock = np.full((3, 3, 390, 10), 100.)
    stock += np.arange(390)[None, None, :, None] * .001
    stock[:, :, 32:] += rng.uniform(-8, 8, (3, 3, 1, 10))
    market = with_etfs(stock)
    curve = market.mean(0)
    delta = np.broadcast_to(curve[:, 36:42].mean(1) - curve[:, 0], (3, 3, 12)).copy()
    return market, curve, delta


def test_exact_v3_execution_parity():
    parent = Path(__file__).resolve().parents[2]
    sys.path.insert(0, str(parent))
    spec = importlib.util.spec_from_file_location("parent_routes", parent / "etf_route_v3.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    market, curve, delta = synthetic()
    original = module.simulate_routes(market, None, curve, audit=True)
    local = simulate(market, delta, audit=True)
    for key in original:
        np.testing.assert_allclose(local[key], original[key], atol=1e-8, err_msg=key)


@pytest.mark.parametrize("latency,depth,replenish", [(2, 50, 2), (12, 50, 2), (2, 10, 2), (2, 50, 10)])
def test_no_conversion_cash_and_execution_constraints(latency, depth, replenish):
    market, _, delta = synthetic()
    market[:] = with_etfs(np.full_like(market[..., :10], 100.))
    result = simulate(market, delta, latency=latency, depth=depth, replenish_seconds=replenish, audit=True)
    np.testing.assert_allclose(result["pnl"], -result["cost"], atol=1e-8)
    np.testing.assert_allclose(result["attribution"].sum(1), result["pnl"], atol=1e-8)
    assert np.all(result["positions"] == 0)
    assert result["conversion_actions"].sum() > 0
    assert result["max_rolling_actions"].max() <= 60
    assert result["max_position_fraction"].max() <= 1


def public_data():
    market, _, _ = synthetic()
    n = len(market)
    obs = np.ones((n, 3, 241, 6))
    obs[..., 4] = 10
    return dict(market=market, obs=obs, damage=np.zeros((n, 3, 390, 5)),
                loss=np.zeros((n, 3, 390)), official=np.full((n, 3, 390), -1),
                probability=np.zeros((n, 3, 390, 4)), cone=np.zeros((n, 3, 390, 9)),
                site_xy=np.array([[0, 0], [10, 10], [20, 20], [30, 30], [40, 40]]),
                site_company=np.arange(5), site_weight=np.ones(5))


def test_formation_has_no_current_storm_or_future_quote_input():
    a = public_data()
    b = {k: v.copy() for k, v in a.items()}
    b["obs"][:, 0] *= 5
    b["market"][:, 0, 1:] *= 2
    b["damage"][:, 0] += 1
    b["loss"][:, 0] += 2000
    b["official"][:, 0] = 3
    np.testing.assert_array_equal(formation_features(a)[:, 0], formation_features(b)[:, 0])


def test_exit_t70_cannot_see_future_motion_or_advisory():
    a = public_data()
    b = {k: v.copy() for k, v in a.items()}
    b["obs"][:, 0, 6:] *= 5
    b["market"][:, 0, 36:] *= 2
    b["official"][:, 0, 36:] = 3
    b["probability"][:, 0, 36:] = .9
    b["cone"][:, 0, 36:] = 100
    np.testing.assert_array_equal(exit_features(a, 70)[:, 0], exit_features(b, 70)[:, 0])


def test_exit_prediction_does_not_change_earlier_orders():
    market, _, delta = synthetic()
    ones = np.ones_like(delta)
    a = simulate(market, delta, exit_predictions={70: ones}, audit=True)
    b = simulate(market, delta, exit_predictions={70: -ones}, audit=True)
    np.testing.assert_array_equal(a["action_ticks"][:, :, :35], b["action_ticks"][:, :, :35])
    np.testing.assert_array_equal(a["inventory60"], b["inventory60"])
