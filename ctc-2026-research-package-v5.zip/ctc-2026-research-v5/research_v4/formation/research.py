"""Reproduce declaration -> inner selection/freeze -> one validation evaluation.

Run from this directory with BLAS/OMP threads=1 and PYTHONDONTWRITEBYTECODE=1.
No data file other than ../development.npz is ever opened for outcomes.
"""

import argparse
import csv
import hashlib
import json
import os
import pickle
from pathlib import Path

for _name in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ[_name] = "1"

import numpy as np

from forecast import fit_models, formation_features, exit_features
from simulator import simulate

HERE = Path(__file__).resolve().parent
DATA = HERE.parent / "development.npz"
CANDIDATES = [
    dict(id="B70", kind="unconditional", exit=70),
    dict(id="B100", kind="unconditional", exit=100),
    dict(id="B120", kind="unconditional", exit=120),
    dict(id="S70", kind="state", exit=70),
    dict(id="S100", kind="state", exit=100),
    dict(id="Q70", kind="quote", exit=70),
    dict(id="Q100", kind="quote", exit=100),
    dict(id="Q70soft", kind="quote", exit=70, soft=True),
    dict(id="X70", kind="quote", exit=70, dynamic=True),
    dict(id="X70hurdle", kind="quote", exit=70, dynamic=True, hurdle=250),
    dict(id="A70", kind="unconditional", exit=70, dynamic=True),
    dict(id="X70advisory", kind="quote", exit=70, dynamic=True, advisory=True),
]
SCENARIOS = {
    "base": {},
    "cost40": {"cost_bps": 40},
    "cost50": {"cost_bps": 50},
    "adverse10": {"adverse_bps": 10},
    "depth25": {"depth": 25},
    "depth10": {"depth": 10},
    "latency4": {"latency": 4},
    "schedule_late4": {"start": 4, "exit_shift": 4},
    "exit_early4": {"exit_shift": -4},
    "forecast_residual50": {"residual_scale": .5},
    "forecast_plus25sigma": {"perturb": .25},
    "forecast_minus25sigma": {"perturb": -.25},
    "inventory50": {"fraction": .5},
}


def load(lo, hi):
    with np.load(DATA, allow_pickle=False) as z:
        ids = z["season_ids"]
        mask = (ids >= lo) & (ids <= hi)
        d = {"season_ids": ids[mask]}
        for k in ("market", "obs", "damage", "loss", "official", "probability", "cone"):
            d[k] = z[k][mask]
        for k in ("site_xy", "site_company", "site_weight"):
            d[k] = z[k]
    assert np.all((d["season_ids"] >= lo) & (d["season_ids"] <= hi))
    return d


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")


def write_csv(path, records):
    keys = list(dict.fromkeys(k for row in records for k in row))
    with path.open("w") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        w.writerows(records)


def metrics(result):
    p = result["pnl"]
    rng = np.random.default_rng(2026)
    means = p[rng.integers(0, len(p), (5000, len(p)))].mean(1)
    return dict(n=len(p), mean_usd=float(p.mean()), median_usd=float(np.median(p)),
                minimum_usd=float(p.min()), p05_usd=float(np.quantile(p, .05)),
                std_usd=float(p.std(ddof=1)), win_rate=float((p > 0).mean()),
                mean_ci_low=float(np.quantile(means, .025)), mean_ci_high=float(np.quantile(means, .975)),
                mean_cost=float(result["cost"].mean()), mean_actions=float(result["actions"].mean()),
                mean_turnover=float(result["turnover_shares"].mean()),
                mean_conversions=float(result["conversion_actions"].mean()),
                mean_drawdown=float(result["drawdown"].mean()),
                max_rolling_actions=int(result["max_rolling_actions"].max()),
                max_position_fraction=float(result["max_position_fraction"].max()),
                latest_flat_time=int(result["flat_times"].max()),
                mean_exit_decision=float(result["exit_decisions"].mean()),
                mean_abs_goal=float(np.abs(result["goals"]).sum(2).mean()))


def unconditional(models, n, at, start=0):
    curve = models["curve"]
    delta = curve[:, (at + 2) // 2:(at + 14) // 2].mean(1) - curve[:, start // 2]
    return np.broadcast_to(delta, (n, 3, 12)).copy()


def run(d, models, config, *, audit=False, goal_override=None, **stress):
    stress = stress.copy()
    start = stress.pop("start", 0)
    shift = stress.pop("exit_shift", 0)
    residual_scale = stress.pop("residual_scale", 1.)
    perturb = stress.pop("perturb", 0.)
    at = config["exit"]
    base = unconditional(models, len(d["market"]), at + shift, start)
    if config["kind"] == "unconditional":
        delta = base
    else:
        model = models[f"{config['kind']}{at}"]
        delta = model.predict(formation_features(d, config["kind"] == "quote", start), residual_scale, perturb)
    checks = (70, 90) if config.get("advisory") else (70,)
    predictions = None
    if config.get("dynamic"):
        predictions = {t + shift: models[f"exit{t}"].predict(
            exit_features(d, t + shift, t == 90), residual_scale, perturb) for t in checks}
    return simulate(d["market"], delta, start=start, exit_at=at + shift,
                    soft=config.get("soft", False), unconditional=base,
                    goal_override=goal_override, exit_predictions=predictions,
                    exit_checks=tuple(t + shift for t in checks), hard_exit=120 + shift,
                    hold_hurdle=config.get("hurdle", 0), audit=audit, **stress)


def freeze():
    assert (HERE / "PLAN.md").exists()
    if (HERE / "validation_started.json").exists():
        raise RuntimeError("Validation already opened; refitting/reselection is prohibited")
    fit, tune = load(361, 600), load(241, 360)
    models = fit_models(fit)
    with (HERE / "inner_models.pkl").open("wb") as f:
        pickle.dump(models, f)
    records, season_records, results = [], [], {}
    for config in CANDIDATES:
        result = run(tune, models, config, audit=True)
        results[config["id"]] = result
        row = {"id": config["id"], "config": json.dumps(config, sort_keys=True), **metrics(result)}
        records.append(row)
        for i, season_id in enumerate(tune["season_ids"]):
            season_records.append(dict(id=config["id"], season_id=int(season_id), pnl=float(result["pnl"][i])))
        print("INNER", config["id"], round(row["mean_usd"], 2), "p05", round(row["p05_usd"], 2), flush=True)
    write_csv(HERE / "candidate_metrics.csv", records)
    write_csv(HERE / "candidate_tune_seasons.csv", season_records)
    np.savez_compressed(HERE / "inner_results.npz", season_ids=tune["season_ids"],
                        **{f"{name}__{k}": v for name, result in results.items() for k, v in result.items()})
    mean = {x["id"]: x["mean_usd"] for x in records}
    entry = max((c for c in CANDIDATES if c["kind"] != "unconditional" and not c.get("dynamic")), key=lambda c: mean[c["id"]])
    dynamic = max((c for c in CANDIDATES if c.get("dynamic")), key=lambda c: mean[c["id"]])
    baseline = max((c for c in CANDIDATES if c["id"].startswith("B")), key=lambda c: mean[c["id"]])
    frozen = dict(objective="arithmetic mean realized net season PnL", fit_ids=[361, 600],
                  tune_ids=[241, 360], refit_ids=[241, 600], validation_ids=[121, 240],
                  selected=[entry, dynamic], best_unconditional=baseline,
                  inner_means=mean, scenarios=SCENARIOS, candidate_count=len(CANDIDATES),
                  plan_sha256=hashlib.sha256((HERE / "PLAN.md").read_bytes()).hexdigest(),
                  evidence_status="post-selection development validation; not a fresh global holdout",
                  execution=dict(cost_bps=25, fixed_cost=.02, latency=2, depth=50,
                                 rolling_actions_per_real60s=60, keys=1, conversion_cash=0))
    # Save frozen policy before refitting and before any validation outcome load.
    write_json(HERE / "frozen_config.json", frozen)
    refit = fit_models(load(241, 600))
    with (HERE / "frozen_models.pkl").open("wb") as f:
        pickle.dump(refit, f)
    write_json(HERE / "model_manifest.json", {
        "model_sha256": hashlib.sha256((HERE / "frozen_models.pkl").read_bytes()).hexdigest(),
        "config_sha256": hashlib.sha256((HERE / "frozen_config.json").read_bytes()).hexdigest(),
        "formation": "per-symbol 6 or7-feature round-fixed-effect ridge alpha200 blend.75",
        "exit": "per-symbol 19-feature t70 /30-feature t90 ridge alpha300 blend.75",
        "fit_season_ids": [241, 600]})
    print("FROZEN", entry["id"], dynamic["id"], "baseline", baseline["id"], flush=True)


def validate():
    marker = HERE / "validation_started.json"
    if marker.exists():
        raise RuntimeError("Validation is single-use; inspect saved artifacts, do not rerun")
    frozen = json.loads((HERE / "frozen_config.json").read_text())
    manifest = json.loads((HERE / "model_manifest.json").read_text())
    assert manifest["config_sha256"] == hashlib.sha256((HERE / "frozen_config.json").read_bytes()).hexdigest()
    assert manifest["model_sha256"] == hashlib.sha256((HERE / "frozen_models.pkl").read_bytes()).hexdigest()
    with (HERE / "frozen_models.pkl").open("rb") as f:
        models = pickle.load(f)
    write_json(marker, {"config_sha256": manifest["config_sha256"], "opened_validation_once": True})
    d = load(121, 240)
    records, seasons, results = [], [], {}

    def record(name, result):
        results[name] = result
        row = {"name": name, **metrics(result)}
        records.append(row)
        for i, season_id in enumerate(d["season_ids"]):
            seasons.append(dict(name=name, season_id=int(season_id), pnl=float(result["pnl"][i]),
                                cost=float(result["cost"][i]), actions=int(result["actions"][i]),
                                drawdown=float(result["drawdown"][i]),
                                round1_pnl=float(result["round_pnl"][i, 0]),
                                round2_pnl=float(result["round_pnl"][i, 1]),
                                round3_pnl=float(result["round_pnl"][i, 2])))
        # Persist each completed scenario for an auditable single evaluation pass.
        write_csv(HERE / "validation_metrics.csv", records)
        write_csv(HERE / "validation_seasons.csv", seasons)
        print("VALIDATION", name, round(row["mean_usd"], 2), "p05", round(row["p05_usd"], 2), flush=True)

    for baseline in CANDIDATES[:3]:
        record(baseline["id"], run(d, models, baseline, audit=True))
    for config in frozen["selected"]:
        name = config["id"]
        for scenario, stress in frozen["scenarios"].items():
            record(f"{name}__{scenario}", run(d, models, config, audit=scenario == "base", **stress))
        base_result = results[f"{name}__base"]
        base_sign = np.sign(unconditional(models, len(d["market"]), config["exit"])).astype(int)
        matched_goal = np.abs(base_result["goals"]) * base_sign
        record(f"{name}__matched_unconditional_direction", run(d, models, config, goal_override=matched_goal))
        if config.get("dynamic"):
            for at in (70, 100, 120):
                # Same initial conditional inventory, ranking, costs and fills;
                # vary only the scheduled exit, by invoking simulator directly.
                delta = (unconditional(models, len(d["market"]), config["exit"]) if config["kind"] == "unconditional"
                         else models[f"{config['kind']}{config['exit']}"].predict(formation_features(d, True)))
                record(f"{name}__fixed{at}_same_goal", simulate(d["market"], delta, exit_at=at, goal_override=base_result["goals"]))
    np.savez_compressed(HERE / "validation_results.npz", season_ids=d["season_ids"],
                        **{f"{name}__{k}": v for name, result in results.items() for k, v in result.items()})
    paired = []
    comparator_names = ["B70", "B100", "B120"]
    for config in frozen["selected"]:
        name = config["id"]
        for comparator in comparator_names + [f"{name}__matched_unconditional_direction"]:
            diff = results[f"{name}__base"]["pnl"] - results[comparator]["pnl"]
            rng = np.random.default_rng(2026)
            means = diff[rng.integers(0, len(diff), (10000, len(diff)))].mean(1)
            paired.append(dict(candidate=name, comparator=comparator, mean_increment=float(diff.mean()),
                               paired_ci_low=float(np.quantile(means, .025)), paired_ci_high=float(np.quantile(means, .975))))
    write_csv(HERE / "validation_paired.csv", paired)
    write_json(HERE / "validation_complete.json", {"scenarios": len(results), "seasons": len(d["season_ids"]),
               "frozen_config_sha256": manifest["config_sha256"], "all_accounting_assertions_passed": True})


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("stage", choices=["freeze", "validate"])
    args = p.parse_args()
    {"freeze": freeze, "validate": validate}[args.stage]()
