"""Local adaptation of ../../etf_route_v3.py with conditional goals/causal exits.

Execution accounting is retained: zero-cash atomic conversions, worst-order
pending reserves, actual rolling 60 actions, latency, depth, and closing fills.
"""

import numpy as np

from contracts import BASKETS, LIMITS


def simulate(market, delta, *, start=0, exit_at=70, fraction=1., soft=False,
             unconditional=None, goal_override=None, exit_predictions=None,
             exit_checks=(70,), hard_exit=120, hold_hurdle=0., cost_bps=25,
             fixed_cost=.02, latency=2, depth=50, adverse_bps=0.,
             replenish_seconds=2, audit=False):
    n = len(market)
    row = np.arange(n)
    limits = LIMITS.copy()
    q = np.zeros((n, 12), dtype=int)
    pp, pn = np.zeros_like(q), np.zeros_like(q)
    cash, costs, turnover = np.zeros(n), np.zeros(n), np.zeros(n)
    actions, conversions, max_window = (np.zeros(n, dtype=int) for _ in range(3))
    max_pos, peak, dd = np.zeros(n), np.zeros(n), np.zeros(n)
    flat_times = np.full((n, 3), -1, dtype=int)
    counts = np.zeros((n, 3, 390), dtype=np.int8)
    attribution = np.zeros((n, 12))
    goals = np.zeros((n, 3, 12), dtype=int)
    round_pnl = np.zeros((n, 3))
    exit_decisions = np.full((n, 3), exit_at, dtype=int)
    inventory60 = np.zeros((n, 3, 12), dtype=int)
    delay = max(1, int(np.ceil(latency / 2)))
    cooldown = max(1, int(np.ceil(replenish_seconds / 2)))
    vectors = np.zeros((2, 12), dtype=int)
    vectors[:, :10] = BASKETS
    vectors[0, 10], vectors[1, 11] = -1, -1
    for r in range(3):
        opening_cash = cash.copy()
        queue = [[] for _ in range(390 + delay)]
        used = np.zeros(n, dtype=int)
        history = np.zeros((n, 30), dtype=int)
        last_depth = np.full((n, 12), -1000, dtype=int)
        closing, done = np.zeros(n, bool), np.zeros(n, bool)
        expected_jump = delta[:, r]
        anchor = market[:, r, start // 2]
        fees = (anchor + np.maximum(anchor + expected_jump, 0)) * cost_bps / 10000 + 2 * fixed_cost
        signal = np.abs(expected_jump) - fees
        size = np.full_like(signal, fraction)
        if soft:
            assert unconditional is not None
            size *= np.clip(signal / (.5 * np.abs(unconditional[:, r]) + fees), 0, 1)
        goal = np.sign(expected_jump).astype(int) * np.floor(limits * size).astype(int) * (signal > 0)
        if goal_override is not None:
            goal = goal_override[:, r].copy()
        assert np.all(np.abs(goal) <= limits)
        goals[:, r] = goal
        scheduled_exit = np.full(n, hard_exit if exit_predictions is not None else exit_at)
        remaining, direction = np.zeros((n, 2), int), np.zeros((n, 2), int)

        def plan_routes(i):
            exposure = q + pp - pn
            for b in range(2):
                sites = np.where(vectors[b, :10] > 0)[0]
                diff = goal[i][:, sites] - exposure[i][:, sites]
                unit = vectors[b, sites]
                buy = np.min(np.maximum(diff, 0) // unit, axis=1)
                sell = np.min(np.maximum(-diff, 0) // unit, axis=1)
                direction[i, b] = np.where(buy > 0, 1, np.where(sell > 0, -1, 0))
                remaining[i, b] = np.maximum(buy, sell)

        plan_routes(row)
        for ti in range(390):
            t = 2 * ti
            slot = ti % 30
            used -= history[:, slot]
            history[:, slot] = 0
            price = market[:, r, ti]
            for i, change, kind in queue[ti]:
                pp[i] -= np.maximum(change, 0)
                pn[i] -= np.maximum(-change, 0)
                if kind == "market":
                    unit_cost = price[i] * (cost_bps + adverse_bps) / 10000 + fixed_cost
                    payment = change * price[i] + np.abs(change) * unit_cost
                    cash[i] -= payment.sum(1)
                    attribution[i] -= payment
                    costs[i] += (np.abs(change) * unit_cost).sum(1)
                    turnover[i] += np.abs(change).sum(1)
                else:
                    marks = price[i].copy()
                    marks[:, 10:] = price[i, :10] @ BASKETS.T
                    booking = change * marks
                    assert np.allclose(booking.sum(1), 0, atol=1e-8)
                    attribution[i] -= booking
                q[i] += change
                assert np.all(np.abs(q[i]) <= limits)
            assert np.all(q + pp <= limits) and np.all(q - pn >= -limits)
            wealth = cash + (q * price).sum(1)
            peak = np.maximum(peak, wealth)
            dd = np.maximum(dd, peak - wealth)
            max_pos = np.maximum(max_pos, np.max(np.abs(q) / limits, axis=1))
            if t == 60:
                inventory60[:, r] = q

            def submit(i, change, kind):
                if not len(i):
                    return
                assert np.all(used[i] < 60)
                assert np.all(q[i] + pp[i] + np.maximum(change, 0) <= limits)
                assert np.all(q[i] - pn[i] - np.maximum(-change, 0) >= -limits)
                pp[i] += np.maximum(change, 0)
                pn[i] += np.maximum(-change, 0)
                queue[ti + delay].append((i.copy(), change.copy(), kind))
                used[i] += 1
                history[i, slot] += 1
                actions[i] += 1
                counts[i, r, ti] += 1
                if kind != "market":
                    conversions[i] += 1

            if exit_predictions is not None and t in exit_checks:
                prediction = exit_predictions[t][:, r]
                gain = ((q + pp - pn) * prediction).sum(1)
                leave = (gain <= hold_hurdle) & ~closing
                scheduled_exit[leave] = t
            ready = (t >= scheduled_exit) & ~closing & np.all(pp + pn == 0, axis=1)
            i = np.where(ready)[0]
            if len(i):
                goal[i] = 0
                plan_routes(i)
                closing[i] = True
                exit_decisions[i, r] = t
            flat = closing & np.all(q == 0, axis=1) & np.all(pp + pn == 0, axis=1)
            fresh = flat & ~done
            flat_times[fresh, r] = t
            done |= flat
            if ti + delay >= 390:
                continue
            active = ((start <= t) & (t <= 60) & ~closing) | (closing & ~done)
            for b in range(2):
                change_unit = direction[:, b, None] * vectors[b]
                positive = np.where(change_unit > 0, (limits - q - pp) // np.maximum(change_unit, 1), 10**9)
                negative = np.where(change_unit < 0, (limits + q - pn) // np.maximum(-change_unit, 1), 10**9)
                cap = np.minimum(positive.min(1), negative.min(1))
                quantity = np.minimum(remaining[:, b], np.maximum(cap, 0))
                valid = active & (used < 60) & (quantity > 0)
                i = np.where(valid)[0]
                submit(i, change_unit[i] * quantity[i, None], "convert")
                remaining[i, b] -= quantity[i]
            reserved_route = np.zeros_like(goal)
            for b in range(2):
                reserved_route[:, :10] += remaining[:, b, None] * direction[:, b, None] * vectors[b, :10]
            direct_goal = goal - reserved_route
            exposure = q + pp - pn
            diff = direct_goal - exposure
            ready_depth = ti - last_depth >= cooldown
            side = np.sign(diff).astype(int)
            capacity = np.where(side > 0, limits - q - pp, limits + q - pn)
            qty = np.minimum(np.minimum(depth, np.abs(diff)), np.maximum(capacity, 0))
            rank = np.argsort(-qty * (np.abs(expected_jump) + .01), axis=1)
            for k in range(12):
                j = rank[:, k]
                valid = active & (used < 60) & ready_depth[row, j] & (qty[row, j] > 0)
                i = np.where(valid)[0]
                change = np.zeros((len(i), 12), dtype=int)
                change[np.arange(len(i)), j[i]] = qty[i, j[i]] * side[i, j[i]]
                submit(i, change, "market")
                last_depth[i, j[i]] = ti
            max_window = np.maximum(max_window, used)
            if done.all():
                break
        assert np.all(q == 0) and np.all(pp + pn == 0), "Must actually flatten every round"
        assert np.all(counts[:, r, -30:] == 0), "Round boundary reset requires a 60s idle gap"
        round_pnl[:, r] = cash - opening_cash
    assert np.allclose(attribution.sum(1), cash, atol=1e-8)
    cumulative = counts.cumsum(2)
    lag = np.concatenate([np.zeros_like(cumulative[:, :, :30]), cumulative[:, :, :-30]], axis=2)
    assert (cumulative - lag).max() <= 60
    result = dict(pnl=cash, actions=actions, cost=costs, turnover_shares=turnover,
                  positions=q, attribution=attribution, drawdown=dd,
                  max_rolling_actions=max_window, max_position_fraction=max_pos,
                  conversion_actions=conversions, flat_times=flat_times,
                  goals=goals, inventory60=inventory60, round_pnl=round_pnl,
                  exit_decisions=exit_decisions)
    if audit:
        result["action_ticks"] = counts
    return result
