"""Verify frozen hashes and saved accounting; does not fit or evaluate policies."""

import csv
import hashlib
import json

import numpy as np

from research import HERE


def main():
    config = json.loads((HERE / "frozen_config.json").read_text())
    manifest = json.loads((HERE / "model_manifest.json").read_text())
    complete = json.loads((HERE / "validation_complete.json").read_text())
    for filename, expected in [
        ("PLAN.md", config["plan_sha256"]),
        ("frozen_config.json", manifest["config_sha256"]),
        ("frozen_models.pkl", manifest["model_sha256"]),
    ]:
        assert hashlib.sha256((HERE / filename).read_bytes()).hexdigest() == expected
    assert complete["frozen_config_sha256"] == manifest["config_sha256"]
    with (HERE / "candidate_metrics.csv").open() as f:
        assert len(list(csv.DictReader(f))) == 12
    with (HERE / "validation_seasons.csv").open() as f:
        assert len(list(csv.DictReader(f))) == complete["scenarios"] * 120
    for filename, bounds in [("inner_results.npz", (241, 360)), ("validation_results.npz", (121, 240))]:
        with np.load(HERE / filename, allow_pickle=False) as z:
            np.testing.assert_array_equal(z["season_ids"], np.arange(bounds[0], bounds[1] + 1))
            for key in z.files:
                if not key.endswith("__pnl"):
                    continue
                prefix = key[:-5]
                pnl = z[key]
                np.testing.assert_allclose(z[prefix + "__round_pnl"].sum(1), pnl, atol=1e-8)
                np.testing.assert_allclose(z[prefix + "__attribution"].sum(1), pnl, atol=1e-8)
                assert not z[prefix + "__positions"].any()
                assert z[prefix + "__max_rolling_actions"].max() <= 60
                assert z[prefix + "__max_position_fraction"].max() <= 1
                assert z[prefix + "__flat_times"].min() >= 0
                action_key = prefix + "__action_ticks"
                if action_key in z.files:
                    counts = z[action_key].reshape(len(pnl), -1)
                    cumulative = counts.cumsum(1)
                    lag = np.pad(cumulative[:, :-30], ((0, 0), (30, 0)))
                    assert (cumulative - lag).max() <= 60
                    np.testing.assert_array_equal(counts.sum(1), z[prefix + "__actions"])
    print("Frozen hashes, 12 candidates, 34 validation scenarios, season IDs, flatness, accounting and rolling-action audits passed.")


if __name__ == "__main__":
    main()
