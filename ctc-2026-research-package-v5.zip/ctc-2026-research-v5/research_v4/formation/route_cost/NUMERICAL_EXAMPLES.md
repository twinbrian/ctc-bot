# Numerical examples, completed before historical scoring

`python -m pytest -q test_route_cost.py`: **12 passed**.

ARCH basket units are PORT1 + ISLE1 + AQUA2 + GRID1 + FERRY2 + HAVEN1.
In these examples every stock is $100, so the basket is $800. The target is
ten basket units of stocks, with no change in outright ETF inventory.
Fees are 25bps plus $0.02/share/side; conversions have zero cash and fee.

| Observable condition | Chosen conversion | Explanation |
|---|---:|---|
| ARCH=$810, depth50, ample actions | 0 of 10 | Direct cash cost $8,021.60 versus $8,120.45 via ETF: **$98.85 saved**. Both finish in2s. |
| ARCH=$800, depth50 | 10 of 10 | ETF conversion saves the fixed per-share fees at basket parity. |
| ARCH=$790, depth50 | 10 of 10 | Discount and fixed-fee saving favor conversion. |
| ARCH=$810, only2 rolling-minute actions remain | 10 of 10 | Conversion+ETF purchase needs2 actions; direct stocks need6. |
| ARCH=$810, depth10 | 5 of 10 | Reduces two-share basket legs' direct residual to10 shares, preserving the2s reference completion. **$49.425 saved**. |
| ARCH=$810, initial/final ETF inventory at +50 limit | 0 of 10 | Direct execution finishes in2s; conversion then replenishing ETF inventory needs4s under worst-order pending reserves. |

Additional tests establish:

- Exact original-v3 parity for control PnL, fees, positions, attribution, actions,
  action ticks, conversions, drawdown and flattening under base, latency4,
  depth25 and depth10.
- A constant basket-parity market yields PnL exactly equal to negative charged
  market fees: no conversion cash creation.
- Target and t60 inventory remain identical between route arms.
- Changing all later quotes does not change entry route choices or earlier orders.
- The joint two-basket choice's predicted actions/completion match an exact
  throttled dry run, including position and gross pending-order capacity limits.

The dry-run scheduler receives positions, goals, history, depth and latency;
it has no market-price path input. The cost selector receives only one current
quote vector. Later historical prices are used solely for actual delayed fills.
