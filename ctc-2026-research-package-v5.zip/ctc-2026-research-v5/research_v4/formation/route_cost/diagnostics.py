"""Summarize saved route decisions; no policy fitting or historical replay."""

import csv
from collections import defaultdict

from run import HERE, csv_out


def main():
    groups = defaultdict(list)
    for split in ("fit", "inner", "validation_diagnostic"):
        with (HERE / f"{split}_routes.csv").open() as f:
            for row in csv.DictReader(f):
                groups[(split, row["scenario"], row["phase"])].append(row)
    output = []
    for (split, scenario, phase), rows in groups.items():
        n = len(rows)
        changed = [r for r in rows if r["changed"] == "True"]
        output.append(dict(split=split, scenario=scenario, phase=phase, decisions=n,
            changed_decisions=len(changed), changed_fraction=len(changed) / n,
            mean_quoted_saving_usd=sum(float(r["quoted_savings"]) for r in rows) / n,
            total_quoted_saving_usd=sum(float(r["quoted_savings"]) for r in rows),
            mean_arch_units_removed=sum(abs(int(r["original_z0"])) - abs(int(r["selected_z0"])) for r in rows) / n,
            mean_rebld_units_removed=sum(abs(int(r["original_z1"])) - abs(int(r["selected_z1"])) for r in rows) / n,
            mean_incremental_predicted_phase_actions=sum(int(r["selected_actions"]) - int(r["reference_actions"]) for r in rows) / n,
            baseline_phase_incomplete=sum(r["reference_complete"] == "False" for r in rows)))
    csv_out("phase_diagnostics.csv", output)
    print("Saved phase diagnostics from existing route records; no policies rerun.")


if __name__ == "__main__":
    main()
