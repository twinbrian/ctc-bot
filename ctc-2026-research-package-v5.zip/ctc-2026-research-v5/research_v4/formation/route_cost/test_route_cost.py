"""Numerical accounting/known-basis examples developed before historical scoring."""

import importlib.util
from pathlib import Path
import sys

import numpy as np
import pytest

from exchange import BASKETS, LIMITS, VECTORS, maximum_routes
from planner import CostPlanner, cash_cost, dry_run
from simulator import simulate


def marks(stocks):
    return np.concatenate([stocks, stocks @ BASKETS.T], axis=-1)


def example(basis=10., depth=50, history=None, q=None):
    q = np.zeros(12, int) if q is None else q
    goal = q.copy()
    goal[:10] += 10 * VECTORS[0, :10]
    price = marks(np.full(10, 100.))
    price[10] += basis
    history = np.zeros(30, int) if history is None else history
    planner = CostPlanner(depth=depth)
    choice, diagnostic = planner.choose(q, goal, price, history,
        np.full(12, -1000, int), np.ones(12), 35, False)
    return choice, diagnostic, q, goal, price


def test_known_expensive_etf_uses_direct_and_exact_cash_saving():
    choice, record, q, goal, price = example()
    np.testing.assert_array_equal(choice, [0, 0])
    assert record["quoted_savings"] == pytest.approx(98.85)
    assert cash_cost(q, goal, choice, price) == pytest.approx(8021.60)


def test_parity_or_discount_etf_keeps_fee_saving_conversion():
    for basis in (0., -10.):
        choice, record, *_ = example(basis=basis)
        np.testing.assert_array_equal(choice, [10, 0])
        assert record["quoted_savings"] == 0


def test_current_rolling_actions_can_force_more_expensive_conversion():
    history = np.zeros(30, int)
    history[10:15] = [12, 12, 12, 12, 10]
    choice, record, *_ = example(history=history)
    np.testing.assert_array_equal(choice, [10, 0])
    assert record["available_actions"] == 2


def test_depth_and_reference_deadline_require_partial_conversion():
    choice, record, *_ = example(depth=10)
    np.testing.assert_array_equal(choice, [5, 0])
    assert record["selected_seconds"] == record["reference_seconds"] == 2
    assert record["quoted_savings"] == pytest.approx(49.425)


def test_etf_inventory_and_worst_order_pending_capacity_enter_schedule():
    q = np.zeros(12, int)
    q[10] = LIMITS[10]
    choice, record, *_ = example(q=q)
    np.testing.assert_array_equal(choice, [0, 0])
    assert record["reference_seconds"] == 4
    assert record["selected_seconds"] == 2


def synthetic():
    rng = np.random.default_rng(47)
    stocks = np.full((2, 3, 390, 10), 100.)
    stocks[:, :, 32:] += rng.uniform(-8, 8, (2, 3, 1, 10))
    market = marks(stocks)
    curve = market.mean(0)
    return market, curve


@pytest.mark.parametrize("latency,depth", [(2, 50), (4, 50), (2, 25), (2, 10)])
def test_exact_v3_control_parity(latency, depth):
    parent = Path(__file__).resolve().parents[3]
    sys.path.insert(0, str(parent))
    spec = importlib.util.spec_from_file_location("parent_routes", parent / "etf_route_v3.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    market, curve = synthetic()
    original = module.simulate_routes(market, None, curve, latency=latency, depth=depth, audit=True)
    local, _ = simulate(market, curve, latency=latency, depth=depth)
    for key in original:
        np.testing.assert_allclose(local[key], original[key], atol=1e-8, err_msg=key)


def test_flat_parity_only_loses_market_fees_and_keeps_target_inventory():
    market, curve = synthetic()
    market[:] = marks(np.full_like(market[..., :10], 100.))
    a, _ = simulate(market, curve)
    b, records = simulate(market, curve, optimized=True)
    np.testing.assert_allclose(b["pnl"], -b["cost"], atol=1e-8)
    np.testing.assert_array_equal(a["goals"], b["goals"])
    np.testing.assert_array_equal(a["inventory60"], b["inventory60"])
    assert np.all(b["positions"] == 0)
    assert b["max_rolling_actions"].max() <= 60
    assert all(r["quoted_savings"] >= -1e-7 for r in records)


def test_future_quotes_cannot_change_entry_route():
    market, curve = synthetic()
    altered = market.copy()
    altered[:, :, 1:] *= 1.2
    a, ar = simulate(market, curve, optimized=True)
    b, br = simulate(altered, curve, optimized=True)
    assert [r for r in ar if r["phase"] == "entry"] == [r for r in br if r["phase"] == "entry"]
    np.testing.assert_array_equal(a["action_ticks"][:, :, :35], b["action_ticks"][:, :, :35])


def test_joint_feasibility_matches_exact_throttled_schedule():
    q = np.zeros(12, int)
    goal = LIMITS.copy()
    goal[9] = 0
    price = marks(np.full(10, 100.))
    price[10:] += 3
    planner = CostPlanner()
    choice, record = planner.choose(q, goal, price, np.zeros(30, int),
        np.full(12, -1000, int), np.ones(12), 0, True)
    run = dry_run(q[None], goal[None], choice[None], entry=True)
    assert run["completed"][0]
    assert run["actions"][0] <= 60
    assert run["duration_ticks"][0] * 2 == record["selected_seconds"]
    assert run["actions"][0] == record["selected_actions"]
    np.testing.assert_array_equal(run["inventory"][0], goal)
