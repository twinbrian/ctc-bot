"""Execution-only fit/inner comparison, source freeze, retrospective validation."""

import argparse
import csv
import hashlib
import json
import os
from pathlib import Path

for key in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ[key] = "1"

import numpy as np

from simulator import simulate

HERE = Path(__file__).resolve().parent
DATA = HERE.parents[1] / "development.npz"
SCENARIOS = {"base": {}, "latency4": {"latency": 4}, "depth25": {"depth": 25},
             "depth10": {"depth": 10}, "latency4_depth25": {"latency": 4, "depth": 25}}
SOURCE = ["PLAN.md", "exchange.py", "planner.py", "simulator.py", "run.py", "test_route_cost.py"]


def digest(name):
    return hashlib.sha256((HERE / name).read_bytes()).hexdigest()


def load(lo, hi):
    with np.load(DATA, allow_pickle=False) as z:
        ids = z["season_ids"]
        selected = (ids >= lo) & (ids <= hi)
        return ids[selected], z["market"][selected]


def json_out(name, value):
    (HERE / name).write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")


def csv_out(name, records):
    with (HERE / name).open("w") as f:
        writer = csv.DictWriter(f, fieldnames=list(dict.fromkeys(k for row in records for k in row)))
        writer.writeheader()
        writer.writerows(records)


def evaluate(ids, market, curve, split):
    summaries, seasons, routes, saved = [], [], [], {}
    for scenario, stress in SCENARIOS.items():
        control, _ = simulate(market, curve, **stress)
        aware, trace = simulate(market, curve, optimized=True, **stress)
        np.testing.assert_array_equal(control["goals"], aware["goals"])
        np.testing.assert_array_equal(control["inventory60"], aware["inventory60"])
        for record in trace:
            i, r = record["row"], record["round"] - 1
            if record["phase"] == "entry":
                actual_actions = aware["action_ticks"][i, r, :35].sum()
            else:
                actual_actions = aware["action_ticks"][i, r, record["time"] // 2:].sum()
                assert aware["flat_times"][i, r] == record["time"] + record["selected_seconds"]
            assert actual_actions == record["selected_actions"]
            routes.append(dict(split=split, scenario=scenario, season_id=int(ids[i]), **record))
        difference = aware["pnl"] - control["pnl"]
        rng = np.random.default_rng(20261019)
        bootstrap = difference[rng.integers(0, len(ids), (5000, len(ids)))].mean(1)
        row = dict(split=split, scenario=scenario, seasons=len(ids),
            control_mean_pnl=float(control["pnl"].mean()), aware_mean_pnl=float(aware["pnl"].mean()),
            incremental_mean_pnl=float(difference.mean()), incremental_median=float(np.median(difference)),
            incremental_p05=float(np.quantile(difference, .05)), incremental_min=float(difference.min()),
            conditional_increment_ci_low=float(np.quantile(bootstrap, .025)),
            conditional_increment_ci_high=float(np.quantile(bootstrap, .975)),
            incremental_total_cash_spent=float(-difference.mean()),
            incremental_gross_market_cash_spent=float((aware["gross_market_cash_spent"] - control["gross_market_cash_spent"]).mean()),
            incremental_fees=float((aware["cost"] - control["cost"]).mean()),
            control_actions=float(control["actions"].mean()), aware_actions=float(aware["actions"].mean()),
            incremental_actions=float((aware["actions"] - control["actions"]).mean()),
            control_conversions=float(control["conversion_actions"].mean()),
            aware_conversions=float(aware["conversion_actions"].mean()),
            control_turnover=float(control["turnover_shares"].mean()), aware_turnover=float(aware["turnover_shares"].mean()),
            mean_phase_quote_savings=float(aware["quoted_savings"].mean()),
            mean_changed_phases=float(aware["changed_phases"].mean()),
            max_control_actions_60s=int(control["max_rolling_actions"].max()),
            max_aware_actions_60s=int(aware["max_rolling_actions"].max()),
            max_position_fraction=float(aware["max_position_fraction"].max()),
            control_latest_flat=int(control["flat_times"].max()), aware_latest_flat=int(aware["flat_times"].max()),
            targets_identical=True, inventory60_identical=True)
        summaries.append(row)
        for i, season_id in enumerate(ids):
            item = dict(split=split, scenario=scenario, season_id=int(season_id),
                control_cash_spent=float(-control["pnl"][i]), aware_cash_spent=float(-aware["pnl"][i]),
                incremental_total_cash_spent=float(-difference[i]))
            for key in ("pnl", "cost", "gross_market_cash_spent", "actions", "conversion_actions",
                        "turnover_shares", "drawdown", "max_rolling_actions", "quoted_savings", "changed_phases"):
                item[f"control_{key}"] = float(control[key][i])
                item[f"aware_{key}"] = float(aware[key][i])
                item[f"incremental_{key}"] = float(aware[key][i] - control[key][i])
            for r in range(3):
                item[f"control_round{r+1}_pnl"] = float(control["round_pnl"][i, r])
                item[f"aware_round{r+1}_pnl"] = float(aware["round_pnl"][i, r])
                item[f"control_round{r+1}_flat"] = int(control["flat_times"][i, r])
                item[f"aware_round{r+1}_flat"] = int(aware["flat_times"][i, r])
            seasons.append(item)
        for name, result in (("control", control), ("aware", aware)):
            saved.update({f"{scenario}__{name}__{key}": value for key, value in result.items()})
        csv_out(f"{split}_metrics.csv", summaries)
        csv_out(f"{split}_seasons.csv", seasons)
        csv_out(f"{split}_routes.csv", routes)
        print(split, scenario, "control", round(row["control_mean_pnl"], 2),
              "aware", round(row["aware_mean_pnl"], 2), "increment", round(row["incremental_mean_pnl"], 2),
              "actions", round(row["incremental_actions"], 2), flush=True)
    np.savez_compressed(HERE / f"{split}_results.npz", season_ids=ids, **saved)


def development():
    if (HERE / "validation_started.json").exists() or (HERE / "frozen.json").exists():
        raise RuntimeError("Implementation already frozen; preserve existing comparisons")
    ids, market = load(361, 600)
    curve = market.mean(0)
    np.savez_compressed(HERE / "fit_curve.npz", curve=curve)
    evaluate(ids, market, curve, "fit")
    ids, market = load(241, 360)
    evaluate(ids, market, curve, "inner")
    frozen = dict(algorithm="parameter-free quoted-cash-cost two-basket enumeration",
        target="unchanged v3 mean-curve target, fee gate, full fraction", start=0, exit_at=70,
        forecast_priority="unchanged v3 absolute mean drift", fit_ids=[361, 600], inner_ids=[241, 360],
        refit_ids=[241, 600], diagnostic_ids=[121, 240], scenarios=SCENARIOS,
        candidate_count=1, source_sha256={name: digest(name) for name in SOURCE},
        status="retrospective execution diagnostic; validation seasons already observed",
        resources="one process, BLAS/OMP1, one trading key, unchanged rolling60 actions",
        validation_revision_permitted=False)
    json_out("frozen.json", frozen)
    _, market = load(241, 600)
    np.savez_compressed(HERE / "frozen_curve.npz", curve=market.mean(0))
    json_out("frozen_curve_manifest.json", {"sha256": digest("frozen_curve.npz"), "fit_ids": [241, 600]})
    print("FROZEN implementation; no forecast/timing/parameter selection", flush=True)


def validation():
    if (HERE / "validation_started.json").exists():
        raise RuntimeError("New validation diagnostic is single-use")
    frozen = json.loads((HERE / "frozen.json").read_text())
    for name, expected in frozen["source_sha256"].items():
        assert digest(name) == expected, name
    curve_manifest = json.loads((HERE / "frozen_curve_manifest.json").read_text())
    assert digest("frozen_curve.npz") == curve_manifest["sha256"]
    json_out("validation_started.json", {"frozen_sha256": digest("frozen.json"),
        "new_diagnostic_once": True, "validation_already_observed": True})
    with np.load(HERE / "frozen_curve.npz", allow_pickle=False) as z:
        curve = z["curve"]
    ids, market = load(121, 240)
    evaluate(ids, market, curve, "validation_diagnostic")
    json_out("validation_complete.json", {"scenarios": len(SCENARIOS), "seasons": len(ids),
        "matched_targets_and_inventory60": True, "accounting_and_execution_assertions_passed": True,
        "independent_validation": False, "frozen_sha256": digest("frozen.json")})


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("stage", choices=["development", "validation"])
    args = parser.parse_args()
    {"development": development, "validation": validation}[args.stage]()
