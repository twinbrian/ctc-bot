# Execution-only quoted-cost routing diagnostic

The earlier formation study is preserved in the parent directory. This directory
contains one parameter-free route planner, its unchanged v3 control, numerical
examples, frozen implementation hashes, and exact paired season results.

All historical outcomes come from `../../development.npz`. Entry0, exit70,
direction, target inventory and priority are matched; only conversion quantities
can change. Validation seasons121–240 were already observed in the earlier study,
so the final comparison is explicitly retrospective.

## Reproduction

From this directory:

```bash
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1
export PYTHONDONTWRITEBYTECODE=1
python -m pytest -q test_route_cost.py
python run.py development > development_run.log 2>&1
python run.py validation > validation_run.log 2>&1
python verify_saved.py
python diagnostics.py
```

The development and validation commands are single-use and preserve their saved
artifacts. To inspect this completed run, use only `verify_saved.py`,
`diagnostics.py`, and the CSV/NPZ outputs. A clean-copy reproduction needs the
same approved relative input path and the research lead's evaluation protocol.

## Interfaces and outputs

- `planner.CostPlanner.choose(...)` accepts current inventory, target, one current
  quote vector, rolling action history, depth cooldowns, fixed priority and time.
  It returns signed ARCH/REBLD conversion quantities plus an audit record.
- `planner.dry_run(...)` checks execution feasibility without any quote-path input.
- `simulator.simulate(market, curve, optimized=True/False, ...)` runs matched arms.
- `fit_seasons.csv`, `inner_seasons.csv`, `validation_diagnostic_seasons.csv`
  retain each arm and exact per-season incremental PnL, gross market cash spent,
  charged fees, total net cash spent, actions, conversions, turnover and timing.
  Since terminal positions are zero, incremental total cash spent is exactly the
  negative of incremental PnL. All monetary fields are USD.
- Matching `*_metrics.csv`, `*_routes.csv`, and `*_results.npz` retain aggregate
  statistics, phase-level route decisions, action ticks and accounting arrays.
- `frozen.json` and `frozen_curve_manifest.json` link the fixed source/plan and
  training mean curve to the final diagnostic. No route parameters are fitted.
- `NUMERICAL_EXAMPLES.md` records the pre-scoring accounting examples;
  `HANDOFF.md` gives the conclusion and integration implications.

The planner is deliberately conservative: alternative schedules must fit within
the currently unspent action quota and the current-state maximal route's dry-run
completion time. The actual rolling ledger still honors action releases. At low
depth, an incomplete fixed-route entry triggers an identical-route fallback,
preserving matched exposure rather than reporting reduced trading as savings.
