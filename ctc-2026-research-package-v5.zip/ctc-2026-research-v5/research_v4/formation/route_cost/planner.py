"""Quoted-cash-cost enumeration with price-free execution feasibility.

No fitted coefficients, statistical thresholds, or future quote access.
"""

import numpy as np

from exchange import LIMITS, VECTORS, maximum_routes


def dry_run(q0, goal, quantities, *, ti=0, history=None, last_depth=None,
            jump=None, latency=2, depth=50, bounded=True, entry=False):
    """Exact v3 quantity scheduler, without prices/cash. Rows are alternatives.

    Capacity reserves are gross, even when opposing ETF legs arrive together.
    Unbounded mode removes only the action throttle, for disjoint-basket profiles.
    """
    q = np.asarray(q0, dtype=int).copy()
    n = len(q)
    row = np.arange(n)
    goal = np.asarray(goal, dtype=int)
    remaining = np.abs(quantities).copy()
    direction = np.sign(quantities).astype(int)
    history = np.zeros((n, 30), int) if history is None else history.copy()
    last_depth = np.full((n, 12), -1000, int) if last_depth is None else last_depth.copy()
    jump = np.ones((n, 12)) if jump is None else np.broadcast_to(jump, (n, 12))
    used = history.sum(1)
    pp, pn = np.zeros_like(q), np.zeros_like(q)
    delay = max(1, int(np.ceil(latency / 2)))
    qp = np.zeros((delay + 1, n, 12), int)
    qn = np.zeros_like(qp)
    total, conversions = np.zeros(n, int), np.zeros(n, int)
    completion = np.full(n, -1, int)
    done = np.zeros(n, bool)
    for current in range(ti, 390):
        slot = current % 30
        used -= history[:, slot]
        history[:, slot] = 0
        arrival = current % (delay + 1)
        q += qp[arrival] - qn[arrival]
        pp -= qp[arrival]
        pn -= qn[arrival]
        qp[arrival] = 0
        qn[arrival] = 0
        assert np.all(np.abs(q) <= LIMITS)
        assert np.all(q + pp <= LIMITS) and np.all(q - pn >= -LIMITS)
        fresh = ~done & np.all(q == goal, axis=1) & np.all(pp + pn == 0, axis=1)
        completion[fresh] = current - ti
        done |= fresh
        if done.all():
            break
        if current + delay >= 390 or (entry and current > 30):
            if entry and current > 30 + delay:
                break
            continue
        destination = (current + delay) % (delay + 1)

        def submit(change, valid, conversion=False):
            pos, neg = np.maximum(change, 0), np.maximum(-change, 0)
            pp[:] += pos
            pn[:] += neg
            qp[destination] += pos
            qn[destination] += neg
            used[:] += valid
            history[:, slot] += valid
            total[:] += valid
            if conversion:
                conversions[:] += valid

        for b in range(2):
            unit = direction[:, b, None] * VECTORS[b]
            positive = np.where(unit > 0, (LIMITS - q - pp) // np.maximum(unit, 1), 10**9)
            negative = np.where(unit < 0, (LIMITS + q - pn) // np.maximum(-unit, 1), 10**9)
            cap = np.minimum(positive.min(1), negative.min(1))
            quantity = np.minimum(remaining[:, b], np.maximum(cap, 0))
            valid = ~done & (quantity > 0) & ((used < 60) if bounded else True)
            quantity = np.where(valid, quantity, 0)
            submit(unit * quantity[:, None], valid.astype(int), True)
            remaining[:, b] -= quantity
        reserved = np.zeros_like(goal)
        for b in range(2):
            reserved[:, :10] += remaining[:, b, None] * direction[:, b, None] * VECTORS[b, :10]
        diff = goal - reserved - (q + pp - pn)
        side = np.sign(diff).astype(int)
        capacity = np.where(side > 0, LIMITS - q - pp, LIMITS + q - pn)
        qty = np.minimum(np.minimum(depth, np.abs(diff)), np.maximum(capacity, 0))
        ready = current - last_depth >= 1
        rank = np.argsort(-qty * (np.abs(jump) + .01), axis=1)
        for k in range(12):
            j = rank[:, k]
            valid = ~done & ready[row, j] & (qty[row, j] > 0) & ((used < 60) if bounded else True)
            change = np.zeros_like(q)
            change[row, j] = np.where(valid, qty[row, j] * side[row, j], 0)
            submit(change, valid.astype(int))
            last_depth[row[valid], j[valid]] = current
    return dict(actions=total, conversions=conversions, duration_ticks=completion,
                completed=done, inventory=q)


def cash_cost(q, goal, quantities, price, cost_bps=25, fixed_cost=.02):
    market_change = goal - q - quantities @ VECTORS
    fee = price * cost_bps / 10000 + fixed_cost
    return (market_change * price + np.abs(market_change) * fee).sum(-1)


class CostPlanner:
    """Finite two-basket minimum quoted cost, with conservative exact feasibility."""

    def __init__(self, *, depth=50, latency=2, cost_bps=25, fixed_cost=.02):
        self.depth, self.latency = depth, latency
        self.cost_bps, self.fixed_cost = cost_bps, fixed_cost
        self.profiles, self.references = {}, {}
        self.records = []

    def profile(self, q, goal, b, maximum, ti, last_depth):
        members = np.flatnonzero(VECTORS[b]) if b < 2 else np.array([9])
        ready = np.maximum(last_depth - ti + 1, 0)
        key = (b, tuple(q[members]), tuple(goal[members]), int(maximum),
               tuple(ready[members]), self.depth, self.latency)
        if key not in self.profiles:
            quantities = np.arange(abs(maximum) + 1) * np.sign(maximum).astype(int)
            n = len(quantities)
            initial = np.tile(q, (n, 1))
            target = initial.copy()
            target[:, members] = goal[members]
            routes = np.zeros((n, 2), int)
            if b < 2:
                routes[:, b] = quantities
            result = dry_run(initial, target, routes, ti=ti, bounded=False,
                             last_depth=np.tile(last_depth, (n, 1)),
                             depth=self.depth, latency=self.latency)
            self.profiles[key] = dict(z=quantities, members=members, **result)
        return self.profiles[key]

    def choose(self, q, goal, price, history, last_depth, jump, ti, entry):
        maximum = maximum_routes(q[None], goal[None])[0]
        ready = np.maximum(last_depth - ti + 1, 0)
        key = (tuple(q), tuple(goal), tuple(history), tuple(ready), tuple(jump), ti, entry)
        if key not in self.references:
            self.references[key] = dry_run(q[None], goal[None], maximum[None], ti=ti,
                history=history[None], last_depth=last_depth[None], jump=jump[None],
                depth=self.depth, latency=self.latency, entry=entry)
        reference = self.references[key]
        original_cost = float(cash_cost(q, goal, maximum, price, self.cost_bps, self.fixed_cost))
        diagnostic = dict(original_z0=int(maximum[0]), original_z1=int(maximum[1]),
            selected_z0=int(maximum[0]), selected_z1=int(maximum[1]),
            available_actions=int(60 - history.sum()), original_quoted_cash=original_cost,
            selected_quoted_cash=original_cost, quoted_savings=0., changed=False,
            reference_complete=bool(reference["completed"][0]),
            reference_actions=int(reference["actions"][0]), selected_actions=int(reference["actions"][0]),
            reference_seconds=int(2 * reference["duration_ticks"][0]),
            selected_seconds=int(2 * reference["duration_ticks"][0]))
        if not reference["completed"][0]:
            return maximum, diagnostic
        profiles = [self.profile(q, goal, b, maximum[b] if b < 2 else 0, ti, last_depth) for b in range(3)]
        costs = []
        fee = price * self.cost_bps / 10000 + self.fixed_cost
        for b, profile in enumerate(profiles):
            members = profile["members"]
            changes = np.broadcast_to(goal[members] - q[members], (len(profile["z"]), len(members))).copy()
            if b < 2:
                changes -= profile["z"][:, None] * VECTORS[b, members]
            costs.append((changes * price[members] + np.abs(changes) * fee[members]).sum(1))
        a, b, other = profiles
        combined_cost = costs[0][:, None] + costs[1][None, :] + costs[2][0]
        combined_actions = a["actions"][:, None] + b["actions"][None, :] + other["actions"][0]
        duration = np.maximum(np.maximum(a["duration_ticks"][:, None], b["duration_ticks"][None, :]), other["duration_ticks"][0])
        feasible = (a["completed"][:, None] & b["completed"][None, :] & other["completed"][0]
                    & (combined_actions <= 60 - history.sum())
                    & (duration <= reference["duration_ticks"][0]))
        ii, jj = np.where(feasible)
        if len(ii):
            converted = np.abs(a["z"][ii]) + np.abs(b["z"][jj])
            order = np.lexsort((-converted, duration[ii, jj], combined_actions[ii, jj], np.round(combined_cost[ii, jj], 8)))
            i, j = ii[order[0]], jj[order[0]]
            candidate = np.array([a["z"][i], b["z"][j]], int)
            candidate_key = (round(float(combined_cost[i, j]), 8), int(combined_actions[i, j]),
                             int(duration[i, j]), -int(np.abs(candidate).sum()))
            original_key = (round(original_cost, 8), int(reference["actions"][0]),
                            int(reference["duration_ticks"][0]), -int(np.abs(maximum).sum()))
            if candidate_key < original_key:
                diagnostic.update(selected_z0=int(candidate[0]), selected_z1=int(candidate[1]),
                    selected_quoted_cash=float(combined_cost[i, j]),
                    quoted_savings=original_cost - float(combined_cost[i, j]),
                    changed=bool(np.any(candidate != maximum)),
                    selected_actions=int(combined_actions[i, j]), selected_seconds=int(2 * duration[i, j]))
                assert diagnostic["quoted_savings"] >= -1e-7
                return candidate, diagnostic
        return maximum, diagnostic
