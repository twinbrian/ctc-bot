"""Unchanged CTC exchange constants, copied locally."""

import numpy as np

SYMBOLS = ["PORT", "ISLE", "AQUA", "GRID", "FERRY", "RECON", "MAT", "GEN", "HAVEN", "REIN", "ARCH", "REBLD"]
LIMITS = np.array([200, 300, 500, 400, 800, 500, 700, 600, 250, 200, 50, 100])
BASKETS = np.zeros((2, 10), dtype=int)
BASKETS[0, [0, 1, 2, 3, 4, 8]] = [1, 1, 2, 1, 2, 1]
BASKETS[1, [5, 6, 7]] = [2, 2, 1]
VECTORS = np.zeros((2, 12), dtype=int)
VECTORS[:, :10] = BASKETS
VECTORS[0, 10], VECTORS[1, 11] = -1, -1


def maximum_routes(q, goal):
    quantities = np.zeros((len(q), 2), dtype=int)
    for b in range(2):
        sites = np.where(VECTORS[b, :10] > 0)[0]
        diff = goal[:, sites] - q[:, sites]
        units = VECTORS[b, sites]
        buy = np.min(np.maximum(diff, 0) // units, axis=1)
        sell = np.min(np.maximum(-diff, 0) // units, axis=1)
        quantities[:, b] = np.where(buy > 0, buy, -sell)
    return quantities
