"""v3 route execution with an optional phase-start cost-aware route choice.

Target, directional priority, entry cutoff and fixed exit70 are unchanged.
"""

import numpy as np

from exchange import BASKETS, LIMITS, VECTORS, maximum_routes
from planner import CostPlanner


def simulate(market, curve, *, optimized=False, latency=2, depth=50,
             cost_bps=25, fixed_cost=.02, audit=True):
    n = len(market)
    row = np.arange(n)
    q = np.zeros((n, 12), int)
    pp, pn = np.zeros_like(q), np.zeros_like(q)
    cash, costs, gross_cash, turnover = (np.zeros(n) for _ in range(4))
    actions, conversions, max_window = (np.zeros(n, int) for _ in range(3))
    attribution = np.zeros((n, 12))
    max_pos, peak, drawdown = np.zeros(n), np.zeros(n), np.zeros(n)
    counts = np.zeros((n, 3, 390), np.int8)
    flat_times = np.full((n, 3), -1, int)
    round_pnl = np.zeros((n, 3))
    goals, inventory60 = np.zeros((n, 3, 12), int), np.zeros((n, 3, 12), int)
    quoted_savings = np.zeros(n)
    changed_phases = np.zeros(n, int)
    planner = CostPlanner(depth=depth, latency=latency, cost_bps=cost_bps, fixed_cost=fixed_cost) if optimized else None
    delay = max(1, int(np.ceil(latency / 2)))
    for r in range(3):
        opening_cash = cash.copy()
        queue = [[] for _ in range(390 + delay)]
        used = np.zeros(n, int)
        history = np.zeros((n, 30), int)
        last_depth = np.full((n, 12), -1000, int)
        closing, done = np.zeros(n, bool), np.zeros(n, bool)
        jump = curve[r, 36:42].mean(0) - curve[r, 0]
        anchor = market[:, r, 0]
        signal = np.abs(jump)[None] - (anchor + np.maximum(anchor + jump, 0)) * cost_bps / 10000 - 2 * fixed_cost
        goal = np.sign(jump).astype(int)[None] * LIMITS[None] * (signal > 0)
        goals[:, r] = goal
        remaining, direction = np.zeros((n, 2), int), np.zeros((n, 2), int)

        def plan(i, ti, entry):
            assert np.all(pp[i] + pn[i] == 0)
            quantities = maximum_routes(q[i], goal[i])
            if planner is not None:
                for local, index in enumerate(i):
                    chosen, diagnostic = planner.choose(q[index], goal[index], market[index, r, ti],
                        history[index], last_depth[index], jump, ti, entry)
                    quantities[local] = chosen
                    quoted_savings[index] += diagnostic["quoted_savings"]
                    changed_phases[index] += diagnostic["changed"]
                    planner.records.append(dict(row=int(index), round=r + 1,
                        phase="entry" if entry else "exit", time=2 * ti, **diagnostic))
            direction[i] = np.sign(quantities)
            remaining[i] = np.abs(quantities)

        plan(row, 0, True)
        for ti in range(390):
            t, slot = 2 * ti, ti % 30
            used -= history[:, slot]
            history[:, slot] = 0
            price = market[:, r, ti]
            for i, change, kind in queue[ti]:
                pp[i] -= np.maximum(change, 0)
                pn[i] -= np.maximum(-change, 0)
                if kind == "market":
                    fee = price[i] * cost_bps / 10000 + fixed_cost
                    payment = change * price[i] + np.abs(change) * fee
                    cash[i] -= payment.sum(1)
                    gross_cash[i] += (change * price[i]).sum(1)
                    costs[i] += (np.abs(change) * fee).sum(1)
                    turnover[i] += np.abs(change).sum(1)
                    attribution[i] -= payment
                else:
                    marks = price[i].copy()
                    marks[:, 10:] = price[i, :10] @ BASKETS.T
                    booking = change * marks
                    assert np.allclose(booking.sum(1), 0, atol=1e-8)
                    attribution[i] -= booking
                q[i] += change
                assert np.all(np.abs(q[i]) <= LIMITS)
            assert np.all(q + pp <= LIMITS) and np.all(q - pn >= -LIMITS)
            wealth = cash + (q * price).sum(1)
            peak = np.maximum(peak, wealth)
            drawdown = np.maximum(drawdown, peak - wealth)
            max_pos = np.maximum(max_pos, np.max(np.abs(q) / LIMITS, axis=1))
            if t == 60:
                inventory60[:, r] = q

            def submit(i, change, kind):
                if not len(i):
                    return
                assert np.all(used[i] < 60)
                assert np.all(q[i] + pp[i] + np.maximum(change, 0) <= LIMITS)
                assert np.all(q[i] - pn[i] - np.maximum(-change, 0) >= -LIMITS)
                pp[i] += np.maximum(change, 0)
                pn[i] += np.maximum(-change, 0)
                queue[ti + delay].append((i.copy(), change.copy(), kind))
                used[i] += 1
                history[i, slot] += 1
                actions[i] += 1
                counts[i, r, ti] += 1
                if kind != "market":
                    conversions[i] += 1

            if t >= 70:
                ready = ~closing & np.all(pp + pn == 0, axis=1)
                i = np.flatnonzero(ready)
                goal[i] = 0
                plan(i, ti, False)
                closing[i] = True
                flat = closing & np.all(q == 0, axis=1) & np.all(pp + pn == 0, axis=1)
                fresh = flat & ~done
                flat_times[fresh, r] = t
                done |= flat
            if ti + delay >= 390:
                continue
            active = ((t <= 60) & ~closing) | (closing & ~done)
            for b in range(2):
                unit = direction[:, b, None] * VECTORS[b]
                positive = np.where(unit > 0, (LIMITS - q - pp) // np.maximum(unit, 1), 10**9)
                negative = np.where(unit < 0, (LIMITS + q - pn) // np.maximum(-unit, 1), 10**9)
                cap = np.minimum(positive.min(1), negative.min(1))
                quantity = np.minimum(remaining[:, b], np.maximum(cap, 0))
                i = np.flatnonzero(active & (used < 60) & (quantity > 0))
                submit(i, unit[i] * quantity[i, None], "convert")
                remaining[i, b] -= quantity[i]
            reserved = np.zeros_like(goal)
            for b in range(2):
                reserved[:, :10] += remaining[:, b, None] * direction[:, b, None] * VECTORS[b, :10]
            diff = goal - reserved - (q + pp - pn)
            ready_depth = ti - last_depth >= 1
            side = np.sign(diff).astype(int)
            capacity = np.where(side > 0, LIMITS - q - pp, LIMITS + q - pn)
            qty = np.minimum(np.minimum(depth, np.abs(diff)), np.maximum(capacity, 0))
            rank = np.argsort(-qty * (np.abs(jump)[None] + .01), axis=1)
            for k in range(12):
                j = rank[:, k]
                i = np.flatnonzero(active & (used < 60) & ready_depth[row, j] & (qty[row, j] > 0))
                change = np.zeros((len(i), 12), int)
                change[np.arange(len(i)), j[i]] = qty[i, j[i]] * side[i, j[i]]
                submit(i, change, "market")
                last_depth[i, j[i]] = ti
            max_window = np.maximum(max_window, used)
            if done.all():
                break
        assert np.all(q == 0) and np.all(pp + pn == 0)
        assert not counts[:, r, -30:].any()
        round_pnl[:, r] = cash - opening_cash
    np.testing.assert_allclose(cash, -gross_cash - costs, atol=1e-8)
    np.testing.assert_allclose(cash, attribution.sum(1), atol=1e-8)
    cumulative = counts.reshape(n, -1).cumsum(1)
    lag = np.pad(cumulative[:, :-30], ((0, 0), (30, 0)))
    assert (cumulative - lag).max() <= 60
    result = dict(pnl=cash, cost=costs, gross_market_cash_spent=gross_cash,
        actions=actions, conversion_actions=conversions, turnover_shares=turnover,
        attribution=attribution, positions=q, goals=goals, inventory60=inventory60,
        flat_times=flat_times, round_pnl=round_pnl, drawdown=drawdown,
        max_rolling_actions=max_window, max_position_fraction=max_pos,
        quoted_savings=quoted_savings, changed_phases=changed_phases)
    if audit:
        result["action_ticks"] = counts
    return result, [] if planner is None else planner.records
