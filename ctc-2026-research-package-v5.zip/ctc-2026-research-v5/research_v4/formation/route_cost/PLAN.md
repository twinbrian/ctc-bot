# Parameter-free quoted-cost-aware formation routing

Declared before any outcome scoring. This is a distinct execution diagnostic;
the completed parent formation candidates/configuration/results remain intact.
Only `../../development.npz` supplies historical outcomes. One process, BLAS/OMP1;
no agents, services, trades, parent/sibling writes, branches or commits.

## Fixed control and objective

Use the original v3 defaults: start0, fixed exit70, full fraction, formation
direction/target from the training-average round curve and its existing fee
gate. Both arms receive **the exact same target and forecast priority**. This
is not another forecast or timing search. Fit361–600 supplies the curve for fit
and inner241–360 comparisons; freeze implementation, refit the same curve on
241–600, then perform one new, explicitly retrospective diagnostic on121–240.
Those validation outcomes were already observed in the preceding study.

Fees25bps+$0.02/share/side, latency2s, depth50/symbol/2s, original position limits,
one key's actual rolling60-action limit, worst-order pending reserves, zero-cash
atomic ETF conversions, and actual closing trades are retained. Diagnostics
also use latency4, depth25, depth10, and latency4+depth25; these are stresses,
not competing parameter choices.

## Algorithm (no fitted thresholds or statistical grid)

At entry and the actual start of liquidation, while no orders are pending:

1. Compute each basket's maximal common-stock conversion exactly as v3. Enumerate
   integer conversion quantities from zero through that maximum, in the same
   direction. No stock leg is overshot, and no unrelated/repeated arbitrage is
   introduced. The outright ETF target is included in the residual market orders.
2. For conversion vector `v` and signed quantity `z`, the necessary direct market
   order is `m = goal - current_inventory - z*v`. Its **observable synthetic
   quoted cash cost** is `sum(m*mark + abs(m)*(mark*bps/10000 + fixed_fee))`.
   Therefore ETF/basket basis, bid/ask costs and the existing ETF inventory all
   enter the decision. Conversions themselves have zero cash/fee.
3. A price-free dry-run scheduler uses the same depth, latency, pending-capacity
   and action accounting to compute the maximal-route control's completion time.
   Per-basket dry runs enumerate each quantity's market/conversion action count
   and completion time with no action throttling. The baskets are disjoint.
4. Solve the two-basket finite cost problem jointly: require combined action
   counts (including nonbasket REIN orders) <= currently unspent rolling-minute
   actions, and completion no later than the maximal-route dry-run reference.
   These conservative constraints make the independent schedules jointly
   feasible without anticipating future action releases. Existing rolling-window
   releases are still honored by the actual simulator and the reference dry run.
5. Choose minimum quoted cash cost, breaking numerical ties by fewer actions,
   shorter completion, then more conversion. Include the original maximal route
   as a fallback even when it needs future action releases. Adopt an alternative
   only if its quoted cost is no worse. Monetary rounding at 1e-8 USD is numerical
   tie handling, not an economic threshold.
6. If the fixed route cannot fill its entry target by the original t60 order
   cutoff, retain that exact route; do not manufacture an improvement by changing
   preformation inventory under a depth stress. Execute the chosen plan using
   actual later quotes; no future quotes enter routing decisions.

Route choice is made once per entry/liquidation phase. It is not revised using
later prices. The scheduled entry/exit, target and directional priority are fixed;
actual execution times may differ as a direct consequence of routing.

## Sequence and outputs

First develop numerical flat-market, known-basis, fee, action/depth and pending
reserve examples, plus parity with v3. Then score fit/inner once, retain the
parameter-free implementation regardless of success, freeze source hashes before
the new validation diagnostic, and report failure honestly.

Save both arms' per-season net cash/PnL, gross market cash, fees, actions,
conversion actions, turnover, flattening times and exact differences for base
and stress cases. Audit matched entry targets/inventory, zero terminal inventory,
position limits, rolling actions, and quoted predicted savings versus realized
differences. Deliver readable code, frozen source/config hashes and concise
`HANDOFF.md`. This diagnostic cannot establish independent out-of-sample alpha.
