# Quoted-cost-aware routing: execution-only handoff

## Conclusion

**Negative result: retain the maximal-conversion control.** Current synthetic
quotes imply savings, but actual delayed execution does not realize them. The
planner uses more actions and market shares without improving mean net PnL on
inner or retrospective validation seasons. Earlier formation candidates/results
remain untouched; all follow-up work is in `formation/route_cost`.

## Fixed algorithm and control

Original v3 control: entry0, fixed exit70, full existing target, unchanged
training-average formation signal, fee gate and trade priority. Both arms have
identical targets and identical t60 inventories in every split/stress comparison.

At entry and liquidation, enumerate integer conversion quantities from zero to
the maximal common-stock basket. For conversion vector `v` and signed quantity
`z`, residual market orders are `m = target - inventory - z*v`. Minimize current
quoted cash cost `sum(m*quote + abs(m)*(quote*25bps + USD 0.02))`, including the
outright ETF target. Atomic conversions themselves create no cash.

A price-free scheduler checks action counts, depth/latency, worst-order pending
capacity and completion. Joint basket enumeration requires the currently unspent
rolling-minute action quota and completion no later than the maximal route from
the same current state. The maximal route is always a fallback. If it cannot
complete entry by the existing cutoff, retain that exact entry route to preserve
exposure. Numerical ties favor fewer actions, faster completion, then more
conversion. There are no fitted thresholds, statistical parameters or timing grid.

Twelve numerical tests passed before scoring, including exact original-v3 parity,
cash accounting and causal quote access. `NUMERICAL_EXAMPLES.md` documents:

- Ten ARCH basket units, stocks at USD 100, ETF at USD 810 versus USD 800 parity:
  direct execution saves exactly **USD 98.85**, with the same2s completion.
- Only two actions available: conversion remains necessary despite worse quotes.
- Depth10: convert five of ten units, saving **USD 49.425** while preserving2s
  reference completion.
- Constant basket-parity marks produce PnL exactly equal to negative market fees.

## Results

All amounts below are **USD per three-round season**, net of actual closing
trades, 25bps plus USD 0.02/share/side. One key, actual rolling60 actions, original
position limits, baseline latency2s and depth50/symbol/2s are unchanged.

| Base case | Fixed-route mean | Cost-aware mean | Increment | Extra actions |
|---|---:|---:|---:|---:|
| Fit361–600 | 9,961.10 | 9,962.38 | +1.28 | +6.35 |
| Inner241–360 | 10,106.00 | 10,099.69 | **-6.31** | +6.50 |
| Retrospective121–240 | 9,329.16 | 9,323.77 | **-5.39** | +6.50 |

Base incremental-mean conditional bootstrap intervals: fit USD [-6.42, 8.69],
inner USD [-17.47, 4.64], retrospective USD [-15.45, 4.42]. These are descriptive,
not independent out-of-sample evidence: seasons121–240 were already observed in
the preceding formation study.

| Stress | Fit increment | Inner increment | Retrospective increment |
|---|---:|---:|---:|
| Latency4 | +1.94 | +1.12 | -1.68 |
| Depth25 | 0.00 | 0.00 | 0.00 |
| Depth10 | 0.00 | 0.00 | 0.00 |
| Latency4 + depth25 | 0.00 | 0.00 | 0.00 |

All low-depth entry references are incomplete at the cutoff; the matched fallback
and exit constraints leave both routes identical. Zero differences establish
fallback behavior, not improved profitability under low depth. Every arm's full
metrics, including absolute PnL for all15 split/stress comparisons, are saved.

## Quoted versus realized savings

Base retrospective changes, per season:

| Component | Cost-aware minus control |
|---|---:|
| Gross market cash spent | **USD -3.2875** |
| Charged fees | **USD +8.6808** |
| Total net cash spent | **USD +5.3933** |
| Net realized PnL | **USD -5.3933** |
| Market-share turnover | +433.33 shares |
| Order/conversion actions | +6.50 |
| Conversion actions | -2.17 |

Current quotes suggested **USD 101.38** in phase savings per season: about
USD 89.65 at liquidation and USD 11.73 at entry. Only USD 3.29 of gross cash
savings materialized, insufficient for additional fees. This is a current-quote
versus delayed-fill mismatch, not uncharged conversion profit.

Base changes affect REBLD conversion, not ARCH. The planner changes102 of360
entry decisions and158 of360 exit decisions. Average actions rise291→297.5;
conversions fall51→48.83. Latest flattening stays t86 in both base arms and t90
in latency4. Maximum actual rolling actions are52 in base and60 in latency4.

No increased target, extra key, higher depth, direction change or repeated
standalone arbitrage explains the comparison. Persistent-quote numerical examples
validate the optimizer; historical quote changes erase its potential benefit.

## Protocol and integration

`PLAN.md` preceded scoring. Fit361–600 supplied the unchanged formation curve for
fit/inner comparisons. Implementation hashes were then frozen and the same mean
curve refit on241–600. One new retrospective diagnostic evaluated121–240 with
five predeclared stresses. There was no implementation revision after validation.
Saved source hashes, phase action/completion predictions, accounting, limits and
matched inventories passed audits.

Development scoring/freezing completed before the server interruption. The clock
after restart was13:33UTC, past the original06:30 deadline; the explicit continuation
request was used only to complete the remaining diagnostic and handoff. Completed
evaluations were not repeated after either restart.

Integration interface: `CostPlanner.choose(...)` accepts current inventory/target,
one quote vector, rolling action history, depth cooldowns, fixed priority, tick and
entry/exit flag. It returns signed ARCH/REBLD conversion quantities. The existing
shared-account order ledger and pending reserves must remain authoritative. Its
current-state deadline is not a universal guarantee of identical timing across
different shared-account histories. Given the negative result and extra action
usage, this is a research artifact, not a recommended v3 replacement.

## Exact outputs and commands

- `fit_seasons.csv`:1,200 paired season/scenario rows.
- `inner_seasons.csv`:600 paired rows.
- `validation_diagnostic_seasons.csv`:600 paired rows.
- Every row contains both arms and exact incremental PnL, gross market cash,
  charged fees, total cash spent, actions, conversion actions, turnover, round PnL
  and flattening. All monetary CSV fields are USD. Terminal positions are zero,
  so incremental total cash spent is exactly negative incremental PnL.
- Matching `*_metrics.csv`, `*_routes.csv`, `*_results.npz`, and
  `phase_diagnostics.csv` retain summaries, route decisions and full accounting.
- `frozen.json`, `frozen_curve_manifest.json`, `validation_complete.json` preserve
  frozen source/curve hashes and completed audit status.

From this directory, inspect saved work without policy replay:

```bash
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1
export PYTHONDONTWRITEBYTECODE=1
python verify_saved.py
python diagnostics.py
```

Original sequence, for clean-copy reproduction under the lead's protocol:

```bash
python -m pytest -q test_route_cost.py
python run.py development > development_run.log 2>&1
python run.py validation > validation_run.log 2>&1
```

Development and validation commands are single-use. Only approved
`../../development.npz` supplied outcomes. No parent/sibling files, original
candidate outputs, shared sources, repositories or branches were modified.
