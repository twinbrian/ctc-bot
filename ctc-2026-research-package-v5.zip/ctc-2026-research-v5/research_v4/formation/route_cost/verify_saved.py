"""Check saved outcomes and frozen implementation; no historical replay."""

import csv
import json

import numpy as np

from run import HERE, SCENARIOS, digest


def main():
    frozen = json.loads((HERE / "frozen.json").read_text())
    for name, expected in frozen["source_sha256"].items():
        assert digest(name) == expected, name
    manifest = json.loads((HERE / "frozen_curve_manifest.json").read_text())
    assert digest("frozen_curve.npz") == manifest["sha256"]
    for split, lo, hi in (("fit", 361, 600), ("inner", 241, 360), ("validation_diagnostic", 121, 240)):
        with np.load(HERE / f"{split}_results.npz", allow_pickle=False) as z:
            np.testing.assert_array_equal(z["season_ids"], np.arange(lo, hi + 1))
            for scenario in SCENARIOS:
                c, a = scenario + "__control__", scenario + "__aware__"
                np.testing.assert_array_equal(z[c + "goals"], z[a + "goals"])
                np.testing.assert_array_equal(z[c + "inventory60"], z[a + "inventory60"])
                for prefix in (c, a):
                    np.testing.assert_allclose(z[prefix + "pnl"], -z[prefix + "gross_market_cash_spent"] - z[prefix + "cost"], atol=1e-8)
                    np.testing.assert_allclose(z[prefix + "pnl"], z[prefix + "round_pnl"].sum(1), atol=1e-8)
                    assert not z[prefix + "positions"].any()
                    assert z[prefix + "max_position_fraction"].max() <= 1
                    counts = z[prefix + "action_ticks"].reshape(hi - lo + 1, -1)
                    cumulative = counts.cumsum(1)
                    lag = np.pad(cumulative[:, :-30], ((0, 0), (30, 0)))
                    assert (cumulative - lag).max() <= 60
                    np.testing.assert_array_equal(counts.sum(1), z[prefix + "actions"])
        with (HERE / f"{split}_seasons.csv").open() as f:
            rows = list(csv.DictReader(f))
        assert len(rows) == (hi - lo + 1) * len(SCENARIOS)
        for row in rows:
            assert abs(float(row["incremental_pnl"]) + float(row["incremental_total_cash_spent"])) < 1e-7
            assert abs(float(row["incremental_pnl"]) + float(row["incremental_gross_market_cash_spent"]) + float(row["incremental_cost"])) < 1e-7
    print("Frozen source/curve hashes and all15 matched split/stress comparisons passed saved-result audits.")


if __name__ == "__main__":
    main()
