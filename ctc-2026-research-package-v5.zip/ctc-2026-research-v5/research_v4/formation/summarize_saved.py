"""Diagnostics only: summarize saved simulations without fitting or replaying trades."""

import json
import pickle

import numpy as np

from contracts import SYMBOLS
from research import HERE, write_csv, write_json


def main():
    frozen = json.loads((HERE / "frozen_config.json").read_text())
    selected = [x["id"] for x in frozen["selected"]]
    goals, attribution, exits, comparisons = [], [], [], []
    for split, filename in [("inner", "inner_results.npz"), ("validation", "validation_results.npz")]:
        with np.load(HERE / filename, allow_pickle=False) as z:
            for name in selected:
                prefix = name if split == "inner" else name + "__base"
                config = next(x for x in frozen["selected"] if x["id"] == name)
                reference = f"B{config['exit']}"
                goal, base = z[prefix + "__goals"], z[reference + "__goals"]
                by_symbol = z[prefix + "__attribution"] - z[reference + "__attribution"]
                for j, symbol in enumerate(SYMBOLS):
                    goals.append(dict(split=split, candidate=name, comparator=reference, symbol=symbol,
                        changed_fraction=float((goal[..., j] != base[..., j]).mean()),
                        zeroed_fraction=float(((goal[..., j] == 0) & (base[..., j] != 0)).mean()),
                        reversed_fraction=float((goal[..., j] * base[..., j] < 0).mean()),
                        mean_abs_goal=float(np.abs(goal[..., j]).mean()),
                        comparator_abs_goal=float(np.abs(base[..., j]).mean()),
                        mean_conversion_booked_pnl_increment=float(by_symbol[:, j].mean())))
                for r in range(3):
                    attribution.append(dict(split=split, candidate=name, comparator=reference,
                        round=r + 1, mean_pnl=float(z[prefix + "__round_pnl"][:, r].mean()),
                        mean_increment=float((z[prefix + "__round_pnl"][:, r] - z[reference + "__round_pnl"][:, r]).mean())))
                decision = z[prefix + "__exit_decisions"]
                for r in range(3):
                    for at in np.unique(decision[:, r]):
                        mask = decision[:, r] == at
                        exits.append(dict(split=split, candidate=name, round=r + 1, exit_decision=int(at),
                                          storms=int(mask.sum()), fraction=float(mask.mean())))
            if split == "validation":
                for name in selected:
                    keys = [k[:-5] for k in z.files if k.startswith(name + "__fixed") and k.endswith("__pnl")]
                    for reference in keys:
                        delta = z[name + "__base__pnl"] - z[reference + "__pnl"]
                        rng = np.random.default_rng(2026)
                        means = delta[rng.integers(0, len(delta), (10000, len(delta)))].mean(1)
                        comparisons.append(dict(candidate=name, comparator=reference, mean_increment=float(delta.mean()),
                            paired_ci_low=float(np.quantile(means, .025)), paired_ci_high=float(np.quantile(means, .975))))
    write_csv(HERE / "goal_diagnostics.csv", goals)
    write_csv(HERE / "round_attribution.csv", attribution)
    write_csv(HERE / "exit_decisions.csv", exits)
    write_csv(HERE / "exit_alpha_paired.csv", comparisons)
    with (HERE / "frozen_models.pkl").open("rb") as f:
        models = pickle.load(f)
    # Portable coefficients; no outcome arrays or season-identifying features.
    model_json = {}
    for name, model in models.items():
        if name == "curve":
            model_json[name] = model.tolist()
        else:
            model_json[name] = {k: v.tolist() if isinstance(v, np.ndarray) else v for k, v in vars(model).items()}
    write_json(HERE / "frozen_models.json", model_json)
    print("Saved goal, round, exit and portable-model diagnostics; no trades rerun.")


if __name__ == "__main__":
    main()
