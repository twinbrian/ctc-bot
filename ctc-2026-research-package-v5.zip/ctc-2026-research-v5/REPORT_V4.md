# CTC 2026: expanded research and audit, v4

## Decision

**Retain the v3 strategy as the research incumbent. No v4 replacement or additive PnL improvement has been established.** Its previously completed five-fold simulator estimate is USD 11,101 mean net PnL per season. V4 adds a substantial negative-result record, a promising but unvalidated turnover improvement, and execution-model findings.

The research objective remains arithmetic mean terminal net PnL, not Sharpe ratio or win rate. All results are hypothetical. The dataset contains house prices, not executable books; live fills, available capacity, price protection, competitor impact and announcement economics are unverified.

The original five-hour wall-clock window was 05:25–10:25 UTC on 19 October 2026. Server interruptions prevented uninterrupted work. On recovery after the deadline, remaining workers were stopped and saved outputs were consolidated without restarting the search. The last checked usage snapshot during recovery was **USD 106.23 incremental reported model cost** against the USD 350 authorization; this excludes subsequent report preparation and is an estimate, not a final invoice. No paid external compute, data or trading was used. All work remained in a standalone local project.

## 1. What remains strongest

The principal v3 edge is scheduled house repricing around storm formation, combined with ETF conversions that acquire and unwind the desired stock basket using fewer order actions. It is not a claim that predicting every hurricane precisely is necessary.

- Train the expected formation-window price change using other seasons. At current prices, trade only expected changes exceeding modeled entry and exit costs.
- Express common stock exposure through legal ARCH and REBLD create/redeem routes; trade residual shares directly. Conversions move inventory with zero cash flow. Separate market legs pay costs and arrive later.
- Flatten the formation exposure, leave a conservative one-minute separation, then use the short-horizon engine. Use structural settlement estimates after the final round's exact report.
- Respect the published symbol limits, pending exposure, assumed available depth and one key's rolling 60-action limit.

The earlier pooled result was USD 11,100.59 mean, USD 10,018.11 median, 87.7% profitable seasons and USD -8,756.46 worst season. Approximately USD 10,338 of the mean came from formation, USD 467 from later forecasts and USD 295 from final-report trades. The combined 50-bps / four-second / 25-share-depth scenario averaged USD 5,661. These are previously completed results, not a new v4 replay.

The original oldest-to-newest split selected formation entry at real second 20 and earliest exit at second 100. The pooled five-fold mean evaluates fold-specific choices, not one universal configuration. See the v3 report and frozen configurations for exact reproduction.

**The 2r conclusion is unchanged.** The inferred damage support is a Gaussian wind field, `I * exp(-(d/r)^2)`, truncated near `d/r = 2`. PORT's observed zero/positive damage labels support this boundary strongly; severity remains noisy. Closure is a separate threshold, approximately wind 0.35, corresponding to about 1.025r at intensity one. A physical damage cutoff is not an optimal universal trading-entry radius.

## 2. Completed new research

All figures below are mean net USD per three-round season. Standalone engines overlap the incumbent's inventory, time and action budgets: **their profits cannot be added to the v3 total.**

| Research family | Saved result | Decision |
|---|---|---|
| Motion-triggered event forecasts | USD 1,595 standalone on development validation; USD 746 above its same-event price/clock benchmark | Useful information, but combined execution stress loses USD 778; not promoted |
| Post-formation ETF/basket loops | USD 920 standalone on development validation | Six-second latency changes mean to USD -346; not promoted |
| Conditional formation inventory | USD 24 above matched fixed-time control | Almost entirely fee savings; no substantial directional alpha or combined-account improvement |
| Causal formation exits | USD -19 against identical-inventory fixed-second-100 exit | A more complex exit did not improve mean PnL over the proper timing control |
| Insurance loss-distribution analogs | Best of 12 inner candidates: USD -18 | Rejected before opening development validation |
| Public-state economic bounds | USD 17 standalone on development validation | Sparse, small opportunity; only USD 1.49 at eight-second latency; not integrated |
| Quote-cost-aware basket routing | USD -5.39 relative to matched routing control on retrospective validation | Apparent quote savings did not survive actual sequential execution |
| Nonlinear rebuilder tangent hedges | Zero eligible trades in the saved inner runs at both tested contract sizes | Costs, uncertainty and integer hedge rounding eliminated the opportunities |

### Motion information

A fixed regularized linear model forecasts a 60-second price move after an assumed two-second arrival delay. It trades only when measured velocity or projected company wind exposure changes materially. Features use current and past observed paths, public reports, guidance and prices; realized future paths are not inputs.

There were 12 declared event/horizon policies. All failed the combined-stress requirement on the inner sample. One frozen diagnostic was then evaluated on seasons 121–240. Its USD 1,595 mean falls to USD 886 at six-second latency and USD 383 with doubled modeled costs; combining six-second latency, doubled costs and another 10 bps of adverse execution produces USD -778. About 89% of its baseline PnL originates from decisions at or after real second 210, so this is not solely another formation trade.

### ETF lead–lag, not free arbitrage

Measured ETF/basket discrepancies often reflect delayed adjustment. For a conversion loop, the acquisition price and each later hedge price matter; a same-timestamp basket difference is not locked-in profit. The selected diagnostic's mean changes from USD 920 to USD -346 when latency increases from two to six seconds. A simpler directional ETF trade was also a serious inner-sample comparator. Neither result establishes an unconditional, independently additive arbitrage sleeve.

### Routing costs

The parameter-free route-cost follow-up held target inventory, entry time and exit time fixed and changed conversion quantities only. On the saved 120-season retrospective validation, it lost USD 5.39 relative to maximal-common-basket routing, with a conditional paired interval of approximately USD -15.45 to USD 4.42. Both policies flattened at the same latest time in the baseline scenario. Static quoted savings are therefore insufficient justification to replace the existing route.

## 3. Promising work that remains incomplete

The turnover follow-up kept the event model, thresholds and position size fixed. It tested retaining exposure when fresh same-direction information arrived, rather than repeatedly paying to close and reopen.

| Inner seasons 241–360 only | Baseline mean | Combined-stress mean |
|---|---:|---:|
| Original fixed-60-second exit | USD 1,482 | USD -946 |
| Retain at expiry on fresh supporting event | USD 1,927 | USD -166 |
| Refresh target expiry on qualifying events | USD 2,363 | USD -376 |

The highest baseline improvement is USD 881. It reflects both better gross capture and less turnover. However, **these are inner-selection results, not completed validation**, and both challengers still have negative combined-stress means. No new full-account result or production recommendation follows.

A continuous-budget wrapper was also implemented to let the later engine start when formation inventory is flat and actual action capacity is available, instead of always waiting 60 seconds. Four synthetic tests passed before the interruption. Historical paired evaluation was not completed. It must not be credited with any PnL gain.

The receipt-aware feed adapter and nonlinear hedge follow-up are saved as research work in progress. The canonical feed timing scan was not completed; no blanket claim is made that historical timing issues are absent. No v4 final combined-candidate assessment on seasons 1–120 was completed.

## 4. Testing framework and audit findings

### Research separation

The dataset had already informed prior versions. There is **no fresh global holdout** among these 600 seasons. V4 restricted candidate research to seasons 121–600, with 361–600 for initial fitting, 241–360 for inner selection and 121–240 for frozen development validation after refitting on 241–600. All three storms stay with their season. Follow-up reuse of validation is explicitly retrospective.

Candidate grids and rejection rules were declared before their respective scoring. Negative candidates are retained. Neither bootstrap confidence intervals nor a new split erase adaptive research history. Season-level uncertainty is the appropriate sampling unit; individual ticks are not independent trials. Live announcements are absent from the historical training data.

### Execution assumptions

The primary baseline is 25 bps plus USD 0.02/share/side, two real seconds of latency, 50 market shares per symbol per two-second interval, and 60 actions per rolling real minute for one key. ETF conversions cost no fee and change no cash, but consume actions and inventory capacity. Separate fills are charged at their modeled arrival times. Stress configurations differ by research family and are recorded alongside results; they must not be compared as identical tests.

### Independent audit

The audit passed 39 original tests and 11 additional independent checks. Some additional checks intentionally demonstrate defects rather than certify their absence. Nominal ETF cash conservation, delayed fill accounting and the routed engine's separate-side pending reservations passed.

Important findings:

1. **Cross-round rate history:** legacy simulators reset action history by round. A separate audit of saved frozen schedules showed v3 has zero violations across all 600 seasons even if rounds are contiguous; its maximum is exactly 60. The older v2 schedule exceeds 60 in 229 seasons under a zero-gap assumption, reaching 72. A verified pause of at least 60 real seconds removes this overlap. Thus the earlier v2 comparison requires its round-gap assumption; v3's saved schedule does not fail this specific check.
2. **Delayed publication:** the historical preparation code indexes storm measurements by age rather than publication time. A delayed measurement can appear too early in a synthetic replay. Its frequency or impact in the canonical supplied feed has not been established.
3. **Reordered reports:** synthetic out-of-order archives can replace a final report with a preliminary report or cause prefix readers to stop prematurely. Canonical sorted examples pass; live recovery still needs receipt-order handling and final precedence.
4. **Long-latency pending orders:** the older tail simulator can under-reserve opposing pending orders in a 22-second-latency counterexample. The published up-to-12-second scenarios were not shown to be affected. The route engine uses separate positive and negative reservations.
5. **Partial fills and varying latency:** live partial remainders can strand a route, and variable latency can bunch fills beyond assumed instantaneous capacity. Missing passive fills are not automatically conservative because they can be adverse. These require an acknowledgment-aware live executor.

The highest-value next evidence is actual testnet orderbooks and acknowledged fills, plus completion of the shared-account and receipt-time checks. Another large search over the same house-price paths would not solve those uncertainties.

## 5. Deliverable status

The v4 download is a **recovered research snapshot**, not a connected exchange bot or an approved replacement for v3. It contains source, preregistrations, frozen settings, compact saved result tables, audit findings and explicit incomplete-work markers. Raw data, large prediction caches and model pickle files are omitted from the compact archive. Existing reproducible v3 outputs remain in the previously supplied v3 package.

No completed experiment was restarted during recovery. The retained strategy and the negative-result record are the outcome of this research window; the unvalidated turnover and shared-account ideas remain clearly separated from established results.
