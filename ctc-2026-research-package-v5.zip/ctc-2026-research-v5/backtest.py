"""A causal, taker-only *consensus-price scenario*, not an order-book replay.

All decisions use t information. Fills use t+latency consensus plus costs.
One outstanding order per simulated account; at most one new order every 2s.
No passive fills, artificial mid fills, fees on settlement, or forced round closes.
"""

import numpy as np

from common import LIMITS


def phase(t):
    return int(np.searchsorted([60, 180, 540, 570, 740], t, side="right"))


def uncertainty(predictions, truth, times, mask):
    error = predictions[mask] - truth[mask, None, None, :]
    scales = np.empty((3, 6, 12))
    for r in range(3):
        for p in range(6):
            selected = np.array([phase(t) == p for t in times])
            scales[r, p] = np.maximum(
                np.sqrt(np.mean(error[:, r, selected] ** 2, axis=(0, 1))), 0.10
            )
    return scales


def simulate(
    market,
    truth,
    forecasts,
    times,
    scales,
    *,
    start="all",
    fraction=0.5,
    z=0.5,
    edge_floor=0.10,
    cost_bps=25,
    fixed_cost=0.02,
    latency=2,
    fill_cap=50,
    fill_fraction=1.0,
    adverse_bps=0.0,
    symbols=None,
):
    """USD cash ledger. Latency rounds up to the next observable 2s sample.

    Costs are per side: cost_bps * arrival consensus + fixed_cost. The fill
    assumptions are configurable and unverified until recorded testnet books exist.
    Partial filling uses a fixed fraction and cancels the remainder (one extra
    action), with no passive fill credit. No cancellation latency is modeled.
    """
    n = len(market)
    q = np.zeros((n, 12), dtype=int)
    cash = np.zeros(n)
    actions = np.zeros(n, dtype=int)
    traded = np.zeros(n)
    paid_cost = np.zeros(n)
    peak = np.zeros(n)
    drawdown = np.zeros(n)
    pending_symbol = np.full(n, -1, dtype=int)
    pending_qty = np.zeros(n, dtype=int)
    pending_at = np.full(n, -1, dtype=int)
    attribution = np.zeros((n, 12))
    last_order = np.full(n, -1000)
    limit = np.floor(LIMITS * fraction).astype(int)
    delay = max(1, int(np.ceil(latency / 2)))
    selected_symbols = np.ones(12, dtype=bool)
    if symbols is not None:
        selected_symbols[:] = False
        selected_symbols[symbols] = True
    marks = []
    for r in range(3):
        for ti in range(390):
            t = ti * 2
            now = r * 390 + ti
            price = market[:, r, ti]
            ready = np.where(pending_at == now)[0]
            if len(ready):
                j = pending_symbol[ready]
                requested = pending_qty[ready]
                qty = np.sign(requested) * np.floor(
                    np.abs(requested) * fill_fraction
                ).astype(int)
                reference = price[ready, j]
                unit_cost = reference * (cost_bps + adverse_bps) / 10000 + fixed_cost
                execution = reference + np.sign(qty) * unit_cost
                cash[ready] -= qty * execution
                q[ready, j] += qty
                attribution[ready, j] -= qty * execution
                paid_cost[ready] += np.abs(qty) * unit_cost
                traded[ready] += np.abs(qty)
                if fill_fraction < 1:
                    actions[ready] += 1  # cancel unfilled remainder
                    last_order[ready] = now
                pending_at[ready] = -1
            wealth = cash + np.sum(q * price, axis=1)
            peak = np.maximum(peak, wealth)
            drawdown = np.maximum(drawdown, peak - wealth)
            if ti % 5 == 0:
                marks.append(wealth.copy())
            enabled = start == "all" or (
                r == 2
                and (
                    start == "round3"
                    or (start == "poststorm" and t >= 540)
                    or (start == "preliminary" and t >= 570)
                    or (start == "final" and t >= 740)
                )
            )
            if not enabled or ti + delay >= 390:
                continue
            pi = int(np.searchsorted(times, t, side="right") - 1)
            fair = forecasts[:, r, pi]
            edge = fair - price
            side = np.sign(edge).astype(int)
            room = limit[None, :] - q * side
            qty = np.minimum(fill_cap, room)
            cost = price * cost_bps / 10000 + fixed_cost
            surplus = np.abs(edge) - cost - edge_floor - z * scales[r, phase(t)]
            score = surplus * qty
            score[(qty <= 0) | ~selected_symbols[None, :]] = -np.inf
            j = np.argmax(score, axis=1)
            # At most 30 place actions/min; partial fills add <=30 cancels/min.
            valid = (pending_at < 0) & (last_order < now) & (score[np.arange(n), j] > 0)
            i = np.where(valid)[0]
            pending_symbol[i] = j[i]
            pending_qty[i] = qty[i, j[i]] * side[i, j[i]]
            pending_at[i] = now + delay
            actions[i] += 1
            last_order[i] = now
    assert np.all(np.abs(q) <= limit)
    assert np.all(pending_at == -1)
    pnl = cash + np.sum(q * truth, axis=1)
    attribution += q * truth
    assert np.allclose(attribution.sum(1), pnl)
    drawdown = np.maximum(drawdown, peak - pnl)
    return {
        "pnl": pnl,
        "positions": q,
        "actions": actions,
        "turnover_shares": traded,
        "cost": paid_cost,
        "drawdown": drawdown,
        "attribution": attribution,
        "mark_curve": np.stack(marks, axis=1),
    }


def summarize(result):
    pnl = result["pnl"]
    return {
        "seasons": len(pnl),
        "mean_usd": float(pnl.mean()),
        "median_usd": float(np.median(pnl)),
        "win_rate": float(np.mean(pnl > 0)),
        "minimum_usd": float(pnl.min()),
        "p05_usd": float(np.quantile(pnl, 0.05)),
        "p95_usd": float(np.quantile(pnl, 0.95)),
        "worst_5pct_mean_usd": float(
            np.sort(pnl)[: max(1, int(np.ceil(len(pnl) * 0.05)))].mean()
        ),
        "std_usd": float(pnl.std(ddof=1)),
        "mean_actions": float(result["actions"].mean()),
        "mean_turnover_shares": float(result["turnover_shares"].mean()),
        "mean_cost_usd": float(result["cost"].mean()),
        "mean_max_drawdown_usd": float(result["drawdown"].mean()),
    }
