"""Describe already-frozen routes without selecting any new trading parameters."""

import json
from pathlib import Path

import numpy as np
import pandas as pd

from common import dump_json, load_cache
from etf_route_v3 import simulate_routes
from pnl_v2_select import inputs


def main():
    records = []
    for fold in range(5):
        config = json.loads(Path(f"results_v3/fold-{fold}-frozen.json").read_text())[
            "config"
        ]
        ids, args = inputs(fold, "test")
        result = simulate_routes(
            args[0], args[1], args[4], **config["formation_route"], audit=True
        )
        evaluated = load_cache(f"results_v3/fold-{fold}-outer-results.npz")
        np.testing.assert_allclose(
            result["pnl"], evaluated["base__by_engine"][:, 0], atol=1e-8
        )
        for j, season in enumerate(ids):
            records.append(
                {
                    "season": int(season + 1),
                    "fold": fold,
                    "formation_pnl_usd": result["pnl"][j],
                    "formation_actions": result["actions"][j],
                    "conversion_actions": result["conversion_actions"][j],
                    "formation_cost_usd": result["cost"][j],
                    "market_shares_traded": result["turnover_shares"][j],
                    "maximum_actions_at_one_tick": result["action_ticks"][j].max(),
                    **{
                        f"round_{r + 1}_flat_time": result["flat_times"][j, r]
                        for r in range(3)
                    },
                }
            )
    frame = pd.DataFrame(records).sort_values("season")
    frame.to_csv("results_v3/route_audit.csv", index=False)
    timing = frame[[f"round_{r}_flat_time" for r in [1, 2, 3]]].to_numpy()
    stats = {
        "mean_formation_actions_per_season": float(frame.formation_actions.mean()),
        "mean_conversion_actions_per_season": float(frame.conversion_actions.mean()),
        "maximum_actions_at_one_tick": int(frame.maximum_actions_at_one_tick.max()),
        "formation_flat_seconds_after_open": {
            "minimum": int(timing.min()),
            "mean": float(timing.mean()),
            "maximum": int(timing.max()),
        },
        "positions_after_each_round": "all zero; assertion checked during replay",
        "note": "Formation attribution matches the previously evaluated combined account exactly",
    }
    dump_json("results_v3/route_audit.json", stats)
    print(stats)


if __name__ == "__main__":
    main()
