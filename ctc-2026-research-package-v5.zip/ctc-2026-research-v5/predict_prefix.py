"""Demonstrate inference from public historical messages/quotes up to a cutoff.

Never opens manifest.json or settlement.json. This is an offline adapter, not an
exchange connection. Returns forecasts, not live orders.
"""

import argparse
import csv
import json
import pickle
from pathlib import Path

import numpy as np

from common import ISLANDS, OUTLOOKS, PHYSICAL, SYMBOLS, real_second, with_etfs
from models import features


def public_prefix(root, season, round_number, second):
    root = Path(root)
    case = json.loads((root / "case.json").read_text())
    d = {
        "market": np.ones((1, 3, 390, 12)),
        "obs": np.zeros((1, 3, 241, 6)),
        "damage": np.zeros((1, 3, 390, 5)),
        "loss": np.zeros((1, 3, 390)),
        "stage": np.zeros((1, 3, 390)),
        "probability": np.zeros((1, 3, 390, 4)),
        "cone": np.zeros((1, 3, 390, 9)),
        "official": np.full((1, 3, 390), -1, dtype=int),
        "wire": np.full((1, 3, 390), -1, dtype=int),
    }
    d["obs"][..., 4] = 1  # unknown future has zero intensity, not a zero radius
    xy, weight, company = [], [], []
    for j, symbol in enumerate(PHYSICAL):
        for site in case["companies"][symbol]["sites"]:
            xy.append([site["x"], site["y"]])
            weight.append(site["weight"])
            company.append(j)
    d.update(
        site_xy=np.array(xy),
        site_weight=np.array(weight),
        site_company=np.array(company),
    )
    folder = root / "history" / f"season-{season:03d}"
    for row in csv.DictReader((folder / "market.csv").open()):
        r, t = int(row["round"]), real_second(row["time"])
        if r > round_number or (r == round_number and t > second):
            break
        d["market"][0, r - 1, int(t // 2)] = [float(row[s]) for s in SYMBOLS]
    seen = set()
    for line in (folder / "feed.jsonl").open():
        msg = json.loads(line)
        r, t = msg["round"], real_second(msg["time"])
        if r > round_number or (r == round_number and t > second):
            break
        if msg["seq"] in seen:
            continue
        seen.add(msg["seq"])
        r -= 1
        ti = int(np.ceil(t / 2))
        if msg["type"] == "storm":
            d["obs"][0, r, int(msg["age"] // 2)] = [
                msg[k] for k in ["x", "y", "vx", "vy", "radius", "intensity"]
            ]
        elif msg["type"] == "damage_report":
            d["damage"][0, r, ti:] = [msg["damage_pct"][s] / 100 for s in PHYSICAL]
            d["loss"][0, r, ti:] = msg["industry_loss_musd"]
            d["stage"][0, r, ti:] = 2 if msg["stage"] == "final" else 1
        elif msg["type"] == "advisory":
            d[msg["source"]][0, r, ti:] = OUTLOOKS.index(msg["outlook"])
            if msg["source"] == "official":
                d["probability"][0, r, ti:] = [
                    msg["hurricane_conditions"][k] for k in ISLANDS
                ]
                pts = msg["cone"]
                if pts:
                    ages = [q["age"] for q in pts]
                    values = []
                    for lead in [60, 120, 240]:
                        values.extend(
                            [
                                np.interp(msg["age"] + lead, ages, [q[k] for q in pts])
                                for k in ["x", "y", "spread"]
                            ]
                        )
                    d["cone"][0, r, ti:] = values
    return d


def predict(d, round_number, second, short_models, structural):
    r, tick = round_number - 1, int(second // 2)
    x, damage, outage, loss = features(d, [second])
    prev = features(d, [max(0, second - 10)])[0]
    now = d["market"][0, r, tick]
    lag10 = d["market"][0, r, max(0, tick - 5)]
    lag30 = d["market"][0, r, max(0, tick - 15)]
    vector = np.r_[
        x[0, r, 0], x[0, r, 0] - prev[0, r, 0], now, now - lag10, now - lag30
    ]
    delta = with_etfs(np.array([m.predict(vector[None])[0] for m in short_models]))
    result = {
        "round": round_number,
        "second_after_open": second,
        "currency": "USD",
        "next_10s_price_change": dict(zip(SYMBOLS, delta.tolist())),
    }
    if round_number == 3 and second >= 740 and d["stage"][0, r, tick] == 2:
        fair = structural.predict(damage[0, r, 0], outage[0, r, 0], loss[0, r, 0])
        result["settlement_value_estimate"] = dict(zip(SYMBOLS, fair.tolist()))
    return result


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("data")
    ap.add_argument("--season", type=int, required=True)
    ap.add_argument("--round", type=int, choices=[1, 2, 3], required=True)
    ap.add_argument("--second", type=int, required=True)
    args = ap.parse_args()
    if args.second not in range(0, 780, 10):
        ap.error("second must be a 10-second decision-grid point from 0 through 770")
    d = public_prefix(args.data, args.season, args.round, args.second)
    with open("short_models.pkl", "rb") as f:
        short_models = pickle.load(f)
    with open("models.pkl", "rb") as f:
        structural = pickle.load(f)["structural"]
    print(
        json.dumps(
            predict(d, args.round, args.second, short_models, structural), indent=2
        )
    )
