# CTC 2026 local research kit

**Version 2 follow-up:** see `README_V2.md` and `REPORT_V2.md` for the mean-PnL
optimization, nested season validation and shared-account execution simulator.
The v1 methods and results below are retained as the original reference.

Start with **REPORT.md** or the accompanying PDF. `results/` contains the frozen
holdout results, execution stress tests and charts. All monetary results use USD.

## Reproduce from the supplied archive

Python 3.12+ is required for the pinned environment (the recorded run used the versions in
`environment.json`). Keep the original data outside this project.

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements-lock.txt
unzip hurricane-season-research.zip -d ../data
python run_research.py ../data/hurricane-season-research
python -m pytest -q
```

The runner fits on seasons 600–241, selects on 240–121, and evaluates on 120–1.
It writes caches, predictions and results in the current directory. Re-running
the published evaluation reproduces a used test set; it does not create a fresh
holdout for new strategy choices. No network/exchange access is performed.

To run the stages separately:

```bash
python prepare.py ../data/hurricane-season-research --out cache.npz
OMP_NUM_THREADS=4 OPENBLAS_NUM_THREADS=1 python train.py
python validate.py
OMP_NUM_THREADS=4 OPENBLAS_NUM_THREADS=1 python short_horizon.py
python select_engines.py
python evaluate.py
python diagnostics.py
```

To demonstrate inference using only public data up to a cutoff:

```bash
OMP_NUM_THREADS=1 python predict_prefix.py ../data/hurricane-season-research \
  --season 180 --round 3 --second 740
```

This opens `case.json`, the selected season's feed and its consensus-price CSV.
It never opens the manifest or settlements. It outputs forecasts, not orders.

## Main modules

- `prepare.py`: public as-of data cube and separately labeled truth arrays.
- `models.py`: fitted economics, site exposure/outages and causal features.
- `short_horizon.py`: ten-second price-response model and taker scenario replay.
- `endgame.py`: final-report limit-order replay with inventory reservations.
- `backtest.py`: exploratory terminal-value directional replay and metrics.
- `protocol.py`: pure feed, position, conversion and rate-limit primitives.
- `predict_prefix.py`: independent public-only prefix inference adapter.
- `validate.py`, `select_engines.py`: development-only policy selection.
- `evaluate.py`: locked holdout and execution sensitivity.
- `diagnostics.py`: post-selection interpretation and validation-only timer benchmark.
- `explore_physics.py`, `identify_models.py`, `explore_damage.py`: training-only
  structural identification experiments; optional, not required for reproduction.

## Included model artifacts

`models.pkl` contains the fitted structural model and exploratory directional
models. `short_models.pkl` contains the selected short-horizon regressors.
Their model/feature definitions are in the source; use the recorded dependency
versions for compatible deserialization. Raw research data and large intermediate
caches are omitted from the download because they are regenerated from your ZIP.

## Execution model

Default costs are 25 bps plus USD 0.02 per share per side, latency is 2 real
seconds, and the assumed fill cap is 50 shares. No actual books were supplied.
Final-report orders have valuation-based limits, reserve unfilled quantities, and
receive no passive-fill credit. Short-cycle orders use hypothetical taker fills.
Settlement does not pay an invented closing spread.

The selected short engine uses at most 18 order actions per rolling minute,
closes before the last round's final report, and reserves 20 endgame actions.
Position limits are per symbol; ETF look-through exposures remain correlated.

`protocol.py` is not a production exchange client. Testnet integration still
needs the provided starter kit's connection handling, authenticated account
reconciliation, real orderbook sizes, price protection and announcement handling.

## Important result interpretation

- The reported holdout is simulated-season out-of-sample, not a live execution test.
- Most short-engine profit comes from the formation response before the first advisory.
- Twelve-second delayed execution loses money in the measured scenario.
- The upper REIN payout cap is unidentifiable from the observed loss range.
- Announcements are absent from the research data and can invalidate fitted values.
- No Ramp repository was modified; this directory is a standalone local project.
