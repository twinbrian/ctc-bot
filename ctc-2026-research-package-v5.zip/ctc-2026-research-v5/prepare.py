"""Read public feed into an as-of cube. Truth stays in separately named arrays."""

import argparse
import csv
import hashlib
import json
from pathlib import Path

import numpy as np

from common import ISLANDS, OUTLOOKS, PHYSICAL, SYMBOLS, dump_json, real_second


def prepare(root, output):
    root, output = Path(root), Path(output)
    case = json.loads((root / "case.json").read_text())
    manifest = json.loads((root / "history/manifest.json").read_text())["seasons"]
    n, rounds, ticks = len(manifest), 3, 390
    market = np.zeros((n, rounds, ticks, 12))
    obs = np.full((n, rounds, 241, 6), np.nan)
    damage = np.zeros((n, rounds, ticks, 5))
    loss = np.zeros((n, rounds, ticks))
    stage = np.zeros((n, rounds, ticks), dtype=int)
    official = np.full((n, rounds, ticks), -1, dtype=int)
    wire = np.full_like(official, -1)
    probability = np.zeros((n, rounds, ticks, 4))
    # Latest cone at each 2-second decision tick: positions at relative 60/120/240s.
    cone = np.zeros((n, rounds, ticks, 9))
    report_truth = np.zeros((n, rounds, 5))
    loss_truth = np.zeros((n, rounds))
    settlement_truth = np.zeros((n, 12))
    pattern_truth = np.zeros((n, rounds), dtype=int)
    erratic_truth = np.full((n, rounds), np.inf)
    advisories = []
    site_xy, site_weight, site_company = [], [], []
    for j, symbol in enumerate(PHYSICAL):
        for site in case["companies"][symbol]["sites"]:
            site_xy.append([site["x"], site["y"]])
            site_weight.append(site["weight"])
            site_company.append(j)
    digest = hashlib.sha256()
    for season in manifest:
        i = season["season"] - 1
        p = root / "history" / season["dir"]
        for name in ["market.csv", "feed.jsonl", "settlement.json"]:
            digest.update((p / name).read_bytes())
        for row in csv.DictReader((p / "market.csv").open()):
            r = int(row["round"]) - 1
            t = int(real_second(row["time"]) // 2)
            assert 0 <= t < ticks
            market[i, r, t] = [float(row[s]) for s in SYMBOLS]
        settlement = json.loads((p / "settlement.json").read_text())
        settlement_truth[i] = [settlement[s] for s in SYMBOLS]
        for storm in season["storms"]:
            r = storm["round"] - 1
            report_truth[i, r] = [storm["damage_pct"][s] / 100 for s in PHYSICAL]
            loss_truth[i, r] = storm["industry_loss_musd"]
            pattern_truth[i, r] = OUTLOOKS.index(storm["pattern"])
            if storm["turned_erratic_at"] is not None:
                erratic_truth[i, r] = storm["turned_erratic_at"]
        seen = set()
        for line in (p / "feed.jsonl").read_text().splitlines():
            msg = json.loads(line)
            if msg.get("seq") in seen:
                continue
            seen.add(msg.get("seq"))
            r = msg["round"] - 1
            # Never reveal a message before its publication, even at odd real seconds.
            t = int(np.ceil(real_second(msg["time"]) / 2))
            if msg["type"] == "storm":
                obs[i, r, int(msg["age"] // 2)] = [
                    msg[k] for k in ["x", "y", "vx", "vy", "radius", "intensity"]
                ]
            elif msg["type"] == "damage_report":
                damage[i, r, t:] = [msg["damage_pct"][s] / 100 for s in PHYSICAL]
                loss[i, r, t:] = msg["industry_loss_musd"]
                stage[i, r, t:] = 2 if msg["stage"] == "final" else 1
            elif msg["type"] == "advisory":
                v = OUTLOOKS.index(msg["outlook"])
                truth = 5 if msg["age"] >= erratic_truth[i, r] else pattern_truth[i, r]
                advisories.append(
                    [
                        i + 1,
                        r + 1,
                        msg["age"],
                        int(msg["source"] == "official"),
                        v,
                        truth,
                    ]
                )
                if msg["source"] == "official":
                    official[i, r, t:] = v
                    probability[i, r, t:] = [
                        msg["hurricane_conditions"][k] for k in ISLANDS
                    ]
                    pts = msg["cone"]
                    if pts:
                        ages = [q["age"] for q in pts]
                        values = []
                        for lead in [60, 120, 240]:
                            values.extend(
                                [
                                    np.interp(
                                        msg["age"] + lead, ages, [q[k] for q in pts]
                                    )
                                    for k in ["x", "y", "spread"]
                                ]
                            )
                        cone[i, r, t:] = values
                else:
                    wire[i, r, t:] = v
    assert np.isfinite(market).all() and (market > 0).all()
    # The publisher may stop observations at age 478 instead of publishing 480.
    assert np.isfinite(obs[:, :, :240]).all()
    output.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(
        output,
        market=market,
        obs=obs,
        damage=damage,
        loss=loss,
        stage=stage,
        official=official,
        wire=wire,
        probability=probability,
        cone=cone,
        report_truth=report_truth,
        loss_truth=loss_truth,
        settlement_truth=settlement_truth,
        pattern_truth=pattern_truth,
        erratic_truth=erratic_truth,
        advisories=np.array(advisories),
        site_xy=site_xy,
        site_weight=site_weight,
        site_company=site_company,
    )
    dump_json(
        output.with_suffix(".audit.json"),
        {
            "seasons": n,
            "storms": n * 3,
            "market_rows": n * rounds * ticks,
            "input_sha256": digest.hexdigest(),
            "symbols": SYMBOLS,
            "split": {"train": "600..241", "validation": "240..121", "test": "120..1"},
            "currency": "USD",
            "time_unit": "real_seconds",
        },
    )
    print(output, "prepared", n, "seasons")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("data")
    ap.add_argument("--out", default="cache.npz")
    args = ap.parse_args()
    prepare(args.data, args.out)
