"""Structural economics, fitted only on development seasons."""

import numpy as np
from scipy.optimize import least_squares

from common import with_etfs


def weather(d):
    obs = d["obs"][:, :, :240]
    distance = np.linalg.norm(obs[..., None, :2] - d["site_xy"], axis=-1)
    wind = obs[..., None, 5] * np.exp(-((distance / obs[..., None, 4]) ** 2))
    weights = np.zeros((17, 5))
    weights[np.arange(17), d["site_company"]] = d["site_weight"]
    # Age 0 has no elapsed interval; subsequent samples close the preceding 2s.
    elapsed = np.ones(240) * 2
    elapsed[0] = 0
    outage = (
        np.cumsum((wind >= 0.35) * elapsed[None, None, :, None] / 120, axis=2) @ weights
    )
    # Include the final 478..480 interval only at/after dissipation.
    final_outage = outage[:, :, -1] + (wind[:, :, -1] >= 0.35) @ weights * 2 / 120
    exposure = np.cumsum(wind * elapsed[None, None, :, None], axis=2)
    peak = np.maximum.accumulate(wind, axis=2)
    return wind, outage, final_outage, exposure, peak


class StructuralModel:
    def fit(self, damage, outage, loss, values):
        self.physical = []
        for j in range(5):
            columns = [np.ones(len(values)), damage[:, j]]
            if j in [0, 3, 4]:
                columns.append(outage[:, j])
            self.physical.append(
                np.linalg.lstsq(np.column_stack(columns), values[:, j], rcond=None)[0]
            )
        self.insurers = []
        for j, attachment in [(8, 400), (9, 1300)]:
            if j == 8:
                f = least_squares(
                    lambda p: (
                        p[0] - p[1] * np.clip(loss - p[2], 0, p[3]) - values[:, j]
                    ),
                    [75, 0.06, attachment, 900],
                    bounds=(0, np.inf),
                )
            else:
                # No detachment observed: do not pretend its cap is identified.
                f = least_squares(
                    lambda p: p[0] - p[1] * np.maximum(loss - p[2], 0) - values[:, j],
                    [90, 0.035, attachment],
                    bounds=(0, np.inf),
                )
            self.insurers.append(f.x)
        self.rebuild = []
        for j, indices in [(5, [0, 3, 4]), (6, list(range(5))), (7, [3])]:
            x = outage[:, indices] if j == 7 else damage[:, indices]
            f = least_squares(
                lambda p: p[0] + p[1] * (1 - np.exp(-x @ p[2:])) - values[:, j],
                np.r_[32, 20, np.full(x.shape[1], 0.5)],
                bounds=(0, np.inf),
                max_nfev=1000,
            )
            self.rebuild.append(f.x)
        self.insured_weights = np.linalg.lstsq(damage, loss, rcond=None)[0]
        self.max_training_loss = float(loss.max())
        return self

    def predict(self, damage, outage, loss):
        values = np.empty((*damage.shape[:-1], 10))
        for j, p in enumerate(self.physical):
            values[..., j] = p[0] + p[1] * damage[..., j]
            if len(p) == 3:
                values[..., j] += p[2] * outage[..., j]
        for j, indices, p in zip(
            [5, 6, 7], [[0, 3, 4], list(range(5)), [3]], self.rebuild
        ):
            x = outage[..., indices] if j == 7 else damage[..., indices]
            values[..., j] = p[0] + p[1] * (1 - np.exp(-x @ p[2:]))
        for j, p in zip([8, 9], self.insurers):
            layer = np.maximum(loss - p[2], 0)
            if len(p) == 4:
                layer = np.minimum(layer, p[3])
            values[..., j] = p[0] - p[1] * layer
        return with_etfs(values)

    def parameters(self):
        return {
            "physical": [x.tolist() for x in self.physical],
            "rebuild": [x.tolist() for x in self.rebuild],
            "insurers": [x.tolist() for x in self.insurers],
            "insured_weights": self.insured_weights.tolist(),
            "max_training_loss_musd": self.max_training_loss,
            "wind_kernel": "intensity * exp(-(distance/radius)^2)",
            "closure_threshold": 0.35,
            "outage_unit": "site-weighted market hours",
        }


def features(d, times):
    """No manifest truth or settlement access. Each row is a feed prefix."""
    wind, outage, final_outage, exposure, peak = weather(d)
    n = len(d["market"])
    prior_damage = np.concatenate(
        [np.zeros((n, 1, 5)), np.cumsum(d["damage"][:, :-1, -1], axis=1)], axis=1
    )
    prior_loss = np.concatenate(
        [np.zeros((n, 1)), np.cumsum(d["loss"][:, :-1, -1], axis=1)], axis=1
    )
    prior_outage = np.concatenate(
        [np.zeros((n, 1, 5)), np.cumsum(final_outage[:, :-1], axis=1)], axis=1
    )
    all_features = []
    causal_outage, causal_damage, causal_loss = [], [], []
    for r in range(3):
        rows = []
        os, ds, ls = [], [], []
        for t in times:
            tick = int(t // 2)
            age = t - 60
            oi = int(np.clip(age // 2, 0, 239))
            active = int(age >= 0)
            current_outage = (
                outage[:, r, oi] * active if t < 540 else final_outage[:, r]
            )
            total_outage = prior_outage[:, r] + current_outage
            report = d["damage"][:, r, tick]
            total_damage = prior_damage[:, r] + report
            total_loss = prior_loss[:, r] + d["loss"][:, r, tick]
            x = [
                np.tile([r + 1, age], (n, 1)),
                prior_damage[:, r],
                prior_loss[:, r, None],
                prior_outage[:, r],
                current_outage,
                d["obs"][:, r, oi] * active,
                exposure[:, r, oi] * active,
                peak[:, r, oi] * active,
                wind[:, r, oi] * int(0 <= age < 480),
                report,
                d["loss"][:, r, tick, None],
                d["stage"][:, r, tick, None],
                d["probability"][:, r, tick],
                d["cone"][:, r, tick],
            ]
            for source in ["official", "wire"]:
                x.append(np.eye(7)[d[source][:, r, tick] + 1])
            rows.append(np.concatenate(x, axis=1))
            os.append(total_outage)
            ds.append(total_damage)
            ls.append(total_loss)
        all_features.append(np.stack(rows, axis=1))
        causal_outage.append(np.stack(os, axis=1))
        causal_damage.append(np.stack(ds, axis=1))
        causal_loss.append(np.stack(ls, axis=1))
    return (
        np.stack(all_features, axis=1),
        np.stack(causal_damage, axis=1),
        np.stack(causal_outage, axis=1),
        np.stack(causal_loss, axis=1),
    )
