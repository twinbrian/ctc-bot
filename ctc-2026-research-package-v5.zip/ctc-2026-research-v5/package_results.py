"""Build the local, self-contained source/model/results download."""

import hashlib
import json
import platform
import shutil
import sys
from importlib.metadata import version
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile


def digest(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def main():
    root = Path(__file__).parent
    packages = ["numpy", "pandas", "scipy", "scikit-learn", "matplotlib", "pytest"]
    versions = {p: version(p) for p in packages}
    (root / "requirements-lock.txt").write_text(
        "\n".join(f"{p}=={v}" for p, v in versions.items()) + "\n"
    )
    environment = {
        "python": sys.version,
        "platform": platform.platform(),
        "packages": versions,
        "optional_pdf_renderer": {"reportlab": version("reportlab")},
        "random_seed": 2026,
        "model_threads": {"OMP_NUM_THREADS": 4, "OPENBLAS_NUM_THREADS": 1},
    }
    (root / "environment.json").write_text(json.dumps(environment, indent=2) + "\n")
    cert = {
        "unit_tests_passed": 14,
        "public_prefix_checkpoints_passed": 6,
        "training_seasons": "600..241",
        "validation_seasons": "240..121",
        "holdout_seasons": "120..1",
        "frozen_config_sha256": digest(root / "results/engines_frozen.json"),
        "input_audit": json.loads((root / "cache.audit.json").read_text()),
        "result_type": "Hypothetical consensus-price execution scenarios; no order-book data or live trades",
        "repository_changes": False,
    }
    supplied = Path("/tmp/files/f977-hurricane-season-research.zip")
    if supplied.exists():
        cert["original_data_zip_sha256"] = digest(supplied)
    (root / "results/reproduction_certificate.json").write_text(
        json.dumps(cert, indent=2) + "\n"
    )
    files = sorted(
        list(root.glob("*.py"))
        + list(root.glob("*.md"))
        + list(root.glob("requirements*.txt"))
        + list(root.glob("*.pkl"))
        + list(root.glob("environment.json"))
        + list(root.glob("cache.audit.json"))
        + list((root / "tests").glob("*.py"))
        + [p for p in (root / "results").iterdir() if p.is_file()]
    )
    manifest = {str(p.relative_to(root)): digest(p) for p in files}
    (root / "SHA256SUMS.json").write_text(json.dumps(manifest, indent=2) + "\n")
    files.append(root / "SHA256SUMS.json")
    archive = root.parent / "ctc-2026-research-kit-v1.zip"
    with ZipFile(archive, "w", ZIP_DEFLATED, compresslevel=6) as z:
        for p in files:
            z.write(p, "ctc-2026-research-kit-v1/" + str(p.relative_to(root)))
        pdf = root.parent / "ctc-2026-research-report-v1.pdf"
        z.write(pdf, "ctc-2026-research-kit-v1/" + pdf.name)
    shutil.copyfile(
        root / "results/formation-signal.png",
        root.parent / "ctc-2026-formation-signal-v1.png",
    )
    shutil.copyfile(
        root / "results/research-dashboard.png",
        root.parent / "ctc-2026-research-dashboard-v1.png",
    )
    with ZipFile(archive) as z:
        assert z.testzip() is None
    print(f"Packaged {len(files) + 1} files; {archive.stat().st_size / 1e6:.2f} MB")


if __name__ == "__main__":
    main()
