"""Exploratory kernel diagnostics; no policy or outer-PnL selection uses these.

These extend the v3 physics work after the trading policies were frozen. Only
original training and validation damage errors are reported, not outer errors.
"""

import numpy as np
import pandas as pd
from scipy.optimize import least_squares

from common import dump_json, load_cache, partitions
from physics_v3 import geometry


def main():
    d = load_cache("cache.npz")
    train, val, _ = partitions()
    rho, intensity = geometry(d)
    r, i = rho[..., 0], intensity[..., 0]
    target = d["report_truth"][..., 0].cumsum(1)
    rows = []
    for family in ["fixed_gaussian", "free_gaussian", "event_linear", "event_capped"]:

        def predict(p):
            k = p[0]
            power, beta = (1, 1) if family == "fixed_gaussian" else p[1:3]
            exposure = 2 * (i**power * np.exp(-beta * r**2) * (r <= 2)).sum(2)
            if family in ["fixed_gaussian", "free_gaussian"]:
                return 1 - np.exp(-k * exposure.cumsum(1))
            event = np.minimum(k * exposure, p[3] if len(p) > 3 else 0.999999)
            return 1 - np.cumprod(1 - event, axis=1)

        initial, lower, upper = [0.01], [0], [1]
        if family != "fixed_gaussian":
            initial += [1, 1]
            lower += [0, 0.1]
            upper += [4, 5]
        if family == "event_capped":
            initial += [0.95]
            lower += [0.2]
            upper += [1]
        fit = least_squares(
            lambda p: (predict(p)[train] - target[train]).ravel(),
            initial,
            bounds=(lower, upper),
            max_nfev=100,
        )
        row = {"family": family, "parameters": fit.x.tolist()}
        for split, mask in [("train", train), ("validation", val)]:
            row[split + "_rmse_pp"] = float(
                100 * np.sqrt(np.mean((predict(fit.x)[mask] - target[mask]) ** 2))
            )
        rows.append(row)

    dose = 2 * (i * np.exp(-(r**2)) * (r <= 2)).sum(2)
    before = target - d["report_truth"][..., 0]
    hazard = np.log(np.maximum(1 - before, 1e-6) / np.maximum(1 - target, 1e-6))
    rate = hazard / np.maximum(dose, 1e-8)
    valid = train[:, None] & (dose > 10)
    residual = {
        "sample": "training PORT storm exposures with integrated wind dose > 10",
        "storms": int(valid.sum()),
        "effective_rate_mean": float(rate[valid].mean()),
        "effective_rate_std": float(rate[valid].std(ddof=1)),
        "coefficient_of_variation": float(rate[valid].std(ddof=1) / rate[valid].mean()),
        "interpretation": "Residual rate variation, not proof of random simulator parameters",
    }
    dump_json(
        "results_v3/kernel_sensitivity.json", {"models": rows, "residual": residual}
    )
    print(pd.DataFrame(rows).to_string(index=False))
    print(residual)


if __name__ == "__main__":
    main()
