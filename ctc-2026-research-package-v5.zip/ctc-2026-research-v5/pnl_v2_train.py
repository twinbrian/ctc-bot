"""Post-selection nested season CV. Fits never include their outer-test seasons.

These are follow-up stability estimates, not a fresh lockbox: v1 research already
examined every season in some role. Each fold fits on 360 seasons, tunes on 120,
and evaluates on the other 120. Formation targets are fitted on training only.
"""

import pickle
from pathlib import Path

import numpy as np
from sklearn.ensemble import HistGradientBoostingRegressor

from common import SYMBOLS, dump_json, load_cache, with_etfs
from models import StructuralModel, features, weather
from train import TIMES


def masks(fold):
    block = np.arange(600) // 120
    test = block == fold
    val = block == (fold + 1) % 5
    return ~(test | val), val, test


def main():
    out = Path("results_v2")
    out.mkdir(exist_ok=True)
    d = load_cache("cache.npz")
    x, damage, outage, loss = features(d, TIMES)
    market = d["market"][:, :, TIMES // 2]
    change = x - np.concatenate([x[:, :, :1], x[:, :, :-1]], axis=2)
    lag10 = d["market"][:, :, np.maximum(TIMES - 10, 0) // 2]
    lag30 = d["market"][:, :, np.maximum(TIMES - 30, 0) // 2]
    predictors = np.concatenate(
        [x, change, market, market - lag10, market - lag30], axis=-1
    )
    target = d["market"][:, :, np.minimum(TIMES + 10, 778) // 2, :10] - market[..., :10]
    final_outage = weather(d)[2].sum(1)
    plan = {
        "objective": "maximize inner-validation mean net terminal USD PnL; no variance, tail-loss, or stress penalty",
        "folds": 5,
        "training_seasons_per_fold": 360,
        "inner_validation_seasons_per_fold": 120,
        "outer_test_seasons_per_fold": 120,
        "qualification": "Post-selection nested CV on a previously examined simulator dataset; not a fresh independent lockbox",
        "cost_bps_each_side": 25,
        "fixed_cost_usd_each_side": 0.02,
        "latency_real_seconds": 2,
        "depth_per_symbol_per_2s": 50,
        "one_bot_actions_per_rolling_minute": 60,
        "formation_starts": [0, 20, 40, 50, 60],
        "formation_exit_starts": [70, 80, 100, 120],
        "formation_entry_action_budgets": [10, 20, 30, 45, 60],
        "ongoing_thresholds_usd": [0, 0.1, 0.25],
        "ongoing_top_k": [3, 5, 8],
        "ongoing_cycles_seconds": [10, 20],
        "endgame_margins_usd": [0, 0.05, 0.1, 0.2],
        "selection_procedure": "formation-only mean selection, then ongoing configurations conditional on best formation, then endgame margin; compare with ongoing-only alternatives",
    }
    dump_json(out / "research_plan.json", plan)
    for fold in range(5):
        train, val, test = masks(fold)
        predict_mask = val | test
        ids = np.flatnonzero(predict_mask)
        if fold == 0:
            predicted = load_cache("short_predictions.npz")["delta"][predict_mask]
            with open("models.pkl", "rb") as f:
                economic = pickle.load(f)["structural"]
            print("Fold 0: reused exactly matching training-only v1 fits", flush=True)
        else:
            predicted_stocks = np.empty((*predictors[predict_mask].shape[:-1], 10))
            models = []
            for j, symbol in enumerate(SYMBOLS[:10]):
                model = HistGradientBoostingRegressor(
                    max_iter=160,
                    max_leaf_nodes=15,
                    learning_rate=0.06,
                    l2_regularization=30,
                    min_samples_leaf=100,
                    early_stopping=False,
                    random_state=2026,
                )
                model.fit(
                    predictors[train, :, :-1].reshape(-1, predictors.shape[-1]),
                    target[train, :, :-1, j].ravel(),
                )
                predicted_stocks[..., j] = model.predict(
                    predictors[predict_mask].reshape(-1, predictors.shape[-1])
                ).reshape(predictors[predict_mask].shape[:-1])
                models.append(model)
                print("Fold", fold, symbol, "fitted", flush=True)
            predicted = with_etfs(predicted_stocks)
            economic = StructuralModel().fit(
                d["report_truth"][train].sum(1),
                final_outage[train],
                d["loss_truth"][train].sum(1),
                d["settlement_truth"][train],
            )
            with open(out / f"fold-{fold}-models.pkl", "wb") as f:
                pickle.dump({"short": models, "structural": economic}, f)
        fair = economic.predict(
            damage[predict_mask, 2, 74],
            outage[predict_mask, 2, 74],
            loss[predict_mask, 2, 74],
        )
        # A public schedule signal: training-average price trajectory. Never the
        # current outer season's future prices. Shape is round x tick x symbol.
        formation_curve = d["market"][train].mean(0)
        np.savez_compressed(
            out / f"fold-{fold}-predictions.npz",
            ids=ids,
            delta=predicted,
            final_fair=fair,
            formation_curve=formation_curve,
            train_ids=np.flatnonzero(train),
            val_ids=np.flatnonzero(val),
            test_ids=np.flatnonzero(test),
        )
        print("Fold", fold, "saved", flush=True)


if __name__ == "__main__":
    main()
