# CTC 2026 — physical cutoff and PnL research v3

Read `REPORT_V3.md` or the accompanying PDF. The study identifies a strongly
supported **2r spatial damage boundary** and evaluates an ETF-conversion execution
strategy that improves expected terminal PnL under unchanged assumed liquidity.
It is a standalone research project, not a connected exchange bot.

## Reproduce

Extract the user's research dataset outside this directory. Use
`requirements-lock.txt`; no credentials or network access are needed for research.

```bash
python prepare.py ../data/hurricane-season-research --out cache.npz
OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 python train.py
OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 python short_horizon.py
OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 python pnl_v2_train.py
OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 python pnl_v2_select.py --stage all --workers 5
OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 python physics_v3.py
OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 python aftermath_v3_train.py
OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 python pnl_v3_select.py --stage all --workers 5
OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 python kernel_sensitivity_v3.py
OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 python audit_routes_v3.py
OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 python -m pytest -q
python pnl_v3_report.py
```

The compact download omits the original dataset, fitted pickle files and large
prediction caches. These commands regenerate them. Included frozen choices,
validation candidate tables, per-season outcomes, action audits and checksums
allow comparison to the supplied results. `pnl_v3_select.py --stage evaluate`
evaluates existing frozen configurations once the prediction caches exist.
Reproduction is not a new independent statistical validation.

## What is implemented

- `physics_v3.py`: fit PORT's positive-damage support boundary on 360 seasons;
  confirm on two separate 120-season subsets; profile fourteen kernel cutoffs in
  site-weighted cumulative-damage regressions. Also fit incremental damage from
  full observed paths, available only after dissipation.
- `kernel_sensitivity_v3.py`: additional training/validation-only diagnostics of
  Gaussian shape, intensity exponent and cumulative-damage response. These did not
  select trading policies or enter their prediction features.
- `aftermath_v3_train.py`: five season-separated fits of ridge and boosted
  residual-value models, using only observed paths, prices and public reports.
- `pnl_v2_simulator.py`: shared-ledger baseline with optional globally allocated
  formation lots and post-dissipation value trades. Existing v2 defaults preserve
  its per-season PnL exactly. Rejected limit orders get no passive-fill credit.
- `etf_route_v3.py`: atomic ETF position transformations with zero cash change;
  separate, delayed market legs pay execution costs and respect assumed depth.
  Both positive and negative pending legs reserve worst-ordering capacity.
- `pnl_v3_select.py`: a predeclared staged 169-policy search per fold, selected only
  by inner-validation mean net PnL. Freeze all five policies before outer replay.
  The no-aftermath alternative is retained; all five folds rejected that addition.
- `audit_routes_v3.py`: reconcile selected formation-route attribution and actions.
- `tests/`: deterministic cash, conversion, rate/position reservation, delayed
  execution, report deduplication/recovery and feature-causality checks.

## Experimental contract

Five disjoint outer folds, each with 360 training / 120 inner-validation / 120
outer-evaluation seasons. Keep all three storms in a season together. This dataset
has informed earlier research: these are **post-selection nested simulator
estimates**, not a fresh lockbox, chronological walk-forward or live fills.

Baseline: 25 bps plus USD 0.02/share/side, two-second order latency, 50 market
shares per symbol per two seconds, official position limits, one key's rolling
60-actions/minute limit. Conversions consume actions and have the same assumed
latency. They move stock/ETF inventory, not cash. ETF market legs have the same
depth constraint as any other instrument. The selected routing phase flattens
before later engines resume; an additional rolling minute prevents rate-budget
overlap. Recorded action histories verify the combined constraint.

The objective has no Sharpe, drawdown or win-rate penalty. The supplied PnL is
cash plus final settlement, net of modeled trading costs. Mark-to-market drawdown
for the routed combined strategy is a conservative sum of non-overlapping engine
drawdowns; do not compare it as an identical estimator to v2's single-ledger path.

No orderbooks, queue/depth observations, competitor impact or announcements are
in the dataset. Execution assumptions remain hypothetical, even when a stress
test passes. Price protection and the availability of repeated ETF fills need
testnet validation. A physical 2r boundary is not a universal trading entry radius.

## Outputs

- `results_v3/cutoff_support.json`, `cutoff_support_profile.csv`
- `results_v3/damage_cutoff_regressions.csv`, `path_damage_regressions.csv`
- `results_v3/kernel_sensitivity.json`, `damage_survival_coefficients_at_2r.json`
- `results_v3/fold-*-validation.csv`, `fold-*-frozen.json`
- `results_v3/fold-*-aftermath-validation-errors.csv`
- `results_v3/summary.json`, `scenarios.csv`, `outer_seasons.csv`
- `results_v3/fold-*-outer-results.npz`: per-season results and action audit arrays
- `results_v3/route_audit.csv`, `route_audit.json`, `attribution.csv`
- `results_v3/reproduction_certificate.json`, `SHA256SUMS_V3.json`

No Ramp repository or branch is used.
