"""Freeze mean-PnL policy choices on inner seasons, then evaluate outer seasons."""

import argparse
import hashlib
import itertools
import json
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

import numpy as np
import pandas as pd

from backtest import summarize
from common import SYMBOLS, dump_json, load_cache
from evaluate import bootstrap_mean
from etf_route_v3 import simulate_routes
from pnl_v2_select import SCENARIOS, inputs
from pnl_v2_simulator import simulate
from train import TIMES

OUT = Path("results_v3")


def get_inputs(fold, split):
    ids, args = inputs(fold, split)
    forecasts = load_cache(OUT / f"fold-{fold}-aftermath-predictions.npz")
    local = np.searchsorted(forecasts["ids"], ids)
    assert np.array_equal(forecasts["ids"][local], ids)
    return (
        ids,
        args,
        {name: forecasts[name][local] for name in ["ridge", "hgb7", "hgb15"]},
    )


def run(args, config, predictions, **kwargs):
    config = config.copy()
    model = config.pop("aftermath_model", None)
    if model is not None:
        index = [540, 570, 600, 660, 700].index(config["aftermath"]["start"])
        config["aftermath_fair"] = predictions[model][:, :, index]
    route_config = config.pop("formation_route", None)
    if route_config is None:
        return simulate(*args, **config, **kwargs)
    stress = {k: v for k, v in kwargs.items() if k != "audit"}
    routed = simulate_routes(
        args[0], args[1], args[4], **route_config, **stress, audit=True
    )
    resume = np.ceil((routed["flat_times"] + 60) / 10).astype(int) * 10
    delta = args[2].copy()
    delta[TIMES[None, None, :] < resume[:, :, None]] = 0
    if "aftermath" in config:
        assert resume.max() < config["aftermath"]["start"]
    config["formation"] = None
    tail = simulate(
        args[0], args[1], delta, args[3], args[4], **config, **stress, audit=True
    )
    for key in ["pnl", "actions", "cost", "turnover_shares", "attribution", "drawdown"]:
        tail[key] = tail[key] + routed[key]
    tail["by_engine"][:, 0] += routed["pnl"]
    tail["engine_actions"][:, 0] += routed["actions"]
    tail["max_position_fraction"] = np.maximum(
        tail["max_position_fraction"], routed["max_position_fraction"]
    )
    tail["action_ticks"] += routed["action_ticks"]
    c = tail["action_ticks"].cumsum(2)
    lag = np.concatenate([np.zeros_like(c[:, :, :30]), c[:, :, :-30]], axis=2)
    tail["max_rolling_actions"] = (c - lag).max((1, 2))
    assert tail["max_rolling_actions"].max() <= 60
    np.testing.assert_allclose(tail["attribution"].sum(1), tail["pnl"], atol=1e-8)
    return tail


def select_fold(fold):
    ids, args, predictions = get_inputs(fold, "val")
    v2 = json.loads(Path(f"results_v2/fold-{fold}-frozen.json").read_text())["config"]
    records = []

    def evaluate(config, stage):
        result = run(args, config, predictions)
        record = {
            "fold": fold,
            "stage": stage,
            "config": json.dumps(config, sort_keys=True),
            **summarize(result),
        }
        records.append(record)
        return record["mean_usd"]

    best = v2.copy()
    best_mean = evaluate(best, "v2_reference")
    for start, exit_at, budget in itertools.product(
        [0, 20, 40], [70, 80, 100, 120], [30, 45, 60]
    ):
        config = {
            **v2,
            "formation": {
                "start": start,
                "exit": exit_at,
                "entry_budget": budget,
                "allocation": "optimal_lots",
            },
        }
        mean = evaluate(config, "allocation")
        if mean > best_mean:
            best, best_mean = config, mean
    without_after = best.copy()
    for model, start, budget, margin in itertools.product(
        ["ridge", "hgb7", "hgb15"], [540, 570, 600, 660], [10, 30, 59], [0, 0.25, 0.75]
    ):
        config = {
            **without_after,
            "aftermath_model": model,
            "aftermath": {"start": start, "entry_budget": budget, "margin": margin},
        }
        mean = evaluate(config, "aftermath")
        if mean > best_mean:
            best, best_mean = config, mean
    without_routing = best.copy()
    for start, exit_at, fraction in itertools.product(
        [0, 20, 40], [70, 80, 100, 120], [0.75, 1.0]
    ):
        config = {
            **without_routing,
            "formation_route": {
                "start": start,
                "exit_at": exit_at,
                "fraction": fraction,
            },
        }
        mean = evaluate(config, "etf_routing")
        if mean > best_mean:
            best, best_mean = config, mean
    frozen = {
        "fold": fold,
        "config": best,
        "allocation_only_config": without_after,
        "without_etf_routing_config": without_routing,
        "validation_mean_usd": best_mean,
        "validation_seasons": (ids + 1).tolist(),
        "candidate_count": len(records),
        "objective": "mean net terminal USD PnL only",
    }
    pd.DataFrame(records).to_csv(OUT / f"fold-{fold}-validation.csv", index=False)
    dump_json(OUT / f"fold-{fold}-frozen.json", frozen)
    print("FROZEN V3", fold, round(best_mean, 2), best, flush=True)
    return frozen


def evaluate_fold(fold):
    ids, args, predictions = get_inputs(fold, "test")
    frozen_path = OUT / f"fold-{fold}-frozen.json"
    frozen = json.loads(frozen_path.read_text())
    results = {}
    for name, stress in SCENARIOS.items():
        results[name] = run(
            args, frozen["config"], predictions, **stress, audit=name == "base"
        )
    results["allocation_only"] = run(
        args, frozen["allocation_only_config"], predictions
    )
    results["without_etf_routing"] = run(
        args, frozen["without_etf_routing_config"], predictions
    )
    v2_config = json.loads(Path(f"results_v2/fold-{fold}-frozen.json").read_text())[
        "config"
    ]
    results["v2_reference"] = run(args, v2_config, predictions)
    previous = load_cache(f"results_v2/fold-{fold}-outer-results.npz")
    np.testing.assert_allclose(
        results["v2_reference"]["pnl"], previous["base__pnl"], atol=1e-8
    )
    counts = results["base"]["action_ticks"]
    c = np.cumsum(counts, axis=2)
    lag = np.concatenate([np.zeros_like(c[:, :, :30]), c[:, :, :-30]], axis=2)
    assert np.max(c - lag) <= 60
    assert results["base"]["max_position_fraction"].max() <= 1
    serial = {
        f"{name}__{key}": value
        for name, result in results.items()
        for key, value in result.items()
    }
    np.savez_compressed(OUT / f"fold-{fold}-outer-results.npz", ids=ids, **serial)
    print("OUTER V3", fold, round(results["base"]["pnl"].mean(), 2), flush=True)
    return {
        "fold": fold,
        "config": frozen["config"],
        "frozen_sha256": hashlib.sha256(frozen_path.read_bytes()).hexdigest(),
        "validation_mean_usd": frozen["validation_mean_usd"],
        "outer_summary": summarize(results["base"]),
        "v2_summary": summarize(results["v2_reference"]),
    }


def aggregate(folds):
    files = [load_cache(OUT / f"fold-{k}-outer-results.npz") for k in range(5)]
    order = np.argsort(np.concatenate([x["ids"] for x in files]))

    def concatenate(key):
        values = [x[key] for x in files]
        if key.endswith(("__by_engine", "__engine_actions")):
            width = max(x.shape[1] for x in values)
            values = [np.pad(x, ((0, 0), (0, width - x.shape[1]))) for x in values]
        return np.concatenate(values)[order]

    joined = {key: concatenate(key) for key in files[0]}
    assert np.array_equal(joined["ids"], np.arange(600))
    names = list(SCENARIOS) + ["allocation_only", "without_etf_routing", "v2_reference"]
    records = []
    for name in names:
        result = {
            k.split("__", 1)[1]: v
            for k, v in joined.items()
            if k.startswith(name + "__")
        }
        records.append(
            {
                "scenario": name,
                **summarize(result),
                "mean_ci95_usd": bootstrap_mean(result["pnl"]),
                "max_rolling_actions": int(result["max_rolling_actions"].max()),
                "mean_engine_contributions_usd": result["by_engine"].mean(0).tolist(),
            }
        )
    paired = joined["base__pnl"] - joined["v2_reference__pnl"]
    summary = {
        "qualification": "Further post-selection nested simulator evaluation on a repeatedly examined dataset; not fresh/live evidence",
        "folds": folds,
        "scenarios": records,
        "paired_mean_improvement_usd": float(paired.mean()),
        "paired_mean_ci95_usd": bootstrap_mean(paired),
        "paired_win_fraction": float(np.mean(paired > 0)),
    }
    dump_json(OUT / "summary.json", summary)
    pd.DataFrame(records).to_csv(OUT / "scenarios.csv", index=False)
    pd.DataFrame(
        {
            "season": joined["ids"] + 1,
            "outer_fold": joined["ids"] // 120,
            **{name: joined[name + "__pnl"] for name in names},
            "actions": joined["base__actions"],
            "max_drawdown_usd": joined["base__drawdown"],
            "cost_usd": joined["base__cost"],
        }
    ).to_csv(OUT / "outer_seasons.csv", index=False)
    pd.DataFrame(
        {
            "symbol": SYMBOLS,
            "v3_mean_usd": joined["base__attribution"].mean(0),
            "v2_mean_usd": joined["v2_reference__attribution"].mean(0),
        }
    ).to_csv(OUT / "attribution.csv", index=False)
    print(
        pd.DataFrame(records)[
            ["scenario", "mean_usd", "minimum_usd", "win_rate"]
        ].to_string(index=False),
        flush=True,
    )


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--stage", choices=["select", "evaluate", "all"], default="all")
    p.add_argument("--workers", type=int, default=5)
    args = p.parse_args()
    if args.stage in ("select", "all"):
        dump_json(
            OUT / "policy_search_plan.json",
            {
                "objective": "mean net terminal USD PnL; same baseline execution assumptions as v2",
                "formation_allocation_starts": [0, 20, 40],
                "formation_exit_starts": [70, 80, 100, 120],
                "formation_budgets": [30, 45, 60],
                "aftermath_models": ["ridge", "hgb7", "hgb15"],
                "aftermath_starts": [540, 570, 600, 660],
                "aftermath_budgets": [10, 30, 59],
                "aftermath_margins_usd": [0, 0.25, 0.75],
                "stages": "retain v2; choose global formation allocation with existing later engines; choose aftermath conditional on that policy",
                "etf_route_starts": [0, 20, 40],
                "etf_route_exit_starts": [70, 80, 100, 120],
                "etf_route_fractions": [0.75, 1.0],
                "candidate_count_per_fold": 169,
                "execution_note": "59 early entry actions permit one cancel-all and 59 exit actions. Rounds1/2 schedule exits for first arrival742 under known latency, finish before close. Round3 settles remaining positions after final-report refresh.",
            },
        )
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            list(pool.map(select_fold, range(5)))
    if args.stage in ("evaluate", "all"):
        assert all((OUT / f"fold-{k}-frozen.json").exists() for k in range(5))
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            folds = list(pool.map(evaluate_fold, range(5)))
        aggregate(folds)


if __name__ == "__main__":
    main()
