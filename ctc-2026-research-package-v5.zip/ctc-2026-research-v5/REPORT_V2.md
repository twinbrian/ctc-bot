# CTC 2026: maximize expected terminal PnL

## Result

**Yes: a more aggressive, mean-PnL-selected strategy substantially outperformed the earlier policy in this research replay.** Its mean was **USD 9,337 per season**, versus **USD 1,990**, a **4.69x** ratio under identical baseline execution assumptions. The improvement came primarily from accumulating larger positions before a predictable storm-formation repricing.

This objective accepts a less consistent result: 88.0% of seasons were profitable versus 98.7%; the worst season was USD -8,153. The strategy is the best selected policy within the tested families, not a proof of a globally optimal trading algorithm.

**Evidence scope:** 600 seasons, five outer folds, 360 training / 120 inner-validation / 120 outer-evaluation seasons per fold. All seasons had already been examined in v1 research, so these are **post-selection nested-CV estimates, not a new untouched holdout**. Quotes are house consensus: no executable orderbooks or actual fills were supplied.

| Metric | Earlier policy | Mean-PnL policy |
|---|---:|---:|
| Mean net PnL | USD 1,990 | USD 9,337 |
| Median net PnL | USD 1,935 | USD 8,352 |
| Profitable seasons | 592/600 (98.7%) | 528/600 (88.0%) |
| Worst season | USD -750 | USD -8,153 |
| Worst 5%: average PnL | USD 146 | USD -5,158 |
| Average within-season maximum drawdown | USD 441 | USD 5,642 |
| Average order actions | 58.7 | 431.2 |
| Average shares traded | 2,530 | 21,168 |
| Average execution costs | USD 572 | USD 3,194 |

The earlier policy's drawdown is the conservative sum of its two engine drawdowns; v2 measures the shared account every two seconds. The mean-PnL policy's conditional 95% season-bootstrap interval is **USD 8,675 to USD 10,012**. Its paired mean improvement is **USD 7,348**, with a conditional interval of USD 6,717 to USD 7,994. These intervals do not include research-selection, model-fitting, simulator-change or live-execution uncertainty.

![PnL comparison, fold stability and execution stress](results_v2/pnl-dashboard-v2.png)

## 1. What we optimized

The competition scores cash plus final-settlement value of remaining positions. We selected parameters to maximize the **arithmetic mean of net terminal USD PnL** on the inner-validation seasons. There is no Sharpe objective, drawdown penalty, tail-loss penalty, minimum win rate, or stressed-performance ranking.

```text
Choose policy parameters theta to maximize:
    mean_over_validation_seasons(
        final_cash(theta) + positions(theta) @ settlement
    )

Subject to position limits, pending/resting reservations,
one-key rolling action limits, order latency and assumed depth.
```

Expected PnL, the probability of a profitable season, and the probability of beating every other team are different objectives. This experiment targets the first; the dataset provides no opponent PnL distribution for optimizing tournament win probability.

The baseline is unchanged: **25 bps plus USD 0.02 per share per side, two real seconds of order latency, 50 shares per instrument per two-second interval**, and one bot key with 60 order actions per rolling real minute. Settlement itself incurs no invented closing spread. We did not inflate available liquidity or use future-season prices to create the improvement.

## 2. The strategy

### A. Build inventory before the formation repricing

The storm forms 60 real seconds after each round opens. V1 found a systematic shift in house consensus shortly after formation: island businesses and HAVEN tend to rise, while rebuilders tend to fall. Instead of waiting for formation and trading small clips, v2 starts accumulating before it.

Fit a mean price trajectory separately for each round using the 360 training seasons. At the selected start time, anchor the predicted price change to the current season's observed price. Rank each available clip by predicted net profit in USD, after estimated entry and exit costs. Submit positive-edge clips, accumulating up to the legal per-symbol limit and the selected action budget.

Every fold selected the largest tested **60-entry-action formation budget**. This is at most 3,000 shares gross per round at 50 shares per order, with individual stock/ETF limits enforced. Average observed peak formation inventory was **3,000 shares gross**. Typical directions are long HAVEN, PORT, ARCH and other island exposure, and short REBLD and its constituents; individual clips must still cover costs. REIN's small average move usually does not.

**The exit time is an earliest submission time, not a guaranteed flattening time.** Using all 60 entry actions can leave no action capacity for immediate exits. In the selected replays, the first formation exit was submitted at a mean of 96.0 seconds after open, and the account became flat at a mean of 110.0 seconds; the latest was 136 seconds. The first official advisory arrives at t=90, so large inventory can remain exposed to that news. This helps explain the much larger tail losses.

### B. Trade later signals more frequently

After formation inventory and pending orders are flat, evaluate the existing public-feed/price model every **10 seconds**, instead of every 20. The model forecasts the next ten-second price change. Rank positive predicted net edges by USD contribution, permit five or eight symbols per decision, and reserve an exit action for every entry. The rolling scheduler blocks new orders when capacity is insufficient.

Four folds selected no extra edge cushion after costs; one retained USD 0.10 per share. These trades use 50-share clips, including ARCH's full 50-share limit. They close on a scheduled ten-second horizon, subject to arrival latency and available depth. Trading the final round stops early enough to hand the account to the settlement engine.

### C. Trade final-report valuation gaps

At t=740 of round 3, update structural fair values using the final published damage/loss reports and measured outages. Submit price-capped orders only when modeled execution is better than fair value. All folds selected **zero additional valuation margin**, rather than v1's USD 0.10. Unfilled limit orders reserve capacity and receive no passive-fill credit. The engine uses the actual remaining rolling budget rather than a fixed 20-action cap.

The fitted economics and public-feed features are the same as v1; `REPORT.md` contains the recovered damage, outage, rebuilder and insurance-layer equations.

### Contribution to net PnL

| Engine | Mean contribution | Share of net PnL |
|---|---:|---:|
| Formation positions | USD 8,568 | 91.8% |
| Subsequent short-horizon trades | USD 475 | 5.1% |
| Final-report settlement trades | USD 295 | 3.2% |

The largest instrument contributions were HAVEN (USD 2,947), ARCH (USD 1,450), PORT (USD 1,137), GRID (USD 859). Formation-only averaged USD 8,568; adding final-report trades produced USD 8,863. Most of the improvement is therefore **sizing and timing a repeatable house-pricing effect**, rather than a new hurricane-path forecasting breakthrough. The formation attribution includes the entire holding window, including any advisory exposure before it is flat.

## 3. Exact selection and a concrete configuration

Each fold evaluated a fixed, staged 140-configuration search:

- Formation: starts 0/20/40/50/60 seconds; earliest exits 70/80/100/120; entry budgets 10/20/30/45/60. Select the best of 100 formation-only configurations by mean net PnL.
- Ongoing: thresholds USD 0.00/0.10/0.25, top-3/5/8, cadence 10/20 seconds. Compare 18 configurations with the selected formation engine and 18 without it, retaining the formation-only alternative.
- Endgame: margins USD 0.00/0.05/0.10/0.20, retaining the no-endgame alternative.

This is staged optimization, not an exhaustive joint search. All five choices were saved before any outer evaluation. Outer outcomes and stress tests did not determine the configurations.

| Fold | Outer seasons | Start / earliest exit | Entry actions | Later top-k / cushion | Outer mean |
|---|---|---|---:|---|---:|
| 0 | 1–120 | 40 s / 80 s | 60 | 5 / USD 0 | USD 9,390 |
| 1 | 121–240 | 40 s / 120 s | 60 | 5 / USD 0 | USD 9,186 |
| 2 | 241–360 | 0 s / 80 s | 60 | 8 / USD 0 | USD 9,777 |
| 3 | 361–480 | 0 s / 80 s | 60 | 8 / USD 0.10 | USD 9,051 |
| 4 | 481–600 | 20 s / 100 s | 60 | 5 / USD 0 | USD 9,282 |

**Concrete original-split configuration:** accumulate from **t=40**, request formation exits from **t=80**, use at most **60 entry actions**, then trade **top five positive-net-edge signals every ten seconds**, with **zero extra cushion** and **zero extra final-report margin**. All times are real seconds after market open. If the formation budget is exhausted by t=50, the first exits may have to wait until entry actions start expiring around t=100; the simulator includes that wait.

This configuration was selected using seasons 240–121, with models trained on 600–241, and produced **USD 9,390** on the 120 original-split evaluation seasons, versus **USD 2,077** for v1. That evaluation set was already inspected during v1. The pooled USD 9,337 result evaluates the selection procedure across five fold-specific configurations, not a single universal configuration chosen after seeing all 600 outcomes.

## 4. Execution robustness

All rows retain the frozen policy parameters. For known higher costs the policy recomputes its net-edge decision using that cost; the adverse-cost row charges an unanticipated extra 25 bps without changing its cost forecast. No scenario was used to select this policy.

| Scenario | Mean net PnL | Profitable | Worst season |
|---|---:|---:|---:|
| Baseline | USD 9,337 | 88.0% | USD -8,153 |
| 50 bps each side | USD 6,919 | 79.5% | USD -11,058 |
| 100 bps each side | USD 3,806 | 73.7% | USD -9,467 |
| 4 s latency | USD 8,804 | 85.2% | USD -8,434 |
| 12 s latency | USD 8,178 | 82.7% | USD -9,835 |
| 25 shares per 2 s | USD 5,939 | 87.8% | USD -5,198 |
| 10 shares per 2 s | USD 3,217 | 87.3% | USD -2,754 |
| 50 bps, 4 s latency, 25 shares per 2 s | USD 4,446 | 77.5% | USD -7,721 |
| Unexpected extra 25 bps per side | USD 6,604 | 78.7% | USD -10,835 |
| 50 shares, replenishment every 10 s | USD 7,835 | 87.8% | USD -6,123 |

Unlike v1's reactive formation entry, v2 generally builds inventory before the event. This reduces dependence on beating a four-second repricing window, but increases inventory exposure and liquidity demand. At 12 seconds of latency the subsequent short-trade engine loses money on average; most surviving profit comes from pre-positioning.

The result remains conditional on unverified capacity. A consensus-price replay cannot measure house inventory skew caused by our trades, competitor crowding, nonlinear market impact, price protection, or actual queue/fill behavior. The 10-second replenishment scenario challenges repeated clips but is not an observed liquidity estimate. If executable prices move before we can accumulate, the formation edge can vanish.

## 5. Testing and interpretation

- One shared cash ledger tracks formation, later trades and settlement; component and instrument attribution reconcile exactly to final PnL.
- Pending and resting quantities reserve inventory. Late fills use their arrival-time price. No future settlement value influences entry decisions.
- Every two-second action history is checked against a rolling 60-action window. The maximum observed was 60; the maximum observed per-symbol position fraction was 1.0. No second bot key or team-limit expansion was needed.
- Tests cover rate-limited delayed exits, slow liquidity replenishment, overlapping entry/exit latency, future-price poisoning, prefix feature causality, report replacement, duplicate feeds, snapshots and ETF accounting.
- Whole seasons are the unit of splitting and bootstrap resampling. No storm, instrument or tick from an outer-test season enters that fold's fit or parameter selection.
- Cross-validation is grouped by season and block, not chronological walk-forward; four folds can train on numerically newer seasons. The original-split fold preserves the oldest-to-newest ordering. This is appropriate as a simulator stability check, subject to the packet's same-simulator assumption.
- Strategy families and model hyperparameters inherit earlier research. Nested refitting reduces direct fit/tuning leakage; it cannot undo the fact that the dataset has already informed our ideas.

**Bottom line:** if the objective is maximum expected terminal PnL within this tested setup, prefer the larger pre-positioning strategy over the earlier conservative policy. Accept that it loses more often and can lose substantially more in one season. Before using it in the competition, the decisive missing evidence is whether the testnet actually supplies the required pre-event fills and whether announcements preserve the fitted economics.

## Files and reproduction

The compact v2 code/results kit includes source, model-training code, frozen choices, all inner-validation candidates, per-season outer outcomes, stress results and action-audit arrays. Model weights and large prediction caches are regenerated from the original dataset; see `README_V2.md` for the commands. `results_v2/reproduction_certificate.json` records input/config hashes and the test run. Everything remains local and standalone; no Ramp repository or branch was created.
