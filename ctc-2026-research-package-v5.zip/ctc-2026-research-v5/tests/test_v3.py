import numpy as np
import pytest

from common import LIMITS
from pnl_v2_simulator import allocate_lots, simulate


def scenario():
    market = np.full((1, 3, 390, 12), 100.0)
    market[:, :, 370:] = 105.0
    truth = np.full((1, 12), 105.0)
    delta = np.zeros((1, 3, 78, 12))
    curve = np.full((3, 390, 12), 100.0)
    return [market, truth, delta, truth.copy(), curve]


def test_lot_allocator_uses_best_marginal_dollars_and_respects_limits():
    edge = np.zeros((1, 12))
    edge[0, 0] = 1
    edge[0, 1] = 5
    caps = np.full(12, 100)
    allocated = allocate_lots(edge, caps, 50, 3)
    np.testing.assert_array_equal(allocated[0, :2], [50, 100])
    assert allocated.sum() == 150


def test_aftermath_cash_matches_known_price_move_and_settlement():
    args = scenario()
    result = simulate(
        *args,
        aftermath={"start": 540, "entry_budget": 59, "margin": 0},
        aftermath_fair=np.full((1, 3, 12), 105.0),
        cost_bps=0,
        fixed_cost=0,
        audit=True,
    )
    assert result["pnl"][0] == 2950 * 5 * 3
    assert result["actions"][0] == 59 * 5
    assert result["positions"].sum() == 2950
    assert result["max_rolling_actions"].max() <= 60


@pytest.mark.parametrize("latency,replenish", [(2, 2), (4, 2), (12, 2), (2, 10)])
def test_late_aftermath_exits_finish_before_close(latency, replenish):
    args = scenario()
    result = simulate(
        *args,
        aftermath={"start": 660, "entry_budget": 59, "margin": 0},
        aftermath_fair=np.full((1, 3, 12), 105.0),
        cost_bps=0,
        fixed_cost=0,
        latency=latency,
        replenish_seconds=replenish,
        audit=True,
    )
    for r in range(3):
        assert (
            np.convolve(result["action_ticks"][0, r], np.ones(30), mode="full").max()
            <= 60
        )
    assert np.all(np.abs(result["positions"]) <= LIMITS)


def test_rejected_entry_limits_receive_no_fills_and_cancel_once_each_round():
    args = scenario()
    args[0][:, :, 271:] = 110
    result = simulate(
        *args,
        aftermath={"start": 540, "entry_budget": 59, "margin": 0},
        aftermath_fair=np.full((1, 3, 12), 105.0),
        cost_bps=0,
        fixed_cost=0,
        audit=True,
    )
    assert result["pnl"][0] == 0
    assert np.all(result["positions"] == 0)
    np.testing.assert_array_equal(result["action_ticks"][0, :, 360], [1, 1, 1])


def test_final_report_can_reverse_an_early_position_without_limit_breach():
    args = scenario()
    args[0][:] = 100
    args[1][:] = 90
    args[3][:] = 90
    result = simulate(
        *args,
        aftermath={"start": 540, "entry_budget": 10, "margin": 0},
        aftermath_fair=np.full((1, 3, 12), 105.0),
        end_margin=0,
        cost_bps=0,
        fixed_cost=0,
        audit=True,
    )
    assert result["positions"].sum() < 0
    assert result["max_position_fraction"].max() <= 1
    np.testing.assert_allclose(result["by_engine"].sum(1), result["pnl"])


def test_model_target_unavailable_before_aftermath_start():
    args = scenario()
    args[2][:] = 2
    kw = {
        "formation": {
            "start": 20,
            "exit": 80,
            "entry_budget": 30,
            "allocation": "optimal_lots",
        },
        "ongoing": {"cycle": 10, "top_k": 5, "threshold": 0},
        "aftermath": {"start": 570, "entry_budget": 30, "margin": 0.25},
        "audit": True,
    }
    a = simulate(*args, aftermath_fair=np.full((1, 3, 12), 105.0), **kw)
    b = simulate(*args, aftermath_fair=np.full((1, 3, 12), 90.0), **kw)
    np.testing.assert_array_equal(
        a["action_ticks"][:, :, :285], b["action_ticks"][:, :, :285]
    )


def test_final_price_oscillation_cannot_net_opposite_resting_capacity():
    args = scenario()
    args[0][:] = 100
    args[0][:, 2, 370::2] = 109
    args[0][:, 2, 371::2] = 99
    args[3][:] = 105
    result = simulate(
        *args,
        aftermath={"start": 540, "entry_budget": 59, "margin": 0},
        aftermath_fair=np.full((1, 3, 12), 105.0),
        end_margin=0,
        cost_bps=0,
        fixed_cost=0,
        audit=True,
    )
    assert result["max_position_fraction"].max() <= 1


def test_etf_conversion_routing_flat_market_only_loses_execution_costs():
    from etf_route_v3 import simulate_routes
    from common import with_etfs

    args = scenario()
    args[0][:] = 100
    args[4][:] = 100
    args[4][:, 36:] = 105
    args[0] = with_etfs(args[0][..., :10])
    args[4] = with_etfs(args[4][..., :10])
    result = simulate_routes(args[0], args[1], args[4], start=0, exit_at=70, audit=True)
    assert result["conversion_actions"][0] > 0
    np.testing.assert_allclose(result["pnl"], -result["cost"], atol=1e-8)
    assert result["max_position_fraction"].max() <= 1
    assert result["max_rolling_actions"].max() <= 60


@pytest.mark.parametrize(
    "latency,depth,replenish", [(2, 50, 2), (12, 50, 2), (2, 10, 2), (2, 50, 10)]
)
def test_etf_pending_conversion_and_market_orders_preserve_limits(
    latency, depth, replenish
):
    from etf_route_v3 import simulate_routes

    args = scenario()
    # Keep ETF terminal baskets coherent, so conversion alone creates no cash.
    from common import with_etfs

    args[0][:, :, 32:] = 105
    args[0] = with_etfs(args[0][..., :10])
    args[1] = with_etfs(args[1][..., :10])
    args[4] = args[0][0].copy()
    result = simulate_routes(
        args[0],
        args[1],
        args[4],
        start=20,
        exit_at=80,
        latency=latency,
        depth=depth,
        replenish_seconds=replenish,
        audit=True,
    )
    assert np.all(result["positions"] == 0)
    for r in range(3):
        assert (
            np.convolve(result["action_ticks"][0, r], np.ones(30), mode="full").max()
            <= 60
        )
    np.testing.assert_allclose(result["attribution"].sum(1), result["pnl"], atol=1e-8)
