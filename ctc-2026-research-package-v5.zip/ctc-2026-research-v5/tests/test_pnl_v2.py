import numpy as np

from common import LIMITS
from pnl_v2_simulator import simulate
from pnl_v2_train import masks


def synthetic():
    market = np.full((1, 3, 390, 12), 100.0)
    market[:, :, 32:] = 105.0
    truth = np.full((1, 12), 105.0)
    delta = np.zeros((1, 3, 78, 12))
    curve = market[0].copy()
    return market, truth, delta, truth.copy(), curve


def test_nested_partition_covers_each_season_once_as_outer_test():
    all_test = np.zeros(600, dtype=int)
    for k in range(5):
        train, val, test = masks(k)
        assert (train.sum(), val.sum(), test.sum()) == (360, 120, 120)
        assert np.all(train.astype(int) + val + test == 1)
        all_test += test
    assert np.all(all_test == 1)


def test_formation_accumulates_legal_depth_and_closes_with_reserved_actions():
    args = synthetic()
    result = simulate(
        *args,
        formation={"start": 20, "exit": 70, "entry_budget": 30},
        cost_bps=0,
        fixed_cost=0,
        audit=True,
    )
    assert result["pnl"][0] == 22500  # 1500 shares * USD 5 * 3 rounds
    assert result["actions"][0] == 180
    assert result["max_rolling_actions"][0] == 60
    assert np.all(result["positions"] == 0)
    assert result["max_position_fraction"][0] <= 1


def test_fast_ongoing_signal_enforces_actual_rolling_budget():
    args = list(synthetic())
    args[2][:] = 10
    result = simulate(
        *args,
        ongoing={"cycle": 10, "top_k": 8, "threshold": 0},
        end_margin=0.1,
        audit=True,
    )
    assert result["blocked_entries"][0] > 0
    assert result["max_rolling_actions"][0] <= 60
    for r in range(3):
        rolling = np.convolve(result["action_ticks"][0, r], np.ones(30), mode="full")
        assert rolling.max() <= 60
    assert np.all(np.abs(result["positions"]) <= LIMITS)


def test_price_jump_before_arrival_is_paid_by_aggressive_engine():
    market, truth, delta, fair, curve = synthetic()
    # Only PORT is attractive, and the decision at t=60 arrives after its jump.
    curve[:] = 100
    curve[:, 36:, 0] = 110
    market[:] = 100
    market[:, :, 31:, 0] = 110
    truth[:] = 100
    truth[:, 0] = 110
    result = simulate(
        market,
        truth,
        delta,
        fair,
        curve,
        formation={"start": 60, "exit": 70, "entry_budget": 1},
        cost_bps=0,
        fixed_cost=0,
    )
    assert result["pnl"][0] == 0  # no stale t=60 fill


def test_combined_engines_share_rate_inventory_and_cash():
    args = list(synthetic())
    args[2][:] = 2
    result = simulate(
        *args,
        formation={"start": 40, "exit": 80, "entry_budget": 30},
        ongoing={"cycle": 10, "top_k": 8, "threshold": 0},
        end_margin=0,
        audit=True,
    )
    np.testing.assert_allclose(result["pnl"], result["by_engine"].sum(1))
    np.testing.assert_allclose(result["pnl"], result["attribution"].sum(1))
    assert result["max_rolling_actions"].max() <= 60
    assert result["max_position_fraction"].max() <= 1


def test_zero_edge_produces_no_trades():
    args = list(synthetic())
    args[0][:] = 100
    args[1][:] = 100
    args[3][:] = 100
    args[4][:] = 100
    result = simulate(
        *args,
        formation={"start": 0, "exit": 70, "entry_budget": 30},
        ongoing={"cycle": 10, "top_k": 8, "threshold": 0},
        end_margin=0,
    )
    assert result["actions"][0] == 0 and result["pnl"][0] == 0


def test_large_formation_inventory_waits_for_exit_budget():
    result = simulate(
        *synthetic(),
        formation={"start": 40, "exit": 70, "entry_budget": 60},
        cost_bps=0,
        fixed_cost=0,
        audit=True,
    )
    assert result["pnl"][0] == 45000
    assert result["actions"][0] == 360
    assert result["max_rolling_actions"][0] == 60
    # No entry actions have expired at the desired exit start, so exits wait.
    assert result["action_ticks"][0, :, 35:50].sum() == 0
    assert np.all(result["positions"] == 0)


def test_slow_depth_replenishment_throttles_accumulation_and_exits():
    result = simulate(
        *synthetic(),
        formation={"start": 50, "exit": 70, "entry_budget": 60},
        cost_bps=0,
        fixed_cost=0,
        replenish_seconds=10,
        audit=True,
    )
    # Only two entry clips per symbol fit before formation; ARCH allows only one.
    assert result["pnl"][0] == 1150 * 5 * 3
    assert np.all(result["positions"] == 0)
    assert result["max_rolling_actions"].max() <= 60


def test_future_prices_and_settlement_cannot_change_earlier_actions():
    args = list(synthetic())
    args[2][:] = 2
    config = {
        "formation": {"start": 20, "exit": 70, "entry_budget": 60},
        "ongoing": {"cycle": 10, "top_k": 8, "threshold": 0},
        "end_margin": 0,
    }
    original = simulate(*args, **config, audit=True)
    poisoned = [x.copy() for x in args]
    # Poison every observation/forecast after t=300; fitted training curve stays fixed.
    poisoned[0][:, :, 150:] *= 1.7
    poisoned[2][:, :, 30:] *= -10
    poisoned[1] *= 3
    poisoned[3] *= 3
    changed = simulate(*poisoned, **config, audit=True)
    np.testing.assert_array_equal(
        original["action_ticks"][:, :, :150], changed["action_ticks"][:, :, :150]
    )


def test_pending_entry_and_exit_with_long_latency_conserve_inventory():
    args = list(synthetic())
    args[2][:] = 3
    result = simulate(
        *args,
        formation={"start": 40, "exit": 70, "entry_budget": 60},
        ongoing={"cycle": 10, "top_k": 8, "threshold": 0},
        end_margin=0,
        latency=12,
        audit=True,
    )
    assert result["max_rolling_actions"].max() <= 60
    assert result["max_position_fraction"].max() <= 1
    np.testing.assert_allclose(result["attribution"].sum(1), result["pnl"])
