import numpy as np

from common import BASKETS, LIMITS, SYMBOLS, partitions, real_second, with_etfs
from endgame import simulate_endgame
from models import features
from protocol import ActionLimiter, FeedState, can_convert, conversion_delta, order_room
from short_horizon import simulate_short


def test_splits_are_whole_season_disjoint_and_reverse_chronological():
    tr, val, test = partitions()
    assert (tr.sum(), val.sum(), test.sum()) == (360, 120, 120)
    assert np.all(tr.astype(int) + val + test == 1)
    assert tr[-1] and test[0]


def test_old_dates_and_fast_clock():
    assert real_second("1426-08-04T15:40:00") == 740
    assert real_second("2025-08-04T10:15:00") == 90


def test_final_report_replaces_preliminary_and_snapshot_is_idempotent():
    state = FeedState("a")
    msg = {
        "type": "damage_report",
        "round": 1,
        "storm": "one",
        "seq": 7,
        "stage": "preliminary",
        "damage_pct": dict.fromkeys(SYMBOLS[:5], 10),
        "industry_loss_musd": 100,
    }
    assert state.apply(msg)
    assert not state.apply(msg)
    final = dict(msg, seq=29, stage="final", industry_loss_musd=120)
    assert state.apply(final)  # sequence gaps are valid
    snap = {"type": "snapshot", "last_seq": 29, "damage": [msg, final]}
    state.apply(snap)
    state.apply(snap)
    assert state.totals()[1] == 120
    np.testing.assert_allclose(state.totals()[0], 0.1)
    assert not state.apply(final)
    state.reset("b")
    assert state.apply(dict(msg, seq=0))
    assert not state.outage_complete


def test_announcement_invalidates_dependencies():
    state = FeedState("a")
    state.apply({"type": "announcement", "seq": 1, "symbols": ["GRID"]})
    assert set(SYMBOLS).issubset(state.invalid_models)


def test_resting_orders_consume_same_side_room():
    q = np.zeros(12)
    q[0] = 180
    buy, sell = np.zeros(12), np.zeros(12)
    buy[0] = 15
    b, s = order_room(q, buy, sell)
    assert b[0] == 5 and s[0] == 380


def test_conversion_conserves_fundamental_value_and_checks_all_legs():
    stock = np.arange(10) + 10.0
    fair = with_etfs(stock)
    zero = np.zeros(12)
    for etf in ["ARCH", "REBLD"]:
        create = conversion_delta(etf, 10)
        assert abs(create @ fair) < 1e-9
        np.testing.assert_allclose(create + conversion_delta(etf, 10, False), zero)
    q = zero.copy()
    q[0] = -195
    assert not can_convert(q, zero, zero, conversion_delta("ARCH", 10))


def test_rolling_rate_limits_and_reserved_capacity():
    limiter = ActionLimiter(key_limit=3, team_limit=4)
    assert limiter.take("a", 0, reserve=1)
    assert limiter.take("a", 0, reserve=1)
    assert not limiter.take("a", 1, reserve=1)
    assert limiter.take("b", 1)
    assert limiter.take("b", 1)
    assert not limiter.take("c", 2)
    assert not limiter.take("a", 59.999)
    assert limiter.take("a", 60)


def synthetic_market():
    market = np.full((1, 3, 390, 12), 100.0)
    truth = np.full((1, 12), 100.0)
    truth[0, 0] = 110
    return market, truth


def test_arrival_latency_and_limit_prevent_stale_fill():
    market, truth = synthetic_market()
    market[:, 2, 371:, 0] = 111  # quote disappears after decision but before arrival
    result = simulate_endgame(market, truth, truth, symbols=[0], fill_cap=50)
    assert result["positions"][0, 0] == 0
    assert result["pnl"][0] == 0
    assert result["reserved"][0, 0] > 0  # no invented IOC/cancellation


def test_position_depth_action_limits_and_cash_ledger():
    market, truth = synthetic_market()
    result = simulate_endgame(
        market,
        truth,
        truth,
        cost_bps=0,
        fixed_cost=0,
        symbols=[0],
        fill_cap=30,
        action_budget=3,
    )
    assert result["actions"][0] == 3
    assert result["positions"][0, 0] == 90
    assert result["pnl"][0] == 900
    assert np.all(result["positions"] <= LIMITS)


def test_partial_fills_reserve_unfilled_inventory():
    market, truth = synthetic_market()
    result = simulate_endgame(
        market,
        truth,
        truth,
        cost_bps=0,
        fixed_cost=0,
        symbols=[0],
        fill_cap=50,
        fill_fraction=0.5,
    )
    assert result["positions"][0, 0] == 100
    assert result["reserved"][0, 0] == 100
    assert result["pnl"][0] == 1000


def synthetic_feed_cube():
    n = 1
    d = {
        "market": np.full((n, 3, 390, 12), 100.0),
        "obs": np.full((n, 3, 241, 6), 1.0),
        "damage": np.zeros((n, 3, 390, 5)),
        "loss": np.zeros((n, 3, 390)),
        "stage": np.zeros((n, 3, 390)),
        "probability": np.zeros((n, 3, 390, 4)),
        "cone": np.zeros((n, 3, 390, 9)),
        "official": np.full((n, 3, 390), -1, dtype=int),
        "wire": np.full((n, 3, 390), -1, dtype=int),
        "site_xy": np.ones((17, 2)),
        "site_weight": np.full(17, 1 / 17),
        "site_company": np.array([0] + [1] * 3 + [2] * 4 + [3] * 5 + [4] * 4),
    }
    d["obs"][..., 4] = 80
    return d


def test_future_poisoning_cannot_change_current_features():
    d = synthetic_feed_cube()
    baseline = features(d, [180])[0][:, 0].copy()
    d["obs"][:, 0, 61:, :2] = 9000  # after current storm age 120
    d["damage"][:, 0, 100:] = 0.99
    d["loss"][:, 0, 100:] = 9000
    d["obs"][:, 1:] = 7
    d["damage"][:, 1:] = 0.77
    d["settlement_truth"] = np.full((1, 12), 999999)
    d["report_truth"] = np.full((1, 3, 5), 999999)
    d["pattern_truth"] = np.full((1, 3), 999999)
    np.testing.assert_array_equal(baseline, features(d, [180])[0][:, 0])


def test_feature_uses_only_previous_round_final_report():
    d = synthetic_feed_cube()
    d["damage"][:, 0, -1] = 0.2
    d["damage"][:, 1, -1] = 0.9
    _, damage, _, _ = features(d, [0])
    np.testing.assert_allclose(damage[:, 1, 0], 0.2)


def test_etf_values_match_baskets():
    x = np.arange(10.0)
    np.testing.assert_array_equal(with_etfs(x)[10:], BASKETS @ x)


def test_short_horizon_fills_at_arrival_and_exits_on_schedule():
    market, truth = synthetic_market()
    market[:, 0, 1:, 0] = 103
    market[:, 0, 6:, 0] = 105
    delta = np.zeros((1, 3, 78, 12))
    delta[:, 0, 0, 0] = 5
    result = simulate_short(
        market,
        truth,
        delta,
        np.arange(0, 780, 10),
        cost_bps=0,
        fixed_cost=0,
        fill_cap=10,
        threshold=0,
        top_k=1,
    )
    assert result["pnl"][0] == 20  # 10 * (105 - 103), not (105 - 100)
    assert result["actions"][0] == 2
    assert np.all(result["positions"] == 0)
