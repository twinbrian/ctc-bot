"""Publish the frozen mean-PnL experiment; no additional parameter selection."""

import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter
import numpy as np
import pandas as pd

from make_report import main as render_pdf


def usd(value):
    return f"USD {value:,.0f}"


def main():
    root = Path("results_v2")
    data = json.loads((root / "summary.json").read_text())
    scores = {x["scenario"]: x for x in data["scenarios"]}
    base, old = scores["base"], scores["v1_reference"]
    seasons = pd.read_csv(root / "outer_seasons.csv")
    attribution = pd.read_csv(root / "attribution.csv").sort_values(
        "v2_mean_usd", ascending=False
    )
    blue, green, gray = "#37688F", "#0F8877", "#657783"
    plt.rcParams.update(
        {
            "font.family": "DejaVu Sans",
            "font.size": 10,
            "axes.spines.top": False,
            "axes.spines.right": False,
        }
    )
    fig, axes = plt.subplots(2, 2, figsize=(13.5, 9.2), layout="constrained")
    ax = axes[0, 0]
    for name, label, color in [
        ("v1_reference", "Earlier policy", blue),
        ("base", "Mean-PnL policy", green),
    ]:
        ax.plot(
            np.sort(seasons[name]),
            np.arange(1, 601) / 600,
            label=label,
            color=color,
            lw=2.2,
        )
    ax.axvline(0, color=gray, linestyle="--", lw=1)
    ax.set(
        title="Higher mean, wider distribution",
        xlabel="Terminal PnL (USD)",
        ylabel="Fraction of seasons",
    )
    ax.xaxis.set_major_formatter(FuncFormatter(lambda x, _: f"{x / 1000:g}k"))
    ax.legend(loc="lower right", frameon=False)
    ax.grid(alpha=0.15)
    ax = axes[0, 1]
    x = np.arange(5)
    ax.bar(
        x - 0.18,
        [f["v1_summary"]["mean_usd"] for f in data["folds"]],
        width=0.36,
        color=blue,
        label="Earlier policy",
    )
    ax.bar(
        x + 0.18,
        [f["outer_summary"]["mean_usd"] for f in data["folds"]],
        width=0.36,
        color=green,
        label="Mean-PnL policy",
    )
    ax.set(
        title="Improvement across all five outer folds",
        xlabel="Outer fold",
        ylabel="Mean PnL (USD)",
        xticks=x,
    )
    ax.yaxis.set_major_formatter(FuncFormatter(lambda y, _: f"{y / 1000:g}k"))
    ax.legend(frameon=False, loc="upper right")
    ax.set_ylim(0, 12500)
    ax = axes[1, 0]
    names = [
        "base",
        "50bps",
        "12s_latency",
        "25_share_depth",
        "combined_stress",
        "10s_depth_replenishment",
    ]
    labels = [
        "Baseline",
        "50 bps each side",
        "12 s latency",
        "25 shares / 2 s",
        "Combined stress",
        "50 shares / 10 s",
    ]
    y = np.arange(len(names))
    values = [scores[k]["mean_usd"] for k in names]
    ax.barh(y, values, color=[green] + [blue] * 5)
    for yy, v in zip(y, values):
        ax.text(v + 110, yy, f"{v:,.0f}", va="center", fontsize=9)
    ax.set(
        yticks=y,
        yticklabels=labels,
        xlabel="Mean net PnL (USD)",
        title="Same policy, worse execution assumptions",
    )
    ax.invert_yaxis()
    ax.set_xlim(0, max(values) * 1.22)
    ax.xaxis.set_major_formatter(FuncFormatter(lambda z, _: f"{z / 1000:g}k"))
    ax = axes[1, 1]
    y = np.arange(3)
    values = base["engine_mean_usd"]
    ax.barh(y, values, color=[green, blue, gray])
    for yy, v in zip(y, values):
        ax.text(v + 100, yy, f"{v:,.0f}", va="center")
    ax.set(
        yticks=y,
        yticklabels=[
            "Formation positions",
            "Later short trades",
            "Final-report trades",
        ],
        xlabel="Contribution to mean PnL (USD)",
        title="Most profit comes from pre-positioning",
    )
    ax.invert_yaxis()
    ax.set_xlim(0, max(values) * 1.23)
    ax.xaxis.set_major_formatter(FuncFormatter(lambda z, _: f"{z / 1000:g}k"))
    fig.suptitle(
        "CTC 2026: optimizing expected terminal PnL", fontsize=20, weight="bold"
    )
    fig.supxlabel(
        "600 seasons • post-selection nested CV • hypothetical consensus fills, not order-book execution",
        fontsize=10,
        color=gray,
    )
    fig.savefig(root / "pnl-dashboard-v2.png", dpi=180)
    plt.close(fig)

    metrics = [
        ("Mean net PnL", usd(old["mean_usd"]), usd(base["mean_usd"])),
        ("Median net PnL", usd(old["median_usd"]), usd(base["median_usd"])),
        (
            "Profitable seasons",
            f"{int(round(old['win_rate'] * 600))}/600 ({old['win_rate']:.1%})",
            f"{int(round(base['win_rate'] * 600))}/600 ({base['win_rate']:.1%})",
        ),
        ("Worst season", usd(old["minimum_usd"]), usd(base["minimum_usd"])),
        (
            "Worst 5%: average PnL",
            usd(old["worst_5pct_mean_usd"]),
            usd(base["worst_5pct_mean_usd"]),
        ),
        (
            "Average within-season maximum drawdown",
            usd(old["mean_max_drawdown_usd"]),
            usd(base["mean_max_drawdown_usd"]),
        ),
        (
            "Average order actions",
            f"{old['mean_actions']:.1f}",
            f"{base['mean_actions']:.1f}",
        ),
        (
            "Average shares traded",
            f"{old['mean_turnover_shares']:,.0f}",
            f"{base['mean_turnover_shares']:,.0f}",
        ),
        (
            "Average execution costs",
            usd(old["mean_cost_usd"]),
            usd(base["mean_cost_usd"]),
        ),
    ]
    table = "\n".join("| " + " | ".join(row) + " |" for row in metrics)
    stress_names = [
        ("base", "Baseline"),
        ("50bps", "50 bps each side"),
        ("100bps", "100 bps each side"),
        ("4s_latency", "4 s latency"),
        ("12s_latency", "12 s latency"),
        ("25_share_depth", "25 shares per 2 s"),
        ("10_share_depth", "10 shares per 2 s"),
        ("combined_stress", "50 bps, 4 s latency, 25 shares per 2 s"),
        ("extra_25bps_adverse", "Unexpected extra 25 bps per side"),
        ("10s_depth_replenishment", "50 shares, replenishment every 10 s"),
    ]
    stress_table = "\n".join(
        f"| {label} | {usd(scores[name]['mean_usd'])} | {scores[name]['win_rate']:.1%} | {usd(scores[name]['minimum_usd'])} |"
        for name, label in stress_names
    )
    fold_table = []
    for f in data["folds"]:
        cfg, k = f["config"], f["fold"]
        a, b = cfg["formation"], cfg["ongoing"]
        fold_table.append(
            f"| {k} | {120 * k + 1}–{120 * (k + 1)} | {a['start']} s / {a['exit']} s | {a['entry_budget']} | {b['top_k']} / {usd(b['threshold']) if b['threshold'] == 0 else 'USD 0.10'} | {usd(f['outer_summary']['mean_usd'])} |"
        )
    timing = data["formation_timing_seconds_after_open"]
    engine_table = "\n".join(
        f"| {label} | {usd(value)} | {value / base['mean_usd']:.1%} |"
        for label, value in zip(
            [
                "Formation positions",
                "Subsequent short-horizon trades",
                "Final-report settlement trades",
            ],
            base["engine_mean_usd"],
        )
    )
    attr_text = ", ".join(
        f"{row.symbol} ({usd(row.v2_mean_usd)})"
        for row in attribution.head(4).itertuples()
    )
    f0 = data["folds"][0]
    text = f"""# CTC 2026: maximize expected terminal PnL

## Result

**Yes: a more aggressive, mean-PnL-selected strategy substantially outperformed the earlier policy in this research replay.** Its mean was **{usd(base["mean_usd"])} per season**, versus **{usd(old["mean_usd"])}**, a **{base["mean_usd"] / old["mean_usd"]:.2f}x** ratio under identical baseline execution assumptions. The improvement came primarily from accumulating larger positions before a predictable storm-formation repricing.

This objective accepts a less consistent result: {base["win_rate"]:.1%} of seasons were profitable versus {old["win_rate"]:.1%}; the worst season was {usd(base["minimum_usd"])}. The strategy is the best selected policy within the tested families, not a proof of a globally optimal trading algorithm.

**Evidence scope:** 600 seasons, five outer folds, 360 training / 120 inner-validation / 120 outer-evaluation seasons per fold. All seasons had already been examined in v1 research, so these are **post-selection nested-CV estimates, not a new untouched holdout**. Quotes are house consensus: no executable orderbooks or actual fills were supplied.

| Metric | Earlier policy | Mean-PnL policy |
|---|---:|---:|
{table}

The earlier policy's drawdown is the conservative sum of its two engine drawdowns; v2 measures the shared account every two seconds. The mean-PnL policy's conditional 95% season-bootstrap interval is **{usd(base["mean_ci95_usd"][0])} to {usd(base["mean_ci95_usd"][1])}**. Its paired mean improvement is **{usd(data["paired_improvement_mean_usd"])}**, with a conditional interval of {usd(data["paired_improvement_ci95_usd"][0])} to {usd(data["paired_improvement_ci95_usd"][1])}. These intervals do not include research-selection, model-fitting, simulator-change or live-execution uncertainty.

![PnL comparison, fold stability and execution stress](results_v2/pnl-dashboard-v2.png)

## 1. What we optimized

The competition scores cash plus final-settlement value of remaining positions. We selected parameters to maximize the **arithmetic mean of net terminal USD PnL** on the inner-validation seasons. There is no Sharpe objective, drawdown penalty, tail-loss penalty, minimum win rate, or stressed-performance ranking.

```text
Choose policy parameters theta to maximize:
    mean_over_validation_seasons(
        final_cash(theta) + positions(theta) @ settlement
    )

Subject to position limits, pending/resting reservations,
one-key rolling action limits, order latency and assumed depth.
```

Expected PnL, the probability of a profitable season, and the probability of beating every other team are different objectives. This experiment targets the first; the dataset provides no opponent PnL distribution for optimizing tournament win probability.

The baseline is unchanged: **25 bps plus USD 0.02 per share per side, two real seconds of order latency, 50 shares per instrument per two-second interval**, and one bot key with 60 order actions per rolling real minute. Settlement itself incurs no invented closing spread. We did not inflate available liquidity or use future-season prices to create the improvement.

## 2. The strategy

### A. Build inventory before the formation repricing

The storm forms 60 real seconds after each round opens. V1 found a systematic shift in house consensus shortly after formation: island businesses and HAVEN tend to rise, while rebuilders tend to fall. Instead of waiting for formation and trading small clips, v2 starts accumulating before it.

Fit a mean price trajectory separately for each round using the 360 training seasons. At the selected start time, anchor the predicted price change to the current season's observed price. Rank each available clip by predicted net profit in USD, after estimated entry and exit costs. Submit positive-edge clips, accumulating up to the legal per-symbol limit and the selected action budget.

Every fold selected the largest tested **60-entry-action formation budget**. This is at most 3,000 shares gross per round at 50 shares per order, with individual stock/ETF limits enforced. Average observed peak formation inventory was **{data["mean_formation_peak_shares"]:,.0f} shares gross**. Typical directions are long HAVEN, PORT, ARCH and other island exposure, and short REBLD and its constituents; individual clips must still cover costs. REIN's small average move usually does not.

**The exit time is an earliest submission time, not a guaranteed flattening time.** Using all 60 entry actions can leave no action capacity for immediate exits. In the selected replays, the first formation exit was submitted at a mean of {timing["first_exit"]["mean"]:.1f} seconds after open, and the account became flat at a mean of {timing["flat"]["mean"]:.1f} seconds; the latest was {timing["flat"]["max"]} seconds. The first official advisory arrives at t=90, so large inventory can remain exposed to that news. This helps explain the much larger tail losses.

### B. Trade later signals more frequently

After formation inventory and pending orders are flat, evaluate the existing public-feed/price model every **10 seconds**, instead of every 20. The model forecasts the next ten-second price change. Rank positive predicted net edges by USD contribution, permit five or eight symbols per decision, and reserve an exit action for every entry. The rolling scheduler blocks new orders when capacity is insufficient.

Four folds selected no extra edge cushion after costs; one retained USD 0.10 per share. These trades use 50-share clips, including ARCH's full 50-share limit. They close on a scheduled ten-second horizon, subject to arrival latency and available depth. Trading the final round stops early enough to hand the account to the settlement engine.

### C. Trade final-report valuation gaps

At t=740 of round 3, update structural fair values using the final published damage/loss reports and measured outages. Submit price-capped orders only when modeled execution is better than fair value. All folds selected **zero additional valuation margin**, rather than v1's USD 0.10. Unfilled limit orders reserve capacity and receive no passive-fill credit. The engine uses the actual remaining rolling budget rather than a fixed 20-action cap.

The fitted economics and public-feed features are the same as v1; `REPORT.md` contains the recovered damage, outage, rebuilder and insurance-layer equations.

### Contribution to net PnL

| Engine | Mean contribution | Share of net PnL |
|---|---:|---:|
{engine_table}

The largest instrument contributions were {attr_text}. Formation-only averaged {usd(scores["formation_only"]["mean_usd"])}; adding final-report trades produced {usd(scores["formation_plus_final"]["mean_usd"])}. Most of the improvement is therefore **sizing and timing a repeatable house-pricing effect**, rather than a new hurricane-path forecasting breakthrough. The formation attribution includes the entire holding window, including any advisory exposure before it is flat.

## 3. Exact selection and a concrete configuration

Each fold evaluated a fixed, staged 140-configuration search:

- Formation: starts 0/20/40/50/60 seconds; earliest exits 70/80/100/120; entry budgets 10/20/30/45/60. Select the best of 100 formation-only configurations by mean net PnL.
- Ongoing: thresholds USD 0.00/0.10/0.25, top-3/5/8, cadence 10/20 seconds. Compare 18 configurations with the selected formation engine and 18 without it, retaining the formation-only alternative.
- Endgame: margins USD 0.00/0.05/0.10/0.20, retaining the no-endgame alternative.

This is staged optimization, not an exhaustive joint search. All five choices were saved before any outer evaluation. Outer outcomes and stress tests did not determine the configurations.

| Fold | Outer seasons | Start / earliest exit | Entry actions | Later top-k / cushion | Outer mean |
|---|---|---|---:|---|---:|
{chr(10).join(fold_table)}

**Concrete original-split configuration:** accumulate from **t=40**, request formation exits from **t=80**, use at most **60 entry actions**, then trade **top five positive-net-edge signals every ten seconds**, with **zero extra cushion** and **zero extra final-report margin**. All times are real seconds after market open. If the formation budget is exhausted by t=50, the first exits may have to wait until entry actions start expiring around t=100; the simulator includes that wait.

This configuration was selected using seasons 240–121, with models trained on 600–241, and produced **{usd(f0["outer_summary"]["mean_usd"])}** on the 120 original-split evaluation seasons, versus **{usd(f0["v1_summary"]["mean_usd"])}** for v1. That evaluation set was already inspected during v1. The pooled {usd(base["mean_usd"])} result evaluates the selection procedure across five fold-specific configurations, not a single universal configuration chosen after seeing all 600 outcomes.

## 4. Execution robustness

All rows retain the frozen policy parameters. For known higher costs the policy recomputes its net-edge decision using that cost; the adverse-cost row charges an unanticipated extra 25 bps without changing its cost forecast. No scenario was used to select this policy.

| Scenario | Mean net PnL | Profitable | Worst season |
|---|---:|---:|---:|
{stress_table}

Unlike v1's reactive formation entry, v2 generally builds inventory before the event. This reduces dependence on beating a four-second repricing window, but increases inventory exposure and liquidity demand. At 12 seconds of latency the subsequent short-trade engine loses money on average; most surviving profit comes from pre-positioning.

The result remains conditional on unverified capacity. A consensus-price replay cannot measure house inventory skew caused by our trades, competitor crowding, nonlinear market impact, price protection, or actual queue/fill behavior. The 10-second replenishment scenario challenges repeated clips but is not an observed liquidity estimate. If executable prices move before we can accumulate, the formation edge can vanish.

## 5. Testing and interpretation

- One shared cash ledger tracks formation, later trades and settlement; component and instrument attribution reconcile exactly to final PnL.
- Pending and resting quantities reserve inventory. Late fills use their arrival-time price. No future settlement value influences entry decisions.
- Every two-second action history is checked against a rolling 60-action window. The maximum observed was 60; the maximum observed per-symbol position fraction was 1.0. No second bot key or team-limit expansion was needed.
- Tests cover rate-limited delayed exits, slow liquidity replenishment, overlapping entry/exit latency, future-price poisoning, prefix feature causality, report replacement, duplicate feeds, snapshots and ETF accounting.
- Whole seasons are the unit of splitting and bootstrap resampling. No storm, instrument or tick from an outer-test season enters that fold's fit or parameter selection.
- Cross-validation is grouped by season and block, not chronological walk-forward; four folds can train on numerically newer seasons. The original-split fold preserves the oldest-to-newest ordering. This is appropriate as a simulator stability check, subject to the packet's same-simulator assumption.
- Strategy families and model hyperparameters inherit earlier research. Nested refitting reduces direct fit/tuning leakage; it cannot undo the fact that the dataset has already informed our ideas.

**Bottom line:** if the objective is maximum expected terminal PnL within this tested setup, prefer the larger pre-positioning strategy over the earlier conservative policy. Accept that it loses more often and can lose substantially more in one season. Before using it in the competition, the decisive missing evidence is whether the testnet actually supplies the required pre-event fills and whether announcements preserve the fitted economics.

## Files and reproduction

The compact v2 code/results kit includes source, model-training code, frozen choices, all inner-validation candidates, per-season outer outcomes, stress results and action-audit arrays. Model weights and large prediction caches are regenerated from the original dataset; see `README_V2.md` for the commands. `results_v2/reproduction_certificate.json` records input/config hashes and the test run. Everything remains local and standalone; no Ramp repository or branch was created.
"""
    Path("REPORT_V2.md").write_text(text)
    render_pdf("REPORT_V2.md", "../ctc-2026-research-report-v2.pdf", "v2")


if __name__ == "__main__":
    main()
