"""Build a hashed compact research deliverable; never fit or score candidates."""

import hashlib
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

from make_report import main as render_report

ROOT = Path(__file__).resolve().parent
V5 = ROOT / "research_v5"


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def binary_result(path):
    relative = path.relative_to(V5)
    family = relative.parts[0]
    if family == "report":
        return path.suffix == ".png"
    if family == "reproduction":
        return path.name.startswith("deployment_")
    if path.suffix != ".npz":
        return False
    if family in {"pooled_clock", "pooled_conditional"}:
        return path.name.startswith("pooled_")
    if family == "execution_matrix":
        return path.name == "per_season.npz"
    if family == "clock_robustness":
        return path.name in {"bootstrap_predictions.npz", "bootstrap_samples.npz"}
    return family in {
        "stability_execution",
        "information_lag",
        "audit",
        "audit_schedule",
    }


def main():
    pdf = ROOT.parent / "ctc-2026-research-report-v5.pdf"
    render_report(str(ROOT / "REPORT_V5.md"), str(pdf), "v5 • frozen research")
    candidates = set(ROOT.glob("*.py")) | set(ROOT.glob("*.md"))
    candidates |= set(ROOT.glob("requirements*.txt"))
    candidates |= set((ROOT / "tests").rglob("*.py"))
    for directory in ["research_v4", "research_v5", "results_v2", "results_v3"]:
        candidates |= set((ROOT / directory).rglob("*"))
    included, omitted = [], []
    text_suffixes = {".py", ".md", ".txt", ".json", ".csv", ".patch"}
    excluded_names = {
        "opencode-openapi.json",
        "packet.txt",
        "packet_compact.txt",
        "run_state.json",
        "workers.json",
    }
    for path in sorted(candidates):
        if not path.is_file():
            continue
        relative = path.relative_to(ROOT)
        if any(
            part.startswith(".") or part == "__pycache__" for part in relative.parts
        ):
            continue
        if (
            path.name in excluded_names
            or "jobs" in relative.parts
            or "handoffs" in relative.parts
        ):
            continue
        text = path.suffix in text_suffixes and path.stat().st_size <= 500_000
        if path.suffix == ".csv":
            text = text and (
                "report" in relative.parts
                or (
                    relative.parts[0] == "research_v5"
                    and any(
                        word in path.stem
                        for word in [
                            "comparison",
                            "per_season",
                            "all_seasons",
                            "summary",
                        ]
                    )
                )
            )
        binary = path.is_relative_to(V5) and binary_result(path)
        if not (text or binary):
            omitted.append({"path": str(relative), "bytes": path.stat().st_size})
            continue
        included.append(path)
    manifest = {
        "version": "v5",
        "qualification": "Post-selection historical simulations on 600 previously researched seasons; hypothetical fills",
        "entry_point": "README_V5.md",
        "source_sha256": {str(p.relative_to(ROOT)): digest(p) for p in included},
        "pdf_sha256": digest(pdf),
        "omitted": omitted,
        "omission_note": "Original raw dataset and root cache are not included. Duplicate models/caches and bulky optional checkpoints are omitted; reproduce_v5.py refits the main policies.",
    }
    manifest_path = ROOT / "PACKAGE_MANIFEST_V5.json"
    manifest_path.write_text(json.dumps(manifest, indent=2) + "\n")
    archive = ROOT.parent / "ctc-2026-research-package-v5.zip"
    prefix = "ctc-2026-research-v5/"
    with ZipFile(archive, "w", ZIP_DEFLATED, compresslevel=6) as zipped:
        for path in [*included, manifest_path]:
            zipped.write(path, prefix + str(path.relative_to(ROOT)))
        zipped.write(pdf, prefix + pdf.name)
    with ZipFile(archive) as zipped:
        assert zipped.testzip() is None
        for name, expected in manifest["source_sha256"].items():
            assert hashlib.sha256(zipped.read(prefix + name)).hexdigest() == expected
    print(
        json.dumps(
            {
                "files": len(included) + 2,
                "archive_mb": archive.stat().st_size / 1e6,
                "pdf": str(pdf),
                "archive": str(archive),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
