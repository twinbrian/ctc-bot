"""Predict post-report execution prices from fully observed storm paths.

Targets are labels only: mean t=742..774 house price in rounds 1/2, terminal
fundamental value in round 3. At all decision times the storm has dissipated.
"""

import pickle
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.linear_model import Ridge
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

from common import SYMBOLS, dump_json, load_cache, with_etfs
from models import features
from physics_v3 import path_features
from pnl_v2_train import masks

STARTS = np.array([540, 570, 600, 660, 700])


def predictors(d):
    public = features(d, STARTS)[0]
    prices = d["market"][:, :, STARTS // 2]
    lag30 = d["market"][:, :, (STARTS - 30) // 2]
    lag60 = d["market"][:, :, (STARTS - 60) // 2]
    path = path_features(d, cutoff=2.0)
    path = np.broadcast_to(path[:, :, None, :], (*public.shape[:3], path.shape[-1]))
    return np.concatenate(
        [public, prices, prices - lag30, prices - lag60, path], axis=-1
    ), prices


def fit_fold(fold):
    d = load_cache("cache.npz")
    x, prices = predictors(d)
    train, val, test = masks(fold)
    ids = np.flatnonzero(val | test)
    # Exits are spread over this window by actual order/rate scheduling. This is
    # a training target approximation, not an assumption about test execution.
    target = d["market"][:, :, 371:388, :10].mean(2)
    target[:, 2] = d["settlement_truth"][:, :10]
    residual = target[:, :, None, :] - prices[..., :10]
    estimates = {}
    models = {}
    scores = []
    for kind in ["ridge", "hgb7", "hgb15"]:
        preds = np.empty((*x[ids].shape[:-1], 10))
        models[kind] = []
        for j, symbol in enumerate(SYMBOLS[:10]):
            if kind == "ridge":
                model = make_pipeline(StandardScaler(), Ridge(alpha=100))
            else:
                model = HistGradientBoostingRegressor(
                    max_iter=200,
                    max_leaf_nodes=int(kind[3:]),
                    learning_rate=0.05,
                    min_samples_leaf=50,
                    l2_regularization=20,
                    early_stopping=False,
                    random_state=2026,
                )
            model.fit(
                x[train].reshape(-1, x.shape[-1]), residual[train, ..., j].ravel()
            )
            preds[..., j] = (
                model.predict(x[ids].reshape(-1, x.shape[-1])).reshape(
                    x[ids].shape[:-1]
                )
                + prices[ids, ..., j]
            )
            models[kind].append(model)
        estimates[kind] = with_etfs(preds)
        localval = np.isin(ids, np.flatnonzero(val))
        for j, symbol in enumerate(SYMBOLS[:10]):
            for k, t in enumerate(STARTS):
                y = target[val, :, j]
                pred = preds[localval, :, k, j]
                scores.append(
                    {
                        "fold": fold,
                        "model": kind,
                        "symbol": symbol,
                        "start": int(t),
                        "validation_rmse_usd": float(np.sqrt(np.mean((pred - y) ** 2))),
                        "validation_house_rmse_usd": float(
                            np.sqrt(np.mean((prices[val, :, k, j] - y) ** 2))
                        ),
                    }
                )
        print("Aftermath fit", fold, kind, flush=True)
    out = Path("results_v3")
    out.mkdir(exist_ok=True)
    np.savez_compressed(
        out / f"fold-{fold}-aftermath-predictions.npz",
        ids=ids,
        starts=STARTS,
        **estimates,
        train_ids=np.flatnonzero(train),
        val_ids=np.flatnonzero(val),
        test_ids=np.flatnonzero(test),
    )
    with open(out / f"fold-{fold}-aftermath-models.pkl", "wb") as f:
        pickle.dump(models, f)
    pd.DataFrame(scores).to_csv(
        out / f"fold-{fold}-aftermath-validation-errors.csv", index=False
    )


def main():
    dump_json(
        "results_v3/aftermath_model_plan.json",
        {
            "starts": STARTS.tolist(),
            "models": ["ridge_alpha100", "hgb7", "hgb15"],
            "target": "mean t742..774 house price in rounds1/2, final settlement in round3",
            "features": "public feed prefixes, observed prices/lags, fully observed path with 2r Gaussian cutoff",
            "qualifications": "Same dataset examined before; fold models never fit their validation or outer evaluation seasons",
        },
    )
    with ProcessPoolExecutor(max_workers=5) as pool:
        list(pool.map(fit_fold, range(5)))


if __name__ == "__main__":
    main()
