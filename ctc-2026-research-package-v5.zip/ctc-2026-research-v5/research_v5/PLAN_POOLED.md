# Frozen clock strategy: broader retrospective evaluation

No additional policy selection. Use the selected entry180/exit540/full clock
schedule in every fold. Reuse each of the five existing360-season training folds
and its saved model/mean-curve predictions; score the disjoint120-season outer
folds. All600 seasons were previously observed by research, including policy
development on241–360 and diagnostic121–240. The pooled estimate is therefore
post-selection, not an independent holdout or an unbiased policy-selection test.

Matched comparator fixes formation20/100/full, top5 ten-second tail and final740
in every fold with continuous zero-gap action history. A formation+final-only
ablation runs at baseline. Preserve the historical fold-selected V3 result as a
separate published comparator, not as the matched control.

Predeclared scenarios: baseline;50bps;6s latency;25-share depth; combined50bps/6s/
25shares; strict combined50bps+USD0.04/side/6s/25shares/10bps adverse;12s latency;
10-share depth;10-second depth replenishment. Record infeasible flattening as a
blocked stress, never an artificially flat account. Keep full season results,
attributions and action ledgers. Source and fit membership hashes are recorded.
