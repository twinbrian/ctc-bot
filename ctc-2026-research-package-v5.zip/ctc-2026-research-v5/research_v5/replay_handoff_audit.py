"""Replay frozen schedules after execution fixes; never refit or retune."""

import hashlib
import json
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from research_v4.lab import load_development
from research_v4.lead.shared_account import simulate_account
from research_v5.handoff_research import SCENARIOS, forecasts, npz, write_json


def main():
    out = ROOT / "research_v5/handoff_audited"
    out.mkdir(exist_ok=True)
    if (out / "COMPLETE.json").exists():
        return
    data = load_development()
    mask, pred = forecasts(data, "inner")
    rows = []
    for scenario, settings in SCENARIOS.items():
        for handoff in ["wait60", "ready"]:
            name = f"inner_{scenario}_{handoff}.npz"
            original = dict(np.load(ROOT / "research_v5/handoff" / name))
            if (out / name).exists():
                current = dict(np.load(out / name))
            else:
                current = simulate_account(
                    data["market"][mask],
                    data["settlement_truth"][mask],
                    pred["curve"],
                    pred["delta"],
                    pred["final_fair"],
                    handoff=handoff,
                    round_gap_seconds=0,
                    **settings,
                )
                npz(out / name, **current)
            differences = {}
            for key in ["pnl", "cost", "actions", "action_ticks", "positions"]:
                differences[key] = float(np.max(np.abs(current[key] - original[key])))
            rows.append(
                {"scenario": scenario, "handoff": handoff, "differences": differences}
            )
            print(json.dumps(rows[-1]), flush=True)
            write_json(out / "comparison.json", rows)
    sources = [
        "pnl_v2_simulator.py",
        "etf_route_v3.py",
        "replay_contract.py",
        "research_v4/lead/shared_account.py",
    ]
    write_json(
        out / "COMPLETE.json",
        {
            "source_hashes": {
                p: hashlib.sha256((ROOT / p).read_bytes()).hexdigest() for p in sources
            },
            "all_fields_match": all(not any(r["differences"].values()) for r in rows),
            "new_policy_count": 0,
            "seasons": pred["eval_seasons"].tolist(),
        },
    )


if __name__ == "__main__":
    main()
