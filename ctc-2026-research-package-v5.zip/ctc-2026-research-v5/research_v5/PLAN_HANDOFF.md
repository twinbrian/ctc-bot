# Resume the previously declared shared-budget handoff experiment

No new search: carry forward research_v4/lead/PLAN_HANDOFF.md's one challenger,
the same start20/exit100/full-exposure formation, top5 ten-second predictor and
zero endgame margin. Finish the missing fit361–600/inner241–360 comparison.
Freeze before refit241–600/validation121–240. No1–120 assessment here.

First reproduce the legacy wait60 policy using a verified60-second inter-round
gap so previous-round action overlap is absent. Primary paired comparison uses
zero gaps and continuous history for BOTH wait60 and ready variants; if enforcing
history changes the control relative to the old simulator, document it separately.
Ready means actually flat, no pending route orders, plus one depth interval.

Scenario set declared before scoring: baseline;50bps;latency6;depth25;
50bps+latency6+depth25;unexpected10bps;50shares/10s replenishment. Keep model and
policy fixed. Report incremental net PnL, cost, actions, earliest readiness,
position/rolling-budget compliance and seasonal tails. Do not add standalone
engine profits without executing the shared account. Freeze by inner baseline
mean; stress results remain explicit, not a hidden new objective.
