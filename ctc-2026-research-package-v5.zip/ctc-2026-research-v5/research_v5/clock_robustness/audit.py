"""Audit saved membership/alignment/metrics; does not refit or inspect PnL."""

import hashlib
import json
from pathlib import Path
import pickle
import sys

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from research_v5.clock_forecast.forecast import HGB_PARAMS, errors

HERE = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    spec = json.loads((HERE / "frozen.json").read_text())
    for group in ["original_source_hashes", "robustness_source_hashes"]:
        for name, digest in spec[group].items():
            assert sha(ROOT / name) == digest
    with np.load(HERE / "public_features_targets.npz") as full:
        targets, features = full["actual_jump"], full["features"]
    expected_samples = (
        np.random.default_rng(20261019).integers(0, 240, size=(30, 240)) + 361
    )
    samples = np.load(HERE / "bootstrap_samples.npz")
    np.testing.assert_array_equal(samples["sample_ids"], expected_samples)
    counts = np.stack(
        [np.bincount(row - 361, minlength=240) for row in expected_samples]
    )
    np.testing.assert_array_equal(samples["inclusion_counts"], counts)
    np.testing.assert_array_equal(samples["membership"], counts > 0)
    assert (counts.sum(1) == 240).all()
    hashes = [
        hashlib.sha256(row.astype("<i4").tobytes()).hexdigest()
        for row in expected_samples
    ]
    np.testing.assert_array_equal(samples["sample_sha256"], hashes)
    complete = []
    model_index = {}
    for directory in sorted((HERE / "panels").glob("P*")) + sorted(
        (HERE / "bootstrap").glob("B*")
    ):
        if not (directory / "COMPLETE.json").exists():
            continue
        report = json.loads((directory / "metrics.json").read_text())
        lo, hi = report["evaluation_seasons"]
        actual = targets[lo - 1 : hi]
        for name in ["hgb", "round_mean"]:
            with np.load(directory / f"{name}.npz") as z:
                np.testing.assert_array_equal(z["season_ids"], np.arange(lo, hi + 1))
                assert z["jump"].shape == (120, 3, 10)
                recomputed = errors(z["jump"], actual)
                for key in recomputed:
                    np.testing.assert_allclose(
                        recomputed[key],
                        report["metrics"][name][key],
                        rtol=0,
                        atol=1e-12,
                    )
        with (directory / "models.pkl").open("rb") as f:
            model = pickle.load(f)
        regressors = model["hgb"] if isinstance(model, dict) else model.hgb
        assert len(regressors) == 10
        for regressor in regressors:
            params = regressor.get_params()
            assert all(params[k] == v for k, v in HGB_PARAMS.items())
            assert regressor.n_iter_ == 100
            assert (
                max(
                    int(tree[0].nodes["is_leaf"].sum())
                    for tree in regressor._predictors
                )
                <= 7
            )
        provenance = dict(model_sha256=sha(directory / "models.pkl"))
        if directory.name.startswith("B"):
            i = report["replicate_id"] - 1
            row = expected_samples[i]
            assert report["sample_sha256"] == hashes[i]
            control = np.load(directory / "round_mean.npz")["jump"]
            np.testing.assert_array_equal(
                control, np.broadcast_to(targets[row - 1].mean(0), control.shape)
            )
            provenance.update(
                sample_sha256=hashes[i],
                training_features_sha256=hashlib.sha256(
                    np.ascontiguousarray(features[row - 1]).tobytes()
                ).hexdigest(),
                training_targets_sha256=hashlib.sha256(
                    np.ascontiguousarray(targets[row - 1]).tobytes()
                ).hexdigest(),
            )
        elif report["reused_from"]:
            for filename, digest in report["reused_hashes"].items():
                original = (
                    ROOT
                    / "research_v5/clock_forecast"
                    / report["reused_from"]
                    / filename
                )
                assert sha(original) == sha(directory / filename) == digest
        if directory.name.startswith("P"):
            fit_lo, fit_hi = report["fit_seasons"]
            control = np.load(directory / "round_mean.npz")["jump"]
            np.testing.assert_array_equal(
                control,
                np.broadcast_to(targets[fit_lo - 1 : fit_hi].mean(0), control.shape),
            )
        model_index[str(directory.relative_to(HERE))] = provenance
        complete.append(directory.name)
    if (HERE / "bootstrap_predictions.npz").exists():
        with np.load(HERE / "bootstrap_predictions.npz") as aggregate:
            assert aggregate["hgb"].shape == (30, 120, 3, 10)
            for i in range(30):
                for name in ["hgb", "round_mean"]:
                    np.testing.assert_array_equal(
                        aggregate[name][i],
                        np.load(HERE / "bootstrap" / f"B{i + 1:02d}" / f"{name}.npz")[
                            "jump"
                        ],
                    )
            for key in [
                "sample_ids",
                "inclusion_counts",
                "membership",
                "sample_sha256",
            ]:
                np.testing.assert_array_equal(aggregate[key], samples[key])
    (HERE / "model_index.json").write_text(json.dumps(model_index, indent=2) + "\n")
    report = dict(
        completed_checkpoints=complete,
        complete_count=len(complete),
        fixed_parameters=True,
        labels_alignment_and_all_metrics_recomputed=True,
        whole_season_membership_and_hashes_exact=True,
        reused_panels_byte_identical=True,
        aggregate_matches_individuals=(HERE / "bootstrap_predictions.npz").exists(),
        no_refit_or_trading=True,
    )
    (HERE / "audit.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
