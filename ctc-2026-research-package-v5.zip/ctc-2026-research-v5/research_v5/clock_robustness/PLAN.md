# Frozen current-round HGB robustness — v1

Authorized bounded robustness, not a policy/model search. Cumulative starting
model estimate USD40.1172595; total research stop USD55. No descendants or paid
compute. Stop starting fits at USD53 to reserve delivery headroom, or immediately
on the parent's STOP file. All earlier outputs remain intact.

Exactly four descending-ID forward-chaining panels, as requested:

1. Fit481–600 / evaluate361–480: new fixed HGB and train-only round mean.
2. Fit361–600 / evaluate241–360: reuse existing inner models/predictions unchanged.
3. Fit241–600 / evaluate121–240: reuse existing diagnostic models/predictions unchanged.
4. Fit121–600 / evaluate1–120: newly authorized use of1–120, fixed HGB and mean.

All600 seasons were previously researched. No fresh holdout is asserted.
Indices represent the requested ordering; no calendar or season ID is a feature.
The full cache row index is season ID minus1 (prepare.py); verify overlap with the
explicit development IDs before using this mapping. Never load manifest truths.

Exactly30 bootstrap replicates: NumPy default_rng(20261019), generate a30×240
matrix of integer sample indices in[0,240), mapping into ascending361–600 IDs.
Each sampled season retains all three rounds; multiplicity weights both HGB and
the round mean. Evaluate every replicate on the identical241–360 block. Save
ordered sample IDs, inclusion counts, membership masks and SHA256 of each ordered
sample-ID vector encoded little-endian int32. No seed/run selection or PnL.

Use the already frozen94-feature as-of180 public physical/guidance/quote/round
design and unchanged HGB parameters: squared_error,100 iterations,7 leaves,
min_samples_leaf40,L2=30,learning_rate.06,max_bins255,early_stopping=False,
max_depth=None,algorithm random_state0. No new model, feature, threshold or
hyperparameter. Target remains mean quotes542..552 inclusive minus quote180,
for ten stocks. All future values are labels only.

Report every panel/run's signed bias (prediction−actual) and RMSE, including
negative comparisons, and the entire bootstrap error distribution. Neither
ensembling nor selecting a bootstrap run is authorized. No policy execution or
trading score in this worker; parent owns identical common-account evaluation.

One process, one BLAS/OMP thread, tmux and atomic per-fit completion. Preserve all
fitted bootstrap models locally; omit them from the compact artifact. Include
aligned jumps, membership/hashes, source, all numerical metrics and progress.
