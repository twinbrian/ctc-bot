"""Export every completed robustness result, never select a bootstrap run."""

import hashlib
import json
from pathlib import Path
import zipfile

import numpy as np

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def summarize(values):
    x = np.asarray(values)
    return dict(
        n=len(x),
        mean=float(x.mean()),
        median=float(np.median(x)),
        minimum=float(x.min()),
        maximum=float(x.max()),
        p05=float(np.quantile(x, 0.05)),
        p95=float(np.quantile(x, 0.95)),
    )


def main():
    rows = [
        "# Frozen HGB robustness results — v1",
        "",
        "Forecast errors only, USD/share. Signed bias = prediction−actual.",
        "All data previously researched; no trading or run selection.",
        "",
        "## Four forward panels",
        "",
        "| Panel | Fit / evaluation | HGB RMSE / bias | Round mean RMSE / bias | Reused |",
        "|---|---|---:|---:|---|",
    ]
    panel_results = {}
    for directory in sorted((HERE / "panels").glob("P*")):
        if not (directory / "COMPLETE.json").exists():
            continue
        report = json.loads((directory / "metrics.json").read_text())
        panel_results[directory.name] = report
        h, c = report["metrics"]["hgb"], report["metrics"]["round_mean"]
        rows.append(
            f"| {directory.name} | {report['fit_seasons']} / {report['evaluation_seasons']} | {h['rmse']:.6f} / {h['bias']:.6f} | {c['rmse']:.6f} / {c['bias']:.6f} | {report['reused_from'] or 'no'} |"
        )
    all_runs = []
    rows += [
        "",
        "## Entire bootstrap error distribution, original sample order",
        "",
        "| Run | HGB RMSE | HGB bias | Mean-control RMSE | Mean-control bias | HGB−control RMSE |",
        "|---|---:|---:|---:|---:|---:|",
    ]
    for directory in sorted((HERE / "bootstrap").glob("B*")):
        if not (directory / "COMPLETE.json").exists():
            continue
        report = json.loads((directory / "metrics.json").read_text())
        all_runs.append(report)
        h, c = report["metrics"]["hgb"], report["metrics"]["round_mean"]
        rows.append(
            f"| {directory.name} | {h['rmse']:.6f} | {h['bias']:.6f} | {c['rmse']:.6f} | {c['bias']:.6f} | {h['rmse'] - c['rmse']:.6f} |"
        )
    summary = dict(
        panels_completed=len(panel_results),
        bootstraps_completed=len(all_runs),
        bootstrap_requested=30,
        panels=panel_results,
        all_bootstrap_runs=all_runs,
        no_run_selected=True,
        no_trading_scored=True,
    )
    if all_runs:
        summary["distribution"] = {
            name: {
                metric: summarize([r["metrics"][name][metric] for r in all_runs])
                for metric in ["rmse", "bias"]
            }
            for name in ["hgb", "round_mean"]
        }
        delta = [
            r["metrics"]["hgb"]["rmse"] - r["metrics"]["round_mean"]["rmse"]
            for r in all_runs
        ]
        summary["paired_rmse_difference_distribution"] = summarize(delta)
        summary["hgb_worse_than_resampled_control_count"] = int(
            (np.array(delta) > 0).sum()
        )
        rows += [
            "",
            f"Completed {len(all_runs)}/30 bootstraps; all results retained. HGB has higher pooled RMSE than its same-sample control in {summary['hgb_worse_than_resampled_control_count']} runs.",
            "",
            "### Numerical distribution summaries",
            "",
            "```json",
            json.dumps(summary["distribution"], indent=2),
            "```",
        ]
    if (HERE / "bootstrap_predictions.npz").exists():
        with np.load(HERE / "bootstrap_predictions.npz") as predictions:
            summary["mean_prediction_sd_by_stock"] = {
                name: predictions[name].std(axis=0).mean(axis=(0, 1)).tolist()
                for name in ["hgb", "round_mean"]
            }
    (HERE / "SUMMARY.json").write_text(json.dumps(summary, indent=2) + "\n")
    (HERE / "RESULTS.md").write_text("\n".join(rows) + "\n")
    source = []
    for p in HERE.rglob("*"):
        if not p.is_file() or p.suffix not in [".py", ".md", ".json", ".npz", ".pkl"]:
            continue
        if p.name in ["cache.npz", "public_features_targets.npz", "manifest.json"]:
            continue
        if "bootstrap" in p.relative_to(HERE).parts and p.suffix == ".pkl":
            continue
        source.append(p)
    source += [
        ROOT / p
        for p in [
            "common.py",
            "models.py",
            "case.json",
            "prepare.py",
            "research_v5/job_runner.py",
            "research_v5/terminal/model.py",
            "research_v5/clock_forecast/forecast.py",
            "research_v5/clock_forecast/requirements.txt",
            "research_v5/clock_forecast/frozen.json",
            "research_v5/clock_forecast/PLAN.md",
        ]
    ]
    source += list((ROOT / "research_v5/jobs").glob("clock-robustness*.json"))
    source = sorted(set(source))
    manifest = {
        str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
        for p in source
    }
    (HERE / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    source.append(HERE / "manifest.json")
    bundle = ROOT / "ctc-v5-clock-robustness-v1.zip"
    with zipfile.ZipFile(bundle, "w", zipfile.ZIP_DEFLATED) as z:
        for p in source:
            z.write(p, p.relative_to(ROOT))
    print(bundle, bundle.stat().st_size, "bytes", len(source), "files")
    print(
        json.dumps(
            {
                k: summary[k]
                for k in [
                    "panels_completed",
                    "bootstraps_completed",
                    "distribution",
                    "paired_rmse_difference_distribution",
                    "hgb_worse_than_resampled_control_count",
                ]
                if k in summary
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
