"""Fixed forward panels and whole-season bootstrap; never inspect trading PnL."""

import hashlib
import json
from pathlib import Path
import pickle
import shutil
import subprocess
import sys

import numpy as np
from sklearn.ensemble import HistGradientBoostingRegressor

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from common import SYMBOLS
from research_v5.clock_forecast.forecast import (
    HGB_PARAMS,
    atomic,
    audit_prefix,
    errors,
    features,
    target_jump,
)
from research_v5.terminal.model import PUBLIC, STATIC

HERE = Path(__file__).resolve().parent
OLD = ROOT / "research_v5/clock_forecast"
PANELS = [
    ("P1", (481, 600), (361, 480), None),
    ("P2", (361, 600), (241, 360), "inner"),
    ("P3", (241, 600), (121, 240), "diagnostic"),
    ("P4", (121, 600), (1, 120), None),
]


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def guard():
    if any(p.exists() for p in [ROOT / "research_v5/STOP.json", HERE / "STOP.json"]):
        raise SystemExit("Research stop requested; checkpoints preserved")
    usage = json.loads(
        subprocess.check_output(
            ["opencode", "stats", "--all", "--cost", "--json"], cwd=ROOT
        )
    )
    atomic(HERE / "usage_latest.json", usage)
    if usage["cost"] >= 53:
        raise SystemExit("USD53 new-fit stop; reserve headroom below USD55 total")


def freeze():
    original = json.loads((OLD / "frozen.json").read_text())
    assert original["hgb"] == HGB_PARAMS
    for name, expected in original["source_hashes"].items():
        assert digest(ROOT / name) == expected
    spec = dict(
        original_hgb=HGB_PARAMS,
        original_source_hashes=original["source_hashes"],
        robustness_source_hashes={
            str(p.relative_to(ROOT)): digest(p)
            for p in [HERE / "PLAN.md", Path(__file__)]
        },
        panels=PANELS,
        bootstrap_replicates=30,
        bootstrap_rng=20261019,
        bootstrap_sample_size_seasons=240,
        new_fit_stop_usd=53,
        no_trading_scored=True,
        no_model_or_run_selected=True,
    )
    path = HERE / "frozen.json"
    normalized = json.loads(json.dumps(spec))
    if path.exists():
        assert json.loads(path.read_text()) == normalized
    else:
        atomic(path, normalized)


def build_features():
    path = HERE / "public_features_targets.npz"
    if path.exists():
        return dict(np.load(path))
    cache = HERE / "cache.npz"
    if not cache.exists():
        shutil.copyfile("/tmp/files/34e4-cache.npz", cache)
    with np.load(cache) as full, np.load(ROOT / "research_v4/development.npz") as dev:
        assert full["market"].shape[0] == 600
        ids = dev["season_ids"].astype(int)
        overlap = {}
        for key in PUBLIC:
            np.testing.assert_array_equal(full[key][ids - 1], dev[key])
            overlap[key] = "exact match for all development IDs"
        for key in STATIC:
            np.testing.assert_array_equal(full[key], dev[key])
        data = {key: full[key] for key in PUBLIC + STATIC}
        data["season_ids"] = np.arange(1, 601)
    audit_prefix(data)
    result = dict(
        features=features(data),
        actual_jump=target_jump(data["market"]),
        season_ids=np.arange(1, 601),
    )
    assert (
        np.isfinite(result["features"]).all()
        and np.isfinite(result["actual_jump"]).all()
    )
    for phase in ["inner", "diagnostic"]:
        with np.load(OLD / phase / "features.npz") as previous:
            for key, ids_key in [
                ("train", "train_season_ids"),
                ("evaluation", "evaluation_season_ids"),
            ]:
                np.testing.assert_array_equal(
                    result["features"][previous[ids_key] - 1], previous[key]
                )
        with np.load(OLD / phase / "targets.npz") as previous:
            np.testing.assert_array_equal(
                result["actual_jump"][previous["season_ids"] - 1],
                previous["actual_jump"],
            )
    atomic(path, result, "npz")
    atomic(
        HERE / "data_audit.json",
        dict(
            cache_sha256=digest(cache),
            public_overlap=overlap,
            row_mapping="prepare.py: row = season_id - 1; all121–600 public arrays matched",
            previous_features_and_labels="exact match for both existing stages",
            prefix_mutation="passed all rounds",
            truths_loaded=False,
        ),
    )
    return result


def fit_or_resume(directory, x, y):
    path = directory / "models.pkl"
    if path.exists():
        with path.open("rb") as f:
            return pickle.load(f)
    xx, yy = x.reshape(-1, x.shape[-1]), y.reshape(-1, 10)
    fitted = dict(
        hgb=[
            HistGradientBoostingRegressor(**HGB_PARAMS).fit(xx, yy[:, j])
            for j in range(10)
        ],
        round_mean=y.mean(0),
    )
    atomic(path, fitted, "pickle")
    return fitted


def predict(model, x):
    xx = x.reshape(-1, x.shape[-1])
    return dict(
        hgb=np.column_stack([m.predict(xx) for m in model["hgb"]]).reshape(
            len(x), 3, 10
        ),
        round_mean=np.broadcast_to(model["round_mean"], (len(x), 3, 10)).copy(),
    )


def save_result(directory, predictions, y, ids, metadata):
    for name, jump in predictions.items():
        assert jump.shape == (120, 3, 10) and np.isfinite(jump).all()
        atomic(directory / f"{name}.npz", dict(jump=jump, season_ids=ids), "npz")
    atomic(directory / "targets.npz", dict(actual_jump=y, season_ids=ids), "npz")
    report = dict(
        **metadata,
        symbols=list(SYMBOLS[:10]),
        n_seasons=120,
        units="USD/share; bias=prediction minus actual",
        metrics={name: errors(jump, y) for name, jump in predictions.items()},
        no_trading_scored=True,
    )
    atomic(directory / "metrics.json", report)
    atomic(
        directory / "COMPLETE.json",
        dict(completed=True, metrics_sha256=digest(directory / "metrics.json")),
    )
    print(
        json.dumps(
            {
                "completed": directory.name,
                **{
                    k: {v: m[v] for v in ["rmse", "bias"]}
                    for k, m in report["metrics"].items()
                },
            }
        ),
        flush=True,
    )


def panels(data):
    for name, train_range, eval_range, reuse in PANELS:
        directory = HERE / "panels" / name
        directory.mkdir(parents=True, exist_ok=True)
        if (directory / "COMPLETE.json").exists():
            continue
        ids = np.arange(eval_range[0], eval_range[1] + 1)
        metadata = dict(
            panel=name,
            fit_seasons=train_range,
            evaluation_seasons=eval_range,
            reused_from=reuse,
            previously_researched=True,
        )
        if reuse:
            provenance = {}
            for file in ["hgb.npz", "round_mean.npz", "models.pkl"]:
                shutil.copyfile(OLD / reuse / file, directory / file)
                provenance[file] = digest(OLD / reuse / file)
                assert digest(directory / file) == provenance[file]
            predictions = {
                model: np.load(directory / f"{model}.npz")["jump"]
                for model in ["hgb", "round_mean"]
            }
            # Retain original NPZ bytes; write metrics/targets without regenerating predictions.
            atomic(
                directory / "targets.npz",
                dict(actual_jump=data["actual_jump"][ids - 1], season_ids=ids),
                "npz",
            )
            previous_metrics = json.loads((OLD / reuse / "metrics.json").read_text())
            report = dict(
                **metadata,
                symbols=list(SYMBOLS[:10]),
                n_seasons=120,
                metrics={k: previous_metrics["evaluation"][k] for k in predictions},
                reused_hashes=provenance,
                no_trading_scored=True,
            )
            atomic(directory / "metrics.json", report)
            atomic(
                directory / "COMPLETE.json",
                dict(completed=True, reused_byte_identical=True),
            )
            print(
                name, "reused byte-identical original model and forecasts", flush=True
            )
        else:
            guard()
            ii = np.arange(train_range[0] - 1, train_range[1])
            model = fit_or_resume(
                directory, data["features"][ii], data["actual_jump"][ii]
            )
            save_result(
                directory,
                predict(model, data["features"][ids - 1]),
                data["actual_jump"][ids - 1],
                ids,
                metadata,
            )


def bootstrap(data):
    sample_ids = np.random.default_rng(20261019).integers(0, 240, size=(30, 240)) + 361
    counts = np.stack([np.bincount(row - 361, minlength=240) for row in sample_ids])
    hashes = np.array(
        [hashlib.sha256(row.astype("<i4").tobytes()).hexdigest() for row in sample_ids]
    )
    samples = dict(
        sample_ids=sample_ids,
        inclusion_counts=counts,
        membership=counts > 0,
        train_season_ids=np.arange(361, 601),
        replicate_ids=np.arange(1, 31),
        sample_sha256=hashes,
    )
    sample_path = HERE / "bootstrap_samples.npz"
    if sample_path.exists():
        with np.load(sample_path) as previous:
            for key, value in samples.items():
                np.testing.assert_array_equal(previous[key], value)
    else:
        atomic(sample_path, samples, "npz")
    ids = np.arange(241, 361)
    for index, row in enumerate(sample_ids):
        directory = HERE / "bootstrap" / f"B{index + 1:02d}"
        directory.mkdir(parents=True, exist_ok=True)
        if (directory / "COMPLETE.json").exists():
            continue
        guard()
        model = fit_or_resume(
            directory, data["features"][row - 1], data["actual_jump"][row - 1]
        )
        save_result(
            directory,
            predict(model, data["features"][ids - 1]),
            data["actual_jump"][ids - 1],
            ids,
            dict(
                replicate_id=index + 1,
                sample_sha256=str(hashes[index]),
                unique_training_seasons=int((counts[index] > 0).sum()),
                fit_population=[361, 600],
                evaluation_seasons=[241, 360],
            ),
        )
        atomic(
            HERE / "PROGRESS.json",
            dict(
                panels_complete=4,
                bootstrap_complete=index + 1,
                bootstrap_requested=30,
                no_run_selected=True,
            ),
        )
    combined = {
        model: np.stack(
            [
                np.load(HERE / "bootstrap" / f"B{i:02d}" / f"{model}.npz")["jump"]
                for i in range(1, 31)
            ]
        )
        for model in ["hgb", "round_mean"]
    }
    combined.update(
        season_ids=ids,
        replicate_ids=np.arange(1, 31),
        **{
            k: samples[k]
            for k in [
                "sample_ids",
                "inclusion_counts",
                "membership",
                "train_season_ids",
                "sample_sha256",
            ]
        },
    )
    atomic(HERE / "bootstrap_predictions.npz", combined, "npz")


def main():
    freeze()
    guard()
    data = build_features()
    panels(data)
    bootstrap(data)
    atomic(
        HERE / "COMPLETE.json",
        dict(
            panels=4,
            bootstrap_replicates=30,
            no_run_selected=True,
            no_trading_scored=True,
        ),
    )


if __name__ == "__main__":
    main()
