# Frozen HGB robustness — handoff v1

This is robustness of the existing current-round candidate, not a new search.
No trading-policy selection, bootstrap-run selection, PnL inspection or common-
account evaluation occurred here. The parent owns identical common-account
execution and must report the whole bootstrap distribution, never its best run.
All600 seasons have been researched previously; no fresh holdout is claimed.

## Four requested forward panels

| Panel | Fit seasons | Evaluation seasons | Computation |
|---|---|---|---|
| P1 |481–600|361–480|New fixed HGB + training round mean|
| P2 |361–600|241–360|Existing inner model/arrays reused byte-for-byte|
| P3 |241–600|121–240|Existing diagnostic model/arrays reused byte-for-byte|
| P4 |121–600|1–120|New fixed HGB + mean; explicit parent-authorized access|

For each panel, `hgb.npz` and `round_mean.npz` contain `jump[120,3,10]` and
`season_ids[120]`. Rows are explicitly aligned by ID; rounds are zero-based.
Stock order is PORT, ISLE, AQUA, GRID, FERRY, RECON, MAT, GEN, HAVEN, REIN.
`targets.npz` is evaluation-only. `metrics.json` retains aggregate, per-stock,
per-round and round-stock RMSE/bias. Bias is predicted minus actual jump.

The unchanged target is mean house quote542,544,546,548,550,552 minus quote180,
in USD/share. The unchanged94-feature design uses public physical state, guidance,
current quotes and round one-hot as of180. Prior completed rounds may be used;
future quotes are labels only. No date, identity, season seed, manifest truth or
exact replay recognition is a feature. `prepare.py` establishes row=season−1;
the supplied cache's public data121–600 and existing feature/label arrays were
compared exactly before assigning season IDs. Historical receipt-time caveats
still apply. Loading1–120 for P4 is newly authorized, not newly unseen data.

## Thirty whole-season bootstraps

NumPy `default_rng(20261019)` generates exactly30 ordered samples of240 seasons,
with replacement, from ascending IDs361–600. Each occurrence includes all three
rounds. Both HGB and round-mean control are refitted on that same weighted sample;
all runs predict the same untouched evaluation block241–360. HGB parameters and
algorithm random_state0 are unchanged. There is no additional random seed search.

`bootstrap_predictions.npz` contains:

- `hgb` and `round_mean`: `[30,120,3,10]`, axes replicate, season, round, stock.
- `replicate_ids`:1–30, always original sample order, not ranked by performance.
- `season_ids`:241–360, evaluation rows.
- `sample_ids`: `[30,240]`, ordered sampled training IDs including duplicates.
- `train_season_ids`:361–600, training-population column order.
- `inclusion_counts`: `[30,240]`, multiplicity of each training season.
- `membership`: same shape, boolean inclusion.
- `sample_sha256`: SHA256 of each ordered sample-ID vector encoded little-endian
  int32. `bootstrap_samples.npz` retains the same provenance separately.

Individual `bootstrap/Bxx/` checkpoints retain each run's aligned arrays, target
labels, complete numerical metrics and completion marker. Every fitted bootstrap
model is preserved locally but omitted from the compact artifact. No ensemble of
bootstrap predictions is proposed. Numerical error distributions and prediction
dispersion describe stability only; they imply no trading-performance claim.

## Execution and recovery

All work is non-git scratch. One CPU process and one BLAS/OMP thread; jobs ran in
tmux. Each fitted model and each completed evaluation are atomic checkpoints.
`run.py` checks for a parent STOP file and cumulative local model estimate before
each new fit, stopping at USD53 to leave room beneath the USD55 research cap.
Resume the same script with the source/frozen specification intact; completed
panels and bootstrap runs are reused. Original middle-panel fitted models and
forecasts are copied, never refitted or regenerated. `PROGRESS.json` and
`COMPLETE.json` state exactly how far the experiment completed.

Install the included original forecast requirements, keep the extracted project
root on Python's path, and run `research_v5/clock_robustness/run.py` with
OMP_NUM_THREADS=OPENBLAS_NUM_THREADS=MKL_NUM_THREADS=1. The full cache is local as
`research_v5/clock_robustness/cache.npz`; raw data and bootstrap model pickles are
omitted from the artifact. The old forecast source and frozen specification are
included for reproducibility. P1/P4 model pickles are simple dictionaries holding
ten HGB regressors and round means; P2/P3 retain the original DriftModels objects.
Use the aligned arrays for the parent's common-account evaluation.

## Completion and resources

All four panels and all30 bootstrap fits completed. The two middle panels
were reused byte-for-byte. All30 bootstrap model pickles remain local.
Startup-inclusive cumulative local model estimate is USD 42.22;
increment since the robustness opening snapshot is USD 2.10.
Reserve USD2 for final delivery overhead, below the USD55 research stop.
Approximately eight active minutes in this follow-up; restart downtime
is excluded. No descendants, paid compute or new policy/model selection.
