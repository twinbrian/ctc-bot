"""Exhaustive preregistered execution sensitivity, with exact checkpoint reuse."""

import argparse
import hashlib
import itertools
import json
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from research_v4.lab import summarize_pnl
from research_v5.conditional_research import coherent_jump
from research_v5.handoff_research import npz, write_json
from research_v5.pooled_clock import SCENARIOS
from research_v5.scheduled_account import run

OUT = ROOT / "research_v5/execution_matrix"
DEFAULTS = dict(
    cost_bps=25,
    fixed_cost=0.02,
    latency=2,
    depth=50,
    adverse_bps=0.0,
    replenish_seconds=2,
)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("policy", choices=["clock", "hgb"])
    policy = parser.parse_args().policy
    out = OUT / policy
    out.mkdir(parents=True, exist_ok=True)
    if (out / "COMPLETE.json").exists():
        return
    d = dict(np.load(ROOT / "cache.npz"))
    matrix = list(itertools.product([25, 50, 100], [2, 6, 12], [10, 25, 50], [2, 10]))
    reuse_count = 0
    for fold in range(5):
        p = dict(np.load(ROOT / f"results_v2/fold-{fold}-predictions.npz"))
        ids = p["test_ids"]
        take = np.array([np.flatnonzero(p["ids"] == i)[0] for i in ids])
        market, truth = d["market"][ids], d["settlement_truth"][ids]
        jump = None
        if policy == "hgb":
            pred = dict(
                np.load(
                    ROOT / f"research_v5/pooled_conditional/fold{fold}_predictions.npz"
                )
            )
            np.testing.assert_array_equal(pred["season_ids"], ids + 1)
            jump = coherent_jump(pred["jump"], market[:, :, 90])
        for bps, latency, depth, refresh in matrix:
            name = f"bps{bps}_lat{latency}_depth{depth}_refresh{refresh}"
            path = out / f"fold{fold}_{name}.npz"
            failed = out / f"fold{fold}_{name}.blocked.json"
            if path.exists() or failed.exists():
                continue
            settings = dict(
                cost_bps=bps, latency=latency, depth=depth, replenish_seconds=refresh
            )
            reuse = next(
                (
                    k
                    for k, v in SCENARIOS.items()
                    if DEFAULTS | v == DEFAULTS | settings
                ),
                None,
            )
            if reuse is not None:
                base = (
                    f"research_v5/pooled_clock/fold{fold}_clock_{reuse}.npz"
                    if policy == "clock"
                    else f"research_v5/pooled_conditional/fold{fold}_{reuse}.npz"
                )
                result = dict(np.load(ROOT / base))
                reuse_count += 1
            else:
                try:
                    result = run(
                        market,
                        truth,
                        p["formation_curve"],
                        p["final_fair"][take],
                        forecast_jump=jump,
                        **settings,
                    )
                except AssertionError as exc:
                    write_json(
                        failed,
                        dict(
                            fold=fold, settings=settings, blocked=True, error=str(exc)
                        ),
                    )
                    continue
            keep = [
                "pnl",
                "cost",
                "actions",
                "by_engine",
                "max_rolling_actions",
                "max_position_fraction",
            ]
            npz(path, **{k: result[k] for k in keep}, season_ids=ids + 1)
        print(
            json.dumps(
                dict(policy=policy, fold=fold, scenarios=54, reused_so_far=reuse_count)
            ),
            flush=True,
        )
    rows, arrays = [], {}
    for bps, latency, depth, refresh in matrix:
        name = f"bps{bps}_lat{latency}_depth{depth}_refresh{refresh}"
        paths = [out / f"fold{f}_{name}.npz" for f in range(5)]
        row = dict(
            policy=policy, bps=bps, latency=latency, depth=depth, refresh=refresh
        )
        if not all(p.exists() for p in paths):
            rows.append(row | {"blocked": True})
            continue
        parts = [dict(np.load(p)) for p in paths]
        pnl = np.concatenate([p["pnl"] for p in parts])
        arrays[name] = pnl
        rows.append(
            row
            | summarize_pnl(pnl)
            | {
                "mean_cost_usd": float(
                    np.concatenate([p["cost"] for p in parts]).mean()
                ),
                "mean_actions": float(
                    np.concatenate([p["actions"] for p in parts]).mean()
                ),
                "max_rolling_actions": int(
                    max(p["max_rolling_actions"].max() for p in parts)
                ),
                "max_position_fraction": float(
                    max(p["max_position_fraction"].max() for p in parts)
                ),
            }
        )
    write_json(out / "metrics.json", rows)
    npz(out / "per_season.npz", **arrays, season_ids=np.arange(1, 601))
    write_json(
        out / "COMPLETE.json",
        {
            "policy": policy,
            "scenario_count": 54,
            "folds": 5,
            "no_policy_selection": True,
            "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            "exact_reused_this_invocation": reuse_count,
        },
    )


if __name__ == "__main__":
    main()
