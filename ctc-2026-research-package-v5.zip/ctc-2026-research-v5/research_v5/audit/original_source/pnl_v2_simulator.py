"""One-account event simulator for a mean-PnL objective.

All engines share positions, pending quantities, cash, per-symbol depth and a
rolling 60-action budget. A new short trade reserves an action for its exit.
Formation entries cannot overlap ongoing entries; exits wait for rolling-budget
capacity if necessary. Their configured exit time is an earliest start, not a fill.
Quotes/fills remain hypothetical consensus scenarios, not order-book evidence.
"""

import numpy as np

from common import LIMITS


def allocate_lots(edge, limits, depth, budget):
    """Allocate integer depth-sized orders by net USD contribution, globally.

    Ties are stable. Input is available information at the decision, not future
    realized prices. The cap can encode the time available to acquire each name.
    """
    n = len(edge)
    targets = np.zeros((n, 12), dtype=int)
    rows = np.arange(n)
    for _ in range(budget):
        qty = np.minimum(depth, np.maximum(limits - targets, 0))
        score = edge * qty
        j = np.argmax(score, axis=1)
        good = score[rows, j] > 0
        i = rows[good]
        targets[i, j[i]] += qty[i, j[i]]
    return targets


def simulate(
    market,
    truth,
    delta,
    final_fair,
    formation_curve,
    *,
    formation=None,
    ongoing=None,
    end_margin=None,
    cost_bps=25,
    fixed_cost=0.02,
    latency=2,
    depth=50,
    adverse_bps=0.0,
    fraction=1.0,
    audit=False,
    replenish_seconds=2,
    aftermath=None,
    aftermath_fair=None,
    external_actions=None,
    readiness_times=None,
    round_indices=None,
    prior_action_ticks=None,
):
    n = len(market)
    row = np.arange(n)
    rounds = list(range(3)) if round_indices is None else list(round_indices)
    if prior_action_ticks is not None:
        assert len(rounds) == 1, "Explicit continuous history uses one-round calls"
        prior_action_ticks = np.asarray(prior_action_ticks, dtype=int)
        assert prior_action_ticks.shape == (n, 30) and np.all(prior_action_ticks >= 0)
    if external_actions is None:
        external_actions = np.zeros((n, 3, 390), dtype=int)
    if readiness_times is None:
        readiness_times = np.zeros((n, 3), dtype=int)
    external_actions = np.asarray(external_actions)
    readiness_times = np.asarray(readiness_times)
    assert external_actions.shape == (n, 3, 390)
    assert readiness_times.shape == (n, 3)
    assert np.all(external_actions >= 0)
    assert np.all(external_actions[np.arange(390)[None, None, :] * 2 >= readiness_times[:, :, None]] == 0), "External phase must stop before this phase becomes ready"
    q = np.zeros((n, 12), dtype=int)
    pending_qty = np.zeros_like(q)
    resting = np.zeros_like(q)
    cash = np.zeros(n)
    costs = np.zeros(n)
    turnover = np.zeros(n)
    actions = np.zeros(n, dtype=int)
    by_engine = np.zeros((n, 4 if aftermath is not None else 3))
    engine_actions = np.zeros_like(by_engine, dtype=int)
    formation_last_entry = np.full((n, 3), -1, dtype=int)
    formation_first_exit = np.full((n, 3), -1, dtype=int)
    formation_flat = np.full((n, 3), -1, dtype=int)
    formation_peak_shares = np.zeros((n, 3), dtype=int)
    attribution = np.zeros((n, 12))
    peak = np.zeros(n)
    dd = np.zeros(n)
    max_window = np.zeros(n, dtype=int)
    max_position = np.zeros(n)
    blocked_entries = np.zeros(n, dtype=int)
    counts = np.zeros((n, 3, 390), dtype=np.int8)
    delay = max(1, int(np.ceil(latency / 2)))
    cooldown = max(1, int(np.ceil(replenish_seconds / 2)))
    limits = np.floor(LIMITS * fraction).astype(int)
    if formation is not None and not 0 <= formation["entry_budget"] <= 60:
        raise ValueError("Formation entry budget must be between zero and 60")
    if ongoing is not None and ongoing["cycle"] < 10:
        raise ValueError("Forecast grid is 10 seconds")
    if depth <= 0 or not 0 < fraction <= 1:
        raise ValueError("Invalid capacity")
    if aftermath is not None and (
        aftermath["start"] > 660
        or aftermath["entry_budget"] > 59
        or aftermath_fair is None
    ):
        raise ValueError(
            "Aftermath needs forecasts, start<=660 and <=59 entries to reserve cancellation/exit capacity"
        )
    for r in rounds:
        history = np.zeros((n, 30), dtype=int) if prior_action_ticks is None else prior_action_ticks.copy()
        used = history.sum(axis=1)
        queue = [[] for _ in range(390 + delay)]
        short_exit = np.full((n, 12), -1, dtype=int)
        formation_entries = np.zeros(n, dtype=int)
        formation_done = np.full(n, formation is None)
        end_started = np.zeros(n, dtype=bool)
        last_depth = np.full((n, 12), -1000, dtype=int)
        after_entries = np.zeros(n, dtype=int)
        cancel_queue = [[] for _ in range(390 + delay)]
        after_targets = None
        if formation is not None:
            start = formation["start"]
            exit_at = formation["exit"]
            # The future *training* average is a fitted target, not current-season
            # future information. All current-season inputs are known at start.
            target_mean = formation_curve[
                r, (exit_at + 2) // 2 : (exit_at + 14) // 2
            ].mean(0)
            expected_jump = target_mean - formation_curve[r, start // 2]
            anchor = market[:, r, start // 2]
            target = anchor + expected_jump
            form_side = np.sign(expected_jump).astype(int)
            form_targets = None
            if formation.get("allocation", "greedy") == "optimal_lots":
                expected_edge = (
                    np.abs(expected_jump)[None, :]
                    - (anchor + np.maximum(target, 0)) * cost_bps / 10000
                    - 2 * fixed_cost
                )
                acquisition_cap = np.minimum(
                    limits, depth * (1 + int((60 - start) // (2 * cooldown)))
                )
                form_targets = allocate_lots(
                    expected_edge, acquisition_cap, depth, formation["entry_budget"]
                )
        for ti in range(390):
            t = ti * 2
            slot = ti % 30
            used -= history[:, slot]
            history[:, slot] = external_actions[:, r, ti]
            used += history[:, slot]
            sent = np.zeros((n, 12), dtype=bool)
            ready_book = ti - last_depth >= cooldown
            price = market[:, r, ti]
            for i in cancel_queue[ti]:
                resting[i] = 0
            for i, j, requested, cap, engine in queue[ti]:
                pending_qty[i, j] -= requested
                side = np.sign(requested)
                unit_cost = price[i, j] * (cost_bps + adverse_bps) / 10000 + fixed_cost
                execution = price[i, j] + side * unit_cost
                qty = requested.copy()
                if cap is not None:
                    crosses = (execution - cap) * side <= 0
                    qty *= crosses
                    resting[i, j] += requested - qty
                q[i, j] += qty
                cash[i] -= qty * execution
                by_engine[i, engine] -= qty * execution
                attribution[i, j] -= qty * execution
                costs[i] += np.abs(qty) * unit_cost
                turnover[i] += np.abs(qty)
            assert np.all(np.abs(q) <= limits), (
                f"Position breach at round {r + 1}, second {t}: {q[np.any(np.abs(q) > limits, axis=1)]}"
            )
            max_position = np.maximum(max_position, np.max(np.abs(q) / LIMITS, axis=1))
            formation_peak_shares[:, r] = np.maximum(
                formation_peak_shares[:, r],
                np.sum(np.abs(q), axis=1) * (~formation_done),
            )
            wealth = cash + np.sum(q * price, axis=1)
            peak = np.maximum(peak, wealth)
            dd = np.maximum(dd, peak - wealth)

            def submit(i, j, quantity, engine, cap=None):
                if not len(i):
                    return
                assert np.all(used[i] < 60)
                assert not sent[i, j].any()
                assert ready_book[i, j].all()
                assert np.all(np.abs(quantity) <= depth)
                queue[ti + delay].append(
                    (
                        i.copy(),
                        j.copy(),
                        quantity.copy(),
                        None if cap is None else cap.copy(),
                        engine,
                    )
                )
                pending_qty[i, j] += quantity
                sent[i, j] = True
                last_depth[i, j] = ti
                used[i] += 1
                history[i, slot] += 1
                actions[i] += 1
                engine_actions[i, engine] += 1
                if engine == 0:
                    if t <= 60:
                        formation_last_entry[i, r] = t
                    else:
                        fresh = i[formation_first_exit[i, r] < 0]
                        formation_first_exit[fresh, r] = t
                counts[i, r, ti] += 1

            if ti + delay >= 390:
                max_window = np.maximum(max_window, used)
                continue
            # Always service exits before opening any new risk.
            if formation is not None and t >= exit_at:
                exposure = q + pending_qty
                scores = np.abs(exposure) * np.abs(expected_jump)[None, :]
                ranking = np.argsort(-scores, axis=1)
                for k in range(12):
                    j = ranking[:, k]
                    live = exposure[row, j]
                    valid = (
                        ~formation_done & (live != 0) & (used < 60) & ready_book[row, j]
                    )
                    i = np.where(valid)[0]
                    qty = -np.sign(live[i]) * np.minimum(depth, np.abs(live[i]))
                    submit(i, j[i], qty, 0)
                flat = np.all(q == 0, axis=1) & np.all(pending_qty == 0, axis=1)
                newly_flat = flat & ~formation_done
                formation_flat[newly_flat, r] = t
                formation_done |= flat
            if ongoing is not None:
                exposure = q + pending_qty
                due = (short_exit >= 0) & (short_exit <= ti) & (exposure != 0)
                ranking = np.argsort(-np.abs(exposure) * due, axis=1)
                for k in range(12):
                    j = ranking[:, k]
                    live = exposure[row, j]
                    valid = (
                        due[row, j] & ~sent[row, j] & (used < 60) & ready_book[row, j]
                    )
                    i = np.where(valid)[0]
                    qty = -np.sign(live[i]) * np.minimum(depth, np.abs(live[i]))
                    submit(i, j[i], qty, 1)
                    closed = i[np.abs(live[i]) <= depth]
                    short_exit[closed, j[closed]] = -1
            if formation is not None and start <= t <= 60:
                exposure = q + pending_qty
                cap = limits[None, :] if form_targets is None else form_targets
                room = np.maximum(0, cap - np.abs(exposure))
                qty = np.minimum(depth, room)
                edge = (
                    (target - price) * form_side[None, :]
                    - (price + np.maximum(target, 0)) * cost_bps / 10000
                    - 2 * fixed_cost
                )
                scores = edge * qty
                scores[(qty <= 0) | (form_side[None, :] == 0)] = -np.inf
                ranking = np.argsort(-scores, axis=1)
                for k in range(12):
                    j = ranking[:, k]
                    valid = (
                        (formation_entries < formation["entry_budget"])
                        & (scores[row, j] > 0)
                        & ~sent[row, j]
                        & (used < 60)
                        & ready_book[row, j]
                    )
                    i = np.where(valid)[0]
                    submit(i, j[i], qty[i, j[i]] * form_side[j[i]], 0)
                    formation_entries[i] += 1
            if (
                ongoing is not None
                and t % ongoing["cycle"] == 0
                and not (r == 2 and t >= 730)
                and ti + max(5, cooldown) + delay < 390
                and (aftermath is None or t + 10 + 2 * delay < aftermath["start"])
            ):
                pred = delta[:, r, t // 10]
                side = np.sign(pred).astype(int)
                qty = np.minimum(depth, limits)
                edge = (
                    np.abs(pred)
                    - 2 * (price * cost_bps / 10000 + fixed_cost)
                    - ongoing["threshold"]
                )
                available = (
                    (q == 0)
                    & (pending_qty == 0)
                    & (short_exit < 0)
                    & ~sent
                    & ready_book
                )
                scores = edge * qty[None, :]
                scores[~available] = -np.inf
                ranking = np.argsort(-scores, axis=1)
                accepted = np.zeros(n, dtype=int)
                for k in range(12):
                    j = ranking[:, k]
                    exit_reserve = np.sum(short_exit >= 0, axis=1)
                    eligible = (
                        formation_done
                        & (t >= readiness_times[:, r])
                        & (scores[row, j] > 0)
                        & (accepted < ongoing["top_k"])
                    )
                    capacity = used + exit_reserve + 2 <= 60
                    blocked_entries += eligible & ~capacity
                    i = np.where(eligible & capacity)[0]
                    submit(i, j[i], qty[j[i]] * side[i, j[i]], 1)
                    short_exit[i, j[i]] = ti + 5
                    accepted[i] += 1
            if aftermath is not None:
                after_start = aftermath["start"]
                if t == after_start:
                    after_side = np.sign(aftermath_fair[:, r] - price).astype(int)
                    # Round 1/2 require a market exit; round 3 settles directly.
                    target_cost = (
                        (price + np.maximum(aftermath_fair[:, r], 0)) * cost_bps / 10000
                        + 2 * fixed_cost
                        if r < 2
                        else price * cost_bps / 10000 + fixed_cost
                    )
                    after_edge = (
                        np.abs(aftermath_fair[:, r] - price)
                        - target_cost
                        - aftermath["margin"]
                    )
                    acquisition_cap = np.minimum(
                        limits, depth * (1 + int(28 // (2 * cooldown)))
                    )
                    after_targets = allocate_lots(
                        after_edge, acquisition_cap, depth, aftermath["entry_budget"]
                    )
                if after_start <= t < after_start + 30:
                    exposure = q + pending_qty + resting
                    room = np.maximum(0, after_targets - np.abs(exposure))
                    qty = np.minimum(depth, room)
                    edge = (aftermath_fair[:, r] - price) * after_side
                    cost_est = (
                        (price + np.maximum(aftermath_fair[:, r], 0)) * cost_bps / 10000
                        + 2 * fixed_cost
                        if r < 2
                        else price * cost_bps / 10000 + fixed_cost
                    )
                    score = (edge - cost_est - aftermath["margin"]) * qty
                    score[(qty <= 0) | sent | ~ready_book] = -np.inf
                    ranking = np.argsort(-score, axis=1)
                    for k in range(12):
                        j = ranking[:, k]
                        reserve = np.sum(short_exit >= 0, axis=1)
                        valid = (
                            (score[row, j] > 0)
                            & (used + reserve < 60)
                            & (after_entries < aftermath["entry_budget"])
                            & formation_done
                        )
                        i = np.where(valid)[0]
                        side = after_side[i, j[i]]
                        # Limit leaves enough room for the modeled future exit cost.
                        exit_cost = (
                            np.maximum(aftermath_fair[i, r, j[i]], 0) * cost_bps / 10000
                            + fixed_cost
                            if r < 2
                            else 0
                        )
                        cap = aftermath_fair[i, r, j[i]] - side * (
                            aftermath["margin"] + exit_cost
                        )
                        submit(i, j[i], qty[i, j[i]] * side, 3, cap)
                        after_entries[i] += 1
                if t == 720:
                    i = np.where(np.any(resting != 0, axis=1))[0]
                    # All entry fills have arrived by 700 even in the 12s stress.
                    assert np.all(pending_qty[i] == 0)
                    assert np.all(used[i] < 60)
                    cancel_queue[ti + delay].append(i)
                    used[i] += 1
                    history[i, slot] += 1
                    actions[i] += 1
                    engine_actions[i, 3] += 1
                    counts[i, r, ti] += 1
                # Target the same first exit-arrival time (742s) under the known
                # latency scenario so large positions can finish before close.
                if r < 2 and t >= 742 - 2 * delay:
                    exposure = q + pending_qty
                    ranking = np.argsort(-np.abs(exposure), axis=1)
                    for k in range(12):
                        j = ranking[:, k]
                        live = exposure[row, j]
                        valid = (
                            (live != 0)
                            & ~sent[row, j]
                            & ready_book[row, j]
                            & (used < 60)
                        )
                        i = np.where(valid)[0]
                        submit(
                            i,
                            j[i],
                            -np.sign(live[i]) * np.minimum(depth, np.abs(live[i])),
                            3,
                        )
            if end_margin is not None and r == 2 and t >= 740:
                flat = np.all(q == 0, axis=1) & np.all(pending_qty == 0, axis=1)
                if aftermath is not None:
                    flat = np.all(pending_qty == 0, axis=1) & np.all(
                        resting == 0, axis=1
                    )
                end_started |= flat
                edge = final_fair - price
                side = np.sign(edge).astype(int)
                exposure = q + pending_qty + resting
                room = (
                    np.maximum(0, limits[None, :] - np.abs(exposure))
                    if aftermath is None
                    else np.abs(side * limits[None, :] - exposure)
                )
                qty = np.minimum(depth, room)
                scores = (
                    np.abs(edge) - (price * cost_bps / 10000 + fixed_cost) - end_margin
                ) * qty
                scores[
                    (qty <= 0)
                    | ((exposure * side < 0) & (aftermath is None))
                    | sent
                    | ~ready_book
                ] = -np.inf
                if aftermath is not None:
                    # Reversal is permitted only after prior orders resolve. A
                    # non-crossing old limit cannot be netted against a new limit
                    # on the opposite side to manufacture inventory capacity.
                    scores[(pending_qty != 0) | (resting != 0)] = -np.inf
                ranking = np.argsort(-scores, axis=1)
                for k in range(12):
                    j = ranking[:, k]
                    reserve = np.sum(short_exit >= 0, axis=1)
                    valid = end_started & (scores[row, j] > 0) & (used + reserve < 60)
                    i = np.where(valid)[0]
                    signed = qty[i, j[i]] * side[i, j[i]]
                    cap = final_fair[i, j[i]] - side[i, j[i]] * end_margin
                    submit(i, j[i], signed, 2 if aftermath is None else 3, cap)
            max_window = np.maximum(max_window, used)
            assert np.all(used + np.sum(short_exit >= 0, axis=1) <= 60)
            if (
                ongoing is None
                and end_margin is None
                and aftermath is None
                and formation_done.all()
            ):
                break
        assert np.all(pending_qty == 0)
        if r < 2:
            assert np.all(q == 0), "Inventory must be closed before the next round"
    pnl = cash + np.sum(q * truth, axis=1)
    attribution += q * truth
    by_engine[:, 2 if aftermath is None else 3] += np.sum(q * truth, axis=1)
    assert np.allclose(by_engine.sum(1), pnl)
    assert np.allclose(attribution.sum(1), pnl)
    assert np.all(q + np.maximum(resting, 0) <= limits)
    assert np.all(q + np.minimum(resting, 0) >= -limits)
    dd = np.maximum(dd, peak - pnl)
    result = {
        "pnl": pnl,
        "positions": q,
        "actions": actions,
        "cost": costs,
        "turnover_shares": turnover,
        "drawdown": dd,
        "attribution": attribution,
        "by_engine": by_engine,
        "max_rolling_actions": max_window,
        "max_position_fraction": max_position,
        "blocked_entries": blocked_entries,
        "engine_actions": engine_actions,
        "formation_last_entry": formation_last_entry,
        "formation_first_exit": formation_first_exit,
        "formation_flat": formation_flat,
        "formation_peak_shares": formation_peak_shares,
    }
    if audit:
        result["action_ticks"] = counts
    return result
