"""Use fee-free ETF conversion to route desired stock exposure in fewer actions.

Conversions change positions with zero net cash. They are atomic only internally;
the market orders that finance/unwind them are delayed and pay modeled costs.
Positive and negative pending quantities reserve worst-ordering capacity.
"""

import numpy as np

from common import BASKETS, LIMITS


def simulate_routes(
    market,
    truth,
    curve,
    *,
    start=0,
    exit_at=70,
    fraction=1.0,
    cost_bps=25,
    fixed_cost=0.02,
    latency=2,
    depth=50,
    adverse_bps=0.0,
    replenish_seconds=2,
    audit=False,
    round_indices=None,
    prior_action_ticks=None,
):
    n = len(market)
    row = np.arange(n)
    rounds = list(range(3)) if round_indices is None else list(round_indices)
    if prior_action_ticks is not None:
        assert len(rounds) == 1, "Explicit continuous history uses one-round calls"
        prior_action_ticks = np.asarray(prior_action_ticks, dtype=int)
        assert prior_action_ticks.shape == (n, 30) and np.all(prior_action_ticks >= 0)
    limits = LIMITS.copy()
    desired_limits = np.floor(limits * fraction).astype(int)
    q = np.zeros((n, 12), dtype=int)
    pp = np.zeros_like(q)
    pn = np.zeros_like(q)
    cash = np.zeros(n)
    costs = np.zeros(n)
    turnover = np.zeros(n)
    actions = np.zeros(n, dtype=int)
    conversions = np.zeros(n, dtype=int)
    max_window = np.zeros(n, dtype=int)
    max_pos = np.zeros(n)
    peak = np.zeros(n)
    dd = np.zeros(n)
    flat_times = np.full((n, 3), -1, dtype=int)
    counts = np.zeros((n, 3, 390), dtype=np.int8)
    attribution = np.zeros((n, 12))
    delay = max(1, int(np.ceil(latency / 2)))
    cooldown = max(1, int(np.ceil(replenish_seconds / 2)))
    # Each vector is a redemption: positive stock basket, negative ETF share.
    vectors = np.zeros((2, 12), dtype=int)
    vectors[:, :10] = BASKETS.astype(int)
    vectors[0, 10] = -1
    vectors[1, 11] = -1
    for r in rounds:
        queue = [[] for _ in range(390 + delay)]
        history = np.zeros((n, 30), dtype=int) if prior_action_ticks is None else prior_action_ticks.copy()
        used = history.sum(axis=1)
        last_depth = np.full((n, 12), -1000, dtype=int)
        closing = np.zeros(n, dtype=bool)
        done = np.zeros(n, dtype=bool)
        mean_target = curve[r, (exit_at + 2) // 2 : (exit_at + 14) // 2].mean(0)
        expected_jump = mean_target - curve[r, start // 2]
        anchor = market[:, r, start // 2]
        signal = (
            np.abs(expected_jump)[None, :]
            - (anchor + np.maximum(anchor + expected_jump, 0)) * cost_bps / 10000
            - 2 * fixed_cost
        )
        goal = (
            np.sign(expected_jump).astype(int)[None, :]
            * desired_limits[None, :]
            * (signal > 0)
        )
        remaining = np.zeros((n, 2), dtype=int)
        direction = np.zeros((n, 2), dtype=int)

        def plan_routes(i):
            exposure = q + pp - pn
            for b in range(2):
                sites = np.where(vectors[b, :10] > 0)[0]
                diff = goal[i][:, sites] - exposure[i][:, sites]
                unit = vectors[b, sites]
                buy = np.min(np.maximum(diff, 0) // unit, axis=1)
                sell = np.min(np.maximum(-diff, 0) // unit, axis=1)
                direction[i, b] = np.where(buy > 0, 1, np.where(sell > 0, -1, 0))
                remaining[i, b] = np.maximum(buy, sell)

        plan_routes(row)
        for ti in range(390):
            t = 2 * ti
            slot = ti % 30
            used -= history[:, slot]
            history[:, slot] = 0
            price = market[:, r, ti]
            for i, change, kind in queue[ti]:
                pp[i] -= np.maximum(change, 0)
                pn[i] -= np.maximum(-change, 0)
                if kind == "market":
                    unit_cost = price[i] * (cost_bps + adverse_bps) / 10000 + fixed_cost
                    payment = change * price[i] + np.abs(change) * unit_cost
                    cash[i] -= payment.sum(1)
                    attribution[i] -= payment
                    costs[i] += (np.abs(change) * unit_cost).sum(1)
                    turnover[i] += np.abs(change).sum(1)
                else:
                    # No cash changes. Cost-basis booking across instruments is
                    # marked at basket parity, not the deviating ETF market quote.
                    marks = price[i].copy()
                    marks[:, 10:] = price[i, :10] @ BASKETS.T
                    booking = change * marks
                    assert np.allclose(booking.sum(1), 0, atol=1e-8)
                    attribution[i] -= booking
                q[i] += change
                assert np.all(np.abs(q[i]) <= limits)
            assert np.all(q + pp <= limits) and np.all(q - pn >= -limits)
            wealth = cash + (q * price).sum(1)
            peak = np.maximum(peak, wealth)
            dd = np.maximum(dd, peak - wealth)
            max_pos = np.maximum(max_pos, np.max(np.abs(q) / limits, axis=1))

            def submit(i, change, kind):
                if not len(i):
                    return
                assert np.all(used[i] < 60)
                assert np.all(q[i] + pp[i] + np.maximum(change, 0) <= limits)
                assert np.all(q[i] - pn[i] - np.maximum(-change, 0) >= -limits)
                pp[i] += np.maximum(change, 0)
                pn[i] += np.maximum(-change, 0)
                queue[ti + delay].append((i.copy(), change.copy(), kind))
                used[i] += 1
                history[i, slot] += 1
                actions[i] += 1
                counts[i, r, ti] += 1
                if kind != "market":
                    conversions[i] += 1

            if t >= exit_at:
                ready = ~closing & np.all(pp + pn == 0, axis=1)
                i = np.where(ready)[0]
                goal[i] = 0
                plan_routes(i)
                closing[i] = True
                flat = closing & np.all(q == 0, axis=1) & np.all(pp + pn == 0, axis=1)
                fresh = flat & ~done
                flat_times[fresh, r] = t
                done |= flat
            if ti + delay >= 390:
                continue
            active = ((start <= t) & (t <= 60) & ~closing) | (closing & ~done)
            # Atomic conversions first, reserving their worst-case leg exposures.
            for b in range(2):
                change_unit = direction[:, b, None] * vectors[b]
                positive = np.where(
                    change_unit > 0,
                    (limits - q - pp) // np.maximum(change_unit, 1),
                    10**9,
                )
                negative = np.where(
                    change_unit < 0,
                    (limits + q - pn) // np.maximum(-change_unit, 1),
                    10**9,
                )
                cap = np.minimum(positive.min(1), negative.min(1))
                quantity = np.minimum(remaining[:, b], np.maximum(cap, 0))
                valid = active & (used < 60) & (quantity > 0)
                i = np.where(valid)[0]
                submit(i, change_unit[i] * quantity[i, None], "convert")
                remaining[i, b] -= quantity[i]
            # Do not buy stock legs that a still-planned conversion will provide.
            reserved_route = np.zeros_like(goal)
            for b in range(2):
                reserved_route[:, :10] += (
                    remaining[:, b, None] * direction[:, b, None] * vectors[b, :10]
                )
            direct_goal = goal - reserved_route
            exposure = q + pp - pn
            diff = direct_goal - exposure
            # ETFs are financing legs; never preserve their implicit conversion
            # mismatch. Trade toward the desired outright ETF position too.
            ready_depth = ti - last_depth >= cooldown
            side = np.sign(diff).astype(int)
            capacity = np.where(side > 0, limits - q - pp, limits + q - pn)
            qty = np.minimum(np.minimum(depth, np.abs(diff)), np.maximum(capacity, 0))
            rank = np.argsort(-qty * (np.abs(expected_jump)[None, :] + 0.01), axis=1)
            for k in range(12):
                j = rank[:, k]
                valid = active & (used < 60) & ready_depth[row, j] & (qty[row, j] > 0)
                i = np.where(valid)[0]
                change = np.zeros((len(i), 12), dtype=int)
                change[np.arange(len(i)), j[i]] = qty[i, j[i]] * side[i, j[i]]
                submit(i, change, "market")
                last_depth[i, j[i]] = ti
            max_window = np.maximum(max_window, used)
            if done.all():
                break
        assert np.all(q == 0) and np.all(pp + pn == 0), (
            "Route portfolio must flatten each round"
        )
    assert np.allclose(attribution.sum(1), cash, atol=1e-8)
    result = {
        "pnl": cash,
        "actions": actions,
        "cost": costs,
        "turnover_shares": turnover,
        "positions": q,
        "attribution": attribution,
        "drawdown": dd,
        "max_rolling_actions": max_window,
        "max_position_fraction": max_pos,
        "conversion_actions": conversions,
        "flat_times": flat_times,
    }
    if audit:
        result["action_ticks"] = counts
    return result
