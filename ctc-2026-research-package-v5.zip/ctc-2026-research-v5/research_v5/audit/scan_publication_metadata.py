"""Outcome-free audit of the supplied metadata export; never load the NPZ."""

import csv
import gzip
import hashlib
import json
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SOURCE = ROOT / "feed-publication-metadata-121-600.csv.gz"
OUT = Path(__file__).resolve().parent


def scan():
    totals = Counter()
    types = Counter()
    deltas = Counter()
    report_times = defaultdict(Counter)
    rows_by_season = defaultdict(Counter)
    ages = defaultdict(Counter)
    reports = defaultdict(list)
    seen = {}
    previous = {}
    examples = defaultdict(list)

    def flag(name, row):
        totals[name] += 1
        rows_by_season[int(row["season"])][name] += 1
        if len(examples[name]) < 5:
            examples[name].append(dict(row))

    with gzip.open(SOURCE, "rt", newline="") as f:
        for row in csv.DictReader(f):
            season, line, r, seq = (int(row[k]) for k in ("season", "line", "round", "seq"))
            if not 121 <= season <= 600:
                raise ValueError("Out-of-scope season")
            hour, minute, second = map(int, row["time"].split("T")[1].split(":"))
            pub = (hour * 3600 + minute * 60 + second - 34200) / 30
            key = (r, pub)
            totals["messages"] += 1
            rows_by_season[season]["messages"] += 1
            types[row["type"]] += 1
            rows_by_season[season][row["type"]] += 1
            if season in previous:
                old_line, old_key, old_seq = previous[season]
                if line != old_line + 1:
                    flag("nonconsecutive_source_lines", row)
                if key < old_key:
                    flag("publication_regressions", row)
                if seq < old_seq:
                    flag("sequence_regressions", row)
                if seq != old_seq + 1:
                    flag("nonconsecutive_sequences", row)
            elif line != 1 or seq != 0:
                flag("unexpected_first_line_or_sequence", row)
            previous[season] = (line, key, seq)
            identity = (season, seq)
            if identity in seen:
                flag("duplicate_sequence_rows", row)
                if seen[identity] != row["payload_sha256"]:
                    flag("same_sequence_hash_conflicts", row)
                else:
                    flag("same_sequence_same_hash", row)
            else:
                seen[identity] = row["payload_sha256"]
            if row["type"] == "storm":
                age = float(row["age"])
                delta = pub - (60 + age)
                deltas[delta] += 1
                rows_by_season[season]["storm_delayed"] += delta > 0
                rows_by_season[season]["storm_early"] += delta < 0
                if delta != 0:
                    flag("nonzero_publication_age_delta", row)
                ages[season, r][age] += 1
            if row["type"] == "damage_report":
                report_times[row["stage"]][pub] += 1
                reports[season, r].append((line, seq, pub, row["stage"]))
    for season in range(121, 601):
        if season not in rows_by_season:
            raise ValueError(f"Missing season {season}")
        for r in range(1, 4):
            counts = ages[season, r]
            totals["missing_active_age_samples"] += len(set(range(0, 480, 2)) - counts.keys())
            totals["repeated_storm_age_rows"] += sum(v - 1 for v in counts.values())
            totals["terminal_age480_rows"] += counts[480]
            totals["unexpected_storm_age_rows"] += sum(v for k, v in counts.items() if k not in range(0, 481, 2))
            group = reports[season, r]
            stages = Counter(x[3] for x in group)
            totals["rounds_without_exactly_one_report_of_each_stage"] += stages != Counter(preliminary=1, final=1)
            final_seen = False
            for _, _, _, stage in group:
                totals["preliminary_after_final_source_order"] += final_seen and stage == "preliminary"
                final_seen |= stage == "final"
            prelim = [x[2] for x in group if x[3] == "preliminary"]
            final = [x[2] for x in group if x[3] == "final"]
            totals["final_not_later_than_preliminary"] += bool(prelim and final and min(final) <= max(prelim))
    result = {
        "input_sha256": hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
        "scope": "metadata only; seasons 121–600; no outcomes or raw payloads",
        "seasons": len(rows_by_season), "rounds": len(ages),
        "counts": dict(totals), "types": dict(types),
        "publication_minus_60_plus_age": {str(k): v for k, v in sorted(deltas.items())},
        "report_publication_seconds": {stage: dict(sorted(count.items())) for stage, count in report_times.items()},
        "examples": dict(examples),
        "limitations": ["No receipt timestamps", "No raw-payload/prepared-cache equivalence claim", "Report grouping is season/round because export omits storm identity"],
    }
    fields = ["season"] + sorted(set().union(*(x.keys() for x in rows_by_season.values())))
    with (OUT / "metadata_per_season.csv").open("w", newline="") as f:
        writer = csv.DictWriter(f, fields)
        writer.writeheader()
        for season, count in sorted(rows_by_season.items()):
            writer.writerow({"season": season, **count})
    temporary = OUT / "metadata_results.json.tmp"
    temporary.write_text(json.dumps(result, indent=2) + "\n")
    temporary.replace(OUT / "metadata_results.json")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    scan()
