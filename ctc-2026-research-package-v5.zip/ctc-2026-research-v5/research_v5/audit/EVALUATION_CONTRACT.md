# Evaluation contract addendum — audit scope, no PnL promotion

## Historical visibility

For the supplied previously observed seasons 121–600, every storm message has
`publication_second = 60 + age`, source order is publication-monotone and sequence
identities are unique. Each round has one preliminary report at 570 seconds and
one final at 740. These are metadata findings, not raw numerical-payload or
prepared-cache equivalence. No actual network receipt times were supplied.

**Keep the existing canonical historical cache and frozen results.** These checks
do not justify rebuilding its observations or recomputing PnL. No inference is
made about seasons 1–120. Future dirty/live inputs need a separate event envelope
with competition ID, sequence, payload/fingerprint, event age, publication key and
actual monotonic receipt time. Do not silently retrofit invented receipts into
the canonical cache. Revisions require an event/version history: one value and
one availability timestamp per age cannot reproduce all earlier snapshots.

The reference adapter passed delayed/reordered/duplicate/revision tests unchanged.
Use its published-and-received cutoff and final-first version ordering before
features. Missing/unusable path samples suppress full-path dependent decisions;
neither zero-fill nor forward-fill establishes an observed trajectory. New
competition means a new adapter. Quotes at one publication key represent one
full quote envelope; multiple incremental per-symbol envelopes would require a
different quote identity contract. This audit does not implement snapshot recovery,
real receipts, partial fills or a live executor.

## One account and one action key

- Each call's returned `actions` and `action_ticks` count only its own actions.
  `external_actions` consumes budget but does not import its cash or inventory.
  The wrapper adds the separately executed, **flat** preceding route exactly once.
- `prior_action_ticks` is `(n, 30)`, chronological counts at relative seconds
  `[-60, -58, ..., -2]`. Counts must be whole, finite, nonnegative and feasible.
  Only a single selected round may consume an explicit prior ledger.
- The rolling interval is `(now - 60, now]`: an action exactly 60 seconds old
  expires. For zero-gap 780-second rounds, previous round seconds 720–778 become
  the next call's prior slots. Never infer a pause from fictional feed dates.
- `round_indices` is a nonempty, strictly increasing subset of zero-based
  `[0, 1, 2]`. Repeating a round is not another independent account.
- `external_actions` is a flat predecessor's action-count schedule, not a general
  concurrent-account interface. It must end strictly before per-account readiness.
  The caller must establish actual inventory/pending flatness and depth cooldown;
  counts alone cannot prove these. The supported root integration is route then
  ongoing/final tail, without formation/aftermath inside that tail call.
- Both ongoing and final-report entries respect readiness. The external/prior
  schedule is validated even if the owned engine is idle or exits its loop early.
- Positive and negative outstanding quantities reserve capacity independently.
  Net pending zero does not establish flatness. Clip proposed orders to each
  side's room, count only nonzero submitted orders, and preserve unresolved exits.
  This remains a fixed-delay, all-or-none hypothetical fill model.
- `simulate_account` carries counts between rounds and uses flat phase handoffs.
  It defaults to zero gap. A positive fractional gap is rounded **down** to the
  two-second grid, conservatively delaying budget release. Negative/nonfinite
  gaps are errors. `wait60` also respects a longer configured depth cooldown.
- **Legacy multi-round root calls still reset rate history.** They are retained
  for frozen-result compatibility, not certified as continuous accounts. New
  combined-account promotion must use `simulate_account` or an equivalent full
  chronological ledger, not add standalone PnLs or root maxima.
- A final third-round holding settles once at the supplied evaluation settlement.
  Settlement labels never determine the action signal. Rounds one/two must close
  inventory and pending orders. ETF conversion changes inventory with zero cash;
  each market leg pays costs at its own arrival quote.

## Promotion boundary

Baseline remains 25 bps + USD 0.02/share/side, two-second latency, 50 market shares
per symbol per two seconds and 60 actions per real rolling minute for one key.
Hold whole seasons: fit361–600, inner241–360, frozen retrospective diagnostic121–240.
Declare finite policies before scoring; retain negatives and never validation-tune.

This audit declares no trading candidates and produces no historical PnL. Parent
owns any future fixed-policy replay. If these fixes change a claimed schedule,
that schedule must be replayed and stressed before promotion; do not overwrite
old frozen artifacts or label unchanged model coefficients a new validated result.
All claims of baseline/stress improvement require comparable whole-season,
common-account execution. Historical timing metadata cannot validate live receipt,
book capacity, partial/rejected fills or variable order latency.
