"""Demonstrate original defects and bounded compatibility on invented paths."""

import json
from pathlib import Path

import numpy as np

from test_contract import fixture, tail
from common import LIMITS

OUT = Path(__file__).resolve().parent


def original(filename, replacements=(), hooks=None):
    source = (OUT / "original_source" / filename).read_text()
    for before, after in replacements:
        assert source.count(before) == 1
        source = source.replace(before, after)
    scope = {"__name__": "original_synthetic", **(hooks or {})}
    exec(compile(source, filename, "exec"), scope)
    return scope


def run():
    violations = []

    def inspect(r, ti, q, queue):
        buys, sells = np.zeros_like(q), np.zeros_like(q)
        for future in queue[ti + 1:]:
            for ids, symbols, qty, cap, engine in future:
                np.add.at(buys, (ids, symbols), np.maximum(qty, 0))
                np.add.at(sells, (ids, symbols), np.maximum(-qty, 0))
        if np.any(q + buys > LIMITS) or np.any(q - sells < -LIMITS):
            violations.append({"second": 2 * ti, "position": int(q[0, 10]),
                               "pending_buys": int(buys[0, 10]), "pending_sells": int(sells[0, 10])})

    baseline = original("pnl_v2_simulator.py")["simulate"]
    tracked = original("pnl_v2_simulator.py", [
        ("                pending_qty[i, j] += quantity",
         "                pending_qty[i, j] += quantity\n                inspect(r, ti, q.copy(), queue)")
    ], {"inspect": inspect})["simulate"]
    market, truth, curve, delta, fair = fixture()
    delta[..., 10] = 100
    tracked(market, truth, delta, fair, curve, ongoing={"cycle": 10, "top_k": 1, "threshold": 0},
            round_indices=[0], latency=22)
    assert violations and violations[0]["pending_buys"] == 100

    external = np.zeros((1, 3, 390))
    external[0, 0, 0] = .5
    fractional = baseline(market, truth, delta * 0, fair, curve, round_indices=[0],
                          external_actions=external, readiness_times=np.full((1, 3), 10))
    bad_prior = np.full((1, 30), .5)
    truncated_prior = baseline(market, truth, delta * 0, fair, curve, round_indices=[0],
                               prior_action_ticks=bad_prior)
    external[:] = 0
    external[0, 2, 370] = 1
    premature = baseline(market, truth, delta * 0, fair + 20, curve, round_indices=[2],
                         end_margin=0, external_actions=external,
                         readiness_times=np.full((1, 3), 760), audit=True)
    duplicate = baseline(market, truth, delta, fair, curve, round_indices=[0, 0],
                         ongoing={"cycle": 10, "top_k": 1, "threshold": 0})
    single = baseline(market, truth, delta, fair, curve, round_indices=[0],
                      ongoing={"cycle": 10, "top_k": 1, "threshold": 0})
    comparisons = []
    args = list(fixture(2))
    rng = np.random.default_rng(546)
    args[0] += rng.normal(0, .2, args[0].shape)
    args[3][:] = rng.choice([-20., 0., 20.], args[3].shape)
    args[4] += 5
    for latency in [2, 4, 6, 12]:
        settings = dict(ongoing={"cycle": 10, "top_k": 5, "threshold": 0},
                        end_margin=0, audit=True, latency=latency)
        m, y, c, d, f = args
        old = baseline(m, y, d, f, c, **settings)
        new = tail(args, **settings)
        mismatches = [key for key in old if not np.allclose(old[key], new[key], atol=1e-8)]
        comparisons.append({"latency_seconds": latency, "mismatched_fields": mismatches})
        assert not mismatches, (latency, mismatches)
    result = {
        "scope": "entirely invented data, no historical PnL evaluation",
        "original_long_latency_first_risk_violation": violations[0],
        "original_long_latency_risk_violation_submission_count": len(violations),
        "original_fractional_external_actions_reported_max": fractional["max_rolling_actions"].tolist(),
        "original_fractional_prior_actions_reported_max": truncated_prior["max_rolling_actions"].tolist(),
        "original_endgame_orders_before_readiness": int(premature["action_ticks"][0, 2, :380].sum()),
        "original_duplicate_round_actions": duplicate["actions"].tolist(),
        "original_single_round_actions": single["actions"].tolist(),
        "bounded_synthetic_compatibility": comparisons,
        "interpretation": "No historical impact inferred; original frozen artifacts preserved.",
    }
    temp = OUT / "synthetic_comparison.tmp"
    temp.write_text(json.dumps(result, indent=2) + "\n")
    temp.replace(OUT / "synthetic_comparison.json")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    run()
