"""Synthetic regression/independent-ledger checks. Never load research data."""

import itertools
import sys
import unittest
from pathlib import Path
from unittest.mock import patch

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT), str(ROOT / "research_v4/lead"),
                str(ROOT / "research_v4/audit/ingestion")]
from common import BASKETS, LIMITS, with_etfs
from etf_route_v3 import simulate_routes
from pnl_v2_simulator import simulate
import shared_account
from reference_adapter import DuplicateConflict, ReferenceAdapter
from test_reference_adapter import report, storm, view


def fixture(n=1):
    market = with_etfs(np.full((n, 3, 390, 10), 100.))
    truth = market[:, 2, -1].copy()
    curve = market[0].copy()
    curve[:, 32:, :10] += 5
    curve[..., 10:] = curve[..., :10] @ BASKETS.T
    delta = np.zeros((n, 3, 78, 12))
    return market, truth, curve, delta, truth.copy()


def tail(args, **kwargs):
    market, truth, curve, delta, fair = args
    return simulate(market, truth, delta, fair, curve, **kwargs)


def instrument(filename, replacements, hooks):
    source = (ROOT / filename).read_text()
    for old, new in replacements:
        assert source.count(old) == 1, old
        source = source.replace(old, new)
    namespace = {"__name__": "synthetic_instrument", **hooks}
    exec(compile(source, filename, "exec"), namespace)
    return namespace


class ReceiptTests(unittest.TestCase):
    def test_all_processing_orders_and_late_duplicate_preserve_asof(self):
        envelopes = [(storm(1, 0), 60), (storm(2, 2, 66), 69),
                     (report(3, "final", 740, 20), 750),
                     (report(4, "preliminary", 746, 5), 748)]
        expected = None
        for permutation in itertools.permutations(envelopes):
            adapter = ReferenceAdapter()
            for msg, received in permutation:
                adapter.ingest(msg, received_at=received)
            adapter.ingest(envelopes[0][0], received_at=900)
            values = [view(adapter, t, receipt) for t, receipt in
                      [(62, 62), (66, 68), (66, 69), (746, 749), (746, 750)]]
            if expected is None:
                expected = values
            self.assertEqual(expected, values)
        self.assertNotIn((1, 2), expected[1]["observations"])
        self.assertIn((1, 2), expected[2]["observations"])
        self.assertEqual(expected[-2]["reports"][1, "invented"].message["stage"], "preliminary")
        self.assertEqual(expected[-1]["reports"][1, "invented"].message["stage"], "final")

    def test_observation_revision_is_not_backdated(self):
        adapter = ReferenceAdapter()
        adapter.ingest(storm(1, 0, intensity=1), received_at=60)
        before = view(adapter, 64)
        adapter.ingest(storm(2, 0, 64, intensity=2), received_at=70)
        self.assertEqual(before, view(adapter, 64))
        self.assertEqual(view(adapter, 70)["observations"][1, 0].message["intensity"], 2)

    def test_conflict_is_atomic_and_duplicate_seq_is_season_global(self):
        adapter = ReferenceAdapter()
        adapter.ingest(storm(1, 0), received_at=60)
        before = view(adapter, 80)
        with self.assertRaises(DuplicateConflict):
            adapter.ingest({**storm(1, 0), "round": 2}, received_at=1000)
        self.assertEqual(before, view(adapter, 80))


class InterfaceTests(unittest.TestCase):
    def test_selected_rounds_leave_other_rounds_empty(self):
        args = fixture()
        args[3][:] = 20
        for r in range(3):
            a = tail(args, ongoing={"cycle": 10, "top_k": 2, "threshold": 0},
                     round_indices=[r], audit=True)
            b = simulate_routes(*args[:3], round_indices=[r], audit=True)
            for result in [a, b]:
                self.assertGreater(result["actions"][0], 0)
                self.assertEqual(result["action_ticks"][:, [i for i in range(3) if i != r]].sum(), 0)
                np.testing.assert_array_equal(result["actions"], result["action_ticks"].sum((1, 2)))

    def test_invalid_round_indices_are_rejected(self):
        for rounds in [[0, 0], [2, 0], [-1], [3], [0.5], [True]]:
            for fn in [lambda **kw: tail(fixture(), **kw),
                       lambda **kw: simulate_routes(*fixture()[:3], **kw)]:
                with self.subTest(rounds=rounds, fn=fn), self.assertRaises(ValueError):
                    fn(round_indices=rounds)

    def test_fractional_or_impossible_prior_history_is_rejected(self):
        for value in [0.5, -0.5, np.inf, np.nan, 3]:
            history = np.full((1, 30), value)
            for fn in [lambda **kw: tail(fixture(), **kw),
                       lambda **kw: simulate_routes(*fixture()[:3], **kw)]:
                with self.subTest(value=value, fn=fn), self.assertRaises(ValueError):
                    fn(round_indices=[0], prior_action_ticks=history)

    def test_prior_ledger_exact_sixty_second_expiry(self):
        args = fixture()
        args[3][:, 0, :, 0] = 20
        prior = np.zeros((1, 30), int)
        prior[0, -1] = 60  # previous round t=778; next round t=58 is exactly +60s
        result = tail(args, ongoing={"cycle": 10, "top_k": 1, "threshold": 0},
                      round_indices=[0], prior_action_ticks=prior, audit=True)
        self.assertEqual(result["action_ticks"][0, 0, :30].sum(), 0)
        self.assertEqual(result["action_ticks"][0, 0, 30], 1)  # first 10s decision >=58
        schedule = np.r_[prior[0], result["action_ticks"][0, 0]]
        self.assertLessEqual(np.convolve(schedule, np.ones(30), "full").max(), 60)

    def test_external_schedule_requires_integer_and_legal_budget(self):
        for value in [.5, 61]:
            external = np.zeros((1, 3, 390))
            external[0, 0, 0] = value
            with self.subTest(value=value), self.assertRaises(ValueError):
                tail(fixture(), round_indices=[0], external_actions=external,
                     readiness_times=np.full((1, 3), 10))

    def test_prior_plus_external_budget_preflight(self):
        prior = np.zeros((1, 30), int)
        prior[0, -1] = 60
        external = np.zeros((1, 3, 390), int)
        external[0, 0, 0] = 1
        with self.assertRaises(ValueError):
            tail(fixture(), round_indices=[0], prior_action_ticks=prior,
                 external_actions=external, readiness_times=np.full((1, 3), 10))

    def test_external_maximum_includes_later_ticks_without_owned_trades(self):
        external = np.zeros((1, 3, 390), int)
        external[0, 0, 50] = 60
        result = tail(fixture(), round_indices=[0], external_actions=external,
                      readiness_times=np.full((1, 3), 110), audit=True)
        self.assertEqual(result["actions"][0], 0)
        self.assertEqual(result["max_rolling_actions"][0], 60)

    def test_endgame_obeys_readiness_even_when_ongoing_is_disabled(self):
        args = list(fixture())
        args[4] = args[1] + 20
        external = np.zeros((1, 3, 390), int)
        external[0, 2, 370] = 1
        result = tail(args, end_margin=0, round_indices=[2], external_actions=external,
                      readiness_times=np.full((1, 3), 760), audit=True)
        self.assertEqual(result["action_ticks"][0, 2, :380].sum(), 0)
        self.assertGreater(result["action_ticks"][0, 2, 380:].sum(), 0)

    def test_invalid_round_gaps_rejected(self):
        for gap in [-1, np.nan, np.inf]:
            with self.subTest(gap=gap), self.assertRaises(ValueError):
                shared_account.shifted_history(np.zeros((1, 30), int), gap)


class PendingAndAccountingTests(unittest.TestCase):
    def test_cash_fees_and_settlement_reconstructed_from_actual_fills(self):
        args = list(fixture(2))
        rng = np.random.default_rng(1440)
        args[0] += rng.normal(0, .1, args[0].shape)
        args[3][:] = rng.choice([-15., 15.], args[3].shape)
        args[4] = args[1] + 10
        cash, fees, shares = np.zeros(2), np.zeros(2), np.zeros(2)
        inventory = np.zeros((2, 12), int)
        market_depth = {}

        def market_fill(r, ti, ids, symbols, qty):
            for i, j, quantity in zip(ids, symbols, qty):
                price = args[0][i, r, ti, j]
                fee = abs(quantity) * (price * .0025 + .02)
                cash[i] -= quantity * price + fee
                fees[i] += fee
                shares[i] += abs(quantity)
                inventory[i, j] += quantity
                key = (i, r, ti, j)
                market_depth[key] = market_depth.get(key, 0) + abs(quantity)

        def route_fill(r, ti, ids, change, kind):
            if kind == "market":
                for at, i in enumerate(ids):
                    js = np.flatnonzero(change[at])
                    market_fill(r, ti, np.full(len(js), i), js, change[at, js])
            else:
                inventory[ids] += change

        routed = instrument("etf_route_v3.py", [
            ("                q[i] += change",
             "                route_fill(r, ti, i.copy(), change.copy(), kind)\n                q[i] += change")
        ], {"route_fill": route_fill})["simulate_routes"]
        tailed = instrument("pnl_v2_simulator.py", [
            ("                q[i, j] += qty",
             "                market_fill(r, ti, i.copy(), j.copy(), qty.copy())\n                q[i, j] += qty")
        ], {"market_fill": market_fill})["simulate"]
        with patch.object(shared_account, "simulate_routes", routed), patch.object(shared_account, "simulate", tailed):
            result = shared_account.simulate_account(*args, round_gap_seconds=0, latency=12)
        np.testing.assert_array_equal(inventory, result["positions"])
        np.testing.assert_allclose(cash + (inventory * args[1]).sum(1), result["pnl"], atol=1e-7)
        np.testing.assert_allclose(fees, result["cost"], atol=1e-7)
        np.testing.assert_allclose(shares, result["turnover_shares"], atol=1e-7)
        self.assertLessEqual(max(market_depth.values()), 50)

    def test_opposing_pending_orders_reserve_both_sides(self):
        args = fixture()
        args[3][:, :, :, 10] = 100
        violations = []

        def inspect(r, ti, q, queue):
            buy, sell = np.zeros_like(q), np.zeros_like(q)
            for future in queue[ti + 1:]:
                for ids, symbols, quantity, cap, engine in future:
                    np.add.at(buy, (ids, symbols), np.maximum(quantity, 0))
                    np.add.at(sell, (ids, symbols), np.maximum(-quantity, 0))
            if np.any(q + buy > LIMITS) or np.any(q - sell < -LIMITS):
                violations.append((r, 2 * ti, q[0, 10], buy[0, 10], sell[0, 10]))

        module = instrument("pnl_v2_simulator.py", [
            ("                pending_qty[i, j] += quantity",
             "                pending_qty[i, j] += quantity\n                inspect(r, ti, q.copy(), queue)")
        ], {"inspect": inspect})
        for latency in [2, 12, 22, 40]:
            with self.subTest(latency=latency):
                violations.clear()
                market, truth, curve, delta, fair = args
                result = module["simulate"](market, truth, delta, fair, curve,
                    ongoing={"cycle": 10, "top_k": 1, "threshold": 0}, latency=latency,
                    round_indices=[0], audit=True)
                self.assertFalse(violations, violations[:2])
                self.assertLessEqual(result["max_position_fraction"].max(), 1)

    def test_shared_account_independent_fill_ledger(self):
        args = list(fixture(2))
        args[3][:] = 20
        args[4] = args[1] + 10
        # Coherent constant marks and settlement imply PnL equals negative fees,
        # even with route conversions and endgame positions left for settlement.
        for latency, depth, gap in [(2, 50, 0), (12, 25, 1), (22, 50, 60)]:
            with self.subTest(latency=latency, depth=depth, gap=gap):
                result = shared_account.simulate_account(*args, latency=latency,
                    depth=depth, round_gap_seconds=gap)
                np.testing.assert_allclose(result["pnl"], -result["cost"], atol=1e-7)
                np.testing.assert_allclose(result["attribution"].sum(1), result["pnl"], atol=1e-7)
                np.testing.assert_allclose(result["by_engine"].sum(1), result["pnl"], atol=1e-7)
                np.testing.assert_array_equal(result["actions"], result["action_ticks"].sum((1, 2)))
                self.assertTrue((result["tail_ready_times"] > result["formation_flat_times"]).all())
                # Real-time oracle handles non-integer quote-interval gaps.
                for account in result["action_ticks"]:
                    times = sorted(t * 2 + r * (780 + gap)
                                   for r in range(3) for t in range(390)
                                   for _ in range(account[r, t]))
                    left, maximum = 0, 0
                    for right, now in enumerate(times):
                        while times[left] <= now - 60:
                            left += 1
                        maximum = max(maximum, right - left + 1)
                    self.assertLessEqual(maximum, 60)


if __name__ == "__main__":
    unittest.main(verbosity=2)
