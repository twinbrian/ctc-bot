"""Validation for optional grid-account interfaces, not a live order ledger.

Prior counts are chronological two-second slots [-60, -58, ..., -2]. A slot at
exactly now-60 expires: the rolling window is (now-60, now]. Round indices are
zero-based. Multi-round legacy calls still reset rate history between rounds;
use the shared-account wrapper for a continuous real-time budget.
"""

import numpy as np


def selected_rounds(round_indices):
    rounds = list(range(3)) if round_indices is None else list(round_indices)
    if not rounds or any(
        isinstance(r, (bool, np.bool_)) or not isinstance(r, (int, np.integer))
        or r not in range(3) for r in rounds
    ) or rounds != sorted(set(rounds)):
        raise ValueError("round_indices must be a nonempty increasing subset of [0, 1, 2]")
    return rounds


def action_counts(values, shape, name):
    values = np.asarray(values)
    if (values.shape != shape or values.dtype.kind not in "iuf"
        or not np.isfinite(values).all() or np.any(values < 0)
        or np.any(values > 60) or np.any(values != np.floor(values))):
        raise ValueError(f"{name} must contain integer action counts in [0, 60], shape {shape}")
    return values.astype(np.int64)


def prior_history(values, n, rounds):
    if values is None:
        return None
    if len(rounds) != 1:
        raise ValueError("Explicit continuous history uses one-round calls")
    values = action_counts(values, (n, 30), "prior_action_ticks")
    if np.any(values.sum(1) > 60):
        raise ValueError("prior_action_ticks already violates the rolling budget")
    return values


def external_history(values, readiness, n, rounds, prior):
    values = action_counts(values, (n, 3, 390), "external_actions")
    readiness = np.asarray(readiness)
    if (readiness.shape != (n, 3) or not np.isfinite(readiness).all()
        or np.any(readiness < 0)):
        raise ValueError("readiness_times must be finite nonnegative seconds, shape (n, 3)")
    if np.any(values[np.arange(390)[None, None, :] * 2 >= readiness[:, :, None]]):
        raise ValueError("External phase must stop before this phase becomes ready")
    maximum = np.zeros(n, dtype=int)
    for r in rounds:
        history = np.zeros((n, 30), dtype=int) if prior is None else prior
        ledger = np.concatenate([history, values[:, r]], axis=1)
        c = np.pad(ledger.cumsum(1), ((0, 0), (1, 0)))
        windows = c[:, 30:] - c[:, :-30]
        if np.any(windows > 60):
            raise ValueError("External/prior history violates the rolling budget")
        # Exclude the historical window ending at -2; current windows begin at 0.
        maximum = np.maximum(maximum, windows[:, 1:].max(1))
    return values, readiness, maximum
