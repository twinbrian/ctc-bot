# V5 timing and account audit — fixed scope

This is a correctness audit, not a candidate search. No policy candidates, fits,
PnL scoring, validation retuning or seasons 1–120 access are authorized here.
Whole-season research boundaries remain fit 361–600, inner 241–360 and frozen
retrospective diagnostic 121–240. This metadata-only audit covers 121–600.

Finite checks declared before execution:
1. All supplied feed records: count/coverage; publication minus (60 + storm age);
   sequence collisions by supplied payload hash; source-line chronology;
   preliminary/final ordering. Metadata does not establish raw-payload equivalence.
2. Adapter: delayed publication, independent delayed receipt, arbitrary processing
   order, duplicate identity, conflicting identity, revised finals, missing data,
   historical snapshot immutability and multiple-round separation.
3. Simulators: optional round subsets, prior rolling action history and external
   actions; exact 60-second expiry, zero round gap, invalid interface inputs;
   shared phase handoff, independent cash/fees/settlement reconciliation;
   opposing pending orders under long latency.
4. Focused fixes only for demonstrated defects. Preserve original frozen result
   artifacts and publish a minimal integration diff plus synthetic regression tests.

No descendants or paid resources. One computational process with one BLAS/OMP
thread is sufficient. Long jobs use tmux and atomic completion files.
Local usage baseline was USD 0.5140545 (startup already incurred); budget accounting
uses the entire session total from zero, not total minus this snapshot. Stop new
research at USD 60, allocation USD 75. Active-work cap is five hours, excluding
restart downtime. Extraction and contract/report reads completed before recovery;
those are not rerun. Checkpoints live under this directory.
