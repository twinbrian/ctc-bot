# V5 feed timing and common-account audit

## Decision

**The supplied canonical metadata does not exhibit the delayed/reordered-feed
defects. Preserve the historical cache and frozen results.** Synthetic recovery
gaps remain real. The common-account interfaces needed focused hardening before
new results use them. No strategy was fitted, optimized, rescored or promoted.

### Canonical metadata, seasons 121–600 only

| Check | Observed result |
|---|---:|
| Messages / seasons / rounds | 415,563 / 480 / 1,440 |
| Storm messages | 347,040 |
| Publication minus `(60 + age)` | Exactly zero for every storm message |
| Same-sequence duplicates or conflicting hashes | 0 |
| Source-line discontinuities / sequence gaps or reversals | 0 |
| Publication chronology reversals | 0 |
| Missing active ages 0,2,…,478 / repeated ages | 0 / 0 |
| Terminal age480 observations | 1,440 |
| Preliminary reports | One per round, published at 570 seconds |
| Final reports | One per round, published at 740 seconds |
| Preliminary-after-final or stage-order inversions | 0 |

The gzip SHA256 is
`5c4ab9c6b63edd41f5ad0792085cfbfe656eb579b0ab31737c594eafe3a79bea`.
`metadata_results.json` and `metadata_per_season.csv` retain the aggregate and
season-level evidence. Zero-valued event counters not triggered by the scanner
are absent from its `counts` dictionary; the corresponding examples map is empty.

These findings establish **publication/identity-selection preconditions only**.
The export does not contain raw numerical payloads or actual receipt times, and
omits storm identity within a round. Hashes do not establish raw-payload or
prepared-cache equivalence. No claim is made about seasons 1–120, live receipts,
quote availability or actual wall-clock inter-round pauses. The provided
`development.npz` was placed at its requested path but not opened for this audit.

## Adapter

The receipt-aware reference adapter required **no source change**. Eleven existing
tests plus three added tests pass. The additional tests cover all 24 processing
orders of mixed delayed observations/reports, duplicate idempotence, late revised
observations without backdating and atomic rejection of a same-sequence conflict
across rounds. Final precedence is applied only among messages actually available
at the publication and receipt cutoffs; an unreceived final cannot displace a
received preliminary early.

No canonical cache rebuild is warranted by these metadata findings. For dirty or
live recovery, use the adapter's versioned, receipt-aware event state rather than
the original age-indexed arrays. `EVALUATION_CONTRACT.md` defines the required
future event fields and deliberately separates real receipts from publication.

## Confirmed synthetic account defects and focused fixes

| Original behavior | Fix |
|---|---|
| At latency22s, an ARCH example has position0, pending buys100 and pending sells50 at second20 despite the50-share limit. There are74 unsafe submissions in that invented one-round case. | Reserve outstanding buys/sells independently; net-zero pending is not flat; clip to directional room and retain unresolved exits. |
| Fractional prior and external action counts silently truncate to zero. Impossible external histories can escape checking if the owned engine is idle. | Validate integer counts and the entire combined prior/external rolling schedule before execution. |
| `round_indices=[0,0]` executes the same round twice:156 versus78 actions in the counterexample. | Require a nonempty increasing subset of zero-based rounds. |
| Final-report engine submits59 orders before an explicit760s readiness boundary. | Apply readiness to final-report entries as well as ongoing entries. |
| An idle phase can return max rolling actions0 while its supplied predecessor has60 later in the round. | Include the complete external/prior schedule in the reported maximum. |
| Negative/nonfinite round gaps are not a valid wall-clock contract; wait60 can be shorter than a longer depth cooldown. | Reject invalid gaps; use the larger wait/cooldown. |

The corrected shared wrapper conserves cash, market fees, turnover and final
settlement in an independent fill-ledger reconstruction. Coherent constant marks
also give PnL exactly equal to negative fees. Real-time event-list oracles confirm
the60-action limit at zero,1-second and60-second gaps; fixed-latency/depth stresses
include2/12/22 seconds and50/25 shares. Direct pending-risk tests also cover40s
latency. These are correctness stresses on invented data, not strategy returns.

**Important remaining boundary:** legacy multi-round calls to the two root
simulators still reset action history. That behavior is preserved for frozen
reproduction. New continuous-account claims must use the shared wrapper or an
equivalent chronological ledger. `external_actions` carries counts only; it does
not make independently concurrent inventory/cash simulations one account.

## Verification and impact

- **69 tests and 34 subtests pass**, including the existing root, shared-account
  and receipt tests plus 15 new focused tests.
- On two invented varying-price accounts, old/new tail outputs match for every
  returned field at2/4/6/12-second latency. This is bounded regression evidence,
  **not proof that all historical schedules are unchanged**.
- Original defect demonstrations and all comparison outcomes are retained in
  `synthetic_comparison.json`; test output and JUnit evidence are included.
- SHA256 comparisons confirm all 329 other original files are byte-identical to
  the supplied archive. Only the three intended simulator/wrapper sources changed;
  their pristine copies are retained. No original frozen result was overwritten.
- The long-latency defect is demonstrated beyond the published up-to12s stress
  range. No historical PnL effect was measured or inferred. Metadata timing gives
  no reason to invalidate the canonical historical results on these specific
  feed-order grounds. A changed schedule needs a parent-owned fixed-policy replay
  before promotion; old frozen artifacts must remain separately preserved.
- No fills/books, variable-delay execution, rejected conversions, partial fills
  or cash/margin limits were newly calibrated here.

## Performance status and budget

No new historical performance sample exists from this task. The unchanged prior
published incumbent remains mean **USD 11,100.59**, median **USD 10,018.11**, worst
**USD −8,756.46**, win rate **87.7%**, from the previously completed pooled five-fold
research estimate. Its reported 50bps/4s/25-share stress mean is **USD 5,661**. This
audit neither reopens its season outcomes nor recertifies that estimate. No new
mean/median/worst/win rate is asserted for the121–600 diagnostic split.

Local startup usage was USD 0.5140545; accounting includes startup by measuring
the entire session total, not subtracting that snapshot. The last research-stage
high-water snapshot was **USD 18.56**; delivery-stage usage was **USD 22.59** and
is checkpointed in `usage_summary.json`. Stop-new-research threshold USD 60;
allocation USD 75.
There were no descendants or paid compute/data resources. Active work was well
under five hours; no restart downtime is charged as active research. Work is
complete and no new search will be started.

## Integration and recovery

`integration.patch` changes only `pnl_v2_simulator.py`, `etf_route_v3.py`,
`research_v4/lead/shared_account.py`, and adds `replay_contract.py`. Apply from
the original project root with `patch -p1 < integration.patch`; inspect it first
if the parent has independently changed those files. The compact handoff also
contains replacement source and unchanged source snapshots for comparison.

Run `bash research_v5/audit/run_tests.sh` with a local `.venv` containing numpy,
scipy, scikit-learn and pytest. `compare_synthetic.py` uses retained original
source only, not data. The metadata scanner additionally needs the supplied gzip
at project root. Jobs use tmux, one BLAS/OMP thread and atomic completion/results
files. Existing frozen artifacts and all original audit reports are preserved.
