"""Two fixed forecast models; select only on the inner common-account outcomes."""

import argparse
import json
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from common import BASKETS
from research_v4.lab import load_development, summarize_pnl
from research_v5.handoff_research import forecasts, npz, write_json
from research_v5.scheduled_account import run

OUT = ROOT / "research_v5/conditional"
SCENARIOS = {
    "base": {},
    "50bps": {"cost_bps": 50},
    "latency6": {"latency": 6},
    "depth25": {"depth": 25},
    "combined": {"cost_bps": 50, "latency": 6, "depth": 25},
    "strict_combined": {
        "cost_bps": 50,
        "fixed_cost": 0.04,
        "latency": 6,
        "depth": 25,
        "adverse_bps": 10,
    },
}


def coherent_jump(stock_jump, entry_marks):
    stock_fair = entry_marks[..., :10] + stock_jump
    return np.concatenate(
        [stock_jump, stock_fair @ BASKETS.T - entry_marks[..., 10:]], axis=-1
    )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("stage", choices=["inner", "validation"])
    stage = parser.parse_args().stage
    if (OUT / f"{stage}_COMPLETE.json").exists():
        return
    if stage == "validation":
        frozen = json.loads((OUT / "frozen.json").read_text())
        names = list(dict.fromkeys(["clock", frozen["selected"]]))
    else:
        names = ["clock", "ridge", "hgb"]
    d = load_development()
    mask, pred = forecasts(d, stage)
    market, truth = d["market"][mask], d["settlement_truth"][mask]
    records = []
    results = {}
    for name in names:
        if name == "clock":
            jump = None
        else:
            model = dict(np.load(OUT / stage / f"{name}.npz"))
            np.testing.assert_array_equal(model["season_ids"], pred["eval_seasons"])
            jump = coherent_jump(model["jump"], market[:, :, 90])
        results[name] = {}
        for scenario, settings in SCENARIOS.items():
            path = OUT / f"{stage}_{name}_{scenario}.npz"
            if path.exists():
                result = dict(np.load(path))
            else:
                result = run(
                    market,
                    truth,
                    pred["curve"],
                    pred["final_fair"],
                    entry=180,
                    exit_at=540,
                    fraction=1.0,
                    forecast_jump=jump,
                    **settings,
                )
                npz(path, **result, season_ids=pred["eval_seasons"])
            results[name][scenario] = result
            row = {
                "stage": stage,
                "name": name,
                "scenario": scenario,
                **summarize_pnl(result["pnl"]),
                "mean_cost_usd": float(result["cost"].mean()),
                "mean_actions": float(result["actions"].mean()),
                "mean_engine_pnl": result["by_engine"].mean(0).tolist(),
                "max_rolling_actions": int(result["max_rolling_actions"].max()),
            }
            records.append(row)
            print(json.dumps(row), flush=True)
            write_json(OUT / f"{stage}_metrics.json", records)
    if stage == "inner":
        selected = max(names, key=lambda name: results[name]["base"]["pnl"].mean())
        write_json(
            OUT / "frozen.json",
            {
                "selected": selected,
                "candidate_count": 2,
                "inner_mean_usd": float(results[selected]["base"]["pnl"].mean()),
                "objective": "inner mean net shared-account PnL only",
                "policy": "formation20/100; conditional180/540/full; final740",
            },
        )
    write_json(
        OUT / f"{stage}_COMPLETE.json",
        {"names": names, "seasons": pred["eval_seasons"].tolist()},
    )


if __name__ == "__main__":
    main()
