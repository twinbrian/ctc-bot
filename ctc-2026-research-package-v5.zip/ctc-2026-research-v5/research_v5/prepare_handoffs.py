"""Package existing source, development data metadata and saved event checkpoints."""

import csv
import gzip
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile


def main():
    root = Path(__file__).resolve().parents[1]
    out = root / "research_v5" / "handoffs"
    out.mkdir(exist_ok=True)
    selected = list(root.glob("*.py")) + [root / "README_V3.md", root / "REPORT_V4.md"]
    selected += list((root / "tests").glob("*.py"))
    selected += [
        root / "research_v5" / name for name in ["CONTRACT.md", "job_runner.py"]
    ]
    selected += [
        p
        for p in (root / "research_v4").rglob("*")
        if p.is_file()
        and p.suffix in {".py", ".md", ".json"}
        and p.stat().st_size < 100_000
    ]
    for part in ["inner", "validation"]:
        selected.append(root / f"research_v4/event/{part}/motion_h60/prediction.npz")
    for path in (root / "research_v4/event/turnover/inner").rglob("*"):
        if path.is_file() and path.suffix in {".npz", ".csv", ".json"}:
            selected.append(path)
    source = out / "ctc-v5-source-checkpoints.zip"
    with ZipFile(source, "w", ZIP_DEFLATED) as archive:
        for path in sorted(set(selected)):
            archive.write(path, str(path.relative_to(root)))
        archive.write(root.parent / "hurricane-season-research/case.json", "case.json")
    metadata = out / "feed-publication-metadata-121-600.csv.gz"
    raw = root.parent / "hurricane-season-research/history"
    count = 0
    with gzip.open(metadata, "wt", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(
            [
                "season",
                "line",
                "type",
                "round",
                "time",
                "seq",
                "age",
                "stage",
                "source",
                "payload_sha256",
            ]
        )
        import hashlib

        for season in range(121, 601):
            with (raw / f"season-{season:03d}" / "feed.jsonl").open() as feed:
                for line_number, line in enumerate(feed, 1):
                    message = json.loads(line)
                    if "message" in message:
                        message = message["message"]
                    values = [
                        message.get(key, "")
                        for key in [
                            "type",
                            "round",
                            "time",
                            "seq",
                            "age",
                            "stage",
                            "source",
                        ]
                    ]
                    fingerprint = hashlib.sha256(
                        json.dumps(message, sort_keys=True).encode()
                    ).hexdigest()
                    writer.writerow([season, line_number, *values, fingerprint])
                    count += 1
    print(
        json.dumps(
            {
                "source": str(source),
                "source_mb": source.stat().st_size / 1e6,
                "metadata": str(metadata),
                "metadata_mb": metadata.stat().st_size / 1e6,
                "messages": count,
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
