"""Stale-feature sensitivity with correctly anchored stale quote forecasts."""

import json
import pickle
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from common import with_etfs
from research_v4.lab import summarize_pnl
from research_v5.handoff_research import npz, write_json
from research_v5.scheduled_account import run
from research_v5.terminal.model import PUBLIC, STATIC, snapshot

OUT = ROOT / "research_v5/information_lag"
SCENARIOS = {
    "base": {},
    "strict_combined": {
        "cost_bps": 50,
        "fixed_cost": 0.04,
        "latency": 6,
        "depth": 25,
        "adverse_bps": 10,
    },
}


def main():
    OUT.mkdir(exist_ok=True)
    if (OUT / "COMPLETE.json").exists():
        return
    d = dict(np.load(ROOT / "cache.npz"))
    for fold in range(5):
        p = dict(np.load(ROOT / f"results_v2/fold-{fold}-predictions.npz"))
        ids = p["test_ids"]
        take = np.array([np.flatnonzero(p["ids"] == i)[0] for i in ids])
        public = {k: d[k][ids] for k in PUBLIC}
        public.update({k: d[k] for k in STATIC})
        model = pickle.loads(
            (
                ROOT / f"research_v5/pooled_conditional/fold{fold}_models.pkl"
            ).read_bytes()
        )
        for lag in [0, 10, 30]:
            x = np.stack(
                [snapshot(public, r, 180, lag=lag)["full"] for r in range(3)], axis=1
            )
            predicted_change = model.predict_features(x)["hgb"]
            stale_quote = d["market"][ids, :, (180 - lag) // 2, :10]
            exit_fair = with_etfs(stale_quote + predicted_change)
            jump = exit_fair - d["market"][ids, :, 90]
            for scenario, settings in SCENARIOS.items():
                path = OUT / f"fold{fold}_lag{lag}_{scenario}.npz"
                if path.exists():
                    result = dict(np.load(path))
                else:
                    result = run(
                        d["market"][ids],
                        d["settlement_truth"][ids],
                        p["formation_curve"],
                        p["final_fair"][take],
                        forecast_jump=jump,
                        **settings,
                    )
                    npz(
                        path,
                        pnl=result["pnl"],
                        cost=result["cost"],
                        actions=result["actions"],
                        season_ids=ids + 1,
                    )
                if lag == 0:
                    old = np.load(
                        ROOT
                        / f"research_v5/pooled_conditional/fold{fold}_{scenario}.npz"
                    )
                    np.testing.assert_allclose(
                        result["pnl"], old["pnl"], atol=1e-8, rtol=0
                    )
        print("Completed lag fold", fold, flush=True)
    rows = []
    for lag in [0, 10, 30]:
        for scenario in SCENARIOS:
            parts = [
                dict(np.load(OUT / f"fold{f}_lag{lag}_{scenario}.npz"))
                for f in range(5)
            ]
            pnl = np.concatenate([p["pnl"] for p in parts])
            rows.append(
                {"lag_seconds": lag, "scenario": scenario, **summarize_pnl(pnl)}
            )
            npz(
                OUT / f"pooled_lag{lag}_{scenario}.npz",
                pnl=pnl,
                season_ids=np.arange(1, 601),
            )
    write_json(OUT / "metrics.json", rows)
    write_json(
        OUT / "COMPLETE.json",
        {
            "lags": [0, 10, 30],
            "zero_lag_matches": True,
            "scope": "Active forecast inputs only; old formation/final inputs held unchanged",
        },
    )
    print(json.dumps(rows), flush=True)


if __name__ == "__main__":
    main()
