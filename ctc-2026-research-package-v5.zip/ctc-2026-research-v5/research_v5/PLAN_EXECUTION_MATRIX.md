# Fixed-policy execution sensitivity surface

No selection or new policy candidates. Replay both frozen clock and selected HGB
accounts under the complete54-point Cartesian surface: cost25/50/100bps per
side plus USD0.02/share; fixed order latency2/6/12s; executable depth10/25/50
shares per symbol; replenishment2/10s. This is hypothetical sensitivity, not a
calibrated distribution of future books. Retain every combination and any
infeasible liquidation; never report only favorable scenarios.

Reuse all exact matching completed folded replays. New points use the same five
held-out-fit120-season folds, all600 previously researched seasons. No refits,
reoptimized policies or thresholds. Fees are known to the strategy and therefore
affect its existing cost gate; latency/depth are scenario exchange constraints.
All variants share real-time budgets across rounds, pending-side capacity and
zero-cash ETF conversions. Report means, wins, worst/p05 and regime surfaces;
these scenarios do not certify partial fills, market impact, receipts or news.
