# Frozen event-lease common-account evaluation

Evaluate the already frozen renewable lease, without further policy search or
threshold changes. Formation20/100/full must be actually inventory+pending flat
before enabling new event signals, after the two-second depth cooldown. Use
actual formation action times as external preceding counts in the event replay.
Event inventory/pending must be flat by700; final-report engine740 receives all
prior account action counts. Across rounds, event flat700 ensures no event action
remains in the next formation's sixty-second rolling budget. Final settlement
occurs once after round3.

Inner241–360 and frozen diagnostic121–240, using their original frozen event
forecasts and corresponding train-only formation/final-value checkpoints. This
is a fixed composition diagnostic, not permission to add standalone engine PnL.
Compare against the matched ten-second account and the frozen clock account.
Scenarios baseline,50bps,6s,25depth,combined50bps/6s/25depth and strict combined
50bps+USD0.04/side/6s/25depth/10bps adverse. No new adaptation from these outcomes.
