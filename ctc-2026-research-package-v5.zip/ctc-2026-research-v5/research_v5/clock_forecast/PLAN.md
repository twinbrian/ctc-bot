# Fixed current-round jump forecasts — follow-up v1

Declared before fitting/scoring. Exactly two conditional forecasts, with no
trading policies or model selection in this worker:

1. Existing `terminal.model.Ridge`, with centered/scaled features and penalty
   `0.10 * training_rows`, predicting each stock independently (multi-output
   closed-form solve). Use the unchanged `snapshot(..., round, 180)['full']`
   design: public physical state, guidance, quotes and round one-hot.
2. One `HistGradientBoostingRegressor` per stock, pooling rounds with the same
   full feature matrix: squared-error loss, 100 iterations, 7 leaves,
   min_samples_leaf=40, l2_regularization=30, learning_rate=0.06,
   max_depth=None, max_bins=255, early_stopping=False, random_state=0.
   The fixed algorithm random state is not a season seed or predictor.

Control: unconditional training mean jump by round and stock, broadcast over
evaluation seasons. No other feature design, capacity, threshold or model search.

Target for all models is the arithmetic mean of observed house quotes at real
seconds 542,544,546,548,550,552 minus the quote at180, for ten individual stocks.
Features use only information public as of180. Earlier completed rounds are
available; remaining current/future paths, later reports, identity, dates, seeds
and settlement truths are not predictors. Future prices are labels only.

Fit361–600, predict inner241–360. Refit identical designs241–600, predict frozen
diagnostic121–240. Whole seasons stay together. These data have been observed
previously; this is retrospective, not a fresh holdout. No1–120 access.

Export both models and the round-mean control as `jump[n,3,10]` with season_ids,
fit ranges, symbols and model parameters. Save targets, training outputs, fitted
models, per-stock/per-round and aggregate RMSE and signed bias (prediction minus
actual). Diagnostic forecast errors are descriptive and cannot change settings.
No PnL, trading-policy choice, risk-tail tuning or diagnostic trading here. Parent
owns the180 entry/acquire180–240/earliest-exit540 common-account schedule and its
inner-only selection before opening diagnostic trading. No additive PnL claim.

Single process and one BLAS/OMP thread, tmux plus atomic checkpoints. Stop if
parent requests. Follow-up starting local estimate USD37.9533895; at most USD25
additional and stop total research at USD55 (the tighter binding limit). Keep
earlier terminal outputs intact. No descendants or paid data/compute.
