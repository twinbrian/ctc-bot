# Current-round conditional jump forecasts — handoff v1

Exactly two requested conditional forecasts and one unconditional round-mean
control. No trading policy was scored or selected in this worker. These outputs
are for the parent's frozen entry180 / acquire180–240 / earliest-exit540 schedule.
They are not the earlier terminal-horizon forecasts, and imply no PnL improvement.

## Target and causal interface

`jump = mean(quote542,544,546,548,550,552) - quote180`, independently for the ten
stocks PORT, ISLE, AQUA, GRID, FERRY, RECON, MAT, GEN, HAVEN, REIN. Units USD/share.
This is the requested price-change target, not a fee-adjusted expected trading
profit. Parent applies its unchanged costs, gates, inventory, action ledger,
arrival prices and flattening schedule in its common-account executor.

The unchanged terminal research `snapshot(public_cube, round_index, 180)['full']`
provides physical state, public guidance, current quotes and round one-hot. Past
completed rounds are available. Current-round observations stop at age120s
(real second180), reports/guidance/quotes at second180. Later observations or
prices are not prediction inputs. Receipt-time caveats from the existing data
still apply. Season IDs are alignment metadata only, not predictors.

Callable source: `research_v5.clock_forecast.forecast.DriftModels`.
After loading a stage's `models.pkl` with the extracted project root on Python's
path, use `model.predict_round(public_cube, round_index)` at second180. It returns
a dictionary `ridge`, `hgb`, `round_mean`, each shaped `[n,10]`. Round indices are
zero-based. `model.predict_public(public_cube)` produces all rounds `[n,3,10]` for
offline alignment. Forecasts stay fixed through the parent's acquisition window;
these functions do not place orders, resize positions or inspect account state.

## Fixed model designs

- Ridge: the existing centered/scaled full-feature design and unchanged penalty
  `0.10 * training_rows`; independent coefficients for each stock.
- HGB: one squared-error regressor per stock, pooled rounds; 100 iterations,
  7 leaves, minimum40 samples/leaf, L2=30, learning rate0.06, max bins255,
  unlimited depth subject to7 leaves, early stopping disabled. Fixed algorithm
  random state0 is reproducibility machinery, not a season seed or feature.
- Control: unconditional training mean target jump by round and stock.

No feature, model, horizon, threshold or hyperparameter search was performed.
`PLAN.md` and source hashes were frozen before fitting, and the identical
specification is checked before each stage. Both conditional models are returned;
neither is promoted here. Numerical errors are descriptive, not a trading score.

## Alignment, stages and output files

- `inner/`: fitted361–600, predictions241–360 (120 whole seasons /360 rounds).
- `diagnostic/`: refitted241–600, frozen-model predictions121–240 (120 seasons).
  This is previously observed retrospective data, not a fresh holdout.
- `ridge.npz`, `hgb.npz`, `round_mean.npz`: `jump[120,3,10]`, `season_ids[120]`.
- `targets.npz`: `actual_jump`, `entry_quote`, `exit_mean_quote`, `season_ids`.
  These are labels for evaluation only and must not enter any trading decision.
- `training_outputs.npz`: the three fitted forecasts, actual targets and fit IDs.
- `features.npz`: frozen training/evaluation feature matrices and alignment IDs.
- `models.pkl`: both conditional models and round-mean control in one object.
- `metrics.json`: aggregate, per-stock, per-round and round-stock RMSE and signed
  bias, for training and evaluation. Bias means prediction minus actual.
- `COMPLETE.json`: atomic checkpoint. `frozen.json`: fixed settings/source hashes.

Array row order is explicit in each season_ids field; no calendar/identity feature
is used. No1–120 access occurred. All earlier terminal models and execution
checkpoints remain untouched. Parent owns inner-only trading-policy selection,
diagnostic trading and any promotion; standalone profits must not be added.

## Reproduction and checks

Use Python3.12 and `requirements.txt`. From the extracted project root, set
OMP_NUM_THREADS=OPENBLAS_NUM_THREADS=MKL_NUM_THREADS=1 and invoke
`python -m research_v5.clock_forecast.forecast inner` or `diagnostic`.
Completed stages skip refitting. The original jobs ran in tmux, one process and
one BLAS/OMP thread. Partial fitted models and atomic output files permit restart.
The original development dataset belongs at `research_v4/development.npz`; it is
not included in the compact handoff.

Checks cover the exact inclusive six-quote label window; invariance when future
paths, reports, quotes, settlement labels and identity are changed; and equality
of the per-round callable to each exported prediction. No root execution/account
primitives are called, and no trading-policy grid or diagnostic trading ran.

## Completed resources

Startup-inclusive cumulative local model estimate: USD 39.51.
Conservative follow-up increment through this snapshot is at most USD 5.00
(also charging the preceding handoff's unmeasured delivery to this follow-up).
Reserve USD 2 for final delivery overhead. Research is complete, below the
USD 55 total research stop and USD 25 additional allowance. Approximately six
active minutes for this follow-up; downtime excluded. No descendants or paid
data/compute. All fitted models, forecasts and checkpoints remain preserved.
