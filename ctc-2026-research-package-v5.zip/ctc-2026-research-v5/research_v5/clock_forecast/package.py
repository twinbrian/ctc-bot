"""Package saved forecasts and errors; does not fit or evaluate trading."""

import hashlib
import json
from pathlib import Path
import zipfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def main():
    lines = [
        "# Fixed current-round forecast errors — v1",
        "",
        "USD/share; bias = predicted minus actual jump. No trading scored.",
        "",
        "| Split | Forecast | RMSE | Bias |",
        "|---|---|---:|---:|",
    ]
    for phase in ["inner", "diagnostic"]:
        report = json.loads((HERE / phase / "metrics.json").read_text())
        for name, values in report["evaluation"].items():
            lines.append(
                f"| {phase} | {name} | {values['rmse']:.6f} | {values['bias']:.6f} |"
            )
    for phase in ["inner", "diagnostic"]:
        report = json.loads((HERE / phase / "metrics.json").read_text())
        lines += [
            "",
            f"## {phase}: per-stock errors",
            "",
            "| Stock | Ridge RMSE / bias | HGB RMSE / bias | Round mean RMSE / bias |",
            "|---|---:|---:|---:|",
        ]
        for j, symbol in enumerate(report["symbols"]):
            fields = []
            for name in ["ridge", "hgb", "round_mean"]:
                result = report["evaluation"][name]
                fields.append(
                    f"{result['by_stock_rmse'][j]:.6f} / {result['by_stock_bias'][j]:.6f}"
                )
            lines.append("| " + " | ".join([symbol] + fields) + " |")
    (HERE / "RESULTS.md").write_text("\n".join(lines) + "\n")
    source = [
        p
        for p in HERE.rglob("*")
        if p.is_file()
        and p.suffix in [".py", ".md", ".json", ".txt", ".npz", ".pkl"]
        and p.name != "manifest.json"
    ]
    source += [
        ROOT / p
        for p in [
            "common.py",
            "models.py",
            "case.json",
            "research_v5/terminal/model.py",
            "research_v5/job_runner.py",
            "research_v5/CONTRACT.md",
        ]
    ]
    source += list((ROOT / "research_v5/jobs").glob("clock-forecast-*.json"))
    source = sorted(set(source))
    manifest = {
        str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
        for p in source
    }
    (HERE / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    source.append(HERE / "manifest.json")
    bundle = ROOT / "ctc-v5-clock-forecasts-v1.zip"
    with zipfile.ZipFile(bundle, "w", zipfile.ZIP_DEFLATED) as archive:
        for p in source:
            archive.write(p, p.relative_to(ROOT))
    print(bundle, bundle.stat().st_size, "bytes", len(source), "files")


if __name__ == "__main__":
    main()
