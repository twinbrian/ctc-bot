"""Two frozen public-as-of180 forecasts; no execution or policy selection."""

import argparse
import datetime as dt
import hashlib
import json
from pathlib import Path
import pickle
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

import numpy as np
import sklearn
from sklearn.ensemble import HistGradientBoostingRegressor
from common import SYMBOLS
from research_v5.terminal.model import PUBLIC, Ridge, load_data, snapshot

HERE = Path(__file__).resolve().parent
HGB_PARAMS = dict(
    loss="squared_error",
    max_iter=100,
    max_leaf_nodes=7,
    min_samples_leaf=40,
    l2_regularization=30,
    learning_rate=0.06,
    max_depth=None,
    max_bins=255,
    early_stopping=False,
    random_state=0,
)
SPLITS = {"inner": ((361, 600), (241, 360)), "diagnostic": ((241, 600), (121, 240))}


def atomic(path, value, kind="json"):
    path = Path(path)
    tmp = path.with_name(path.name + ".tmp")
    if kind == "json":
        tmp.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")
    else:
        with tmp.open("wb") as stream:
            if kind == "npz":
                np.savez_compressed(stream, **value)
            else:
                pickle.dump(value, stream, protocol=5)
    tmp.replace(path)


def features(public_cube):
    """n x 3 x p; season identity is not read. No labels are required."""
    return np.stack([snapshot(public_cube, r, 180)["full"] for r in range(3)], 1)


def target_jump(market):
    """Training/evaluation label ONLY; never called by prediction functions."""
    return market[:, :, 271:277, :10].mean(2) - market[:, :, 90, :10]


class DriftModels:
    def fit(self, public_training_cube):
        x = features(public_training_cube)
        y = target_jump(public_training_cube["market"])
        assert np.isfinite(x).all() and np.isfinite(y).all()
        xx, yy = x.reshape(-1, x.shape[-1]), y.reshape(-1, 10)
        self.round_mean = y.mean(0)
        self.ridge = Ridge().fit(xx, yy)
        self.hgb = [
            HistGradientBoostingRegressor(**HGB_PARAMS).fit(xx, yy[:, j])
            for j in range(10)
        ]
        return self

    def predict_features(self, x, round_index=None):
        """Return jump arrays. Passing n x p requires explicit round_index."""
        xx = x.reshape(-1, x.shape[-1])
        shape = x.shape[:-1] + (10,)
        prior = self.round_mean if round_index is None else self.round_mean[round_index]
        return dict(
            ridge=self.ridge.predict(xx).reshape(shape),
            hgb=np.column_stack([m.predict(xx) for m in self.hgb]).reshape(shape),
            round_mean=np.broadcast_to(prior, shape).copy(),
        )

    def predict_public(self, public_cube):
        return self.predict_features(features(public_cube))

    def predict_round(self, public_cube, round_index):
        """Causal callable: n x 10 jump, at real second180 of one round."""
        assert 0 <= round_index < 3
        return self.predict_features(
            snapshot(public_cube, round_index, 180)["full"], round_index
        )


def errors(prediction, actual):
    error = prediction - actual
    return {
        "rmse": float(np.sqrt(np.mean(error**2))),
        "bias": float(np.mean(error)),
        "by_stock_rmse": np.sqrt(np.mean(error**2, axis=(0, 1))).tolist(),
        "by_stock_bias": error.mean(axis=(0, 1)).tolist(),
        "by_round_rmse": np.sqrt(np.mean(error**2, axis=(0, 2))).tolist(),
        "by_round_bias": error.mean(axis=(0, 2)).tolist(),
        "by_round_stock_rmse": np.sqrt(np.mean(error**2, axis=0)).tolist(),
        "by_round_stock_bias": error.mean(axis=0).tolist(),
    }


def audit_prefix(d):
    """Mutate all unavailable data/identity; current-round features must match."""
    tiny = {
        k: (v[:2].copy() if k in PUBLIC or k == "season_ids" else v)
        for k, v in d.items()
    }
    for r in range(3):
        before = snapshot(tiny, r, 180)["full"]
        changed = {k: v.copy() for k, v in tiny.items()}
        changed["obs"][:, r, 61:] = 777
        changed["obs"][:, r + 1 :] = 777
        for key in PUBLIC:
            if key != "obs":
                changed[key][:, r, 91:] = 0
                changed[key][:, r + 1 :] = 0
        changed["season_ids"][:] = -999
        changed["settlement_truth"] = np.full((len(before), 10), -999.0)
        np.testing.assert_array_equal(before, snapshot(changed, r, 180)["full"])


def freeze_spec():
    paths = [HERE / "PLAN.md", Path(__file__), ROOT / "research_v5/terminal/model.py"]
    hashes = {
        str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
        for p in paths
    }
    spec = dict(
        conditional_models=["ridge", "hgb"],
        control="round_mean",
        source_hashes=hashes,
        hgb=HGB_PARAMS,
        ridge_penalty="0.10 * number_of_training_rows",
        sklearn=sklearn.__version__,
        numpy=np.__version__,
        decision_second=180,
        label_seconds=[542, 544, 546, 548, 550, 552],
        no_trading_scored=True,
    )
    path = HERE / "frozen.json"
    if path.exists():
        assert json.loads(path.read_text()) == spec, "Frozen specification changed"
    else:
        atomic(path, spec)
    return spec


def run(phase):
    if (ROOT / "research_v5/STOP.json").exists():
        raise SystemExit("Parent requested research stop")
    spec = freeze_spec()
    out = HERE / phase
    out.mkdir(exist_ok=True)
    if (out / "COMPLETE.json").exists():
        print(phase, "already complete; no refit")
        return
    train_range, evaluation_range = SPLITS[phase]
    data = ROOT / "research_v4/development.npz"
    train = load_data(data, *train_range, labels=False)
    evaluation = load_data(data, *evaluation_range, labels=False)
    assert len(train["market"]) == train_range[1] - train_range[0] + 1
    assert len(evaluation["market"]) == 120
    audit_prefix(train)
    if (out / "models.pkl").exists():
        with (out / "models.pkl").open("rb") as stream:
            model = pickle.load(stream)
    else:
        model = DriftModels().fit(train)
        atomic(out / "models.pkl", model, "pickle")
    train_x, evaluation_x = features(train), features(evaluation)
    train_y, evaluation_y = (
        target_jump(train["market"]),
        target_jump(evaluation["market"]),
    )
    predicted = model.predict_features(evaluation_x)
    train_predicted = model.predict_features(train_x)
    for r in range(3):
        online = model.predict_round(evaluation, r)
        for name in predicted:
            np.testing.assert_allclose(
                online[name], predicted[name][:, r], rtol=0, atol=1e-12
            )
    for name, jump in predicted.items():
        assert jump.shape == (120, 3, 10) and np.isfinite(jump).all()
        atomic(
            out / f"{name}.npz",
            dict(jump=jump, season_ids=evaluation["season_ids"]),
            "npz",
        )
    atomic(
        out / "targets.npz",
        dict(
            actual_jump=evaluation_y,
            entry_quote=evaluation["market"][:, :, 90, :10],
            exit_mean_quote=evaluation["market"][:, :, 271:277, :10].mean(2),
            season_ids=evaluation["season_ids"],
        ),
        "npz",
    )
    atomic(
        out / "training_outputs.npz",
        dict(actual_jump=train_y, season_ids=train["season_ids"], **train_predicted),
        "npz",
    )
    atomic(
        out / "features.npz",
        dict(
            train=train_x,
            evaluation=evaluation_x,
            train_season_ids=train["season_ids"],
            evaluation_season_ids=evaluation["season_ids"],
        ),
        "npz",
    )
    report = dict(
        phase=phase,
        fit_seasons=train_range,
        evaluation_seasons=evaluation_range,
        n_seasons=120,
        n_rounds=360,
        features_per_round=train_x.shape[-1],
        symbols=list(SYMBOLS[:10]),
        array_axes=["season", "round_0_based", "stock"],
        units="USD/share jump; signed bias=prediction minus actual",
        previously_observed=True,
        trading_policy_selection=False,
        diagnostic_trading_scored=False,
        evaluation={
            name: errors(jump, evaluation_y) for name, jump in predicted.items()
        },
        training={
            name: errors(jump, train_y) for name, jump in train_predicted.items()
        },
        freeze=spec,
        prefix_mutation_audit="passed all three rounds",
        batch_callable_parity="passed all models and rounds to 1e-12",
    )
    atomic(out / "metrics.json", report)
    atomic(
        out / "COMPLETE.json",
        dict(
            finished_utc=dt.datetime.now(dt.timezone.utc).isoformat(),
            phase=phase,
            no_trading_scored=True,
        ),
    )
    print(
        json.dumps(
            {
                "phase": phase,
                "metrics": {
                    k: {j: v[j] for j in ["rmse", "bias"]}
                    for k, v in report["evaluation"].items()
                },
            },
            indent=2,
        ),
        flush=True,
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("phase", choices=list(SPLITS))
    args = parser.parse_args()
    # Keep pickle module identity stable for callable handoff after direct CLI use.
    from research_v5.clock_forecast.forecast import run as imported_run

    imported_run(args.phase)
