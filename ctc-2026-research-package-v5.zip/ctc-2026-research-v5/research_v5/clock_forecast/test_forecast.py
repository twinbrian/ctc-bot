import numpy as np

from research_v5.clock_forecast.forecast import audit_prefix, target_jump
from research_v5.terminal.model import load_data


def test_label_uses_six_even_second_quotes_and_entry_180():
    market = np.zeros((2, 3, 390, 12))
    market[:, :, 90, :10] = 5
    market[:, :, 271:277, :10] = np.arange(6)[None, None, :, None] + 10
    market[:, :, [270, 277], :] = 10000
    np.testing.assert_array_equal(target_jump(market), np.full((2, 3, 10), 7.5))


def test_public_prefix_ignores_future_prices_paths_reports_and_identity():
    audit_prefix(load_data("research_v4/development.npz", 361, 362, labels=False))
