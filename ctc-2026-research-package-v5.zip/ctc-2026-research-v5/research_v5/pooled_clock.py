"""Frozen-policy pooled replay using existing disjoint fit/prediction checkpoints."""

import hashlib
import json
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from research_v4.lab import summarize_pnl
from research_v4.lead.shared_account import simulate_account
from research_v5.handoff_research import npz, write_json
from research_v5.scheduled_account import run

OUT = ROOT / "research_v5/pooled_clock"
SCENARIOS = {
    "base": {},
    "50bps": {"cost_bps": 50},
    "latency6": {"latency": 6},
    "depth25": {"depth": 25},
    "combined": {"cost_bps": 50, "latency": 6, "depth": 25},
    "strict_combined": {
        "cost_bps": 50,
        "fixed_cost": 0.04,
        "latency": 6,
        "depth": 25,
        "adverse_bps": 10,
    },
    "latency12": {"latency": 12},
    "depth10": {"depth": 10},
    "replenish10s": {"replenish_seconds": 10},
}


def main():
    OUT.mkdir(exist_ok=True)
    if (OUT / "COMPLETE.json").exists():
        return
    frozen = json.loads((ROOT / "research_v5/schedule/frozen.json").read_text())
    assert frozen["config"] == {"entry": 180, "exit_at": 540, "fraction": 1.0}
    d = dict(np.load(ROOT / "cache.npz"))
    rows = []
    for fold in range(5):
        p = dict(np.load(ROOT / f"results_v2/fold-{fold}-predictions.npz"))
        ids = p["test_ids"]
        assert not set(ids) & set(p["train_ids"])
        take = np.array([np.flatnonzero(p["ids"] == i)[0] for i in ids])
        market, truth = d["market"][ids], d["settlement_truth"][ids]
        curve, delta, final_fair = (
            p["formation_curve"],
            p["delta"][take],
            p["final_fair"][take],
        )
        np.testing.assert_allclose(curve, d["market"][p["train_ids"]].mean(0))
        write_json(
            OUT / f"fold{fold}_fit.json",
            {
                "train_seasons": (p["train_ids"] + 1).tolist(),
                "evaluation_seasons": (ids + 1).tolist(),
                "frozen_policy": frozen,
            },
        )
        for scenario, settings in SCENARIOS.items():
            for policy in (
                ["clock", "control", "no_later"]
                if scenario == "base"
                else ["clock", "control"]
            ):
                name = f"fold{fold}_{policy}_{scenario}"
                path = OUT / f"{name}.npz"
                failed = OUT / f"{name}.blocked.json"
                if failed.exists():
                    rows.append(json.loads(failed.read_text()))
                    continue
                if path.exists():
                    result = dict(np.load(path))
                else:
                    try:
                        if policy == "control":
                            result = simulate_account(
                                market,
                                truth,
                                curve,
                                delta,
                                final_fair,
                                handoff="wait60",
                                round_gap_seconds=0,
                                **settings,
                            )
                        else:
                            result = run(
                                market,
                                truth,
                                curve,
                                final_fair,
                                no_later=policy == "no_later",
                                **frozen["config"],
                                **settings,
                            )
                    except AssertionError as exc:
                        row = {
                            "fold": fold,
                            "policy": policy,
                            "scenario": scenario,
                            "blocked": True,
                            "error": str(exc),
                        }
                        write_json(failed, row)
                        rows.append(row)
                        print(json.dumps(row), flush=True)
                        continue
                    npz(path, **result, season_ids=ids + 1)
                row = {
                    "fold": fold,
                    "policy": policy,
                    "scenario": scenario,
                    **summarize_pnl(result["pnl"]),
                    "mean_cost_usd": float(result["cost"].mean()),
                    "mean_actions": float(result["actions"].mean()),
                    "max_rolling_actions": int(result["max_rolling_actions"].max()),
                }
                rows.append(row)
                write_json(OUT / "fold_metrics.json", rows)
                print(json.dumps(row), flush=True)
    pooled = []
    for scenario in SCENARIOS:
        results = {}
        for policy in (
            ["clock", "control", "no_later"]
            if scenario == "base"
            else ["clock", "control"]
        ):
            paths = [OUT / f"fold{f}_{policy}_{scenario}.npz" for f in range(5)]
            if not all(p.exists() for p in paths):
                pooled.append({"policy": policy, "scenario": scenario, "blocked": True})
                continue
            parts = [dict(np.load(p)) for p in paths]
            keys = [
                "pnl",
                "cost",
                "actions",
                "attribution",
                "by_engine",
                "season_ids",
                "max_rolling_actions",
            ]
            combined = {k: np.concatenate([p[k] for p in parts]) for k in keys}
            assert len(set(combined["season_ids"])) == 600
            npz(OUT / f"pooled_{policy}_{scenario}.npz", **combined)
            results[policy] = combined
            row = {
                "policy": policy,
                "scenario": scenario,
                **summarize_pnl(combined["pnl"]),
                "mean_cost_usd": float(combined["cost"].mean()),
                "mean_actions": float(combined["actions"].mean()),
                "worst5_mean_usd": float(np.sort(combined["pnl"])[:30].mean()),
                "mean_engine_pnl": combined["by_engine"].mean(0).tolist(),
            }
            pooled.append(row)
        if "clock" in results and "control" in results:
            pooled.append(
                {
                    "policy": "paired_increment",
                    "scenario": scenario,
                    **summarize_pnl(
                        results["clock"]["pnl"] - results["control"]["pnl"]
                    ),
                }
            )
    write_json(OUT / "pooled_metrics.json", pooled)
    source_names = [
        "research_v5/pooled_clock.py",
        "research_v5/scheduled_account.py",
        "etf_route_v3.py",
        "pnl_v2_simulator.py",
        "replay_contract.py",
    ]
    write_json(
        OUT / "COMPLETE.json",
        {
            "source_hashes": {
                p: hashlib.sha256((ROOT / p).read_bytes()).hexdigest()
                for p in source_names
            },
            "qualification": "Frozen policy; entire-season fit separation; post-selection historical sample",
            "additional_policy_search": False,
            "folds": 5,
            "total_seasons": 600,
        },
    )


if __name__ == "__main__":
    main()
