"""Synthetic input-contract checks; no historical rescoring."""

import numpy as np

from audit import fixture
from integration import CausalEventPolicy, replay_shared
from run import ROOT, stamp, write_json


def rejects(fn):
    try:
        fn()
    except ValueError:
        return
    raise AssertionError("Invalid input accepted")


def main():
    m, p = fixture([])
    ready = np.full((1, 3), 120.)
    ext = np.zeros((1, 3, 390))
    for bad in (.5, np.inf, np.nan, -1, 61):
        counts = ext.copy(); counts[0, 0, 2] = bad
        rejects(lambda: replay_shared(m, p, entry_not_before=ready, external_action_ticks=counts))
    counts = ext.copy(); counts[0, 0, 60] = 1
    rejects(lambda: replay_shared(m, p, entry_not_before=ready, external_action_ticks=counts))
    counts = ext.copy(); counts[0, 0, 2:4] = 40
    rejects(lambda: replay_shared(m, p, entry_not_before=ready, external_action_ticks=counts))
    counts = ext.copy(); counts[0, 2, 50] = 60
    x = replay_shared(m, p, entry_not_before=ready, external_action_ticks=counts)
    assert not x["actions"].any() and x["max_rolling_actions"][0] == 60
    assert np.array_equal(x["total_action_ticks"], counts)
    zero = np.zeros((1, 12), int)
    buy, sell = zero.copy(), zero.copy()
    buy[0, 10] = sell[0, 10] = 50
    rejects(lambda: CausalEventPolicy(1).step(2, zero, np.zeros(1), np.full((1, 12), 100.), zero, buy, sell, zero))
    sell[:] = 0; buy[0, 10] = 51
    rejects(lambda: CausalEventPolicy(1).step(2, zero, np.zeros(1), np.full((1, 12), 100.), zero, buy, sell, zero))
    m, p = fixture([(1, 0, 0, 5), (1, 10, 0, 5)])
    counts = ext.copy(); counts[0, 0, 389] = 60
    ready = np.zeros((1, 3)); ready[0, 0] = 780
    x = replay_shared(m, p, entry_not_before=ready, external_action_ticks=counts, audit=True)
    assert x["orders"][0][1:3] == (2, 58)
    write_json(ROOT / "integration_audit.json", {"status": "passed", "time": stamp(),
        "scope": "synthetic only; frozen source/results unchanged", "checks": [
        "fractional/nonfinite/negative/oversize count rejection", "strict predecessor readiness",
        "infeasible external schedule rejected even idle", "external-only maximum retained",
        "opposing pending sides rejected; same-side limits enforced",
        "cross-round external history expires at exactly60 real seconds"]})
    print("integration contract checks passed")


if __name__ == "__main__":
    main()
