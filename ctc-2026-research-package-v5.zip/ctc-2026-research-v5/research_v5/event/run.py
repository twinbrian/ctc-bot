"""Checkpointed single-candidate study; no forecast fitting or old grid reruns."""

import csv
import hashlib
import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path

os.environ["OPENBLAS_NUM_THREADS"] = "1"
os.environ["OMP_NUM_THREADS"] = "1"
import numpy as np

from replay import SCENARIOS, simulate, summarize

ROOT = Path(__file__).resolve().parent
PROJECT = ROOT.parent.parent
OLD = PROJECT / "research_v4/event"


def stamp():
    return datetime.now(timezone.utc).isoformat()


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")
    tmp.replace(path)


def write_npz(path, **values):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".tmp")
    with tmp.open("wb") as f:
        np.savez_compressed(f, **values)
    tmp.replace(path)


def load(split):
    assert split in ("inner", "validation")
    raw = np.load(OLD / split / "motion_h60/prediction.npz", allow_pickle=False)
    p = {k: raw[k] for k in raw.files}
    p["horizon"] = 60
    d = np.load(PROJECT / "research_v4/development.npz", allow_pickle=False)
    ids = d["season_ids"]
    assert np.array_equal(ids, np.arange(121, 601))
    lo, hi = (241, 360) if split == "inner" else (121, 240)
    mask = (ids >= lo) & (ids <= hi)
    assert np.array_equal(ids[mask], np.arange(lo, hi + 1))
    assert p["delta"].shape == (120, 3, 390, 12)
    return d["market"][mask], p, ids[mask]


def old_vectors(split, scenario):
    if split == "inner":
        z = np.load(OLD / "turnover/inner/target_expiry" / f"{scenario}.npz")
        return {k: z[k] for k in ("pnl", "cost", "actions", "turnover_shares")}
    rows = list(csv.DictReader((ROOT / "recovered/paired_per_season.csv").open()))
    rows = sorted([r for r in rows if r["scenario"] == scenario], key=lambda r: int(r["season_id"]))
    assert [int(r["season_id"]) for r in rows] == list(range(121, 241))
    return {k: np.array([float(r["candidate_" + k]) for r in rows])
            for k in ("pnl", "cost", "actions", "turnover_shares")}


def code_hashes():
    return {p: digest(ROOT / p) for p in ("PLAN.md", "event_policy.py", "replay.py", "run.py")}


def score(split):
    out = ROOT / split
    if (out / "COMPLETE.json").exists():
        print(split, "already complete; reuse", flush=True)
        return
    assert json.loads((ROOT / "audit.json").read_text())["status"] == "passed"
    if split == "validation":
        frozen = json.loads((ROOT / "frozen.json").read_text())
        assert frozen["hashes"] == code_hashes(), "Frozen code changed"
        guard = out / "STARTED.json"
        if not guard.exists():
            write_json(guard, {"time": stamp(), "frozen_hash": digest(ROOT / "frozen.json")})
        assert json.loads(guard.read_text())["frozen_hash"] == digest(ROOT / "frozen.json")
    market, p, ids = load(split)
    metrics = []
    for scenario, kw in SCENARIOS.items():
        result_path = out / f"{scenario}.npz"
        complete = out / f"{scenario}.COMPLETE.json"
        if complete.exists():
            saved = json.loads(complete.read_text())
            assert saved["hashes"] == code_hashes()
            assert saved["result_hash"] == digest(result_path)
            m = saved["metrics"]
            print(split, scenario, "reuse checkpoint", flush=True)
        else:
            result = simulate(market, p, "renewable_lease", **kw)
            old = old_vectors(split, scenario)
            m = summarize(result)
            paired = result["pnl"] - old["pnl"]
            saving = old["cost"] - result["cost"]
            gross = paired - saving
            m.update(rule="renewable_lease", scenario=scenario,
                paired_mean=float(paired.mean()), paired_se=float(paired.std(ddof=1) / np.sqrt(len(paired))),
                paired_win_rate=float((paired > 0).mean()), gross_change=float(gross.mean()),
                cost_saving=float(saving.mean()))
            write_npz(result_path, season_ids=ids, paired_pnl=paired,
                **{k: v for k, v in result.items() if k != "trades"})
            if scenario == "base":
                tmp = out / "trades.csv.tmp"
                with tmp.open("w", newline="") as f:
                    w = csv.writer(f)
                    w.writerow(["season_index", "round", "symbol", "quantity", "decision_time",
                                "entry_time", "exit_time", "holding_seconds", "entry_price",
                                "exit_price", "cost", "pnl", "season_id"])
                    w.writerows([list(t) + [int(ids[t[0]])] for t in result["trades"]])
                tmp.replace(out / "trades.csv")
            write_json(complete, {"time": stamp(), "hashes": code_hashes(),
                "prediction_hash": digest(OLD / split / "motion_h60/prediction.npz"),
                "result_hash": digest(result_path), "metrics": m})
            print(split, scenario, json.dumps(m), flush=True)
        metrics.append(m)
        write_json(out / "metrics.json", metrics)
    write_json(out / "COMPLETE.json", {"time": stamp(), "metrics": metrics})


def freeze():
    path = ROOT / "frozen.json"
    if path.exists():
        print("already frozen; reuse", flush=True)
        return
    metrics = json.loads((ROOT / "inner/COMPLETE.json").read_text())["metrics"]
    new = next(m for m in metrics if m["scenario"] == "base")
    old = old_vectors("inner", "base")["pnl"].mean()
    selected = "renewable_lease" if new["mean_pnl"] > old else "target_expiry"
    write_json(path, {"time": stamp(), "selected_rule": selected,
        "new_candidate": "renewable_lease", "objective": "mean net terminal baseline USD PnL",
        "new_inner_mean": new["mean_pnl"], "old_inner_mean": float(old),
        "hashes": code_hashes(), "no_forecast_refit": True,
        "diagnostic_status": "further reuse of already observed121-240; not fresh holdout",
        "scenarios": SCENARIOS})
    print("FROZEN", selected, flush=True)


if __name__ == "__main__":
    command = sys.argv[1]
    if command in ("inner", "validation"):
        score(command)
    elif command == "freeze":
        freeze()
    else:
        raise ValueError(command)
