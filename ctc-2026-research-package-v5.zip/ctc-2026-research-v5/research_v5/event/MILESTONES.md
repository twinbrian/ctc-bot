# Milestones

## 2026-10-19 13:50 UTC: recovered first milestone

Archive contains completed turnover validation; freeze/source/prediction hashes
match. No rescoring. Old target_expiry, diagnostic121–240, standalone n=120:
mean USD2500.92, median USD2396.53, worst USD-2346.70, p05 USD-127.92;
win rate absent from compact validation metrics (raw season outputs omitted).
Mean costs USD1073.67 and actions67.63. Scenario means: latency6 USD1441.02;
double-cost USD1427.26; depth25 USD1250.46; original combined USD-27.19.
Paired baseline gain versus fixed60 USD905.85, mostly gross capture USD767.29.
Old120s hard hold remains frozen. Model cost snapshot USD3.970937 including startup.

The prompt_inspect_session and share_file tools are currently absent from the
available tool catalog after the restart. Parent message queued here for delivery
when available. Continuing local research without creating descendants.

## 2026-10-19: inner completed and frozen

The recovered per-season validation attachments establish old target_expiry's
baseline win rate94.17% (113/120), worst5%mean USD-812.50; combined-stress win
rate47.5% and worst5%mean USD-3667.29. No old replay was needed.

The sole renewable_lease candidate completed all five inner scenarios on241–360:
baseline mean USD2803.45, median USD2530.51, worst USD-1916.93, win96.67%;
mean costs USD982.65, actions61.58. Original stress means: latency6 USD1625.46,
double-cost USD1820.81, depth25 USD1401.73, combined USD274.64. Baseline paired
gain over saved target_expiry120 is USD440.45. New maximum continuous hold460s.
Frozen by baseline mean before new diagnostic replay; no policy fitting/refitting.
Local estimated spend USD17.9525745 including startup.

Ten accounting/causality tests passed, including a bounded three-season inner
refactor parity comparison in all original scenarios, charged pending reversals,
external rolling actions across rounds, and real flatness by700. Full old grids
and completed old validation were not rescored. The parent adapter is documented
in INTERFACE.md. New diagnostic runs in tmux with per-scenario atomic checkpoints.

## Diagnostic complete; delivery

Frozen renewable_lease completed121–240 once per original scenario. Baseline
mean/median/worst USD2955.90/2875.46/-2508.88;114/120 wins; p05 USD28.28;
worst5%mean USD-714.18. Stress means latency6 USD1871.54, double_cost USD2031.54,
depth25 USD1477.95, combined USD602.63. Combined worst USD-4269.97 and74/120 wins.
Baseline costs USD924.35, actions58.23. Maximum hold470s, median90s, p95 250s.
Paired mean gain USD454.97 versus old120; selection was already frozen on inner.
No tuning or additional family followed the diagnostic.

Independent saved-ledger audits reconstructed3695inner and3494diagnostic trades,
checked every saved rolling action history across rounds and reconciled symbol/
round attribution. Everything is naturally flat by596; shared adapter deadline700.
Latest pre-delivery estimated model spend USD22.6879265 including startup;
USAGE.json will record the later delivery snapshot.

Final delivery: both frozen prediction copies, strict shared adapter and6 synthetic integration groups complete; estimated model USD35.1771 including startup, plus USD2 delivery reserve. No new research remains.
