# Event turnover v5: completed handoff

**Return frozen `renewable_lease` for the parent's common-account comparison.**
The primary objective is arithmetic mean terminal net USD PnL. Standalone profits
cannot be added to v3. No combined-account improvement is claimed here.

## Recovery correction

REPORT_V4.md described an earlier checkpoint: the supplied archive already had
old turnover freeze13:36:37 UTC and validation COMPLETE13:36:49 UTC on2026-10-19.
Their source/prediction hashes match. Old inner scoring and completed validation
were reused. Parent-supplied per-season files restored omitted win rates. Only a
three-season inner refactor parity check replayed the old rule.

## New policy and selection

Exactly one structural candidate was declared before scoring. `renewable_lease`
removes the old120s filled-holding cap but retains the timestamp+60s forecast
lease: fresh eligible same-side forecasts must still pass the original two-leg
cost gate. Opposite targets require a charged close and separately charged entry;
pending orders are irrevocable. No forecast/feature/gate/size/horizon search.

The old `target_expiry` implementation retains its120s cap. New inner baseline
mean selected renewable_lease before diagnostic evaluation; all code hashes were
frozen. Whole-season fit361–600, inner241–360, saved refit241–600, diagnostic121–240.
No new model fitting, post-diagnostic retuning or seasons1–120 access occurred.
These previously observed diagnostic seasons are retrospective, not a fresh holdout.

## Outcomes

All means are standalone net **USD per three-round season**, n=120 per split.

| Scenario | Inner old120 | Inner new | Diagnostic fixed60 | Diagnostic old120 | Diagnostic new |
|---|---:|---:|---:|---:|---:|
| Baseline | 2363.00 | **2803.45** | 1595.08 | 2500.92 | **2955.90** |
| Latency6s | 1166.48 | 1625.46 | 886.31 | 1441.02 | 1871.54 |
| Double costs | 1235.07 | 1820.81 | 382.86 | 1427.26 | 2031.54 |
| Depth25 | 1181.50 | 1401.73 | 797.54 | 1250.46 | 1477.95 |
| Original combined | **-375.98** | **274.64** | **-777.67** | **-27.19** | **602.63** |

Baseline:25bps+USD0.02/share/side,2s latency,50shares/symbol/2s, one key's
60actions/rolling real minute. Double costs:50bps+USD0.04. Combined:latency6s,
50bps+USD0.04 plus10bps adverse execution per side; depth remains50. Gate costs
stay at baseline in every stress. Depth25 reduces the actual lot to25.

| New statistic | Inner baseline | Diagnostic baseline | Diagnostic combined |
|---|---:|---:|---:|
| Mean USD | 2803.45 | 2955.90 | 602.63 |
| Median USD | 2530.51 | 2875.46 | 662.98 |
| Worst USD | -1916.93 | -2508.88 | -4269.97 |
| p05 USD | 176.36 | 28.28 | -2803.61 |
| Worst5% mean USD | -582.15 | -714.18 | -3355.18 |
| Profitable seasons | 116/120 | 114/120 | 74/120 |
| Win rate | 96.67% | 95.00% | 61.67% |
| Mean costs USD | 982.65 | 924.35 | 2191.89 |
| Mean actions | 61.58 | 58.23 | 58.20 |

All old negative stress outcomes are retained. Old120 diagnostic baseline wins
113/120; its combined stress wins57/120. New diagnostic baseline worst season is
slightly worse than old120's USD-2346.70 despite higher mean. The positive-mean
stress condition passes for the new candidate, but does not certify live fills
or generalization from these extensively reused house-price paths.

Diagnostic new-minus-old120 baseline mean USD454.97 decomposes into USD305.66
gross capture and USD149.31 lower costs. Paired season-level SE is USD32.18;
114/120 paired differences are positive. New total baseline SE is USD185.07;
combined-stress SE is USD177.85. These are descriptive, not selection-adjusted.

Mean round trips decline33.82→29.12 and actions67.63→58.23. Mean filled holding
rises86.62s→110.06s; median90s, p95 250s, max470s, with33.29% above120s. Longer
occupation of shared inventory, especially ARCH's full50-share limit, is the
tradeoff. Latency6 still removes USD1084.36 from the new baseline mean.

## Parent interface and evidence

`EventPolicy.step` accepts only the current forecast/event/price slice and actual
held/pending episode state, returning causal targets, exit-submission expiry,
pending-side/intent reservations and exit-action reservations. `replay_shared`
accepts `entry_not_before[n,3]` and `external_action_ticks[n,3,390]`, counts prior
route actions in one rolling minute across rounds, reserves event exits and is
actually flat, including pending, by700. It returns action ticks, final inventory,
actual flat times and monetary attribution. See `INTERFACE.md`.

Parent owns causal formation handoff, common-account replay and final-report740
execution. The original ten-second-tail comparison was not duplicated here.
Standalone defaults retain round778; historical new leases finish by592 baseline
and596 at latency6. The separate shared adapter has the hard700 deadline.

`predictions_121_240.npz` is a byte-identical saved refit forecast copy, not a new
model. `prediction_manifest.json` records shape, season/symbol order and hash.
The forecast target is price(t+62)-price(t+2). Only `source>0` at the current
timestamp can establish or renew an intent; no later snapshot decides an earlier
action.

Ten synthetic/parity checks passed. `artifact_audit.json` and
`accounting_audit.json` reconcile saved cashflows, arrival-price costs, attribution,
rolling actions, flatness and frozen hashes without rerunning research. Maximum
standalone diagnostic rolling usage19; no standalone entry action blocking.
All per-season outcomes, baseline trade ledgers, old negative results and atomic
completion markers remain saved. `REPORT.md` contains full scenario risk tables.

Scoring commands reuse completed outputs: `python run.py inner`,
`python run.py freeze`, `python run.py validation`. Use OMP/OPENBLAS=1. Long scoring
jobs ran in tmux. `python report.py` and `python summarize_results.py` audit saved
outputs only. Run from this directory within the supplied source/checkpoint tree.

Latest model estimate before final delivery: USD30.81 including startup; later
snapshot and active-work accounting are in `USAGE.json`. USD75 allocation,
stop-new-research threshold USD60. Research is finished, with no further candidates.
No descendants, paid resources or repository changes. Preserve this sandbox for
recovery; the parent's integration work remains independent.

## Integration addendum after root audit

Import `replay_shared` and `CausalEventPolicy` from `integration.py`. Its strict
boundary rejects fractional/nonfinite budgets, predecessor/readiness overlap,
rolling-infeasible external history, opposing pending sides and same-side limit
violations. This wraps the unchanged frozen executor, so completed standalone
results were preserved. Six synthetic integration-contract groups passed.
Parent supplies actual formation gross pending flatness plus depth cooldown as
readiness. No10-second handoff variant was added. Calls span all3rounds chronologically.

Both byte-identical frozen checkpoints are delivered: `predictions_241_360.npz`
(fit361–600) and `predictions_121_240.npz` (saved refit241–600). Shapes/order/hashes
are documented in `prediction_manifest.json`.
