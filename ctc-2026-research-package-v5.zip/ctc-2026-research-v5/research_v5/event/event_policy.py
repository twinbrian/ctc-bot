"""Causal event intents. No fills, future prices, or settlement labels are inputs."""

import numpy as np

SYMBOLS = ("PORT", "ISLE", "AQUA", "GRID", "FERRY", "RECON", "MAT", "GEN",
           "HAVEN", "REIN", "ARCH", "REBLD")
LIMITS = np.array([200, 300, 500, 400, 800, 500, 700, 600, 250, 200, 50, 100])


class EventPolicy:
    """One instance per round, batched by season; all times are real seconds.

    `step` consumes ONLY the current forecast/event/price snapshot and the actual
    account state after current fills. `entry_submit_time` is the real submission
    time starting the current filled/pending episode, or -1 when flat. Never
    update it for a renewal. The executor owns orders, fills and action capacity.

    `enabled` suppresses new/renewed intent until the parent's formation handoff.
    It should remain true after handoff. It is not an instruction to liquidate an
    unrelated formation position. q/pending must represent the event-owned episode
    after the parent makes shared inventory available. Reservations are advisory
    inputs to a single account executor, not permission to spend extra capacity.
    """

    def __init__(self, n, rule="target_expiry", depth=50):
        if rule not in ("target_expiry", "renewable_lease"):
            raise ValueError(rule)
        if not 0 < depth <= 50:
            raise ValueError("depth must be in (0, 50]")
        self.rule = rule
        self.lot = np.minimum(depth, LIMITS).astype(int)
        self.target = np.zeros((n, 12), dtype=int)
        self.expiry = np.full((n, 12), -1, dtype=int)
        self.signal_time = np.full((n, 12), -1, dtype=int)
        self.forecast = np.zeros((n, 12))
        self.score = np.zeros((n, 12))
        self.blocked = np.zeros((n, 12), dtype=bool)
        self.last_time = -1

    def step(self, time, delta, source, price, q, pending_buy, pending_sell,
             entry_submit_time, *, latency=2, flat_by=778, enabled=True):
        if time <= self.last_time:
            raise ValueError("step requires increasing timestamps; use a new instance per round")
        self.last_time = time
        shape = self.target.shape
        delta, price, q = np.asarray(delta), np.asarray(price), np.asarray(q)
        buy, sell = np.asarray(pending_buy), np.asarray(pending_sell)
        assert all(x.shape == shape for x in (delta, price, q, buy, sell, entry_submit_time))
        assert np.all(buy >= 0) and np.all(sell >= 0)
        assert np.isfinite(delta).all() and np.isfinite(price).all()
        enabled = np.broadcast_to(np.asarray(enabled, dtype=bool), shape)
        episode = (q != 0) | (buy != 0) | (sell != 0)
        assert np.all(np.asarray(entry_submit_time)[episode] >= 0)
        deadline = np.full(shape, flat_by - latency, dtype=int)
        if self.rule == "target_expiry":
            deadline = np.where(episode, np.minimum(deadline, entry_submit_time + 120), deadline)
        self.blocked[~episode] = False
        hard_due = episode & (time >= deadline)
        newly_hard = hard_due & ~self.blocked
        self.blocked |= hard_due
        self.target[self.blocked] = 0
        self.expiry[self.blocked] = -1

        edge = np.abs(delta) - 2 * (price * .0025 + .02) - .15
        side = np.sign(delta).astype(int)
        event = (np.asarray(source) > 0) & (time + 60 + latency <= flat_by)
        qualifying = event[:, None] & (edge > 0) & enabled
        same = qualifying & (self.target != 0) & (side == np.sign(self.target)) & ~self.blocked
        renewals = (same & (self.expiry < time + 60)).sum(axis=1)
        self.expiry[same] = time + 60
        self.signal_time[same] = time
        self.forecast[same] = delta[same]
        self.score[same] = (edge * self.lot)[same]
        candidate = qualifying & ~same & ~self.blocked
        score = np.where(candidate, edge * self.lot, -np.inf)
        rank = np.argsort(-score, axis=1, kind="stable")
        row = np.arange(len(q))
        accepted = np.zeros(len(q), dtype=int)
        opposite = np.zeros(len(q), dtype=int)
        for k in range(12):
            j = rank[:, k]
            i = np.flatnonzero((score[row, j] > 0) & (accepted < 2))
            jj = j[i]
            old_side = np.sign(np.where(self.target[i, jj] != 0, self.target[i, jj],
                                        q[i, jj] + buy[i, jj] - sell[i, jj]))
            opposite[i] += (old_side != 0) & (old_side != side[i, jj])
            self.target[i, jj] = self.lot[jj] * side[i, jj]
            self.expiry[i, jj] = time + 60
            self.signal_time[i, jj] = time
            self.forecast[i, jj] = delta[i, jj]
            self.score[i, jj] = score[i, jj]
            accepted[i] += 1
        self.target[self.expiry <= time] = 0
        effective_expiry = np.where(self.target != 0, np.minimum(self.expiry, deadline), -1)
        # Separate sides retain the worst endpoint even for opposing pending orders.
        long_reserved = np.maximum(q + buy, 0)
        short_reserved = np.maximum(sell - q, 0)
        projected = q + buy - sell
        return {
            "target": self.target.copy(), "expiry": effective_expiry,
            "signal_time": self.signal_time.copy(), "forecast": self.forecast.copy(),
            "score": self.score.copy(), "hard_block": self.blocked.copy(),
            "pending_buy": buy.copy(), "pending_sell": sell.copy(),
            "reserved_long": long_reserved, "reserved_short": short_reserved,
            "intent_reserved_long": np.maximum(long_reserved, self.target),
            "intent_reserved_short": np.maximum(short_reserved, -self.target),
            "exit_actions_reserved": np.sum(projected != 0, axis=1),
            "renewals": renewals, "target_changes": accepted,
            "opposite_intents": opposite, "hard_exits": newly_hard.sum(axis=1),
        }
