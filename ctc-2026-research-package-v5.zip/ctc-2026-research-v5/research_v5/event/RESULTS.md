# Scenario comparison

All means are standalone net terminal USD per season; n=120 for each split.

| Split | Scenario | Fixed60 (reused) | Old target_expiry120 (reused) | New renewable_lease | Paired vs old120 |
|---|---|---:|---:|---:|---:|
| inner | base | 1482.44 | 2363.00 | 2803.45 | 440.45 |
| inner | latency6 | 794.28 | 1166.48 | 1625.46 | 458.97 |
| inner | double_cost | 214.85 | 1235.07 | 1820.81 | 585.74 |
| inner | depth25 | 741.22 | 1181.50 | 1401.73 | 220.23 |
| inner | combined | -946.12 | -375.98 | 274.64 | 650.63 |
| validation | base | 1595.08 | 2500.92 | 2955.90 | 454.97 |
| validation | latency6 | 886.31 | 1441.02 | 1871.54 | 430.52 |
| validation | double_cost | 382.86 | 1427.26 | 2031.54 | 604.29 |
| validation | depth25 | 797.54 | 1250.46 | 1477.95 | 227.49 |
| validation | combined | -777.67 | -27.19 | 602.63 | 629.83 |
