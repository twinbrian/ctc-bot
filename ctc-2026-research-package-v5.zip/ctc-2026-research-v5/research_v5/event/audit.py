"""Small causal/accounting checks; three-season archived parity, not a grid rerun."""

import numpy as np

from event_policy import EventPolicy, LIMITS
from replay import SCENARIOS, replay_shared, simulate
from run import OLD, ROOT, load, stamp, write_json


def fixture(events):
    m = np.full((1, 3, 390, 12), 100.0)
    p = {"delta": np.zeros_like(m), "source": np.zeros((1, 3, 390), dtype=int)}
    for r, t, j, delta in events:
        p["source"][0, r, t // 2] = 3
        p["delta"][0, r, t // 2, j] = delta
    return m, p


def run():
    checks = []
    m, p = fixture([(0, t, 10, 5) for t in range(120, 301, 10)])
    old = simulate(m, p, "target_expiry", audit=True)
    new = simulate(m, p, "renewable_lease", audit=True)
    assert old["max_holding_seconds"][0] == 120
    assert new["max_holding_seconds"][0] == 240
    np.testing.assert_allclose(old["pnl"], [-54])
    np.testing.assert_allclose(new["pnl"], [-27])
    assert new["actions"][0] == 2 and old["actions"][0] == 4
    checks.append("fresh renewals exceed120 only in new policy; same-price fees exact")

    m, p = fixture([(0, 120, 10, 5), (0, 122, 10, -5)])
    x = simulate(m, p, "renewable_lease", latency=6, audit=True)
    assert [o[2] for o in x["orders"]] == [120, 126, 132, 182]
    assert [o[5] for o in x["orders"]] == [50, -50, -50, 50]
    np.testing.assert_allclose(x["pnl"], [-54])
    assert x["turnover_shares"][0] == 200
    checks.append("pending reversal incurs4 charged separate50-share fills")

    m, p = fixture([(0, 120, 0, 5), (0, 130, 0, 5)])
    x = simulate(m, p, "renewable_lease", audit=True)
    assert x["actual_flat_times"][0, 0] == 192
    assert x["max_holding_seconds"][0] == 70
    checks.append("no fresh event means expiry at latest timestamp+60")

    # Prefix causality: no later mark/forecast influences decisions before300.
    a = simulate(m, p, "renewable_lease", audit=True)
    m2 = m.copy()
    m2[:, :, 150:] *= 2
    p2 = {k: v.copy() for k, v in p.items()}
    p2["source"][:, :, 150:] = 3
    p2["delta"][:, :, 150:, 0] = -10
    b = simulate(m2, p2, "renewable_lease", audit=True)
    for key in ("target_ticks", "expiry_ticks", "inventory_ticks"):
        np.testing.assert_array_equal(a[key][:, 0, :150], b[key][:, 0, :150])
    assert [o for o in a["orders"] if o[1] == 1 and o[2] < 300] == [
        o for o in b["orders"] if o[1] == 1 and o[2] < 300]
    checks.append("future-price/forecast mutation leaves earlier intents and orders unchanged")

    # Actual external orders leave only enough capacity for one reserved roundtrip.
    m, p = fixture([(0, 120, 0, 5), (0, 120, 1, 4), (0, 130, 0, 5)])
    ext = np.zeros((1, 3, 390), dtype=int)
    ext[0, 0, 59] = 58
    x = replay_shared(m, p, "renewable_lease", entry_not_before=np.full((1, 3), 120),
                      external_action_ticks=ext, audit=True)
    assert x["action_ticks"][0, 0, 60] == 1
    assert x["max_rolling_actions"][0] <= 60 and x["blocked_entries"][0] > 0
    checks.append("external58 actions plus entry reserve blocks second entry")

    m, p = fixture([(1, 0, 0, 5), (1, 10, 0, 5)])
    ext = np.zeros((1, 3, 390), dtype=int)
    ext[0, 0, 389] = 60
    x = replay_shared(m, p, "renewable_lease", entry_not_before=np.zeros((1, 3)),
                      external_action_ticks=ext, audit=True)
    assert x["orders"][0][1:3] == (2, 58)
    checks.append("rolling action history crosses contiguous round boundary")

    m, p = fixture([(0, 120, 0, 5)])
    x = replay_shared(m, p, "renewable_lease", entry_not_before=np.full((1, 3), 122),
                      external_action_ticks=np.zeros((1, 3, 390)), audit=True)
    assert not x["actions"].any()
    checks.append("pre-handoff events cannot become delayed stale entries")

    m, p = fixture([(0, t, 0, 5) for t in range(120, 701, 2)])
    x = replay_shared(m, p, "renewable_lease", entry_not_before=np.zeros((1, 3)),
                      external_action_ticks=np.zeros((1, 3, 390)), audit=True)
    assert x["actual_flat_times"][0, 0] == 700
    assert not x["inventory_ticks"][:, :, 350:].any()
    checks.append("renewal and fill deadline guarantee actual flat by700")

    policy = EventPolicy(1)
    q = np.zeros((1, 12), int)
    buy = q.copy(); sell = q.copy()
    buy[0, 10] = 50; sell[0, 10] = 50
    entry = np.full(q.shape, -1); entry[0, 10] = 0
    z = policy.step(2, np.zeros(q.shape), np.zeros(1), np.full(q.shape, 100.),
                    q, buy, sell, entry)
    assert z["reserved_long"][0, 10] == z["reserved_short"][0, 10] == 50
    checks.append("opposing pending quantities never net away side reservations")

    market, pred, _ = load("inner")
    p = {k: v[:3] if hasattr(v, "shape") and v.ndim and v.shape[0] == 120 else v
         for k, v in pred.items()}
    assert LIMITS.tolist() == [200, 300, 500, 400, 800, 500, 700, 600, 250, 200, 50, 100]
    for name, kw in SCENARIOS.items():
        x = simulate(market[:3], p, "target_expiry", **kw)
        old = np.load(OLD / "turnover/inner/target_expiry" / f"{name}.npz")
        for key in ("pnl", "cost", "actions", "turnover_shares", "attribution", "action_ticks",
                    "positions", "max_holding_seconds", "max_rolling_actions", "drawdown"):
            np.testing.assert_allclose(x[key], old[key][:3], rtol=0, atol=1e-8, err_msg=name + key)
    checks.append("three-season old-policy adapter parity in all5 scenarios; no full old rerun")
    write_json(ROOT / "audit.json", {"status": "passed", "time": stamp(), "checks": checks})
    print("PASSED", len(checks), "checks", flush=True)


if __name__ == "__main__":
    run()
