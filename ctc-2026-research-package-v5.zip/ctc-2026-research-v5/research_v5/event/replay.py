"""Standalone replay and optional disjoint formation handoff adapter.

All event decisions delegate to the same EventPolicy callable delivered to parent.
No output from a later time step is used to place an earlier order.
"""

import numpy as np

from event_policy import EventPolicy, LIMITS, SYMBOLS

SCENARIOS = {
    "base": {}, "latency6": {"latency": 6},
    "double_cost": {"cost_bps": 50, "fixed_cost": .04},
    "depth25": {"depth": 25},
    "combined": {"latency": 6, "cost_bps": 50, "fixed_cost": .04, "adverse_bps": 10},
}


def simulate(market, prediction, rule="target_expiry", *, latency=2, cost_bps=25,
             fixed_cost=.02, adverse_bps=0, depth=50, entry_not_before=None,
             external_action_ticks=None, flat_by=778, audit=False):
    """Market/delta [n,3,390,12]; source [n,3,390]. Optional handoff is real seconds.

    external_action_ticks [n,3,390] contains *actual* other-engine submissions,
    counted at their own timestamps in the one-key rolling 60-second budget.
    Rounds are conservatively contiguous (780 real seconds). No future external
    counts are used to decide current trades. Parent must keep event-owned
    holdings disjoint and preserve exit reservations; conflicting injected
    external actions fail closed rather than silently violating the budget.
    Use flat_by=700 for the requested formation/event/final-report integration.
    Monetary outputs are event-only; total_action_ticks includes other engines.
    """
    market = np.asarray(market)
    n = len(market)
    assert market.shape == prediction["delta"].shape == (n, 3, 390, 12)
    delay = max(1, int(np.ceil(latency / 2)))
    latency = 2 * delay
    assert 0 < depth <= 50 and flat_by % 2 == 0 and flat_by <= 778
    if entry_not_before is None:
        entry_not_before = np.zeros((n, 3), dtype=int)
    if external_action_ticks is None:
        external_action_ticks = np.zeros((n, 3, 390), dtype=int)
    assert np.shape(entry_not_before) == (n, 3)
    assert np.shape(external_action_ticks) == (n, 3, 390)
    assert np.all(external_action_ticks >= 0)
    assert np.all(external_action_ticks == np.floor(external_action_ticks))
    assert np.all(np.isfinite(entry_not_before)) and np.all(entry_not_before >= 0)
    row = np.arange(n)
    q = np.zeros((n, 12), dtype=int)
    pending = np.zeros_like(q)
    cash, cost, turnover, peak, drawdown = np.zeros((5, n))
    used, actions, max_rolling, trades_count, max_holding = np.zeros((5, n), dtype=int)
    total_holding = np.zeros(n)
    max_position = np.zeros(n)
    blocked = np.zeros(n, dtype=int)
    counters = {k: np.zeros(n, dtype=int) for k in
                ("renewals", "target_changes", "opposite_intents", "hard_exits")}
    history = np.zeros((n, 30), dtype=int)
    action_ticks = np.zeros((n, 3, 390), dtype=np.int16)
    attribution = np.zeros((n, 12))
    by_round = np.zeros((n, 3))
    flat_times = np.zeros((n, 3), dtype=int)
    final_by_round = np.zeros((n, 3, 12), dtype=int)
    inventory = np.zeros_like(market, dtype=np.int16) if audit else None
    intents = np.zeros_like(market, dtype=np.int16) if audit else None
    expiries = np.full_like(market, -1, dtype=np.int16) if audit else None
    orders, trades = [], []
    for r in range(3):
        policy = EventPolicy(n, rule, depth)
        queue = np.zeros((390 + delay, n, 12), dtype=int)
        entry_submit = np.full((n, 12), -1, dtype=int)
        entry_fill = np.full((n, 12), -1, dtype=int)
        entry_price, entry_fee = np.zeros((2, n, 12))
        for ti in range(390):
            time = 2 * ti
            slot = (r * 390 + ti) % 30
            used -= history[:, slot]
            history[:, slot] = np.asarray(external_action_ticks[:, r, ti], dtype=int)
            used += history[:, slot]
            price = market[:, r, ti]
            fills = queue[ti]
            ii, jj = np.where(fills != 0)
            if len(ii):
                qty = fills[ii, jj]
                assert np.all(np.abs(qty) <= depth)
                fees = np.abs(qty) * (price[ii, jj] * (cost_bps + adverse_bps) / 10000 + fixed_cost)
                old = q[ii, jj].copy()
                exits = old != 0
                assert np.all(old[exits] + qty[exits] == 0)
                np.add.at(cash, ii, -qty * price[ii, jj] - fees)
                np.add.at(cost, ii, fees)
                np.add.at(turnover, ii, np.abs(qty))
                for k in np.flatnonzero(exits):
                    i, j = ii[k], jj[k]
                    holding = time - entry_fill[i, j]
                    assert rule != "target_expiry" or holding <= 120
                    pnl = old[k] * (price[i, j] - entry_price[i, j]) - entry_fee[i, j] - fees[k]
                    attribution[i, j] += pnl
                    by_round[i, r] += pnl
                    trades_count[i] += 1
                    total_holding[i] += holding
                    max_holding[i] = max(max_holding[i], holding)
                    flat_times[i, r] = time
                    trades.append((int(i), r + 1, SYMBOLS[j], int(old[k]),
                                   int(entry_submit[i, j]), int(entry_fill[i, j]), time,
                                   int(holding), float(entry_price[i, j]), float(price[i, j]),
                                   float(entry_fee[i, j] + fees[k]), float(pnl)))
                    entry_submit[i, j] = -1
                a, b = ii[~exits], jj[~exits]
                entry_fill[a, b] = time
                entry_price[a, b] = price[a, b]
                entry_fee[a, b] = fees[~exits]
                q += fills
                pending -= fills
            assert np.all(np.maximum(np.abs(q), np.abs(q + pending)) <= LIMITS)
            max_position = np.maximum(max_position, np.max(np.abs(q) / LIMITS, axis=1))
            wealth = cash + (q * price).sum(axis=1)
            peak = np.maximum(peak, wealth)
            drawdown = np.maximum(drawdown, peak - wealth)
            assert np.all(used + np.sum(q + pending != 0, axis=1) <= 60), "External actions consumed reserved exits"
            out = policy.step(time, prediction["delta"][:, r, ti], prediction["source"][:, r, ti],
                              price, q, np.maximum(pending, 0), np.maximum(-pending, 0),
                              entry_submit, latency=latency, flat_by=flat_by,
                              enabled=(time >= np.asarray(entry_not_before)[:, r])[:, None])
            for k in counters:
                counters[k] += out[k]
            if audit:
                inventory[:, r, ti] = q
                intents[:, r, ti] = out["target"]
                expiries[:, r, ti] = out["expiry"]
            sent = np.zeros((n, 12), dtype=bool)

            def submit(i, j, quantity, kind):
                if not len(i):
                    return
                assert not pending[i, j].any() and not sent[i, j].any()
                assert np.all(used[i] < 60) and np.all(np.abs(quantity) <= depth)
                assert time + latency <= flat_by
                queue[ti + delay, i, j] = quantity
                pending[i, j] += quantity
                sent[i, j] = True
                used[i] += 1
                history[i, slot] += 1
                actions[i] += 1
                action_ticks[i, r, ti] += 1
                if kind == "entry":
                    entry_submit[i, j] = time
                if audit:
                    orders.extend((int(a), r + 1, time, time + latency, int(b), int(qty), kind)
                                  for a, b, qty in zip(i, j, quantity))

            if time + latency <= flat_by:
                for j in range(12):
                    need = (q[:, j] != 0) & ((out["target"][:, j] == 0) |
                                             (q[:, j] * out["target"][:, j] < 0))
                    i = np.flatnonzero(need & (pending[:, j] == 0) & (used < 60))
                    submit(i, np.full(len(i), j), -q[i, j], "exit")
                ready = (out["target"] != 0) & (q == 0) & (pending == 0) & ~sent & ~out["hard_block"]
                ready &= out["expiry"] > time + latency
                score = np.where(ready, out["score"], -np.inf)
                rank = np.argsort(-score, axis=1, kind="stable")
                for k in range(12):
                    j = rank[:, k]
                    eligible = score[row, j] > 0
                    capacity = used + np.sum(q + pending != 0, axis=1) + 2 <= 60
                    blocked += eligible & ~capacity
                    i = np.flatnonzero(eligible & capacity)
                    jj = j[i]
                    submit(i, jj, out["target"][i, jj], "entry")
            max_rolling = np.maximum(max_rolling, used)
            assert np.all(used + np.sum(q + pending != 0, axis=1) <= 60)
            if time >= flat_by:
                assert not q.any() and not pending.any()
        final_by_round[:, r] = q
    assert not q.any() and not pending.any()
    assert np.allclose(attribution.sum(axis=1), cash)
    assert np.allclose(by_round.sum(axis=1), cash)
    result = dict(pnl=cash, cost=cost, turnover_shares=turnover, actions=actions,
                  drawdown=drawdown, max_rolling_actions=max_rolling,
                  max_position_fraction=max_position, blocked_entries=blocked,
                  trades_count=trades_count, max_holding_seconds=max_holding,
                  total_holding_seconds=total_holding, positions=q.copy(),
                  pending=pending.copy(), final_positions_by_round=final_by_round,
                  action_ticks=action_ticks, total_action_ticks=action_ticks + external_action_ticks,
                  actual_flat_times=flat_times, attribution=attribution, by_round=by_round,
                  trades=trades, **counters)
    if audit:
        result.update(orders=orders, inventory_ticks=inventory,
                      target_ticks=intents, expiry_ticks=expiries)
    return result


def replay_shared(market, prediction, rule="target_expiry", *, entry_not_before,
                  external_action_ticks, **scenario):
    """Parent adapter: use actual route handoff and be flat by real second700."""
    if "flat_by" in scenario:
        raise ValueError("Shared-account deadline is fixed at700")
    return simulate(market, prediction, rule, entry_not_before=entry_not_before,
                    external_action_ticks=external_action_ticks, flat_by=700, **scenario)


def summarize(result):
    p = result["pnl"]
    out = {"n": len(p), "mean_pnl": float(p.mean()), "median_pnl": float(np.median(p)),
           "min_pnl": float(p.min()), "p05_pnl": float(np.quantile(p, .05)),
           "worst5_mean": float(np.sort(p)[:max(1, int(np.ceil(len(p) * .05)))].mean()),
           "win_rate": float(np.mean(p > 0)), "se_pnl": float(p.std(ddof=1) / np.sqrt(len(p))),
           "mean_gross": float((p + result["cost"]).mean())}
    for key in ("cost", "actions", "turnover_shares", "trades_count", "drawdown",
                "blocked_entries", "renewals", "target_changes", "opposite_intents", "hard_exits"):
        out["mean_" + key] = float(result[key].mean())
    for key in ("max_rolling_actions", "max_position_fraction", "max_holding_seconds"):
        out[key] = float(result[key].max())
    out["mean_holding_seconds"] = float(result["total_holding_seconds"].sum() /
                                         max(1, result["trades_count"].sum()))
    out["latest_flat_time"] = int(result["actual_flat_times"].max())
    return out
