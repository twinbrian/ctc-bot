"""Saved-output-only reconciliation and compact tables; never calls simulate."""

import csv
import json
from pathlib import Path

import numpy as np

from event_policy import SYMBOLS
from run import OLD, ROOT, code_hashes, digest, old_vectors, stamp, write_json


def report():
    frozen = json.loads((ROOT / "frozen.json").read_text())
    assert frozen["hashes"] == code_hashes()
    rows, audit, holding, attribution = [], [], [], []
    for split in ("inner", "validation"):
        assert (ROOT / split / "COMPLETE.json").exists()
        for scenario in frozen["scenarios"]:
            path = ROOT / split / f"{scenario}.npz"
            checkpoint = json.loads((ROOT / split / f"{scenario}.COMPLETE.json").read_text())
            assert checkpoint["result_hash"] == digest(path)
            x = np.load(path)
            old = old_vectors(split, scenario)
            assert not x["positions"].any() and not x["pending"].any()
            assert not x["final_positions_by_round"].any()
            assert x["actual_flat_times"].max() <= 700
            np.testing.assert_allclose(x["attribution"].sum(axis=1), x["pnl"], atol=1e-8, rtol=0)
            np.testing.assert_allclose(x["by_round"].sum(axis=1), x["pnl"], atol=1e-8, rtol=0)
            ticks = x["total_action_ticks"].reshape(120, -1)
            rolling = np.array([np.convolve(t, np.ones(30), "full").max() for t in ticks])
            np.testing.assert_array_equal(rolling, x["max_rolling_actions"])
            assert rolling.max() <= 60
            np.testing.assert_array_equal(x["action_ticks"].sum(axis=(1, 2)), x["actions"])
            for i, sid in enumerate(x["season_ids"]):
                rows.append({"split": split, "scenario": scenario, "season_id": int(sid),
                    "old120_pnl": float(old["pnl"][i]), "new_pnl": float(x["pnl"][i]),
                    "paired_pnl": float(x["pnl"][i] - old["pnl"][i]),
                    "old120_cost": float(old["cost"][i]), "new_cost": float(x["cost"][i]),
                    "old120_actions": int(old["actions"][i]), "new_actions": int(x["actions"][i]),
                    "new_gross": float(x["pnl"][i] + x["cost"][i]),
                    "latest_flat_second": int(x["actual_flat_times"][i].max()),
                    "max_rolling_actions": int(rolling[i])})
            audit.append({"split": split, "scenario": scenario, "flat": True,
                          "rolling_max": int(rolling.max()), "monetary_attribution_reconciled": True})
        trades = list(csv.DictReader((ROOT / split / "trades.csv").open()))
        total = np.zeros(120)
        cost = np.zeros(120)
        shares = np.zeros(120)
        count = np.zeros(120, dtype=int)
        for t in trades:
            i = int(t["season_index"])
            q = int(t["quantity"])
            net = q * (float(t["exit_price"]) - float(t["entry_price"])) - float(t["cost"])
            assert np.isclose(net, float(t["pnl"]), rtol=0, atol=1e-8)
            assert int(t["exit_time"]) - int(t["entry_time"]) == int(t["holding_seconds"])
            total[i] += net
            cost[i] += float(t["cost"])
            shares[i] += 2 * abs(q)
            count[i] += 1
        base = np.load(ROOT / split / "base.npz")
        for a, key in ((total, "pnl"), (cost, "cost"), (shares, "turnover_shares"), (count, "trades_count")):
            np.testing.assert_allclose(a, base[key], rtol=0, atol=1e-8)
        h = np.array([int(t["holding_seconds"]) for t in trades])
        holding.append({"split": split, "trades": len(h), "mean": float(h.mean()),
            "median": float(np.median(h)), "p95": float(np.quantile(h, .95)),
            "maximum": int(h.max()), "fraction_above120": float((h > 120).mean()),
            "fraction_below60": float((h < 60).mean())})
        for j, symbol in enumerate(SYMBOLS):
            attribution.append({"split": split, "symbol": symbol,
                                "mean_pnl": float(base["attribution"][:, j].mean())})
    for name, data in (("paired_per_season.csv", rows), ("attribution.csv", attribution)):
        with (ROOT / name).open("w", newline="") as f:
            w = csv.DictWriter(f, list(data[0])); w.writeheader(); w.writerows(data)
    write_json(ROOT / "artifact_audit.json", {"status": "passed", "time": stamp(),
        "source_hashes_match_freeze": True, "checks": audit,
        "baseline_trades_reconciled": True, "no_replays_or_fits": True})
    write_json(ROOT / "holding.json", holding)
    table = ["# Scenario comparison", "", "All means are standalone net terminal USD per season; n=120 for each split.", "",
             "| Split | Scenario | Fixed60 (reused) | Old target_expiry120 (reused) | New renewable_lease | Paired vs old120 |",
             "|---|---|---:|---:|---:|---:|"]
    for split in ("inner", "validation"):
        oldm = json.loads((OLD / "turnover" / split / "metrics.json").read_text())
        for m in json.loads((ROOT / split / "metrics.json").read_text()):
            scenario = m["scenario"]
            fixed = next(x["mean_pnl"] for x in oldm if x["scenario"] == scenario and x["rule"] == "control")
            old120 = next(x["mean_pnl"] for x in oldm if x["scenario"] == scenario and x["rule"] == "target_expiry")
            table.append(f"| {split} | {scenario} | {fixed:.2f} | {old120:.2f} | {m['mean_pnl']:.2f} | {m['paired_mean']:.2f} |")
    (ROOT / "RESULTS.md").write_text("\n".join(table) + "\n")
    print(json.dumps(holding, indent=2))


if __name__ == "__main__":
    report()
