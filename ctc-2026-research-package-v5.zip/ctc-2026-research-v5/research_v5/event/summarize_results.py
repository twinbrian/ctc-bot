"""Summarize saved outcomes and audit ledgers, without replaying any policy."""

import csv
import json
from pathlib import Path

import numpy as np

from event_policy import SYMBOLS
from run import ROOT, OLD, PROJECT, digest, code_hashes, write_json


def basic(p, c, a):
    return dict(n=len(p), mean=float(p.mean()), median=float(np.median(p)),
                worst=float(p.min()), p05=float(np.quantile(p, .05)),
                worst5_mean=float(np.sort(p)[:6].mean()),
                win_rate=float(np.mean(p > 0)), mean_cost=float(c.mean()),
                mean_actions=float(a.mean()), mean_gross=float((p + c).mean()))


def main():
    assert json.loads((ROOT / 'frozen.json').read_text())['hashes'] == code_hashes()
    rows, audit, holdings = [], {}, {}
    for split in ('inner', 'validation'):
        assert (ROOT / split / 'COMPLETE.json').exists()
        for rule in ('control', 'target_expiry', 'renewable_lease'):
            for scenario in ('base', 'latency6', 'double_cost', 'depth25', 'combined'):
                if rule == 'renewable_lease':
                    path = ROOT / split / f'{scenario}.npz'
                    z = np.load(path, allow_pickle=False)
                    checkpoint = json.loads((ROOT / split / f'{scenario}.COMPLETE.json').read_text())
                    assert checkpoint['result_hash'] == digest(path)
                    p, c, a = (z[k] for k in ('pnl', 'cost', 'actions'))
                    # Count (t-60,t] independently, including prior-round actions.
                    counts = z['total_action_ticks'].reshape(120, -1)
                    rolling = np.lib.stride_tricks.sliding_window_view(
                        np.pad(counts, ((0, 0), (29, 0))), 30, axis=1).sum(axis=-1)
                    assert np.array_equal(rolling.max(axis=1), z['max_rolling_actions'])
                    assert rolling.max() <= 60
                    assert np.array_equal(z['action_ticks'].sum(axis=(1, 2)), a)
                    assert not z['positions'].any() and not z['pending'].any()
                    assert not z['final_positions_by_round'].any()
                    assert z['actual_flat_times'].max() <= 700
                    assert np.allclose(z['attribution'].sum(axis=1), p)
                    assert np.allclose(z['by_round'].sum(axis=1), p)
                elif split == 'inner':
                    z = np.load(OLD / 'turnover/inner' / rule / f'{scenario}.npz')
                    p, c, a = (z[k] for k in ('pnl', 'cost', 'actions'))
                else:
                    with (ROOT / 'recovered/paired_per_season.csv').open() as f:
                        raw = sorted((r for r in csv.DictReader(f) if r['scenario'] == scenario),
                                     key=lambda r: int(r['season_id']))
                    assert [int(r['season_id']) for r in raw] == list(range(121, 241))
                    prefix = 'control' if rule == 'control' else 'candidate'
                    p, c, a = (np.array([float(r[f'{prefix}_{k}']) for r in raw])
                               for k in ('pnl', 'cost', 'actions'))
                rows.append(dict(split=split, rule=rule, scenario=scenario, **basic(p, c, a)))

        with (ROOT / split / 'trades.csv').open() as f:
            trades = list(csv.DictReader(f))
        z = np.load(ROOT / split / 'base.npz')
        net, fees = np.zeros(120), np.zeros(120)
        durations = []
        d = np.load(PROJECT / 'research_v4/development.npz', allow_pickle=False)
        ids = d['season_ids']
        assert np.array_equal(ids, np.arange(121, 601))
        market = d['market']
        for t in trades:
            i, sid, r = int(t['season_index']), int(t['season_id']), int(t['round']) - 1
            assert sid == z['season_ids'][i]
            j, q = SYMBOLS.index(t['symbol']), int(t['quantity'])
            entry, exit_ = int(t['entry_time']), int(t['exit_time'])
            pe, px = market[sid - 121, r, entry // 2, j], market[sid - 121, r, exit_ // 2, j]
            fee = abs(q) * ((pe + px) * .0025 + .04)
            pnl = q * (px - pe) - fee
            assert abs(q) == 50
            assert entry - int(t['decision_time']) == 2
            assert exit_ - entry == int(t['holding_seconds'])
            assert np.isclose(fee, float(t['cost'])) and np.isclose(pnl, float(t['pnl']))
            net[i] += pnl
            fees[i] += fee
            durations.append(exit_ - entry)
        assert np.allclose(net, z['pnl']) and np.allclose(fees, z['cost'])
        hold = np.array(durations)
        holdings[split] = dict(trades=len(hold), mean=float(hold.mean()),
            median=float(np.median(hold)), p90=float(np.quantile(hold, .9)),
            p95=float(np.quantile(hold, .95)), max=int(hold.max()),
            fraction_over120=float(np.mean(hold > 120)),
            latest_flat=int(z['actual_flat_times'].max()))
        audit[split] = dict(baseline_trades_reconstructed=len(trades),
            all_five_scenario_rolling_budgets_and_flatness='passed',
            fees_and_pnl_from_arrival_prices='passed',
            symbol_and_round_attribution='passed', holdings=holdings[split])
    write_json(ROOT / 'comparison.json', rows)
    write_json(ROOT / 'accounting_audit.json', dict(status='passed', results=audit))
    with (ROOT / 'comparison.csv').open('w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)

    out = ['# Event policy results — V5', '',
           'All amounts below are USD per whole three-round season. Each row has n=120.',
           'Primary objective: arithmetic mean net terminal PnL. Results are standalone.', '',
           '**Correction:** old turnover validation was already COMPLETE at 13:36:49 UTC.',
           'REPORT_V4.md described an earlier checkpoint. Its old inner grid and validation',
           'were reused, not rerun. Recovered files supply the previously omitted win rates.', '',
           '## Protocol and selection', '',
           'Exactly one new candidate was declared: renewable_lease removes the120s continuous',
           'holding cap while retaining the60s fresh-forecast lease, old gate and all other',
           'forecast/execution settings. Inner241–360 uses saved fit361–600 forecasts.',
           'Baseline mean selected renewable_lease, frozen before the diagnostic. Archived',
           'refit241–600 predictions were reused for121–240 exactly once per original scenario.',
           'No new model fit, validation retuning or access to1–120 occurred. These previously',
           'observed diagnostic seasons are retrospective and are not a fresh holdout.', '',
           '## Outcomes', '',
           'Baseline:25bps + USD0.02/share/side,2s latency,50-share depth. Latency6 changes',
           'latency only; double_cost uses50bps+USD0.04; depth25 halves depth; combined uses',
           '6s latency,50bps+USD0.04 plus10bps adverse/side (not depth25). The eligibility',
           'gate remains at baseline costs for every scenario.', '']
    for split in ('inner', 'validation'):
        out += [f'### {split}: ' + ('241–360' if split == 'inner' else '121–240'), '',
                '| Policy | Scenario | Mean | Median | Worst | p05 | Win | Cost | Actions |',
                '|---|---|---:|---:|---:|---:|---:|---:|---:|']
        for x in (x for x in rows if x['split'] == split):
            out.append(f"| {x['rule']} | {x['scenario']} | {x['mean']:.2f} | {x['median']:.2f} | "
                       f"{x['worst']:.2f} | {x['p05']:.2f} | {x['win_rate']:.2%} | "
                       f"{x['mean_cost']:.2f} | {x['mean_actions']:.2f} |")
        out.append('')
    out += ['## Why PnL changed; retained negatives', '',
        'New versus old120 baseline inner gain: USD440.45 (USD295.17 gross capture +',
        'USD145.29 lower costs). Diagnostic gain: USD454.97 (USD305.66 gross capture +',
        'USD149.31 lower costs). Diagnostic paired SE is USD32.18;114/120 differences',
        'are positive. These paired summaries are descriptive after extensive dataset reuse.', '',
        'The old120 combined stress is negative: inner USD-375.98 and diagnostic USD-27.19;',
        'fixed60 control is worse. New combined means are positive (inner USD274.64,',
        'diagnostic USD602.63), satisfying the declared positive-mean stress condition.',
        'This is not execution certification: new combined worst seasons are USD-4702.53',
        'and USD-4269.97, with worst5%means USD-3602.70 and USD-3355.18. Even baseline',
        'diagnostic worst season worsened from old120 USD-2346.70 to new USD-2508.88.', '',
        '## Holding and execution audit', '',
        '| Split | Trades | Mean hold | Median | p90 | p95 | Max | Over120s | Latest flat |',
        '|---|---:|---:|---:|---:|---:|---:|---:|---:|']
    for split, h in holdings.items():
        out.append(f"| {split} | {h['trades']} | {h['mean']:.2f}s | {h['median']:.0f}s | "
                   f"{h['p90']:.0f}s | {h['p95']:.0f}s | {h['max']}s | "
                   f"{h['fraction_over120']:.2%} | {h['latest_flat']}s |")
    out += ['', 'Old120 retains its120s hard filled-hold limit. New continuous holds require',
        'repeated fresh eligible renewals. Longer occupancy is the economic tradeoff.',
        'Same-side renewals do not trade; reversals pay for a completed close and separate',
        'new entry. Pending orders are irrevocable. No later forecast changes an earlier',
        'decision. Ten synthetic/parity checks and independent saved-ledger accounting',
        'passed. Every saved scenario is flat by596, below the shared adapter deadline700.', '',
        '## Parent integration', '',
        'Use the frozen renewable_lease rule explicitly with replay_shared, passing actual',
        'entry_not_before[n,3] and external_action_ticks[n,3,390]. The adapter counts all',
        'prior route actions in one real rolling minute across contiguous rounds, reserves',
        'event exits and is completely flat by700. The per-tick EventPolicy returns causal',
        'targets, expiries and pending-side/exit reservations. See INTERFACE.md.', '',
        'Frozen121–240 forecasts and code/results are packaged together. Parent owns',
        'formation timing, common-account replay and separate final-report trading from740.',
        '**Do not add these standalone profits to v3.** No common-account uplift is claimed.', '',
        'Usage and restart accounting are recorded in USAGE.json; source/results hashes are',
        'recorded in MANIFEST.json. Original and new completion markers remain preserved.']
    (ROOT / 'REPORT.md').write_text('\n'.join(out) + '\n')
    print(json.dumps(dict(status='passed', holding=holdings), indent=2))


if __name__ == '__main__':
    main()
