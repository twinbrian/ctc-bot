# Event policy results — V5

All amounts below are USD per whole three-round season. Each row has n=120.
Primary objective: arithmetic mean net terminal PnL. Results are standalone.

**Correction:** old turnover validation was already COMPLETE at 13:36:49 UTC.
REPORT_V4.md described an earlier checkpoint. Its old inner grid and validation
were reused, not rerun. Recovered files supply the previously omitted win rates.

## Protocol and selection

Exactly one new candidate was declared: renewable_lease removes the120s continuous
holding cap while retaining the60s fresh-forecast lease, old gate and all other
forecast/execution settings. Inner241–360 uses saved fit361–600 forecasts.
Baseline mean selected renewable_lease, frozen before the diagnostic. Archived
refit241–600 predictions were reused for121–240 exactly once per original scenario.
No new model fit, validation retuning or access to1–120 occurred. These previously
observed diagnostic seasons are retrospective and are not a fresh holdout.

## Outcomes

Baseline:25bps + USD0.02/share/side,2s latency,50-share depth. Latency6 changes
latency only; double_cost uses50bps+USD0.04; depth25 halves depth; combined uses
6s latency,50bps+USD0.04 plus10bps adverse/side (not depth25). The eligibility
gate remains at baseline costs for every scenario.

### inner: 241–360

| Policy | Scenario | Mean | Median | Worst | p05 | Win | Cost | Actions |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| control | base | 1482.44 | 1256.43 | -1916.87 | -483.95 | 85.83% | 1267.59 | 83.03 |
| control | latency6 | 794.28 | 881.00 | -2590.37 | -1334.56 | 70.00% | 1266.87 | 83.03 |
| control | double_cost | 214.85 | 62.17 | -2694.23 | -1916.36 | 53.33% | 2535.19 | 83.03 |
| control | depth25 | 741.22 | 628.22 | -958.43 | -241.97 | 85.83% | 633.80 | 83.03 |
| control | combined | -946.12 | -986.67 | -4361.81 | -3140.43 | 25.83% | 3007.27 | 83.03 |
| target_expiry | base | 2363.00 | 2099.09 | -1925.57 | -92.53 | 94.17% | 1127.93 | 70.62 |
| target_expiry | latency6 | 1166.48 | 1203.36 | -2748.27 | -1857.98 | 69.17% | 1121.84 | 70.28 |
| target_expiry | double_cost | 1235.07 | 1058.55 | -3031.15 | -1286.76 | 75.83% | 2255.86 | 70.62 |
| target_expiry | depth25 | 1181.50 | 1049.55 | -962.79 | -46.26 | 94.17% | 563.97 | 70.62 |
| target_expiry | combined | -375.98 | -347.39 | -4837.47 | -3325.35 | 44.17% | 2664.31 | 70.28 |
| renewable_lease | base | 2803.45 | 2530.51 | -1916.93 | 176.36 | 96.67% | 982.65 | 61.58 |
| renewable_lease | latency6 | 1625.46 | 1694.02 | -2748.27 | -1484.48 | 74.17% | 982.46 | 61.58 |
| renewable_lease | double_cost | 1820.81 | 1658.53 | -2603.37 | -976.86 | 86.67% | 1965.29 | 61.58 |
| renewable_lease | depth25 | 1401.73 | 1265.26 | -958.47 | 88.18 | 96.67% | 491.32 | 61.58 |
| renewable_lease | combined | 274.64 | 372.71 | -4702.53 | -2837.86 | 56.67% | 2333.28 | 61.58 |

### validation: 121–240

| Policy | Scenario | Mean | Median | Worst | p05 | Win | Cost | Actions |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| control | base | 1595.08 | 1551.39 | -2566.96 | -821.73 | 85.00% | 1212.22 | 80.28 |
| control | latency6 | 886.31 | 883.40 | -4278.66 | -1516.53 | 72.50% | 1211.50 | 80.28 |
| control | double_cost | 382.86 | 309.81 | -3961.06 | -1938.35 | 60.00% | 2424.44 | 80.28 |
| control | depth25 | 797.54 | 775.69 | -1283.48 | -410.86 | 85.00% | 606.11 | 80.28 |
| control | combined | -777.67 | -730.37 | -6476.59 | -3365.04 | 31.67% | 2875.48 | 80.28 |
| target_expiry | base | 2500.92 | 2396.53 | -2346.70 | -127.92 | 94.17% | 1073.67 | 67.63 |
| target_expiry | latency6 | 1441.02 | 1382.69 | -3148.48 | -1347.03 | 79.17% | 1067.96 | 67.32 |
| target_expiry | double_cost | 1427.26 | 1379.31 | -3231.39 | -1167.59 | 77.50% | 2147.33 | 67.63 |
| target_expiry | depth25 | 1250.46 | 1198.26 | -1173.35 | -63.96 | 94.17% | 536.83 | 67.63 |
| target_expiry | combined | -27.19 | -27.36 | -4368.46 | -3006.52 | 47.50% | 2536.17 | 67.32 |
| renewable_lease | base | 2955.90 | 2875.46 | -2508.88 | 28.28 | 95.00% | 924.35 | 58.23 |
| renewable_lease | latency6 | 1871.54 | 1908.88 | -3208.28 | -1319.27 | 81.67% | 922.99 | 58.20 |
| renewable_lease | double_cost | 2031.54 | 2024.83 | -3279.27 | -773.75 | 85.00% | 1848.71 | 58.23 |
| renewable_lease | depth25 | 1477.95 | 1437.73 | -1254.44 | 14.14 | 95.00% | 462.18 | 58.23 |
| renewable_lease | combined | 602.63 | 662.98 | -4269.97 | -2803.61 | 61.67% | 2191.89 | 58.20 |

## Why PnL changed; retained negatives

New versus old120 baseline inner gain: USD440.45 (USD295.17 gross capture +
USD145.29 lower costs). Diagnostic gain: USD454.97 (USD305.66 gross capture +
USD149.31 lower costs). Diagnostic paired SE is USD32.18;114/120 differences
are positive. These paired summaries are descriptive after extensive dataset reuse.

The old120 combined stress is negative: inner USD-375.98 and diagnostic USD-27.19;
fixed60 control is worse. New combined means are positive (inner USD274.64,
diagnostic USD602.63), satisfying the declared positive-mean stress condition.
This is not execution certification: new combined worst seasons are USD-4702.53
and USD-4269.97, with worst5%means USD-3602.70 and USD-3355.18. Even baseline
diagnostic worst season worsened from old120 USD-2346.70 to new USD-2508.88.

## Holding and execution audit

| Split | Trades | Mean hold | Median | p90 | p95 | Max | Over120s | Latest flat |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| inner | 3695 | 107.33s | 80s | 208s | 248s | 460s | 31.56% | 592s |
| validation | 3494 | 110.06s | 90s | 210s | 250s | 470s | 33.29% | 592s |

Old120 retains its120s hard filled-hold limit. New continuous holds require
repeated fresh eligible renewals. Longer occupancy is the economic tradeoff.
Same-side renewals do not trade; reversals pay for a completed close and separate
new entry. Pending orders are irrevocable. No later forecast changes an earlier
decision. Ten synthetic/parity checks and independent saved-ledger accounting
passed. Every saved scenario is flat by596, below the shared adapter deadline700.

## Parent integration

Use the frozen renewable_lease rule explicitly with replay_shared, passing actual
entry_not_before[n,3] and external_action_ticks[n,3,390]. The adapter counts all
prior route actions in one real rolling minute across contiguous rounds, reserves
event exits and is completely flat by700. The per-tick EventPolicy returns causal
targets, expiries and pending-side/exit reservations. See INTERFACE.md.

Frozen121–240 forecasts and code/results are packaged together. Parent owns
formation timing, common-account replay and separate final-report trading from740.
**Do not add these standalone profits to v3.** No common-account uplift is claimed.

Usage and restart accounting are recorded in USAGE.json; source/results hashes are
recorded in MANIFEST.json. Original and new completion markers remain preserved.
