# V5 event follow-up: one renewable-forecast-lease policy

Declared before new scoring, 2026-10-19. Primary selection objective is arithmetic
mean terminal net USD PnL per whole season. No risk-adjusted replacement objective.

## Recovery first

The attached archive supersedes REPORT_V4.md's incomplete-turnover statement:
turnover/frozen.json and validation/COMPLETE.json record selection at 13:36:37 UTC
and completed validation at 13:36:49 UTC. Their source and prediction hashes match.
Reuse these results; neither the old inner grid nor the old validation is rerun.
The selected old policy is target_expiry with its existing 120-second filled-hold
limit, unchanged. Its validation mean is USD 2,500.92, versus USD 1,595.08 fixed60;
the original combined stress remains negative at USD -27.19.

## Exactly one new candidate: renewable_lease

Motivation: target_expiry improved gross capture as well as turnover, yet still
forced roughly 12 supported episodes per season to close at its 120-second cap.
Test whether a genuine new forecast can justify retaining these episodes, rather
than charging a close/reopen merely because of position age. This is one structural
policy change, not a grid of holding limits or thresholds.

Everything in target_expiry is fixed except the 120-second continuous-hold cap.
Remove that cap for renewable_lease. Keep the hard end-of-round liquidation deadline.
Every retained position must still have an unexpired eligible forecast lease:
same-direction events pass the original two-leg cost-plus-USD0.15 gate and renew
expiry only to that event's own timestamp + 60 seconds. No new event means no
renewal. An expired lease becomes flat intent. Opposite eligible targets compete
in the original top-two new-risk ranking and require charged close-to-zero and
separate opposite entry, with irrevocable pending orders. No hindsight merging,
free cancellations, or artificial holding-clock resets. Forecasts only exist on
the original motion-event grid 120..530; therefore all natural leases end by590.

The new policy can exceed120s of continuous filled exposure. Report its observed
holding distribution and resulting occupancy/costs explicitly. The old policy's
120s limit remains intact. Flat fixed60 and old target_expiry are fixed comparators,
not new selectable families. No new forecasts, features, gate, lot, event grid,
horizon, or per-symbol thresholds are fitted.

## Data, selection, and one-time diagnostic

Reuse archived motion_h60 predictions fit361–600 on inner241–360 (120 seasons).
Score the sole new candidate in all five original scenarios. Compare against saved
old per-season results. Select by baseline mean only; an exact tie retains old
target_expiry. Save all negatives. Freeze policy and code before any new replay of
121–240. Run the frozen new candidate exactly once on saved refit241–600 forecasts
for diagnostic121–240, even if it loses inner selection, to report the predeclared
single candidate; label its replacement eligibility accordingly. This is explicit
further reuse of previously observed data, not a fresh holdout. Do not retune after
this diagnostic. Never read seasons1–120.

Scenarios: baseline latency2s,25bps+USD0.02/share/side,depth50; latency6s;
double_cost50bps+USD0.04; depth25; combined latency6s,50bps+USD0.04,+10bps
adverse/side. Gate stays at baseline in stresses. A positive combined-stress mean
is required for an execution-robust label, separate from the baseline PnL ranking.

## Execution and delivery

One rolling60-action real-minute budget across rounds; <=50 market shares/symbol/
2s; published limits with separate buy/sell pending reservations; reserve exits;
actual filled zero inventory at each round end. No passive fills or conversions.
Build a causal per-tick callable taking current forecast/event/price arrays and
actual held/pending account state, returning target intents, expiries and
reservations. It must not infer fills from targets or inspect future snapshots.
Parent owns formation timing and the combined-account executor. Standalone PnL
must not be added to v3. Prefix invariance, charged reversals, hard120 old policy,
renewable expiry, same-price fees and constrained accounting receive synthetic tests.

Use tmux, atomic checkpoints, <=2 processes and one BLAS/OMP thread; no descendants
or paid resources. Local model-cost baseline before session is USD0; startup
snapshot USD0.4440925 is included, not subtracted. Stop new research at USD60 and
all work by USD75 estimate, with a five-hour active-work cap excluding restarts.
