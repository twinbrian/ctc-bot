"""Strict parent boundary around unchanged frozen policy and replay.

External counts belong to a flat predecessor, not a concurrent sleeve. Parent
establishes actual gross pending flatness and depth cooldown before readiness.
"""

import numpy as np

from event_policy import EventPolicy, LIMITS
from replay import replay_shared as _replay_shared


def integer_array(values, shape, name, maximum=None):
    x = np.asarray(values)
    if (x.shape != shape or x.dtype.kind not in "iuf" or not np.isfinite(x).all()
            or np.any(x != np.floor(x)) or np.any(x < 0)
            or (maximum is not None and np.any(x > maximum))):
        raise ValueError(f"{name} must be finite nonnegative integers, shape={shape}")
    return x.astype(np.int64)


def replay_shared(market, prediction, rule="renewable_lease", *, entry_not_before,
                  external_action_ticks, **scenario):
    """Full chronological three-round call; no independent-round/prior-ledger API.

    Input validation can reject a bad supplied schedule upfront. The frozen
    executor still reads only current/past external counts to decide orders.
    All own/event and total/external outputs retain their frozen meanings.
    """
    n = len(market)
    ext = integer_array(external_action_ticks, (n, 3, 390), "external_action_ticks", 60)
    ready = np.asarray(entry_not_before)
    if (ready.shape != (n, 3) or ready.dtype.kind not in "iuf"
            or not np.isfinite(ready).all() or np.any(ready < 0)):
        raise ValueError("entry_not_before must be finite nonnegative seconds, shape[n,3]")
    if np.any(ext[np.arange(390)[None, None, :] * 2 >= ready[:, :, None]]):
        raise ValueError("External predecessor actions must end strictly before readiness")
    ledger = ext.reshape(n, -1)
    rolling = np.lib.stride_tricks.sliding_window_view(
        np.pad(ledger, ((0, 0), (29, 0))), 30, axis=1).sum(axis=-1)
    if np.any(rolling > 60):
        raise ValueError("External schedule violates rolling60 budget")
    result = _replay_shared(market, prediction, rule, entry_not_before=ready,
                            external_action_ticks=ext, **scenario)
    assert np.all(result["max_rolling_actions"] >= rolling.max(axis=1))
    assert not result["positions"].any() and not result["pending"].any()
    return result


class CausalEventPolicy(EventPolicy):
    """Current-snapshot callable with strict one-pending-order episode checks."""

    def step(self, time, delta, source, price, q, pending_buy, pending_sell,
             entry_submit_time, *, latency=2, flat_by=700, enabled=True):
        shape = self.target.shape
        buy = integer_array(pending_buy, shape, "pending_buy")
        sell = integer_array(pending_sell, shape, "pending_sell")
        q = np.asarray(q)
        if (q.shape != shape or q.dtype.kind not in "iuf" or not np.isfinite(q).all()
                or np.any(q != np.floor(q))):
            raise ValueError("Held shares must be finite integers")
        if np.any((buy != 0) & (sell != 0)):
            raise ValueError("Opposing pending sides violate the one-pending-order contract")
        if np.any(q + buy > LIMITS) or np.any(q - sell < -LIMITS):
            raise ValueError("Gross pending-side reservations exceed published limits")
        if np.any(np.maximum(np.abs(q), np.abs(q + buy - sell)) > self.lot):
            raise ValueError("State is not a one-lot event-owned episode")
        if not np.isfinite(time) or time < 0 or time % 2:
            raise ValueError("Time must be nonnegative even real seconds")
        if not np.isfinite(latency) or latency < 2 or latency % 2:
            raise ValueError("Historical latency must be a positive two-second-grid interval")
        return super().step(time, delta, source, price, q, buy, sell, entry_submit_time,
                            latency=latency, flat_by=flat_by, enabled=enabled)
