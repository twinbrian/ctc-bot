# Parent integration interface

`event_policy.py` and `replay.py` depend only on NumPy. Symbol order is exported as
`SYMBOLS`; published limits are exported as `LIMITS`. All times are real seconds.

## Shared-account replay

```python
from integration import replay_shared

result = replay_shared(
    market, prediction, rule="renewable_lease",  # frozen inner winner
    entry_not_before=route_flat_time,          # [n,3], real seconds
    external_action_ticks=route_actions,       # [n,3,390], actual counts
    latency=2, cost_bps=25, fixed_cost=.02, depth=50,
)
```

`market` and `prediction['delta']` have shape `[n,3,390,12]`;
`prediction['source']` is `[n,3,390]`. Tick index `i` is real second `2*i`.
Use the matched frozen forecasts in season order121..240 for the diagnostic,
or241..360 for inner. Neither season IDs nor future truth are trading inputs.

The parent owns formation and its causal handoff timestamp. Formation holdings
and pending orders must both be flat before event entry is enabled. Earlier
events are discarded, not accumulated for entry at handoff. Other-engine action
counts enter the single rolling60-action budget only at their actual timestamps.
Round clocks are conservatively contiguous780-second intervals. Event entries
reserve one additional exit action. External orders that consume this reserved
capacity raise an assertion instead of silently creating an infeasible schedule.

The adapter forces actual zero event holdings and pending orders by second700.
Final-report trading can begin at740 under the same account's action history.
Feed the aggregate action history to any subsequent engine. Do not double-count
`external_action_ticks` when adding event `action_ticks` to the parent's schedule.

Returned keys:
- `pnl`, `cost`, `turnover_shares`, `actions`: event-only season monetary/activity
  totals, with all market legs charged at arrival-time marks.
- `action_ticks`: event submissions `[n,3,390]`; `total_action_ticks` includes the
  supplied external submissions. `max_rolling_actions` measures the total.
- `positions`, `pending`: terminal event inventory, both zero.
- `final_positions_by_round`: `[n,3,12]`, zero each round.
- `actual_flat_times`: `[n,3]`, last event exit fill time; zero means no event
  position was opened in that round.
- `attribution`: net event USD PnL per symbol `[n,12]`; `by_round`: net USD `[n,3]`.
- `trades`: tuples `(season_index, round_1based, symbol, signed_quantity,
  decision_time, entry_time, exit_time, holding_seconds, entry_price, exit_price,
  both_leg_cost, net_pnl)`.
- With `audit=True`: actual order tuples, inventory, target and expiry tick arrays.

The standalone `simulate` defaults to round end778 to preserve the original
research. `replay_shared` is a separate adapter with fixed700 cutoff. The historical
motion sources stop at530, so ordinary leases already end by590, filling by592
(or596 at latency6). The700 boundary additionally protects nonstandard input.

## Per-tick callable for the parent's own executor

Instantiate `CausalEventPolicy(n, rule='renewable_lease', depth=50)` from
`integration.py` once per round. It wraps the unchanged frozen `EventPolicy`. Call
`step(time, delta, source, price, q, pending_buy, pending_sell, entry_submit_time,
latency=2, flat_by=700, enabled=True)` after processing actual current fills.
`delta`, `price`, `q`, each pending-side quantity and `entry_submit_time` are
`[n,12]`; source is `[n]`; enabled broadcasts to `[n,12]`. Both pending-side arrays
use nonnegative quantities. Current time must strictly increase within the round.

The returned `target` is logical signed intent, not a fill. `expiry` is the exit
**submission** deadline, capped by the old120s episode deadline where applicable.
`entry_submit_time` is the actual first order submission in a continuous episode;
preserve it through pending entry/exit and same-side renewals; clear only when flat.
Constant scenario latency makes the old120s submission clock an exact120s maximum
filled holding period. Variable-latency/partial-fill live execution needs its own
acknowledgment-aware deadline handling; this is a historical research adapter.

Reversals require a charged close-to-zero fill and a separate opposite entry.
Do not cancel or net away pending orders. This replay allows one pending order
per symbol and one50-share lot; the parent must enforce shared limits/depth too.
Return reservations `reserved_long`/`reserved_short` bound each pending side
separately; `intent_reserved_long`/`intent_reserved_short` additionally represent
the requested target. `exit_actions_reserved` covers future exits of current
projected event exposure. Reservations are not extra exchange capacity.

For a standalone executor, enforce at most one pending order per symbol (the
adapter does). The two side-reservation bounds remain conservative for opposing
pending orders, but the scalar exit-action count assumes this one-pending-order
contract. A more general executor must reserve exits for every possible fill
endpoint rather than relying on net projected exposure.

Source>0 is required for a fresh forecast; passing a later snapshot at an earlier
timestamp is not allowed. No future-price array is accepted by the policy callable.
Standalone event profit is never an additive claim against v3. Parent owns the
combined-account replay, formation timing and final-report engine.

## Root execution-contract addendum

The strict `integration.py` wrapper rejects nonfinite/fractional/negative/oversize
counts, rolling-infeasible histories and predecessor actions at/after readiness,
including when the event engine is idle. `entry_not_before` must include actual
formation gross pending flatness and depth cooldown. The strict policy checks
gross pending-side capacity and rejects opposing pending sides: its exit-action
reservation contract requires one pending order per symbol. Same-side pending
orders cannot be duplicated or netted away by the frozen executor.

This is a complete three-round chronological replay starting at season time zero.
It has no one-round/prior-history API; do not repeatedly reset it per round and
add maxima. External predecessor count history and owned event counts are carried
continuously across780-second rounds with window(now-60,now]. Final740 trading
must receive aggregate history from the parent. The externally supplied root
patch was reviewed, not applied to root files in this worker. Frozen standalone
sources/results remained intact; only synthetic integration checks were added.

`predictions_241_360.npz` is also included for parent inner integration. It is the
byte-identical saved fit361–600 prediction checkpoint, not an inner-data fit.

## Packaged forecasts

`predictions_121_240.npz` is a byte-identical copy of the old frozen diagnostic
forecast file. It contains `delta`, `source`, `regime`, and `times`; load with
`dict(np.load(path, allow_pickle=False))`. `prediction_manifest.json` specifies
season and symbol order, shapes, reuse/training provenance and SHA-256. Predictions
are unchanged, not new fits. The callable reads only the current slice; `regime`
is not used by the event policy.
