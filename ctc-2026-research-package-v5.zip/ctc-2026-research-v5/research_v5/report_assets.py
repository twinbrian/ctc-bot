"""Render frozen results and export tables; no fitting, selection or backtesting."""

import csv
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "research_v5/report"


def load(path):
    return json.loads((ROOT / "research_v5" / path).read_text())


def main():
    OUT.mkdir(exist_ok=True)
    clock = {
        r["scenario"]: r
        for r in load("pooled_clock/pooled_metrics.json")
        if r["policy"] == "clock"
    }
    hgb = {r["scenario"]: r for r in load("pooled_conditional/pooled_metrics.json")}
    rows = []
    for policy, results in [("clock", clock), ("hgb", hgb)]:
        for scenario, row in results.items():
            rows.append(
                {
                    "policy": policy,
                    "scenario": scenario,
                    **{
                        k: row[k]
                        for k in [
                            "seasons",
                            "mean_usd",
                            "median_usd",
                            "minimum_usd",
                            "p05_usd",
                            "win_rate",
                            "mean_cost_usd",
                            "mean_actions",
                        ]
                    },
                }
            )
    with (OUT / "summary-v5.csv").open("w") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    matrices = load("execution_matrix/clock/metrics.json") + load(
        "execution_matrix/hgb/metrics.json"
    )
    with (OUT / "execution-matrix-v5.csv").open("w") as stream:
        keys = [k for k in matrices[0] if k != "conditional_mean_ci95_usd"]
        writer = csv.DictWriter(stream, fieldnames=keys, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(matrices)
    with (OUT / "stability-v5.csv").open("w") as stream:
        stability = load("stability_execution/metrics.json")
        keys = [k for k in stability[0] if k != "conditional_mean_ci95_usd"]
        writer = csv.DictWriter(stream, fieldnames=keys, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(stability)
    sources = {
        "matched_10s": "pooled_clock/pooled_control_base.npz",
        "clock": "pooled_clock/pooled_clock_base.npz",
        "hgb": "pooled_conditional/pooled_base.npz",
    }
    pnl = {}
    for name, path in sources.items():
        d = np.load(ROOT / "research_v5" / path)
        order = np.argsort(d["season_ids"])
        np.testing.assert_array_equal(d["season_ids"][order], np.arange(1, 601))
        pnl[name] = d["pnl"][order]
    with (OUT / "season-pnl-v5.csv").open("w") as stream:
        writer = csv.writer(stream)
        writer.writerow(["season_id"] + [name + "_net_pnl_usd" for name in pnl])
        writer.writerows(
            (i + 1, *(values[i] for values in pnl.values())) for i in range(600)
        )
    plt.rcParams.update(
        {
            "font.family": "DejaVu Sans",
            "font.size": 10,
            "axes.spines.top": False,
            "axes.spines.right": False,
            "axes.titleweight": "bold",
        }
    )
    blue, green, grey = "#27658A", "#168572", "#9AA5AD"
    fig, axes = plt.subplots(2, 2, figsize=(12, 8.4), layout="constrained")
    ax = axes[0, 0]
    x = np.arange(3)
    means = [pnl[k].mean() / 1000 for k in sources]
    bars = ax.bar(x, means, color=[grey, blue, green], width=0.6)
    ax.bar_label(bars, fmt="%.2f", padding=4)
    ax.set(xticks=x, xticklabels=["Old 10s tail", "Scheduled", "Weather HGB"])
    ax.set_ylim(0, 23)
    ax.set_ylabel("Mean net PnL (thousand USD)")
    ax.set_title("The holding horizon drives the gain", loc="left")
    ax = axes[0, 1]
    for name, color, label in [
        ("matched_10s", grey, "Old 10s tail"),
        ("clock", blue, "Scheduled"),
        ("hgb", green, "Weather HGB"),
    ]:
        ax.plot(
            np.sort(pnl[name]) / 1000, np.arange(1, 601) / 6, color=color, label=label
        )
    ax.axvline(0, color="#B2B9BD", lw=1)
    ax.set(xlabel="Season net PnL (thousand USD)", ylabel="Cumulative seasons (%)")
    ax.set_title("Higher average; losses still occur", loc="left")
    ax.legend(fontsize=9, loc="lower right", frameon=False)
    ax = axes[1, 0]
    for scenario, color, label in [
        ("base", blue, "Baseline"),
        ("strict_combined", green, "Strict execution"),
    ]:
        values = {
            (r["label"], r["policy"]): r["mean_usd"]
            for r in stability
            if r["scenario"] == scenario and r["label"].startswith("B")
        }
        difference = [
            values[(f"B{i:02}", "hgb")] - values[(f"B{i:02}", "clock")]
            for i in range(1, 31)
        ]
        ax.plot(
            np.arange(1, 31), difference, ".-", ms=5, lw=0.8, color=color, label=label
        )
    ax.axhline(0, color="#777777", lw=1)
    ax.set(
        xlabel="Training bootstrap (original order)", ylabel="HGB minus scheduled (USD)"
    )
    ax.set_title("Weather uplift is not stable at baseline", loc="left")
    ax.legend(fontsize=9, loc="lower right", frameon=False)
    ax = axes[1, 1]
    scenarios = ["base", "50bps", "depth25", "strict_combined", "depth10"]
    labels = ["Baseline", "50bps", "25 depth", "Strict", "10 depth"]
    x = np.arange(len(scenarios))
    ax.bar(
        x - 0.18,
        [clock[s]["mean_usd"] / 1000 for s in scenarios],
        0.36,
        color=blue,
        label="Scheduled",
    )
    ax.bar(
        x + 0.18,
        [hgb[s]["mean_usd"] / 1000 for s in scenarios],
        0.36,
        color=green,
        label="Weather HGB",
    )
    ax.set(xticks=x, xticklabels=labels, ylabel="Mean net PnL (thousand USD)")
    ax.set_title("Execution costs matter materially", loc="left")
    ax.legend(fontsize=9, frameon=False)
    fig.suptitle("CTC 2026 • Frozen historical results", fontsize=17, fontweight="bold")
    fig.supxlabel(
        "600 previously researched seasons; hypothetical fills. Bootstrap panel reuses 120 evaluation seasons.",
        fontsize=9,
    )
    fig.savefig(OUT / "results-overview-v5.png", dpi=160, facecolor="white")
    plt.close(fig)

    curve = np.load(ROOT / "research_v5/reproduction/deployment_curve.npz")["curve"]
    fig, axes = plt.subplots(1, 2, figsize=(12, 4.3), layout="constrained")
    time = np.arange(390) * 2
    for ax, indices, title in zip(
        axes,
        [[0, 8, 10], [5, 6, 11]],
        ["Island / insurer basket: rise then fall", "Rebuilders: opposite broad drift"],
    ):
        for j, color in zip(indices, [blue, green, "#C98632"]):
            names = [
                "PORT",
                "ISLE",
                "AQUA",
                "GRID",
                "FERRY",
                "RECON",
                "MAT",
                "GEN",
                "HAVEN",
                "REIN",
                "ARCH",
                "REBLD",
            ]
            delta = (curve[:, :, j] - curve[:, :1, j]).mean(0)
            ax.plot(time, delta, color=color, label=names[j])
        ax.axvspan(20, 100, color=grey, alpha=0.17)
        ax.axvspan(180, 540, color=blue, alpha=0.08)
        for t in [60, 540, 740]:
            ax.axvline(t, color="#AAB1B5", ls="--", lw=0.7)
        ax.axhline(0, color="#AAB1B5", lw=0.8)
        ax.set(
            title=title,
            xlabel="Real seconds after open",
            ylabel="Mean quote change (USD/share)",
        )
        ax.legend(frameon=False, fontsize=9)
    fig.suptitle(
        "The economic signal is a scheduled reversal", fontsize=16, fontweight="bold"
    )
    fig.supxlabel(
        "Descriptive full-600 average, rounds averaged; not an evaluation input. Shading: acquisition/holding windows.",
        fontsize=9,
    )
    fig.savefig(OUT / "clock-drift-v5.png", dpi=160, facecolor="white")
    plt.close(fig)
    print("Frozen tables and figures written", OUT)


if __name__ == "__main__":
    main()
