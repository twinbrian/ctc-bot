# V5 research contract

New authorization: USD 400 additional estimated model cost and at most five hours
of active research. This run starts 2026-10-19 at approximately13:45 UTC. Downtime
is not research. Training/replay jobs run in tmux with atomic result checkpoints;
independent Inspect sessions isolate agent runtimes. No Ramp repo changes,
branches, commits or PRs. Use only external local scratch directories.

## Budget allocation

Parent baseline local reported cost: USD182.2370985. Parent allocation USD125,
stop new research by an increment of USD110. Three independent worker sessions
have USD75 maximum each, stop new research by USD60 each. Reserve USD50 of the
total authorization for measurement lag and delivery. These are model estimates,
not verified billed amounts. Each worker must establish its own cost baseline
(include its new-session startup cost), checkpoint usage regularly, and report
spend with results. No paid data/compute, extra workers or delegated descendants.

## Research protocol

The 600-season dataset has already informed earlier research. No fresh global
holdout exists. Use supplied development seasons121–600 only: fit361–600, inner
241–360, refit241–600 and frozen diagnostic validation121–240. Keep whole seasons
together. Previously seen validation is retrospective. Parent controls final
1–120 assessment. Do not identify replay seasons from dates, names or seeds.

Do not rerun completed v4 searches. Read REPORT_V4.md and relevant HANDOFF/PLAN
first. Declare finite new candidate families before scoring. Save all negative
results, freeze before validation, and do not retune on validation outcomes.

Primary objective is mean net terminal USD PnL subject to exchange constraints.
Report cost/latency/depth stresses separately, including negative results; do not
silently replace the objective with Sharpe or worst-case PnL. A fragile highest
baseline PnL is labeled conditional, not certified for live deployment. Compare
new engines inside an actual common account before claiming additive improvement.

Baseline execution:25bps+USD0.02/share/side,2s latency,50market shares/symbol/2s,
60actions/rolling real minute for one key, published limits including pending
orders. ETF conversions change inventory with zero cash, consume one action,
and market legs arrive separately and pay costs. No invented passive fills.
All observations must be available at decision time. Final labels are training
targets/evaluation only, never trading inputs. Announcement economics are not
present in history. No orderbook data means all fills remain hypothetical.

Report on meaningful milestones and approximately every15minutes of active work:
best completed comparable mean, median, worst, p05 or worst5%mean, win rate,
actions, costs and at least latency/cost/depth stresses; label the dataset split
and whether this is standalone or a combined account. Parent reports incumbent
USD11,100.59 until an appropriately evaluated successor exists.

Each worker uses at most2 CPU processes and one BLAS/OMP thread. Use atomic
completion markers so interrupted fits/experiments resume from saved outputs.
Return source+compactresults as attachments; keep bulky data local. Do not
archive a worker while its code/results are needed for recovery.
