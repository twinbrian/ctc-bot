"""Tmux-resident local budget/active-clock journal; never runs strategy searches.

Active time requires recent model progress or a registered live compute job.
Large monitor gaps are treated as downtime, not charged as continuous research.
The independent workers have separately bounded allocations in CONTRACT.md.
"""

import datetime as dt
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parent
STATE = ROOT / "run_state.json"


def atomic(path, value):
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(value, indent=2) + "\n")
    temp.replace(path)


def live_job():
    for file in (ROOT / "jobs").glob("*.running.json"):
        try:
            job = json.loads(file.read_text())
            os.kill(int(job["pid"]), 0)
            return True
        except (OSError, ValueError, KeyError):
            continue
    return False


def main():
    previous = time.time()
    last_progress = previous
    last_cost = None
    failures = 0
    while True:
        state = json.loads(STATE.read_text())
        if state["status"] != "active":
            return
        now = time.time()
        elapsed = now - previous
        record = {"utc": dt.datetime.now(dt.timezone.utc).isoformat()}
        try:
            result = subprocess.run(
                ["opencode", "stats", "--days", "0", "--cost", "--json"],
                text=True,
                capture_output=True,
                check=True,
                timeout=30,
            )
            cost = float(json.loads(result.stdout)["cost"])
            if last_cost is None or cost > last_cost:
                last_progress = now
            last_cost = cost
            record["parent_increment_usd"] = cost - state["parent_baseline_usd"]
            failures = 0
        except (subprocess.SubprocessError, ValueError, KeyError) as exc:
            failures += 1
            record["telemetry_error"] = type(exc).__name__
        active = elapsed <= 120 and (now - last_progress <= 180 or live_job())
        state["observed_active_seconds"] += elapsed if active else 0
        state["observed_idle_or_downtime_seconds"] += 0 if active else elapsed
        record["active_seconds"] = state["observed_active_seconds"]
        record["idle_or_downtime_seconds"] = state["observed_idle_or_downtime_seconds"]
        record["live_compute_job"] = live_job()
        stop = None
        if record.get("parent_increment_usd", 0) >= 110:
            stop = "Parent USD110 research allocation reached; reserve remains for delivery"
        if state["observed_active_seconds"] >= 18000:
            stop = "Five-hour observed-active research cap reached"
        if failures >= 3:
            stop = "Budget telemetry unavailable; stop new research until reconciled"
        if stop:
            state["status"] = "stop_requested"
            record["stop_reason"] = stop
            atomic(ROOT / "STOP.json", record)
            for file in (ROOT / "jobs").glob("*.running.json"):
                try:
                    os.kill(int(json.loads(file.read_text())["pid"]), 15)
                except (OSError, ValueError, KeyError):
                    pass
            subprocess.run(
                [
                    "opencode",
                    "api",
                    "post",
                    f"/api/session/{state['parent_opencode_session']}/interrupt",
                ],
                capture_output=True,
                timeout=20,
            )
        state["last_checkpoint_utc"] = record["utc"]
        state["last_parent_increment_usd"] = record.get("parent_increment_usd")
        atomic(STATE, state)
        with (ROOT / "budget_active_journal.jsonl").open("a") as handle:
            handle.write(json.dumps(record) + "\n")
        print(json.dumps(record), flush=True)
        if stop:
            return
        previous = now
        time.sleep(60)


if __name__ == "__main__":
    main()
