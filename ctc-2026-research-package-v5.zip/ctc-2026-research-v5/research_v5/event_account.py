"""Compose flat formation/event/final phases with a single chronological budget."""

import argparse
import json
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "research_v5/event"))
from integration import replay_shared

from etf_route_v3 import simulate_routes
from pnl_v2_simulator import simulate
from research_v4.lab import load_development, summarize_pnl
from research_v5.conditional_research import SCENARIOS
from research_v5.handoff_research import forecasts, npz, write_json


def run(market, truth, curve, final_fair, prediction, **settings):
    n = len(market)
    formation = simulate_routes(
        market,
        truth,
        curve,
        start=20,
        exit_at=100,
        fraction=1.0,
        audit=True,
        **settings,
    )
    # Formation ends early each round; subsequent events must end by700, so no
    # preceding-round event count can remain in a next-round formation window.
    assert np.max(formation["flat_times"]) < 700
    assert not formation["positions"].any()
    readiness = formation["flat_times"] + 2
    events = replay_shared(
        market,
        prediction,
        rule="renewable_lease",
        entry_not_before=readiness,
        external_action_ticks=formation["action_ticks"],
        **settings,
    )
    assert not events["positions"].any() and not events["pending"].any()
    assert np.max(events["actual_flat_times"]) <= 700
    assert not events["action_ticks"][:, :2, 350:].any()
    external = np.zeros((n, 3, 390), int)
    external[:, 2] = events["total_action_ticks"][:, 2]
    ready = np.zeros((n, 3), int)
    ready[:, 2] = 740
    final = simulate(
        market,
        truth,
        np.zeros((n, 3, 78, 12)),
        final_fair,
        curve,
        formation=None,
        ongoing=None,
        end_margin=0,
        external_actions=external,
        readiness_times=ready,
        round_indices=[2],
        prior_action_ticks=np.zeros((n, 30), int),
        audit=True,
        **settings,
    )
    components = [formation, events, final]
    out = {
        key: sum(x[key] for x in components)
        for key in [
            "pnl",
            "cost",
            "actions",
            "turnover_shares",
            "attribution",
            "action_ticks",
        ]
    }
    out["by_engine"] = np.stack([x["pnl"] for x in components], axis=1)
    out["positions"] = final["positions"]
    out["phase_flat_times"] = events["actual_flat_times"]
    out["entry_readiness"] = readiness
    out["max_position_fraction"] = np.maximum.reduce(
        [x["max_position_fraction"] for x in components]
    )
    cumulative = out["action_ticks"].reshape(n, -1).cumsum(1)
    lag = np.pad(cumulative[:, :-30], ((0, 0), (30, 0)))
    out["max_rolling_actions"] = (cumulative - lag).max(1)
    assert out["max_rolling_actions"].max() <= 60
    np.testing.assert_allclose(out["attribution"].sum(1), out["pnl"], atol=1e-8)
    np.testing.assert_allclose(out["by_engine"].sum(1), out["pnl"], atol=1e-8)
    np.testing.assert_array_equal(out["action_ticks"].sum((1, 2)), out["actions"])
    return out


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("stage", choices=["inner", "validation"])
    stage = parser.parse_args().stage
    out = ROOT / "research_v5/event_combined"
    out.mkdir(exist_ok=True)
    if (out / f"{stage}_COMPLETE.json").exists():
        return
    d = load_development()
    mask, pred = forecasts(d, stage)
    ids = pred["eval_seasons"]
    path = ROOT / f"research_v5/event/predictions_{ids.min()}_{ids.max()}.npz"
    events = dict(np.load(path))
    rows = []
    for scenario, settings in SCENARIOS.items():
        path = out / f"{stage}_{scenario}.npz"
        if path.exists():
            result = dict(np.load(path))
        else:
            result = run(
                d["market"][mask],
                d["settlement_truth"][mask],
                pred["curve"],
                pred["final_fair"],
                events,
                **settings,
            )
            npz(path, **result, season_ids=ids)
        row = {
            "stage": stage,
            "scenario": scenario,
            **summarize_pnl(result["pnl"]),
            "mean_cost_usd": float(result["cost"].mean()),
            "mean_actions": float(result["actions"].mean()),
            "mean_engine_pnl": result["by_engine"].mean(0).tolist(),
            "max_rolling_actions": int(result["max_rolling_actions"].max()),
        }
        rows.append(row)
        write_json(out / f"{stage}_metrics.json", rows)
        print(json.dumps(row), flush=True)
    write_json(
        out / f"{stage}_COMPLETE.json", {"seasons": ids.tolist(), "new_policy_count": 0}
    )


if __name__ == "__main__":
    main()
