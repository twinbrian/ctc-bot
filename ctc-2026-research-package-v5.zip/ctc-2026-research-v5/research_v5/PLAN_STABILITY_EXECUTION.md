# Forecast-refit stability: fixed common-account evaluation

No new policy choices or selection of bootstrap seeds. Evaluate all four supplied
forward-only panels and all30 resamples using baseline and strict combined
50bps+USD0.04/side/6s/25depth/10bps adverse. Forward panels fit all components only
on their stated earlier simulated seasons. All outcome data were previously
researched; forward-only fitting is not a fresh holdout.

Bootstrap inference isolates uncertainty in the active180-second forecast:
formation mean curve and final-value model stay fixed at their original361–600
fit; HGB and the clock's full12-symbol mean jump use each supplied whole-season
training resample. The clock jump is mean quotes542..552 minus mean quote180,
including ETF prices, matching the original clock benchmark. The HGB's ETF fair
is the coherent basket of stock fairs, as already frozen. No averaging of model
predictions into a new ensemble and no best-seed choice. Report every replicate
in original sample order, the distribution of mean PnL, paired increments and
counts of positive mean; these are refit-sensitivity results, not independent
future-return confidence intervals.
