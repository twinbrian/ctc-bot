# Exactly two conditional versions of the frozen clock-drift schedule

Declared after the eight clock schedules completed; this is a new, explicitly
adaptive research family, not fresh global out-of-sample evidence. No changes
are permitted after diagnostic outcomes for these conditional policies are read.

Keep formation20/100/full, active acquisition180–240, earliest exit540, full
published limits, fee-free ETF routing, actual shared action/depth history and
final740 unchanged. Replace only the active-phase expected price change.

1. Ridge: physical/guidance/quotes available at180, round one-hot, fixed ridge
   penalty0.10 times training rows, existing terminal research feature design.
2. HGB: same feature availability, one model per stock,100 iterations,7 leaves,
   min40 observations/leaf,l2=30,learning rate0.06, fixed seed2026.

Target is mean stock quote542,544,...,552 minus quote180. Train361–600 and select
one of these two or the existing unconditional clock policy on inner241–360
mean net account PnL. No sizing, timing, threshold or risk grid. Refit unchanged
models241–600 for diagnostic121–240. Parent opens diagnostic trading only after
inner freeze. Coherent ETF future fair value is the basket of stock forecasts;
ETF expected change subtracts its actually observed entry quote.

Both controls remain: matched old ten-second account and frozen clock account.
Baseline25bps+USD0.02/side,2s latency,50 shares/symbol/2s. Fixed separate stresses:
50bps,6s latency,25-share depth; combined50bps/6s/25shares; plus strict combined
50bps+USD0.04/side,6s,25shares,10bps adverse. Policies are selected by inner mean,
not stress or validation maximum. Retain all negative outcomes.

Implementation provenance: the worker froze `random_state=0` before fitting,
where this parent plan wrote2026. Retain the actually frozen seed0, with no seed
search or retrospective refit. All other requested HGB settings match. The model
uses no early stopping or row subsampling; record this discrepancy explicitly.

## Broader fixed-policy replay

The inner-only gate selected HGB (mean USD19,450.03 versus USD19,423.69 clock).
The diagnostic has completed without further changes. Refit that same frozen
HGB specification on each existing360-season fold and score its disjoint120
outer seasons. Keep all600 previously researched seasons and post-selection
qualification explicit. Compare to the saved frozen-clock and matched old-tail
accounts. Use the same nine scenarios as PLAN_POOLED; no new models or choices.
