"""Run a checkpointed research command inside tmux and publish a completion marker."""

import argparse
import datetime as dt
import json
from pathlib import Path
import subprocess


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("name")
    parser.add_argument("command", nargs=argparse.REMAINDER)
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    jobs = root / "jobs"
    jobs.mkdir(exist_ok=True)
    complete = jobs / f"{args.name}.complete.json"
    if complete.exists():
        print(f"Already completed: {args.name}; not rerunning")
        return
    if (root / "STOP.json").exists():
        raise SystemExit("Research stop requested")
    if not args.command:
        raise SystemExit("Missing command")
    started = dt.datetime.now(dt.timezone.utc).isoformat()
    with (jobs / f"{args.name}.log").open("a") as log:
        child = subprocess.Popen(args.command, stdout=log, stderr=subprocess.STDOUT)
        running = jobs / f"{args.name}.running.json"
        running.write_text(
            json.dumps(
                {"pid": child.pid, "started_utc": started, "command": args.command}
            )
        )
        code = child.wait()
    running.unlink(missing_ok=True)
    result = {
        "returncode": code,
        "started_utc": started,
        "finished_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
        "command": args.command,
    }
    target = complete if code == 0 else jobs / f"{args.name}.failed.json"
    temporary = target.with_suffix(".tmp")
    temporary.write_text(json.dumps(result, indent=2) + "\n")
    temporary.replace(target)
    raise SystemExit(code)


if __name__ == "__main__":
    main()
