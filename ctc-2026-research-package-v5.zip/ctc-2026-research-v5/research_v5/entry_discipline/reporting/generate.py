"""Read completed checkpoints only; no model fitting or replay."""

import csv
import difflib
import hashlib
import json
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]


def main():
    report = [
        '# One clock entry-price challenger: retain static control', '',
        'All monetary figures below are USD per complete three-round season. '
        'Each split has120 whole seasons. Primary objective is mean net PnL.', '',
        'The challenger was frozen after inner scoring. Diagnostic121–240 is '
        'previously observed retrospective data, not a fresh holdout. '
        'No retuning or additional policy. See PLAN and HANDOFF for the exact rule.', '',
    ]
    rows=[]
    checks=[]
    for split in ['inner','diagnostic']:
        metrics=json.loads((ROOT/split/'metrics.json').read_text())
        complete=json.loads((ROOT/split/'COMPLETE.json').read_text())
        assert complete['source_hashes']==json.loads((ROOT/'FROZEN.json').read_text())['source_hashes']
        report += [f'## {split.title()}', '',
                   '|Scenario|Control net|New net|Increment net|Increment gross|Increment cost|',
                   '|---|---:|---:|---:|---:|---:|']
        for scenario,m in metrics.items():
            c,p,d=m['control'],m['stop_acquiring'],m['increment']
            vals=[c['mean'],p['mean'],d['net'],d['gross'],d['cost']]
            report.append('|'+scenario+'|'+'|'.join(f'USD {v:,.4f}' for v in vals)+'|')
            rows.append(dict(split=split,scenario=scenario,control_net=c['mean'],
                             new_net=p['mean'],increment_net=d['net'],increment_gross=d['gross'],
                             increment_cost=d['cost'],increment_actions=d['actions'],
                             increment_turnover_shares=d['turnover_shares'],
                             paired_better_rate=d['better_rate']))
            old=dict(np.load(ROOT/split/f'control_{scenario}.npz'))
            new=dict(np.load(ROOT/split/f'stop_acquiring_{scenario}.npz'))
            np.testing.assert_allclose(old['by_engine'][:,[0,2]],new['by_engine'][:,[0,2]],atol=1e-9)
            np.testing.assert_array_equal(old['positions'],new['positions'])
            np.testing.assert_array_equal(old['action_ticks'][:,:,:90],new['action_ticks'][:,:,:90])
            np.testing.assert_array_equal(old['action_ticks'][:,:,370:],new['action_ticks'][:,:,370:])
            for arm,r in [('control',old),('stop_acquiring',new)]:
                counts=r['action_ticks'].reshape(120,-1)
                cumulative=np.pad(counts.cumsum(1),((0,0),(1,0)))
                rolling=cumulative[:,30:]-cumulative[:,:-30]
                assert np.all(counts>=0) and np.all(counts==np.floor(counts))
                assert rolling.max()<=60
                np.testing.assert_array_equal(counts.sum(1),r['actions'])
                np.testing.assert_allclose(r['attribution'].sum(1),r['pnl'],atol=1e-8)
                np.testing.assert_allclose(r['by_engine'].sum(1),r['pnl'],atol=1e-8)
                assert r['max_position_fraction'].max()<=1
                assert r['phase_flat_times'].max()+2<=740
                if arm=='stop_acquiring':
                    stops=r['first_stop'];assert np.all((stops==-1)|((stops>=180)&(stops<=240)))
                checks.append(dict(split=split,scenario=scenario,arm=arm,
                                   max_rolling=int(rolling.max()),
                                   latest_flat=int(r['phase_flat_times'].max())))
        report += ['', '|Baseline distribution|Control|New|', '|---|---:|---:|']
        for key in ['mean','median','worst','p05','worst5mean','cost','gross']:
            report.append(f"|{key}|USD {metrics['base']['control'][key]:,.4f}|USD {metrics['base']['stop_acquiring'][key]:,.4f}|")
        for key in ['win_rate','actions','turnover_shares','max_rolling_actions']:
            report.append(f"|{key}|{metrics['base']['control'][key]:.6f}|{metrics['base']['stop_acquiring'][key]:.6f}|")
        report += ['', '|Stress new distribution|Median|Worst|Win rate|', '|---|---:|---:|---:|']
        for scenario,m in metrics.items():
            p=m['stop_acquiring']
            report.append(f"|{scenario}|USD {p['median']:,.4f}|USD {p['worst']:,.4f}|{100*p['win_rate']:.2f}%|")
        report += ['']
    report += [
        '## Accounting and execution observations', '',
        '- Every supplied inner control array matched. The replay used the same '
        'complete account, not standalone profit addition.',
        '- Formation and final-engine PnL, their action prefixes/tails, and final '
        'positions are identical between arms in all scenarios and both splits.',
        '- Ledger, cash attribution, gross pending-capacity assertions and legal '
        'position bounds passed. Actual clock phase flat times precede final740 '
        'with cooldown in every run; latest challenger flat610 across all stresses.',
        '- Baseline diagnostic action use rises from599.8667 to602.4000 per '
        'season; turnover rises from24,497.9167 to24,638.9583 shares, while cost '
        'falls. The pairing/replanning mechanism therefore is not merely fewer fills.',
        '- Positive depth25/combined increments do not override negative baseline '
        'inner and diagnostic increments. Retain control; no validation optimization.', '',
        'Synthetic tests, per-season outputs, full precision metrics, source hashes, '
        'freeze/complete records and original files are included. No event result changed.',
    ]
    (ROOT/'REPORT.md').write_text('\n'.join(report)+'\n')
    with (ROOT/'comparison.csv').open('w') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    (ROOT/'RESULTS_AUDIT.json').write_text(json.dumps({'passed':True,'checks':checks},indent=2)+'\n')
    patch=[]
    for source,dest in [('etf_route_v3.py','etf_route_v3.py'),
                        ('scheduled_account.py','research_v5/scheduled_account.py')]:
        before=(ROOT/'source_control'/source).read_text().splitlines(True)
        after=(ROOT/source).read_text().splitlines(True)
        patch.extend(difflib.unified_diff(before,after,fromfile='a/'+dest,tofile='b/'+dest))
    patch.extend(difflib.unified_diff([], (ROOT/'entry_policy.py').read_text().splitlines(True),
                                    fromfile='/dev/null',tofile='b/entry_policy.py'))
    (ROOT/'integration.patch').write_text(''.join(patch))
    source={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in ROOT.glob('*.py')}
    assert source==json.loads((ROOT/'FROZEN.json').read_text())['source_hashes']
    print(json.dumps({'checkpoint_audits':len(checks),'source_frozen':True,'rows':rows},indent=2))


if __name__=='__main__':
    main()
