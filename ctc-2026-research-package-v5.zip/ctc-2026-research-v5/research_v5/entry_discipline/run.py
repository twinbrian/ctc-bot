"""Checkpointed one-candidate paired complete-account evaluation."""

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np

from scheduled_account import run

HERE = Path(__file__).resolve().parent
SCENARIOS = {
    'base': {},
    'fee50': {'cost_bps': 50},
    'latency6': {'latency': 6},
    'depth25': {'depth': 25},
    'combined': {'cost_bps': 50, 'latency': 6, 'depth': 25},
    'extra10bps': {'adverse_bps': 10},
}


def write_json(path, value):
    temp = path.with_suffix('.tmp')
    temp.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
    temp.replace(path)


def hashes():
    return {p.name:hashlib.sha256(p.read_bytes()).hexdigest()
            for p in HERE.glob('*.py')}


def summarize(r):
    p = r['pnl']
    return dict(n=len(p),mean=float(p.mean()),median=float(np.median(p)),
                worst=float(p.min()),p05=float(np.quantile(p,.05)),
                worst5mean=float(np.sort(p)[:6].mean()),
                win_rate=float((p>0).mean()),cost=float(r['cost'].mean()),
                gross=float((p+r['cost']).mean()),
                actions=float(r['actions'].mean()),
                turnover_shares=float(r['turnover_shares'].mean()),
                max_rolling_actions=int(r['max_rolling_actions'].max()),
                max_position=float(r['max_position_fraction'].max()),
                mean_engine_pnl=r['by_engine'].mean(0).tolist(),
                last_phase_flat=int(r['phase_flat_times'].max()),
                stopped_symbols_mean=float(r['stopped_symbols'].sum((1,2)).mean()))


def main():
    ap=argparse.ArgumentParser();ap.add_argument('split',choices=['inner','diagnostic'])
    args=ap.parse_args();split=args.split
    out=HERE/split;out.mkdir(exist_ok=True)
    if (out/'COMPLETE.json').exists():
        print('Already COMPLETE:',split);return
    if split=='diagnostic':
        frozen=json.loads((HERE/'FROZEN.json').read_text())
        assert frozen['source_hashes']==hashes(), 'Changed source after freezing'
        assert (HERE/'inner'/'COMPLETE.json').exists()
    forecast=np.load(HERE/f'{split}_forecasts.npz')
    data=np.load(HERE.parents[1]/'research_v4'/'development.npz')
    ids=data['season_ids'];assert ids.min()==121 and ids.max()==600
    expected=np.arange(241,361) if split=='inner' else np.arange(121,241)
    train=np.arange(361,601) if split=='inner' else np.arange(241,601)
    np.testing.assert_array_equal(forecast['eval_seasons'],expected)
    np.testing.assert_array_equal(forecast['train_seasons'],train)
    all_market=data['market']
    np.testing.assert_allclose(forecast['curve'],all_market[np.isin(ids,train)].mean(0),atol=1e-10)
    sel=np.flatnonzero(np.isin(ids,expected))
    np.testing.assert_array_equal(ids[sel],expected)
    market=all_market[sel];truth=data['settlement_truth'][sel]
    metrics={}
    for scenario,settings in SCENARIOS.items():
        pair={}
        for policy in ['control','stop_acquiring']:
            target=out/f'{policy}_{scenario}.npz'
            if target.exists():
                r=dict(np.load(target))
            else:
                r=run(market,truth,forecast['curve'],forecast['final_fair'],
                      entry=180,exit_at=540,fraction=1.0,
                      entry_discipline=policy=='stop_acquiring',**settings)
                r['season_ids']=expected
                if split=='inner' and scenario=='base' and policy=='control':
                    supplied=np.load(HERE/'control_inner_base_supplied.npz')
                    for key in supplied.files:
                        np.testing.assert_allclose(r[key],supplied[key],atol=1e-8,
                                                   rtol=1e-12,err_msg=key)
                    write_json(HERE/'CONTROL_REPRODUCED.json',
                               {'matched_every_supplied_array':True,'keys':supplied.files})
                with target.with_suffix('.tmp').open('wb') as f:
                    np.savez_compressed(f,**r)
                target.with_suffix('.tmp').replace(target)
            pair[policy]=r
            print(split,scenario,policy,json.dumps(summarize(r)),flush=True)
        c,p=pair['control'],pair['stop_acquiring']
        delta=p['pnl']-c['pnl']
        metrics[scenario]={k:summarize(v) for k,v in pair.items()}
        metrics[scenario]['increment']={
            'net':float(delta.mean()),'median':float(np.median(delta)),
            'worst':float(delta.min()),'better_rate':float((delta>0).mean()),
            'cost':float((p['cost']-c['cost']).mean()),
            'gross':float((delta+p['cost']-c['cost']).mean()),
            'actions':float((p['actions']-c['actions']).mean()),
            'turnover_shares':float((p['turnover_shares']-c['turnover_shares']).mean()),
            'engine_net':(p['by_engine']-c['by_engine']).mean(0).tolist(),
        }
        write_json(out/'metrics.json',metrics)
        columns=np.column_stack([expected,c['pnl'],p['pnl'],delta,c['cost'],p['cost'],
                                 c['pnl']+c['cost'],p['pnl']+p['cost']])
        np.savetxt(out/f'paired_{scenario}.csv',columns,delimiter=',',
                   header='season,control_net,new_net,delta_net,control_cost,new_cost,control_gross,new_gross',comments='')
    write_json(out/'COMPLETE.json',{'split':split,'seasons':expected.tolist(),
                                  'scenarios':SCENARIOS,'source_hashes':hashes()})
    if split=='inner':
        gain=metrics['base']['increment']['net']
        write_json(HERE/'FROZEN.json',{'policy':'stop_acquiring','source_hashes':hashes(),
                   'primary_objective':'mean net terminal USD PnL',
                   'inner_increment':gain,'inner_selection':'stop_acquiring' if gain>0 else 'control',
                   'diagnostic_rule':'One frozen diagnostic of both arms, retain negatives; no retuning'})


if __name__=='__main__':
    main()
