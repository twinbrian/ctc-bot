# Clock entry-price discipline — one completed negative challenger

Primary objective remains mean terminal **net USD PnL** in the same complete
account. Retain the attached static-goal clock account: this one challenger loses
baseline mean PnL on both inner and retrospective diagnostic. Full numbers and
all fixed stresses are in REPORT.md, comparison.csv and per-season checkpoints.

## Scope and provenance

- Exactly one new policy: irreversible edge-exhaustion acquisition stops plus
  matched ETF conversion financing/replanning. No other candidates or tuning.
- Formation20/100/full, clock180–240/exit540/full and final740 are the complete
  common account. The same continuous real rolling-minute ledger spans rounds.
- The control reproduced **every array** in the supplied inner baseline fixture.
- Frozen train-only curve361–600 for inner241–360; curve241–600 for diagnostic
  121–240. Both supplied curves were checked against their training mean prices.
  Final forecasts were reused unchanged. No model fitting or seasons1–120 access.
- The diagnostic data was previously observed. This is retrospective evidence,
  not a fresh holdout. FROZEN.json was written after inner completion and its
  source hashes checked before diagnostic. All six stresses and negatives kept.
- Event research and its completed-validation correction remain unchanged.
  These common-account results are not additive to event or v3 profits.

## Callable behavior and integration

`entry_policy.stop_acquiring(initial_goal, goal, stopped, fair, price, position,
pending_buys, pending_sells, *, cost_bps=25, fixed_cost=0.02, adverse_bps=0)`
returns revised goal, persistent stop mask and current remaining net edge.
All arrays are current tick `[account, symbol]`; pending sides are separate gross
nonnegative reservations. `fair` is anchored once at180. Apply only180..240.
When edge <=0, goal becomes held plus signed pending inventory and stays there
for this acquisition window. No reversal, cancellation or early liquidation.

The pure goal callable is **not sufficient on an unchanged route executor**:
unsubmitted basket plans must be replaced. The supplied `etf_route_v3.py` does
that and commits the ETF financing order in the same tick as each acquisition
conversion. Both legs independently reserve gross capacity, require two actions,
and consume ETF depth once. A conversion cannot launch without its financing.
The neutral financing leg is not a new outright ETF bet. Liquidation from540
uses the original mechanism. Already accepted orders can fill after edge expiry.

Full-account call: `scheduled_account.run(market, truth, curve, final_fair,
entry=180, exit_at=540, fraction=1.0, entry_discipline=True, **scenario)`.
`False` is the exact attached static-goal control. Returns PnL, cost, turnover,
actions/action_ticks, attribution/by_engine, final positions, phase flat times,
rolling/position maxima, stop mask/times and financing-share diagnostics.

Use integration.patch against the supplied original files: root
`etf_route_v3.py`, root new `entry_policy.py`, and
`research_v5/scheduled_account.py`. The patch preserves the parent's existing
module layout. Full evaluated source and original source are also retained.
When replaying the self-contained snapshot, keep it at
`research_v5/clock_entry` with dataset at `research_v4/development.npz`, and ensure
the enclosing research_v5 directory has no conflicting etf_route_v3 module.

## Interpretation

The matched-financing constraint is deliberately included in this single policy
to avoid orphaned conversion risk. It changes route size/timing and can increase
action use and stock turnover even while reducing monetary costs. Therefore the
paired result tests the declared implementable policy, not a clean attribution
of every dollar solely to filtering economically exhausted direct fills.
Do not tune it after these diagnostic outcomes or infer that all entry-price
discipline must fail. Keep the static control under the declared primary objective.

All checkpoints are preserved. Research is complete; no additional candidate run.
