"""Focused policy, route-commitment and causal-prefix regression checks."""

import json
from pathlib import Path

import numpy as np

from entry_policy import stop_acquiring
from etf_route_v3 import simulate_routes


def main():
    goal = np.array([[200, -200, 200]])
    q = np.array([[50, -50, 0]])
    buys, sells = np.array([[20, 0, 10]]), np.array([[0, 20, 0]])
    fair = np.array([[110., 90., 110.]])
    price = np.array([[110., 90., 100.]])
    new, stopped, edge = stop_acquiring(goal, goal, np.zeros_like(goal, bool),
                                       fair, price, q, buys, sells)
    np.testing.assert_array_equal(new, [[70, -70, 200]])
    np.testing.assert_array_equal(stopped, [[True, True, False]])
    resumed, mask, _ = stop_acquiring(goal, new, stopped, fair,
                                      np.array([[90., 110., 100.]]), q, buys, sells)
    np.testing.assert_array_equal(resumed, new)
    np.testing.assert_array_equal(mask, stopped)
    # Exactly exhausted edge must stop, not require strictly negative edge.
    new, mask, _ = stop_acquiring(np.array([[1]]), np.array([[1]]),
                                  np.array([[False]]), np.array([[100.]]),
                                  np.array([[100.]]), np.array([[0]]),
                                  np.array([[0]]), np.array([[0]]),
                                  cost_bps=0, fixed_cost=0)
    assert mask.item() and new.item() == 0
    cases = []
    for latency, depth, direction in [(2,50,1),(6,50,1),(6,25,-1)]:
        m = np.full((1,3,390,12), 100.)
        m[:,:,1:] += direction * 11
        kwargs = dict(start=0, exit_at=360, round_indices=[0],
                      latency=latency, depth=depth, audit=True,
                      forecast_jump=np.full((1,3,12), direction*10.),
                      entry_discipline=True)
        r = simulate_routes(m,np.zeros((1,12)),np.zeros((3,390,12)),**kwargs)
        assert not np.any(r['action_ticks'][0,0,1:180])
        assert np.all(r['first_stop'][0,0] == 2)
        assert np.all(r['positions'] == 0)
        assert r['max_rolling_actions'].max() <= 60
        assert r['max_position_fraction'].max() <= 1
        assert r['paired_financing_shares'].sum() > 0
        # No later prices can alter the already-submitted acquisition prefix.
        m2 = m.copy(); m2[:,:,100:] *= .7
        s = simulate_routes(m2,np.zeros((1,12)),np.zeros((3,390,12)),**kwargs)
        np.testing.assert_array_equal(r['action_ticks'][:,:,:100],s['action_ticks'][:,:,:100])
        np.testing.assert_array_equal(r['first_stop'],s['first_stop'])
        cases.append({'latency':latency,'depth':depth,'direction':direction})
    # Saturated prior budget must prevent conversion as well as its financing.
    prior = np.zeros((1,30),int);prior[0,-1]=60
    m = np.full((1,3,390,12),100.)
    r = simulate_routes(m,np.zeros((1,12)),np.zeros((3,390,12)),
                        start=0,exit_at=360,round_indices=[0],
                        prior_action_ticks=prior,forecast_jump=np.full((1,3,12),10.),
                        entry_discipline=True,audit=True)
    assert not np.any(r['action_ticks'][0,0,:29])
    assert r['max_rolling_actions'].max() <= 60
    result={'passed':True,'checks':['held and gross pending preservation',
            'no restart or reversal','equality gate','causal prefix',
            'no acquisition after stop','paired financing','gross capacity',
            'latency and depth','prior rolling budget','flat liquidation'],
            'cases':cases}
    Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result))


if __name__ == '__main__':
    main()
