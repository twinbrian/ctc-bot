# One clock entry-price challenger: retain static control

All monetary figures below are USD per complete three-round season. Each split has120 whole seasons. Primary objective is mean net PnL.

The challenger was frozen after inner scoring. Diagnostic121–240 is previously observed retrospective data, not a fresh holdout. No retuning or additional policy. See PLAN and HANDOFF for the exact rule.

## Inner

|Scenario|Control net|New net|Increment net|Increment gross|Increment cost|
|---|---:|---:|---:|---:|---:|
|base|USD 19,423.6856|USD 19,140.6740|USD -283.0117|USD -368.1250|USD -85.1133|
|fee50|USD 13,623.6242|USD 13,210.5509|USD -413.0733|USD -1,264.0729|USD -850.9996|
|latency6|USD 19,162.5564|USD 18,778.8096|USD -383.7468|USD -503.8562|USD -120.1094|
|depth25|USD 12,177.2701|USD 12,436.1998|USD 258.9297|USD 295.0339|USD 36.1042|
|combined|USD 8,748.7216|USD 9,002.0132|USD 253.2916|USD -118.6187|USD -371.9103|
|extra10bps|USD 17,065.8298|USD 16,786.7392|USD -279.0906|USD -517.3437|USD -238.2531|

|Baseline distribution|Control|New|
|---|---:|---:|
|mean|USD 19,423.6856|USD 19,140.6740|
|median|USD 17,551.8881|USD 17,503.9700|
|worst|USD -3,218.9763|USD -3,261.4300|
|p05|USD 1,538.5667|USD 1,535.6889|
|worst5mean|USD -361.1096|USD -802.4656|
|cost|USD 6,407.7060|USD 6,322.5927|
|gross|USD 25,831.3917|USD 25,463.2667|
|win_rate|0.975000|0.966667|
|actions|599.883333|603.025000|
|turnover_shares|24501.250000|24660.625000|
|max_rolling_actions|49.000000|60.000000|

|Stress new distribution|Median|Worst|Win rate|
|---|---:|---:|---:|
|base|USD 17,503.9700|USD -3,261.4300|96.67%|
|fee50|USD 12,181.4288|USD -7,093.8900|92.50%|
|latency6|USD 18,058.2931|USD -3,347.0137|97.50%|
|depth25|USD 11,896.1315|USD -1,868.9594|97.50%|
|combined|USD 8,807.8310|USD -6,583.0217|90.83%|
|extra10bps|USD 15,188.6378|USD -5,655.3613|94.17%|

## Diagnostic

|Scenario|Control net|New net|Increment net|Increment gross|Increment cost|
|---|---:|---:|---:|---:|---:|
|base|USD 18,986.5419|USD 18,824.2106|USD -162.3313|USD -251.1646|USD -88.8332|
|fee50|USD 13,035.5151|USD 12,743.6729|USD -291.8421|USD -1,106.2000|USD -814.3579|
|latency6|USD 18,822.1067|USD 18,367.8123|USD -454.2944|USD -594.0833|USD -139.7889|
|depth25|USD 12,001.4248|USD 12,440.2194|USD 438.7945|USD 471.1278|USD 32.3332|
|combined|USD 8,655.4441|USD 8,893.0332|USD 237.5890|USD -241.3232|USD -478.9123|
|extra10bps|USD 16,627.2865|USD 16,375.9151|USD -251.3714|USD -511.8938|USD -260.5224|

|Baseline distribution|Control|New|
|---|---:|---:|
|mean|USD 18,986.5419|USD 18,824.2106|
|median|USD 19,426.7794|USD 18,880.0844|
|worst|USD -28,797.7000|USD -26,286.6137|
|p05|USD -2,051.5885|USD -2,051.5885|
|worst5mean|USD -8,675.3415|USD -8,553.8773|
|cost|USD 6,411.7706|USD 6,322.9374|
|gross|USD 25,398.3125|USD 25,147.1479|
|win_rate|0.941667|0.941667|
|actions|599.866667|602.400000|
|turnover_shares|24497.916667|24638.958333|
|max_rolling_actions|49.000000|60.000000|

|Stress new distribution|Median|Worst|Win rate|
|---|---:|---:|---:|
|base|USD 18,880.0844|USD -26,286.6137|94.17%|
|fee50|USD 12,787.5337|USD -25,637.9838|87.50%|
|latency6|USD 18,539.6591|USD -21,341.7650|95.00%|
|depth25|USD 12,709.2207|USD -14,678.5625|95.00%|
|combined|USD 9,334.7102|USD -16,306.2525|90.83%|
|extra10bps|USD 16,494.6199|USD -27,027.9528|93.33%|

## Accounting and execution observations

- Every supplied inner control array matched. The replay used the same complete account, not standalone profit addition.
- Formation and final-engine PnL, their action prefixes/tails, and final positions are identical between arms in all scenarios and both splits.
- Ledger, cash attribution, gross pending-capacity assertions and legal position bounds passed. Actual clock phase flat times precede final740 with cooldown in every run; latest challenger flat610 across all stresses.
- Baseline diagnostic action use rises from599.8667 to602.4000 per season; turnover rises from24,497.9167 to24,638.9583 shares, while cost falls. The pairing/replanning mechanism therefore is not merely fewer fills.
- Positive depth25/combined increments do not override negative baseline inner and diagnostic increments. Retain control; no validation optimization.

Synthetic tests, per-season outputs, full precision metrics, source hashes, freeze/complete records and original files are included. No event result changed.
