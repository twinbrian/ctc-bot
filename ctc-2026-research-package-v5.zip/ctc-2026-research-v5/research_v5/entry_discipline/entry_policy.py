"""Causal, irreversible acquisition stops; no liquidation or forecast updating."""

import numpy as np


def stop_acquiring(
    initial_goal, goal, stopped, fair, price, position, pending_buys,
    pending_sells, *, cost_bps=25, fixed_cost=0.02, adverse_bps=0.0,
):
    """Return revised goal, persistent stop mask, and current net per-share edge.

    Call after arrivals at each acquisition tick only, with contemporaneous price
    and fair anchored at180. Pending sides must be gross, nonnegative quantities.
    Inputs are not mutated. No cancellation, reversal or liquidation instruction
    is emitted. Converter must preserve projected outright ETF inventory by
    committing its financing leg together with each new acquisition conversion.
    """
    side = np.sign(initial_goal)
    cost = (price + np.maximum(fair, 0)) * (cost_bps + adverse_bps) / 10000
    edge = side * (fair - price) - cost - 2 * fixed_cost
    newly = (side != 0) & ~stopped & (edge <= 0)
    stopped = stopped | newly
    exposure = position + pending_buys - pending_sells
    goal = np.where(newly, exposure, goal)
    return goal, stopped, edge
