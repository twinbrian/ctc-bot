"""Nonoverlapping formation, long clock-drift route, and final-report phases."""

from pathlib import Path
import sys

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from etf_route_v3 import simulate_routes
from pnl_v2_simulator import simulate


def shifted(values, seconds):
    offset = seconds // 2
    return np.concatenate(
        [values[..., offset:, :], np.repeat(values[..., -1:, :], offset, axis=-2)],
        axis=-2,
    )


def run(
    market,
    truth,
    curve,
    final_fair,
    *,
    entry=180,
    exit_at=540,
    fraction=1.0,
    no_later=False,
    cost_bps=25,
    fixed_cost=0.02,
    latency=2,
    depth=50,
    adverse_bps=0.0,
    replenish_seconds=2,
    forecast_jump=None,
    entry_discipline=False,
):
    if entry not in [180, 300] or exit_at not in [540, 660]:
        raise ValueError("Outside predeclared schedule")
    n = len(market)
    prior = np.zeros((n, 30), int)
    counts = np.zeros((n, 3, 390), int)
    pnl = np.zeros(n)
    costs = np.zeros(n)
    actions = np.zeros(n, int)
    shares = np.zeros(n)
    attribution = np.zeros((n, 12))
    engines = np.zeros((n, 3))
    max_position = np.zeros(n)
    positions = np.zeros((n, 12), int)
    phase_flat = np.full((n, 3), -1, int)
    skipped = np.zeros((n, 3), bool)
    drawdown_bound = np.zeros(n)
    stopped_symbols = np.zeros((n, 3, 12), dtype=bool)
    first_stop = np.full((n, 3, 12), -1, dtype=int)
    entry_market_shares = np.zeros((n, 12))
    paired_financing_shares = np.zeros((n, 2))
    settings = dict(
        cost_bps=cost_bps,
        fixed_cost=fixed_cost,
        latency=latency,
        depth=depth,
        adverse_bps=adverse_bps,
        replenish_seconds=replenish_seconds,
        audit=True,
    )

    def accumulate(result, selected, r, engine):
        pnl[selected] += result["pnl"]
        costs[selected] += result["cost"]
        actions[selected] += result["actions"]
        shares[selected] += result["turnover_shares"]
        attribution[selected] += result["attribution"]
        engines[selected, engine] += result["pnl"]
        max_position[selected] = np.maximum(
            max_position[selected], result["max_position_fraction"]
        )
        drawdown_bound[selected] += result["drawdown"]

    for r in range(3):
        formation = simulate_routes(
            market,
            truth,
            curve,
            start=20,
            exit_at=100,
            fraction=1.0,
            round_indices=[r],
            prior_action_ticks=prior,
            **settings,
        )
        assert np.all(formation["positions"] == 0)
        accumulate(formation, np.arange(n), r, 0)
        counts[:, r] = formation["action_ticks"][:, r]
        phase_flat[:, r] = formation["flat_times"][:, r]
        eligible = formation["flat_times"][:, r] + replenish_seconds <= entry
        skipped[:, r] = ~eligible
        if not no_later and eligible.any():
            selected = np.flatnonzero(eligible)
            start_tick = entry // 2
            preceding = counts[selected, r, start_tick - 30 : start_tick].copy()
            phase = simulate_routes(
                shifted(market[selected], entry),
                truth[selected],
                shifted(curve, entry),
                start=0,
                exit_at=exit_at - entry,
                fraction=fraction,
                round_indices=[r],
                prior_action_ticks=preceding,
                forecast_jump=None
                if forecast_jump is None
                else forecast_jump[selected],
                entry_discipline=entry_discipline,
                **settings,
            )
            flat = phase["flat_times"][:, r] + entry
            assert np.all(flat < 780), (
                "Scheduled phase used padded prices beyond real close"
            )
            assert np.all(phase["action_ticks"][:, r, 390 - start_tick :] == 0)
            assert np.all(phase["positions"] == 0)
            phase_flat[selected, r] = flat
            counts[selected, r, start_tick:] += phase["action_ticks"][
                :, r, : 390 - start_tick
            ]
            accumulate(phase, selected, r, 1)
            if entry_discipline:
                stopped_symbols[selected, r] = phase["stopped_symbols"][:, r]
                stop = phase["first_stop"][:, r]
                first_stop[selected, r] = np.where(stop >= 0, stop + entry, -1)
                entry_market_shares[selected] += phase["entry_market_shares"]
                paired_financing_shares[selected] += phase["paired_financing_shares"]
        if r == 2:
            selected = np.flatnonzero(phase_flat[:, r] + replenish_seconds <= 740)
            if len(selected):
                external = np.zeros((len(selected), 3, 390), int)
                external[:, r] = counts[selected, r]
                ready = np.zeros((len(selected), 3), int)
                ready[:, r] = 740
                final = simulate(
                    market[selected],
                    truth[selected],
                    np.zeros((len(selected), 3, 78, 12)),
                    final_fair[selected],
                    curve,
                    formation=None,
                    ongoing=None,
                    end_margin=0,
                    external_actions=external,
                    readiness_times=ready,
                    round_indices=[r],
                    prior_action_ticks=prior[selected],
                    **settings,
                )
                counts[selected, r] += final["action_ticks"][:, r]
                positions[selected] = final["positions"]
                accumulate(final, selected, r, 2)
        prior = counts[:, r, -30:].copy()
    timeline = counts.reshape(n, -1)
    cumulative = timeline.cumsum(1)
    lag = np.pad(cumulative[:, :-30], ((0, 0), (30, 0)))
    maximum = (cumulative - lag).max(1)
    assert maximum.max() <= 60
    np.testing.assert_array_equal(counts.sum((1, 2)), actions)
    np.testing.assert_allclose(attribution.sum(1), pnl, atol=1e-8)
    np.testing.assert_allclose(engines.sum(1), pnl, atol=1e-8)
    return {
        "pnl": pnl,
        "cost": costs,
        "actions": actions,
        "turnover_shares": shares,
        "attribution": attribution,
        "by_engine": engines,
        "positions": positions,
        "max_position_fraction": max_position,
        "max_rolling_actions": maximum,
        "action_ticks": counts,
        "phase_flat_times": phase_flat,
        "skipped_phase": skipped,
        "drawdown_upper_bound": drawdown_bound,
        "stopped_symbols": stopped_symbols,
        "first_stop": first_stop,
        "entry_market_shares": entry_market_shares,
        "paired_financing_shares": paired_financing_shares,
    }
