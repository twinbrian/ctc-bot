# One frozen entry-price discipline challenger

Declared before any new scoring. Primary objective: mean terminal net USD PnL
of the complete formation20/100/full + clock180/540/full + final740 account.
Exactly two arms: attached static-goal control and `stop_acquiring` below.
No timing, threshold, size or forecast search. Event results remain independent.

Use attached train-only mean curves: fit361–600/evaluate241–360; freeze this
implementation before retrospective diagnostic121–240 using curve241–600.
Forecast jump is the training mean price at542..552 minus mean price at180.
Anchor fair once at observed180 price plus that jump. Never refresh that fair.
Reuse supplied final forecasts; no fitting. Never access seasons1–120.

## Exact new rule

Only clock acquisition ticks180..240 inclusive change. Original per-symbol
direction, limit-sized initial goal and initial fee gate are unchanged.
At each acquisition tick after due fills, compute for that ORIGINAL direction:

    remaining = direction * (anchored_fair - current_price)
    costs = (current_price + max(anchored_fair, 0))
            * (cost_bps + adverse_bps) / 10000 + 2 * fixed_cost

If remaining <= costs, irreversibly stop that symbol for this acquisition
window: reduce its goal to current position + signed pending orders. Preserve
all accepted pending orders. Never reverse, sell a held long, cover a held short,
resume acquisition, or move liquidation before540 in response to this gate.
No new buffer or tuned parameter. Prices at submit time decide; already sent
orders may arrive after edge disappears and are still honored.

Replan each unsubmitted basket route from these revised goals and projected
inventory each tick. A new conversion may acquire only still-eligible missing
stock legs. Pair each acquisition conversion with its opposite ETF financing
market order in the SAME submit tick; both arrive at the scenario latency and
consume separate actions. Clip to ETF depth, both gross pending-side capacities,
stock capacities, and availability of two actions. This leaves no uncommitted
ETF financing obligation when a symbol stops. Financing is economically neutral
ETF exposure, not a new outright ETF bet; it does not require an ETF forecast.
It consumes that tick's ETF market depth, so no second outright ETF order then.
Do not launch a conversion if its financing order cannot be submitted.

This paired-acquisition routing is part of the ONE gating/replanning policy,
and can change execution timing even before a gate closes; its effect is included
in paired full-account PnL and must not be described as pure signal improvement.
Closing from540 retains the original route primitive. Formation/final unchanged.
All phases use the existing continuous integer rolling60-action ledger; gross
pending buy/sell position capacities are reserved separately. No price padding
may cause a real action or fill beyond actual close.

## Fixed evaluation and decision

Run both arms on inner and then frozen diagnostic, all120 seasons each.
Scenarios: base25bps + USD0.02/share/side, latency2s, depth50; fee50bps;
latency6s; depth25; combined50bps+6s+25; adverse extra10bps. Fixed fee stays
USD0.02 in every scenario, matching attached PLAN's 50bps stress.
Save all outcomes, including negatives, paired net/gross/cost changes, median,
worst, win rate, actions, turnover, maxima and phase attribution. Promotion is
based on inner baseline mean only, not validation. Diagnostic never retunes.

Follow-up usage baseline USD39.3039855 (includes this session's startup and
earlier work). Additional cap USD20; stricter total research stop USD58.
Use a USD2 delivery reserve and stop new research by USD56. No descendants,
paid resources, git, or modification of frozen event artifacts.
