"""Execute every declared forward panel and training resample without selection."""

import json
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from models import StructuralModel, features, weather
from research_v4.lab import summarize_pnl
from research_v5.conditional_research import coherent_jump
from research_v5.handoff_research import npz, write_json
from research_v5.scheduled_account import run

SOURCE = ROOT / "research_v5/clock_robustness"
OUT = ROOT / "research_v5/stability_execution"
SCENARIOS = {
    "base": {},
    "strict_combined": dict(
        cost_bps=50, fixed_cost=0.04, latency=6, depth=25, adverse_bps=10
    ),
}


def main():
    OUT.mkdir(exist_ok=True)
    if (OUT / "COMPLETE.json").exists():
        return
    d = dict(np.load(ROOT / "cache.npz"))
    _, damage, outage, loss = features(d, np.array([740]))
    final_outage = weather(d)[2].sum(1)
    rows = []

    def evaluate(label, kind, ids, curve, fair, jump, scenario):
        path = OUT / f"{label}_{kind}_{scenario}.npz"
        if path.exists():
            result = dict(np.load(path))
        else:
            result = run(
                d["market"][ids],
                d["settlement_truth"][ids],
                curve,
                fair,
                forecast_jump=jump,
                **SCENARIOS[scenario],
            )
            keep = ["pnl", "cost", "actions", "by_engine", "max_rolling_actions"]
            npz(path, **{k: result[k] for k in keep}, season_ids=ids + 1)
        record = dict(
            label=label, policy=kind, scenario=scenario, **summarize_pnl(result["pnl"])
        )
        rows.append(record)
        write_json(OUT / "metrics.json", rows)
        return result

    for panel, first in enumerate([481, 361, 241, 121], 1):
        trained = np.arange(first - 1, 600)
        pred = dict(np.load(SOURCE / f"panels/P{panel}/hgb.npz"))
        ids = pred["season_ids"] - 1
        assert not set(trained) & set(ids)
        econ = StructuralModel().fit(
            d["report_truth"][trained].sum(1),
            final_outage[trained],
            d["loss_truth"][trained].sum(1),
            d["settlement_truth"][trained],
        )
        fair = econ.predict(damage[ids, 2, 0], outage[ids, 2, 0], loss[ids, 2, 0])
        curve = d["market"][trained].mean(0)
        jump = coherent_jump(pred["jump"], d["market"][ids, :, 90])
        for scenario in SCENARIOS:
            for kind, value in [("clock", None), ("hgb", jump)]:
                result = evaluate(f"P{panel}", kind, ids, curve, fair, value, scenario)
                if panel in [2, 3]:
                    stage = "inner" if panel == 2 else "validation"
                    old = np.load(
                        ROOT / f"research_v5/conditional/{stage}_{kind}_{scenario}.npz"
                    )
                    np.testing.assert_allclose(
                        result["pnl"], old["pnl"], atol=1e-8, rtol=0
                    )
        print("Completed forward panel", panel, flush=True)
    boot = dict(np.load(SOURCE / "bootstrap_predictions.npz"))
    ids = boot["season_ids"] - 1
    fixed = dict(np.load(ROOT / "research_v5/handoff/inner_forecasts.npz"))
    np.testing.assert_array_equal(ids + 1, fixed["eval_seasons"])
    for index, replicate in enumerate(boot["replicate_ids"]):
        sampled = boot["sample_ids"][index] - 1
        assert not set(sampled) & set(ids)
        sample_curve = d["market"][sampled].mean(0)
        clock_jump = sample_curve[:, 271:277].mean(1) - sample_curve[:, 90]
        clock_jump = np.broadcast_to(clock_jump, (len(ids), 3, 12)).copy()
        hgb_jump = coherent_jump(boot["hgb"][index], d["market"][ids, :, 90])
        for scenario in SCENARIOS:
            for kind, jump in [("clock", clock_jump), ("hgb", hgb_jump)]:
                evaluate(
                    f"B{replicate:02}",
                    kind,
                    ids,
                    fixed["curve"],
                    fixed["final_fair"],
                    jump,
                    scenario,
                )
        print("Completed resample", int(replicate), flush=True)
    summary = []
    for scenario in SCENARIOS:
        for kind in ["clock", "hgb"]:
            means = np.array(
                [
                    r["mean_usd"]
                    for r in rows
                    if r["label"].startswith("B")
                    and r["policy"] == kind
                    and r["scenario"] == scenario
                ]
            )
            assert len(means) == 30
            summary.append(
                dict(
                    policy=kind,
                    scenario=scenario,
                    replicates=30,
                    mean_of_means_usd=float(means.mean()),
                    median_mean_usd=float(np.median(means)),
                    min_mean_usd=float(means.min()),
                    max_mean_usd=float(means.max()),
                    p05_mean_usd=float(np.quantile(means, 0.05)),
                    p95_mean_usd=float(np.quantile(means, 0.95)),
                    positive_mean_count=int((means > 0).sum()),
                    original_order_means=means.tolist(),
                )
            )
    write_json(OUT / "bootstrap_summary.json", summary)
    write_json(
        OUT / "COMPLETE.json",
        {
            "forward_panels": 4,
            "replicates": 30,
            "policies": ["clock", "hgb"],
            "scenarios": list(SCENARIOS),
            "selection": False,
        },
    )
    print(json.dumps(summary), flush=True)


if __name__ == "__main__":
    main()
