"""Bounded frozen-policy audit. Never fits or selects a policy."""

import importlib.util
import json
from pathlib import Path
import sys

import numpy as np
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
SUPPLIED = HERE / "supplied"
sys.path.insert(0, str(ROOT))
from common import BASKETS, LIMITS, with_etfs


def load_schedule():
    spec = importlib.util.spec_from_file_location("audited_schedule", SUPPLIED / "scheduled_account.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def instrument(filename, replacements, hooks):
    source = (ROOT / filename).read_text()
    for old, new in replacements:
        assert source.count(old) == 1, old
        source = source.replace(old, new)
    ns = {"__name__": "instrumented", **hooks}
    exec(compile(source, filename, "exec"), ns)
    return ns


class Ledger:
    def __init__(self, market, truth, settings):
        self.market, self.truth = market, truth
        self.settings = settings
        n = len(market)
        self.inventory = np.zeros((n, 12), int)
        self.cash = np.zeros(n)
        self.fees = np.zeros(n)
        self.turnover = np.zeros(n)
        self.depth = {}
        self.counts = np.zeros((n, 3, 390), int)
        self.submissions = []
        self.conversion_count = 0
        self.reserved_checks = 0
        self.last_fill = np.full((n, 3), -1, int)
        self.ids, self.offset = np.arange(n), 0
        self.calls = []

    def submit(self, r, ti, ids, change, kind):
        ids = self.ids[ids]
        real_tick = ti + self.offset
        assert real_tick < 390
        self.counts[ids, r, real_tick] += 1
        for i, vec in zip(ids, change):
            self.submissions.append((int(i), int(r), 2 * real_tick, kind, tuple(vec)))

    def fill(self, r, ti, ids, change, kind):
        ids = self.ids[ids]
        real_tick = ti + self.offset
        assert real_tick < 390, "Padded fill"
        self.last_fill[ids, r] = np.maximum(self.last_fill[ids, r], 2 * real_tick)
        if kind == "market":
            for i, vec in zip(ids, change):
                prices = self.market[i, r, real_tick]
                unit = prices * (self.settings.get("cost_bps", 25) + self.settings.get("adverse_bps", 0)) / 10000 + .02
                self.cash[i] -= (vec * prices + np.abs(vec) * unit).sum()
                self.fees[i] += (np.abs(vec) * unit).sum()
                self.turnover[i] += np.abs(vec).sum()
                for j in np.flatnonzero(vec):
                    key = i, r, real_tick, int(j)
                    self.depth[key] = self.depth.get(key, 0) + abs(int(vec[j]))
        else:
            # Every conversion is exactly an integer basket, with zero cash.
            assert np.all(change[:, :10] == -change[:, 10:] @ BASKETS)
            self.conversion_count += len(ids)
        self.inventory[ids] += change
        assert np.all(np.abs(self.inventory) <= LIMITS)

    def tail_submit(self, r, ti, ids, symbols, qty):
        change = np.zeros((len(ids), 12), int)
        change[np.arange(len(ids)), symbols] = qty
        self.submit(r, ti, ids, change, "market")

    def tail_fill(self, r, ti, ids, symbols, qty):
        change = np.zeros((len(ids), 12), int)
        change[np.arange(len(ids)), symbols] = qty
        self.fill(r, ti, ids, change, "market")

    def reservations(self, q, pp, pn, remaining, direction, vectors, direct_goal, goal):
        # Preplanned legs are not pending executions and earn no cash. Direct
        # trading deliberately excludes them; pending pp/pn reserves submitted
        # legs separately, without netting opposite-side pending quantities.
        planned = np.zeros_like(q)
        for b in range(2):
            planned[:, :10] += remaining[:, b, None] * direction[:, b, None] * vectors[b, :10]
        np.testing.assert_array_equal(direct_goal + planned, goal)
        assert np.all(q + pp <= LIMITS) and np.all(q - pn >= -LIMITS)
        self.reserved_checks += int(np.any(remaining > 0))

    def wrap_route(self, fn):
        def wrapped(market, truth, curve, **kw):
            if kw["start"] == 0:
                r = kw["round_indices"][0]
                ids = np.flatnonzero(self.formation_flat[:, r] + self.settings.get("replenish_seconds", 2) <= 180)
                offset = 90
            else:
                ids, offset = np.arange(len(self.market)), 0
            self.ids, self.offset = ids, offset
            assert np.all(self.inventory[ids] == 0)
            # Exact source-price identity proves local tick is original tick+entry.
            np.testing.assert_array_equal(market[:, :, :390-offset], self.market[ids, :, offset:])
            result = fn(market, truth, curve, **kw)
            assert np.all(self.inventory[ids] == 0)
            self.calls.append({"start": kw["start"], "round": kw["round_indices"][0],
                               "flat_min": int(result["flat_times"][:, kw["round_indices"][0]].min() + 2*offset),
                               "flat_max": int(result["flat_times"][:, kw["round_indices"][0]].max() + 2*offset),
                               "conversions": int(result["conversion_actions"].sum())})
            if not offset:
                if not hasattr(self, "formation_flat"):
                    self.formation_flat = np.full((len(self.market), 3), -1)
                r = kw["round_indices"][0]
                self.formation_flat[:, r] = result["flat_times"][:, r]
            else:
                if not hasattr(self, "phase_flat"):
                    self.phase_flat = self.formation_flat.copy()
                r = kw["round_indices"][0]
                self.phase_flat[ids, r] = result["flat_times"][:, r] + 180
            return result
        return wrapped

    def wrap_tail(self, fn):
        def wrapped(market, truth, *args, **kw):
            flat = getattr(self, "phase_flat", self.formation_flat)
            ids = np.flatnonzero(flat[:, 2] + self.settings.get("replenish_seconds", 2) <= 740)
            self.ids, self.offset = ids, 0
            assert np.all(self.inventory[ids] == 0)
            np.testing.assert_array_equal(market, self.market[ids])
            return fn(market, truth, *args, **kw)
        return wrapped

    def validate(self, result):
        np.testing.assert_allclose(result["pnl"], self.cash + (self.inventory * self.truth).sum(1), atol=1e-7)
        np.testing.assert_allclose(result["cost"], self.fees, atol=1e-7)
        np.testing.assert_array_equal(result["turnover_shares"], self.turnover)
        np.testing.assert_array_equal(result["positions"], self.inventory)
        np.testing.assert_array_equal(result["action_ticks"], self.counts)
        np.testing.assert_array_equal(result["actions"], self.counts.sum((1, 2)))
        assert max(self.depth.values(), default=0) <= self.settings.get("depth", 50)
        # Independent event-list oracle uses exact real times, zero round gap.
        maxima = []
        for account in self.counts:
            times = [r*780+2*t for r in range(3) for t in range(390) for _ in range(account[r, t])]
            left = maximum = 0
            for right, now in enumerate(times):
                while times[left] <= now - 60:
                    left += 1
                maximum = max(maximum, right-left+1)
            maxima.append(maximum)
        np.testing.assert_array_equal(result["max_rolling_actions"], maxima)
        assert max(maxima) <= 60
        return {"conversion_fills": self.conversion_count, "ticks_with_planned_reservations": self.reserved_checks,
                "maximum_market_depth": max(self.depth.values(), default=0), "maximum_rolling_actions": max(maxima),
                "calls": self.calls}


def audited_run(market, truth, curve, fair, **settings):
    schedule = load_schedule()
    ledger = Ledger(market, truth, settings)
    routed = instrument("etf_route_v3.py", [
        ("                q[i] += change", "                hook_fill(r, ti, i, change, kind)\n                q[i] += change"),
        ("                pp[i] += np.maximum(change, 0)", "                hook_submit(r, ti, i, change, kind)\n                pp[i] += np.maximum(change, 0)"),
        ("            direct_goal = goal - reserved_route", "            direct_goal = goal - reserved_route\n            hook_reservations(q, pp, pn, remaining, direction, vectors, direct_goal, goal)"),
    ], {"hook_fill": ledger.fill, "hook_submit": ledger.submit, "hook_reservations": ledger.reservations})["simulate_routes"]
    tailed = instrument("pnl_v2_simulator.py", [
        ("                q[i, j] += qty", "                hook_fill(r, ti, i, j, qty)\n                q[i, j] += qty"),
        ("                pending_qty[i, j] += quantity", "                hook_submit(r, ti, i, j, quantity)\n                pending_qty[i, j] += quantity"),
    ], {"hook_fill": ledger.tail_fill, "hook_submit": ledger.tail_submit})["simulate"]
    with patch.object(schedule, "simulate_routes", ledger.wrap_route(routed)), patch.object(schedule, "simulate", ledger.wrap_tail(tailed)):
        result = schedule.run(market, truth, curve, fair, **settings)
    return result, ledger.validate(result), ledger.submissions


def summary(pnl):
    return {"n": len(pnl), "mean_usd": float(pnl.mean()), "median_usd": float(np.median(pnl)),
            "worst_usd": float(pnl.min()), "win_rate": float((pnl > 0).mean())}


def write_json(name, value):
    target = HERE / name
    temp = target.with_suffix(".tmp")
    temp.write_text(json.dumps(value, indent=2) + "\n")
    temp.replace(target)


def fixed_replay():
    pred = dict(np.load(SUPPLIED / "validation_forecasts.npz", allow_pickle=False))
    frozen = dict(np.load(SUPPLIED / "validation_entry180_exit540_fraction1.0_base.npz", allow_pickle=False))
    with np.load(ROOT / "research_v4/development.npz", allow_pickle=False) as data:
        ids = data["season_ids"]
        np.testing.assert_array_equal(ids, np.arange(121, 601))
        np.testing.assert_array_equal(pred["train_seasons"], np.arange(241, 601))
        np.testing.assert_array_equal(pred["eval_seasons"], np.arange(121, 241))
        np.testing.assert_array_equal(frozen["season_ids"], pred["eval_seasons"])
        market = data["market"]
        np.testing.assert_array_equal(pred["curve"], market[ids >= 241].mean(0))
        market = market[ids <= 240]
        truth = data["settlement_truth"][ids <= 240]
        assert np.all(data["stage"][ids <= 240, :, 370] == 2)
    reference_verified = False
    reference_path = SUPPLIED / "restricted_reference.npz"
    if reference_path.exists():
        with np.load(reference_path, allow_pickle=False) as ref:
            np.testing.assert_array_equal(ref["season_ids"], pred["eval_seasons"])
            np.testing.assert_array_equal(pred["final_fair"], ref["final_fair"])
        reference_verified = True
    result, evidence, _ = audited_run(market, truth, pred["curve"], pred["final_fair"])
    for key in result:
        np.testing.assert_array_equal(result[key], frozen[key], err_msg=key)
    evidence.update(exact_fields=list(result), summary=summary(result["pnl"]),
                    mean_cost_usd=float(result["cost"].mean()), mean_actions=float(result["actions"].mean()),
                    mean_engine_pnl_usd=result["by_engine"].mean(0).tolist(),
                    phase_flat_min=int(result["phase_flat_times"].min()),
                    phase_flat_max=int(result["phase_flat_times"].max()),
                    skipped=int(result["skipped_phase"].sum()),
                    curve_exact_refit_mean=True, final_fair_exact_reference=reference_verified)
    write_json("fixed_replay.json", evidence)
    print("Fixed diagnostic baseline:", json.dumps(evidence), flush=True)


if __name__ == "__main__":
    fixed_replay()
