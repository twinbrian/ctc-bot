# Frozen clock-drift combined-account audit

## Finding

**No concrete accounting or decision-time causality defect found in the supplied
frozen entry180 / earliest-exit540 / full implementation. No integration patch
is warranted by this audit.** This is bounded implementation evidence, not live
execution certification or a new strategy selection.

The supplied baseline was independently replayed on the120 previously observed
diagnostic seasons121–240. All13 output fields matched exactly, including PnL,
costs, action counts, positions, attribution, phase times and drawdown bound.
The supplied files and earlier frozen artifacts were not overwritten.

| Diagnostic baseline | Value |
|---|---:|
| Mean net PnL | USD18,986.54 |
| Median net PnL | USD19,426.78 |
| Worst net PnL | USD−28,797.70 |
| Win rate | 94.17% |
| Mean fees/slippage cost | USD6,411.77 |
| Mean actions / season | 599.87 |
| Maximum rolling60s actions | 49 |
| Mean formation / long phase / final PnL | USD10,487.30 / USD8,218.45 / USD280.79 |

These are the supplied policy's retrospective results, not independently selected
performance. No matched-incumbent output was supplied for independent paired
comparison. No new cost/latency/depth PnL scenarios were scored here.

## Causality and clock translation

- The forecast checkpoint's curve equals, bit for bit, the mean of development
  market rows241–600. Its training IDs and diagnostic IDs exactly match241–600
  and121–240. The refit uses inner seasons as allowed by the contract; diagnostic
  seasons are excluded. The original inner-fit curve checkpoint was not supplied.
- Shifting both market and training curve by180 makes local time0 original180.
  The route target is the training mean at original542,544,…,552 minus the training
  price at180. It is not a current-season future-price target. The current-season
  anchor is the quote at180, available when the phase starts.
- `start=0` activates route acquisition at local0 through60 inclusive: actual180
  through240. `exit_at=360` initiates flattening at actual540. **It is not a flat
  deadline of540.** Every historical baseline formation phase became flat at116;
  every long phase became flat at556, with no skipped phase. Descriptions should
  say “begin liquidation at540; wait for confirmed flatness.”
- Actions and fills in the independent ledger use original quote indices. No fill
  reached padded prices or real close. Replacing every padded quote and training
  value with NaN left synthetic outputs identical. The baseline close assertions
  also passed. Future-quote perturbation preserved all earlier submissions;
  settlement-label perturbation preserved every order and affected only terminal
  settlement value.
- Final trading is only in round3 at/after740 and only after prior flatness plus
  cooldown. Cached report stage is final at740 for all audited season-rounds.
  Source inspection of `features` uses the current report and past-round totals
  plus storm observations already published by that time, not manifest truth.

### Final-fair provenance link verified

The follow-up restricted reference contains exactly seasons121–240, and its final
fair values match the supplied forecast checkpoint bit for bit. Independently
restoring the saved JSON structural parameters and predicting from cached public
features at round3 second740 also reproduces every final fair value **bit for bit,
maximum absolute difference0.0**. No fitting, truth inputs, settlement inputs or
pickle execution was needed. The saved pickle is retained with its hash.

The supplied source-chain hashes match `train.py`, `common.py` and
`prepare_development.py`. The source training mask is241–600. This closes the
missing supplied-artifact link. `provenance_verified.json` is the final provenance
checkpoint; it supersedes the unverified flag in the earlier `fixed_replay.json`,
which was completed before the restricted reference arrived. It does not certify
raw-payload/cache equivalence or reconstruct the original training execution.

## One-account and conversion evidence

The independent ledger observed every submission and fill, then reconstructed
cash, fees, turnover, inventories and final settlement from original market rows.
It reconciled all120 accounts with the frozen results. Every market fill was at
the delayed original-clock quote with25bps plus USD0.02/share/side; maximum
combined market depth was50 shares/symbol/two-second tick.

All12,240 conversion fills were exact signed integer baskets. The independent
ledger credited **zero cash** to conversions, including mark deviations. Final
cash plus settlement of actual final inventory equals reported PnL. The route's
parity booking only reallocates attribution across instruments; it is not income.

The original route's preplanned conversion reservations are intentional:

- `remaining` is an unsubmitted plan, not inventory, a pending execution or cash.
- Direct stock targets exclude still-planned stock legs. Once a conversion is
  submitted, its plan quantity decreases and its legs enter separate positive and
  negative pending reservations. This prevents counting a leg as both a planned
  acquisition and a direct purchase.
- ETF financing/unwinding legs remain delayed, fee-paying market transactions.
  Both baskets are disjoint; no overlapping stock leg is reserved twice.
- Submitted conversions count one action each. Their size obeys every leg's
  absolute position limit including worst-ordering pending reservations. Original
  engine assertions and independently reconstructed fill-time positions passed.
- Delayed conversion completion prevents handoff; both inventory and pending legs
  must be zero before the next account phase. Real-clock action history transfers
  across phases and zero-gap rounds. An independent event-list oracle matched
  the rolling counts using `(now−60, now]`.

No cash/margin/borrow constraints beyond those in the supplied research contract
were audited. If the actual venue requires owned units before converting rather
than permitting signed inventories within limits, that additional venue rule
would need a separate check. This audit does not assert such a rule exists.

## Regression evidence and boundaries

Six focused synthetic tests plus four latency/depth subcases passed. Cases include
latency2/depth50, latency6/depth25, latency22/depth50 and latency40/depth25. Constant
coherent quotes/settlement produce exactly negative fees despite conversions,
providing a cash-neutrality check. Other tests cover exact clock translation,
poisoned padding, future-quote noninterference, settlement noninterference and the
absolute training target window. These are execution stress tests, not estimates
of stressed historical profitability.

The executor remains a fixed-latency hypothetical-fill simulator. This audit does
not certify random fill reordering, partial fills, rejected conversion recovery,
real order-book liquidity, asynchronous receipt timing or actual venue matching.
The earlier canonical feed-metadata audit remains applicable; metadata does not
prove full raw-payload/cache equivalence. Receipt-aware live recovery requires the
separately audited adapter and a receipt/version-aware consumer.

No new policy, fit, selection or promotion occurred. No seasons1–120 were opened.
The task stayed in non-git scratch; no repository changes, descendants or paid
compute. Exact checkpoints and test logs accompany this report.

The parent's later all600 post-selection replay and strict stress results are
outside this audit's scope and were not loaded or independently audited here.
