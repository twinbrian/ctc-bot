"""Verify restricted final-fair provenance without fitting or executing pickle."""

import hashlib
import json
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
SUPPLIED = HERE / "supplied"
sys.path.insert(0, str(ROOT))
from models import StructuralModel, features


def main():
    provenance = json.loads((SUPPLIED / "provenance.json").read_text())
    for original, local in [
        ("train.py", "train.py"),
        ("common.py", "common.py"),
        ("research_v4/prepare_development.py", "prepare_development.py"),
    ]:
        assert hashlib.sha256((SUPPLIED / local).read_bytes()).hexdigest() == provenance["source_files"][original]
        assert (ROOT / original).read_bytes() == (SUPPLIED / local).read_bytes()
    with np.load(SUPPLIED / "restricted_reference.npz", allow_pickle=False) as ref:
        np.testing.assert_array_equal(ref["season_ids"], np.arange(121, 241))
        reference = ref["final_fair"]
    with np.load(SUPPLIED / "validation_forecasts.npz", allow_pickle=False) as pred:
        np.testing.assert_array_equal(pred["eval_seasons"], np.arange(121, 241))
        np.testing.assert_array_equal(pred["final_fair"], reference)
    # Use public cached features only. No truth, label or outcome arrays enter
    # prediction. The supplied parameters are restored directly, never fit.
    keys = ["market", "obs", "damage", "loss", "stage", "probability", "cone", "official", "wire"]
    with np.load(ROOT / "research_v4/development.npz", allow_pickle=False) as archive:
        np.testing.assert_array_equal(archive["season_ids"], np.arange(121, 601))
        data = {key: archive[key][:120] for key in keys}
        data.update({key: archive[key] for key in ["site_xy", "site_company", "site_weight"]})
    _, damage, outage, loss = features(data, np.array([740]))
    parameters = json.loads((SUPPLIED / "structural_parameters.json").read_text())
    model = StructuralModel()
    for key in ["physical", "rebuild", "insurers"]:
        setattr(model, key, [np.asarray(value) for value in parameters[key]])
    predicted = model.predict(damage[:, 2, 0], outage[:, 2, 0], loss[:, 2, 0])
    np.testing.assert_allclose(predicted, reference, rtol=0, atol=1e-12)
    result = {
        "seasons": [121, 240], "n": 120,
        "supplied_reference_exactly_matches_checkpoint": True,
        "saved_parameters_predict_reference_max_abs_difference": float(np.max(np.abs(predicted-reference))),
        "saved_parameters_predict_reference_bit_exact": bool(np.array_equal(predicted, reference)),
        "prediction_uses_public_features_only": True,
        "source_hashes_verified": True,
        "source_training_mask": "241..600",
        "refit_performed": False,
        "pickle_executed": False,
    }
    temp = HERE / "provenance_verified.tmp"
    temp.write_text(json.dumps(result, indent=2) + "\n")
    temp.replace(HERE / "provenance_verified.json")
    print(json.dumps(result), flush=True)


if __name__ == "__main__":
    main()
