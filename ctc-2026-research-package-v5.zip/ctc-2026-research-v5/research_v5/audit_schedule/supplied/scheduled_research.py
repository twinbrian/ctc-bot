"""Evaluate the predeclared eight long-horizon clock schedules without refitting."""

import argparse
import itertools
import json
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from research_v4.lab import load_development, summarize_pnl
from research_v4.lead.shared_account import simulate_account
from research_v5.handoff_research import forecasts, npz, write_json
from research_v5.scheduled_account import run

OUT = ROOT / "research_v5/schedule"
SCENARIOS = {
    "base": {},
    "50bps": {"cost_bps": 50},
    "latency6": {"latency": 6},
    "depth25": {"depth": 25},
    "combined": {"cost_bps": 50, "latency": 6, "depth": 25},
    "adverse10bps": {"adverse_bps": 10},
}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("stage", choices=["inner", "validation"])
    stage = parser.parse_args().stage
    OUT.mkdir(exist_ok=True)
    if (OUT / f"{stage}_COMPLETE.json").exists():
        print("Completed stage retained", stage)
        return
    if stage == "validation" and not (OUT / "frozen.json").exists():
        raise SystemExit("Freeze first")
    data = load_development()
    # Enforce shared fit reuse; this runner may not start an unbudgeted duplicate fit.
    source = ROOT / f"research_v5/handoff/{stage}_forecasts.npz"
    if not source.exists():
        raise SystemExit(f"Missing completed forecast checkpoint: {source}")
    mask, pred = forecasts(data, stage)
    market, truth = data["market"][mask], data["settlement_truth"][mask]
    records = []

    def evaluate(name, config, scenario="base"):
        file = OUT / f"{stage}_{name}_{scenario}.npz"
        settings = SCENARIOS[scenario]
        if file.exists():
            result = dict(np.load(file))
        elif name == "incumbent":
            result = simulate_account(
                market,
                truth,
                pred["curve"],
                pred["delta"],
                pred["final_fair"],
                handoff="wait60",
                round_gap_seconds=0,
                **settings,
            )
            npz(file, **result, season_ids=pred["eval_seasons"])
        else:
            result = run(
                market, truth, pred["curve"], pred["final_fair"], **config, **settings
            )
            npz(file, **result, season_ids=pred["eval_seasons"])
        record = {
            "name": name,
            "stage": stage,
            "scenario": scenario,
            "config": config,
            **summarize_pnl(result["pnl"]),
            "mean_cost_usd": float(result["cost"].mean()),
            "mean_actions": float(result["actions"].mean()),
            "max_rolling_actions": int(result["max_rolling_actions"].max()),
            "max_position_fraction": float(result["max_position_fraction"].max()),
            "mean_engine_pnl": result["by_engine"].mean(0).tolist(),
        }
        records.append(record)
        write_json(OUT / f"{stage}_metrics.json", records)
        print(json.dumps(record), flush=True)
        return result, record

    incumbent, incumbent_record = evaluate("incumbent", {})
    _no_later, no_later_record = evaluate("no_later", {"no_later": True})
    if stage == "inner":
        best_name, best_config, best_record = "incumbent", {}, incumbent_record
        if no_later_record["mean_usd"] > best_record["mean_usd"]:
            best_name, best_config, best_record = (
                "no_later",
                {"no_later": True},
                no_later_record,
            )
        for entry, exit_at, fraction in itertools.product(
            [180, 300], [540, 660], [0.5, 1.0]
        ):
            name = f"entry{entry}_exit{exit_at}_fraction{fraction}"
            config = {"entry": entry, "exit_at": exit_at, "fraction": fraction}
            _result, record = evaluate(name, config)
            if record["mean_usd"] > best_record["mean_usd"]:
                best_name, best_config, best_record = name, config, record
        write_json(
            OUT / "frozen.json",
            {
                "name": best_name,
                "config": best_config,
                "inner_mean_usd": best_record["mean_usd"],
                "incumbent_mean_usd": incumbent_record["mean_usd"],
                "new_candidate_count": 8,
                "qualification": "Predeclared train-only clock benchmark; previously observed data",
            },
        )
    else:
        frozen = json.loads((OUT / "frozen.json").read_text())
        best_name, best_config = frozen["name"], frozen["config"]
        if best_name not in ["incumbent", "no_later"]:
            evaluate(best_name, best_config)
    for scenario in SCENARIOS:
        if scenario == "base":
            continue
        control, _ = evaluate("incumbent", {}, scenario)
        if best_name != "incumbent":
            challenger, _ = evaluate(best_name, best_config, scenario)
            records.append(
                {
                    "stage": stage,
                    "scenario": scenario,
                    "name": "paired_increment",
                    **summarize_pnl(challenger["pnl"] - control["pnl"]),
                }
            )
    if best_name != "incumbent":
        selected = dict(np.load(OUT / f"{stage}_{best_name}_base.npz"))
        records.append(
            {
                "stage": stage,
                "scenario": "base",
                "name": "paired_increment",
                **summarize_pnl(selected["pnl"] - incumbent["pnl"]),
            }
        )
    write_json(OUT / f"{stage}_metrics.json", records)
    write_json(
        OUT / f"{stage}_COMPLETE.json",
        {
            "stage": stage,
            "seasons": pred["eval_seasons"].tolist(),
            "records": len(records),
            "selected": best_name,
        },
    )


if __name__ == "__main__":
    main()
