"""Finish the interrupted fixed-policy handoff research with per-model checkpoints."""

import argparse
import hashlib
import json
import pickle
from pathlib import Path
import sys

import numpy as np
from sklearn.ensemble import HistGradientBoostingRegressor

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from common import SYMBOLS, with_etfs
from models import StructuralModel, features, weather
from pnl_v3_select import run as legacy_run
from research_v4.lab import load_development, summarize_pnl
from research_v4.lead.shared_account import simulate_account
from train import TIMES

OUT = ROOT / "research_v5/handoff"
SCENARIOS = {
    "base": {},
    "50bps": {"cost_bps": 50},
    "latency6": {"latency": 6},
    "depth25": {"depth": 25},
    "combined": {"cost_bps": 50, "latency": 6, "depth": 25},
    "adverse10bps": {"adverse_bps": 10},
    "replenish10s": {"replenish_seconds": 10},
}


def write_json(path, value):
    temp = path.with_suffix(".tmp")
    temp.write_text(json.dumps(value, indent=2) + "\n")
    temp.replace(path)


def npz(path, **values):
    temp = path.with_suffix(".tmp.npz")
    np.savez_compressed(temp, **values)
    temp.replace(path)


def forecasts(data, stage):
    ids = data["season_ids"]
    train = ids >= (361 if stage == "inner" else 241)
    evaluate = ((ids >= 241) & (ids <= 360)) if stage == "inner" else ids <= 240
    target = OUT / f"{stage}_forecasts.npz"
    if target.exists():
        saved = dict(np.load(target))
        np.testing.assert_array_equal(saved["train_seasons"], ids[train])
        np.testing.assert_array_equal(saved["eval_seasons"], ids[evaluate])
        return evaluate, saved
    curve = data["market"][train].mean(0)
    if stage == "validation":
        # Existing reference was fit241–600; use only its held-out121–240 rows.
        reference = dict(np.load(ROOT / "research_v4/reference.npz"))
        np.testing.assert_array_equal(reference["season_ids"], ids)
        saved = {
            "delta": reference["delta"][evaluate],
            "final_fair": reference["final_fair"][evaluate],
        }
    else:
        x, damage, outage, loss = features(data, TIMES)
        marks = data["market"][:, :, TIMES // 2]
        changes = x - np.concatenate([x[:, :, :1], x[:, :, :-1]], axis=2)
        lag10 = data["market"][:, :, np.maximum(TIMES - 10, 0) // 2]
        lag30 = data["market"][:, :, np.maximum(TIMES - 30, 0) // 2]
        predictors = np.concatenate(
            [x, changes, marks, marks - lag10, marks - lag30], axis=-1
        )
        targets = (
            data["market"][:, :, np.minimum(TIMES + 10, 778) // 2, :10]
            - marks[..., :10]
        )
        prediction = np.empty((*predictors[evaluate].shape[:-1], 10))
        fit_x = predictors[train, :, :-1].reshape(-1, predictors.shape[-1])
        pred_x = predictors[evaluate].reshape(-1, predictors.shape[-1])
        for j, symbol in enumerate(SYMBOLS[:10]):
            checkpoint = OUT / f"inner_{symbol}.pkl"
            if checkpoint.exists():
                with checkpoint.open("rb") as handle:
                    model = pickle.load(handle)
            else:
                model = HistGradientBoostingRegressor(
                    max_iter=160,
                    max_leaf_nodes=15,
                    learning_rate=0.06,
                    l2_regularization=30,
                    min_samples_leaf=100,
                    early_stopping=False,
                    random_state=2026,
                )
                model.fit(fit_x, targets[train, :, :-1, j].ravel())
                temp = checkpoint.with_suffix(".tmp")
                with temp.open("wb") as handle:
                    pickle.dump(model, handle)
                temp.replace(checkpoint)
            prediction[..., j] = model.predict(pred_x).reshape(
                predictors[evaluate].shape[:-1]
            )
            print("CHECKPOINT", stage, symbol, flush=True)
        final_outage = weather(data)[2].sum(1)
        economic = StructuralModel().fit(
            data["report_truth"][train].sum(1),
            final_outage[train],
            data["loss_truth"][train].sum(1),
            data["settlement_truth"][train],
        )
        saved = {
            "delta": with_etfs(prediction),
            "final_fair": economic.predict(
                damage[evaluate, 2, 74], outage[evaluate, 2, 74], loss[evaluate, 2, 74]
            ),
        }
    saved.update(curve=curve, train_seasons=ids[train], eval_seasons=ids[evaluate])
    npz(target, **saved)
    return evaluate, saved


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("stage", choices=["inner", "validation"])
    stage = parser.parse_args().stage
    OUT.mkdir(exist_ok=True)
    complete = OUT / f"{stage}_COMPLETE.json"
    if complete.exists():
        print("Completed experiment retained; no rerun", stage)
        return
    if stage == "validation" and not (OUT / "frozen.json").exists():
        raise SystemExit("Freeze on inner results first")
    data = load_development()
    mask, pred = forecasts(data, stage)
    market, truth = data["market"][mask], data["settlement_truth"][mask]
    args = (market, truth, pred["curve"], pred["delta"], pred["final_fair"])
    parity_path = OUT / f"{stage}_control_parity.json"
    if not parity_path.exists():
        legacy = legacy_run(
            (market, truth, pred["delta"], pred["final_fair"], pred["curve"]),
            {
                "formation_route": {"start": 20, "exit_at": 100, "fraction": 1.0},
                "ongoing": {"cycle": 10, "top_k": 5, "threshold": 0},
                "end_margin": 0,
            },
            {},
            audit=True,
        )
        current = simulate_account(*args, handoff="wait60", round_gap_seconds=60)
        np.testing.assert_allclose(legacy["pnl"], current["pnl"], atol=1e-8)
        np.testing.assert_array_equal(legacy["action_ticks"], current["action_ticks"])
        write_json(
            parity_path,
            {
                "matched": True,
                "seasons": len(market),
                "verified_interround_gap_seconds": 60,
                "maximum_absolute_pnl_difference": float(
                    np.max(np.abs(legacy["pnl"] - current["pnl"]))
                ),
                "source": "legacy wait60 policy versus continuous ledger with sufficient round gap",
            },
        )
    records = []
    for name, settings in SCENARIOS.items():
        outcomes = {}
        for handoff in ["wait60", "ready"]:
            file = OUT / f"{stage}_{name}_{handoff}.npz"
            if file.exists():
                result = dict(np.load(file))
            else:
                result = simulate_account(
                    *args, handoff=handoff, round_gap_seconds=0, **settings
                )
                npz(file, **result, season_ids=pred["eval_seasons"])
            outcomes[handoff] = result
            record = {
                "stage": stage,
                "scenario": name,
                "handoff": handoff,
                **summarize_pnl(result["pnl"]),
                "mean_cost_usd": float(result["cost"].mean()),
                "mean_actions": float(result["actions"].mean()),
                "max_rolling_actions": int(result["max_rolling_actions"].max()),
                "max_position_fraction": float(result["max_position_fraction"].max()),
                "mean_ready_second": float(result["tail_ready_times"].mean()),
            }
            records.append(record)
            print(json.dumps(record), flush=True)
        increment = outcomes["ready"]["pnl"] - outcomes["wait60"]["pnl"]
        records.append(
            {
                "stage": stage,
                "scenario": name,
                "handoff": "paired_increment",
                **summarize_pnl(increment),
            }
        )
        write_json(OUT / f"{stage}_metrics.json", records)
    if stage == "inner":
        base = next(
            row
            for row in records
            if row["scenario"] == "base" and row["handoff"] == "paired_increment"
        )
        frozen = {
            "selected": "ready" if base["mean_usd"] > 0 else "wait60",
            "inner_increment_usd": base["mean_usd"],
            "candidate_count": 1,
            "policy": "formation20/100/full,ten-second top5,zero margins,continuous round history",
            "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            "qualification": "Previously observed data; no fresh global holdout",
        }
        write_json(OUT / "frozen.json", frozen)
    write_json(
        complete,
        {
            "stage": stage,
            "seasons": pred["eval_seasons"].tolist(),
            "records": len(records),
        },
    )


if __name__ == "__main__":
    main()
