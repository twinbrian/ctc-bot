"""Fit once on 360 training seasons; no tuning against the final 120 seasons."""

import pickle
from pathlib import Path

import numpy as np
from sklearn.ensemble import HistGradientBoostingRegressor

from common import SYMBOLS, dump_json, load_cache, partitions, with_etfs
from models import StructuralModel, features, weather

TIMES = np.arange(0, 780, 10)


def main():
    d = load_cache("cache.npz")
    train, _, _ = partitions()
    _, _, final_outage, _, _ = weather(d)
    economic = StructuralModel().fit(
        d["report_truth"][train].sum(1),
        final_outage[train].sum(1),
        d["loss_truth"][train].sum(1),
        d["settlement_truth"][train],
    )
    dump_json("results/parameters.json", economic.parameters())
    x, damage, outage, loss = features(d, TIMES)
    shape = x.shape[:-1]
    market = d["market"][:, :, TIMES // 2]
    lag = d["market"][:, :, np.maximum(TIMES - 30, 0) // 2]
    y = np.broadcast_to(d["settlement_truth"][:, None, None, :10], (*shape, 10))
    results = {"times": TIMES}
    model_sets = {}
    for mode in ["fundamental", "hybrid"]:
        predictors = (
            x
            if mode == "fundamental"
            else np.concatenate(
                [x, market[..., :10], market[..., :10] - lag[..., :10]], axis=-1
            )
        )
        target = y if mode == "fundamental" else y - market[..., :10]
        xtrain = predictors[train].reshape(-1, predictors.shape[-1])
        pred = np.empty((*shape, 10))
        models = []
        for j, symbol in enumerate(SYMBOLS[:10]):
            model = HistGradientBoostingRegressor(
                max_iter=180,
                max_leaf_nodes=15,
                learning_rate=0.07,
                l2_regularization=20,
                min_samples_leaf=80,
                early_stopping=False,
                random_state=2026,
            )
            model.fit(xtrain, target[train, ..., j].ravel())
            pred[..., j] = model.predict(
                predictors.reshape(-1, predictors.shape[-1])
            ).reshape(shape)
            if mode == "hybrid":
                pred[..., j] += market[..., j]
            models.append(model)
            print(mode, symbol, "fitted", flush=True)
        model_sets[mode] = models
        results[mode + "_raw"] = with_etfs(pred)
        fv = with_etfs(pred)
        exact = economic.predict(damage[:, 2], outage[:, 2], loss[:, 2])
        fv[:, 2, TIMES >= 740] = exact[:, TIMES >= 740]
        results[mode] = fv
    results["structural"] = economic.predict(damage, outage, loss)
    results["outage"] = outage
    results["damage"] = damage
    results["loss"] = loss
    results["unconditional"] = np.broadcast_to(
        d["settlement_truth"][train].mean(0), (*shape, 12)
    ).copy()
    # Training residual errors are descriptive; uncertainty sizing uses validation.
    np.savez_compressed("predictions.npz", **results)
    Path("results").mkdir(exist_ok=True)
    with open("models.pkl", "wb") as f:
        pickle.dump({"structural": economic, "models": model_sets, "times": TIMES}, f)
    print("Models and predictions saved. Test performance not inspected.")


if __name__ == "__main__":
    main()
