# Frozen schedule audit (no policy search)

Scope: supplied frozen entry180/earliest-exit540/full policy, plus synthetic
execution-contract checks. No fitting, selection, or frozen-output replacement.
Data access is restricted to development121–600; fixed diagnostic replay uses
121–240 and supplied predictions. Verify curve against the241–600 refit mean and
final predictions against the preserved reference. Do not load other caches.

Predeclared checks:
1. Exact fixed baseline replay of all120 supplied diagnostic seasons, independent
   fill/cash/fee/turnover/conversion/settlement/action/depth reconstruction.
2. Synthetic fixed-policy runs at latency2,6,22,40 and depth50/25; real clock
   translation, gross pending reservations, preplanned conversion reservations,
   flat handoffs, zero inter-round gap and one rolling action ledger.
3. Poison padded prices; perturb future quotes and settlement independently to
   distinguish lawful training targets from decision-time future data.
4. Conversion-only booking remains cash-neutral; all queued fills and conversion
   legs respect real close, positions and the same action budget.

No stress-policy optimization and no new PnL promotion. Existing frozen artifacts
remain immutable. Results are retrospective and hypothetical, not live-fill proof.
Usage baseline USD29.10 cumulative including startup; stop research early enough
to deliver below USD45 cumulative (also below USD20 additional).
