"""Synthetic execution and prefix-causality checks for the frozen schedule."""

import unittest
from unittest.mock import patch

import numpy as np

from audit_schedule import audited_run, load_schedule
from common import with_etfs


def fixture(n=2):
    market = with_etfs(np.full((n, 3, 390, 10), 100.))
    truth = market[:, 2, -1].copy()
    curve = market[0].copy()
    curve[:, 51:90, :10] += 5
    curve[:, 271:, :10] += 20
    curve = with_etfs(curve[..., :10])
    fair = with_etfs(np.full((n, 10), 110.))
    return market, truth, curve, fair


class ScheduleTests(unittest.TestCase):
    def test_constant_mark_conversion_and_accounting_stresses(self):
        for latency, depth in [(2, 50), (6, 25), (22, 50), (40, 25)]:
            with self.subTest(latency=latency, depth=depth):
                result, evidence, _ = audited_run(*fixture(), latency=latency, depth=depth)
                np.testing.assert_allclose(result["pnl"], -result["cost"], atol=1e-7)
                self.assertGreater(evidence["conversion_fills"], 0)
                self.assertGreater(evidence["ticks_with_planned_reservations"], 0)

    def test_shift_has_exact_original_quote_mapping(self):
        schedule = load_schedule()
        values = np.arange(3*390*12).reshape(3, 390, 12)
        for entry in [180, 300]:
            shifted = schedule.shifted(values, entry)
            offset = entry // 2
            np.testing.assert_array_equal(shifted[:, :390-offset], values[:, offset:])
            np.testing.assert_array_equal(shifted[:, 390-offset:], np.repeat(values[:, -1:], offset, axis=1))

    def test_padding_poison_never_affects_execution(self):
        schedule = load_schedule()
        args = fixture()
        expected = schedule.run(*args)
        original = schedule.shifted

        def poison(values, seconds):
            out = original(values, seconds)
            out[..., 390-seconds//2:, :] = np.nan
            return out

        with patch.object(schedule, "shifted", poison):
            got = schedule.run(*args)
        for key in expected:
            np.testing.assert_array_equal(got[key], expected[key], err_msg=key)

    def test_future_quotes_do_not_change_prior_submissions(self):
        args = list(fixture())
        _, _, before = audited_run(*args)
        # Only current-season FUTURE quotes change. The trained mean is frozen.
        args[0] = args[0].copy()
        args[0][:, :, 200:] += 7
        _, _, after = audited_run(*args)
        self.assertEqual([x for x in before if x[2] < 400], [x for x in after if x[2] < 400])

    def test_settlement_labels_do_not_change_any_order(self):
        args = list(fixture())
        before, _, before_orders = audited_run(*args)
        args[1] = args[1] + 123
        after, _, after_orders = audited_run(*args)
        self.assertEqual(before_orders, after_orders)
        np.testing.assert_allclose(after["pnl"]-before["pnl"], before["positions"].sum(1)*123, atol=1e-7)

    def test_route_target_is_exact_absolute_training_window(self):
        schedule = load_schedule()
        original = schedule.simulate_routes
        args = fixture()
        calls = []

        def inspect(market, truth, curve, **kw):
            if kw["start"] == 0:
                r = kw["round_indices"][0]
                jump = curve[r, (kw["exit_at"]+2)//2:(kw["exit_at"]+14)//2].mean(0)-curve[r, 0]
                expected = args[2][r, 271:277].mean(0)-args[2][r, 90]
                np.testing.assert_array_equal(jump, expected)
                np.testing.assert_array_equal(market[:, r, 0], args[0][:, r, 90])
                calls.append(r)
            return original(market, truth, curve, **kw)

        with patch.object(schedule, "simulate_routes", inspect):
            schedule.run(*args)
        self.assertEqual(calls, [0, 1, 2])


if __name__ == "__main__":
    unittest.main(verbosity=2)
