"""Compact reproducible handoff; never includes raw development data."""

import csv
import hashlib
from pathlib import Path
import sys
import zipfile
import numpy as np

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from research_v5.terminal.run import NAMES, write

HERE = Path(__file__).resolve().parent


def main():
    rows = []
    for phase, (lo, hi) in [("inner", (241, 360)), ("validation", (121, 240))]:
        directory = HERE / phase
        for path in sorted(directory.glob("C??_*.npz")):
            candidate = int(path.stem[1:3])
            scenario = path.stem[4:]
            z = np.load(path)
            if "pnl" not in z:
                continue
            for i, season in enumerate(range(lo, hi + 1)):
                rows.append(
                    dict(
                        phase=phase,
                        season=season,
                        candidate=candidate,
                        name=NAMES[candidate],
                        scenario=scenario,
                        pnl=float(z["pnl"][i]),
                        cost=float(z["cost"][i]),
                        actions=int(z["actions"][i]),
                        turnover=float(z["turnover"][i]),
                    )
                )
        saved_predictions = np.load(directory / "predictions.npz")["predictions"]
        pred = saved_predictions[5]
        if not (directory / "C05_fair.npz").exists():
            np.savez_compressed(
                directory / "C05_fair.npz",
                fair=pred,
                season_ids=np.arange(lo, hi + 1),
                times=np.array([180, 300, 420]),
            )
        integration = {
            f"C{candidate:02d}": saved_predictions[candidate]
            for candidate in [0, 1, 2, 5, 8, 9, 10, 11]
        }
        integration.update(
            season_ids=np.arange(lo, hi + 1), times=np.array([180, 300, 420])
        )
        export = directory / "integration_predictions.npz"
        if export.exists():
            with np.load(export) as existing:
                for key, value in integration.items():
                    np.testing.assert_array_equal(existing[key], value)
        else:
            np.savez_compressed(export, **integration)
    with (HERE / "per_season.csv").open("w") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    source = [
        ROOT / "models.py",
        ROOT / "common.py",
        ROOT / "case.json",
        ROOT / "research_v5/job_runner.py",
        ROOT / "research_v5/CONTRACT.md",
        ROOT / "research_v5/LONG_HORIZON_PLAN.md",
    ]
    source += [
        p
        for p in HERE.glob("*")
        if p.suffix in [".py", ".md", ".json", ".csv", ".txt"]
        and p.name != "manifest.json"
    ]
    for phase in ["inner", "validation"]:
        source += list((HERE / phase).glob("*.json"))
        source += [HERE / phase / "models.pkl", HERE / phase / "C05_fair.npz"]
        source += [HERE / phase / "integration_predictions.npz"]
        source += list((HERE / phase).glob("C05_*.npz"))
    source += list((ROOT / "research_v5/jobs").glob("terminal-*.json"))
    source = sorted(set(source))
    manifest = {
        str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
        for p in source
    }
    write(HERE / "manifest.json", manifest)
    source.append(HERE / "manifest.json")
    bundle = ROOT / "ctc-v5-terminal-handoff-v2.zip"
    with zipfile.ZipFile(bundle, "w", zipfile.ZIP_DEFLATED) as z:
        for p in source:
            z.write(p, p.relative_to(ROOT))
    print(bundle, bundle.stat().st_size, "bytes", len(source), "files")


if __name__ == "__main__":
    main()
