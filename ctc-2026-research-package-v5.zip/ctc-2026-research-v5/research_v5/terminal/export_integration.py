"""Export existing frozen predictions only; no model fit or strategy replay."""

import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent
CONTROLS = [0, 1, 2, 8, 9, 10, 11]


def main():
    for phase, lo, hi in [("inner", 241, 360), ("validation", 121, 240)]:
        saved = np.load(HERE / phase / "predictions.npz")["predictions"]
        candidates = sorted(set([5] + CONTROLS))
        arrays = {f"C{c:02}": saved[c] for c in candidates}
        arrays.update(season_ids=np.arange(lo, hi + 1), times=np.array([180, 300, 420]))
        np.savez_compressed(HERE / phase / "integration_predictions.npz", **arrays)
        metadata = dict(
            phase=phase,
            fit_seasons=[361, 600] if phase == "inner" else [241, 600],
            evaluation_seasons=[lo, hi],
            previously_observed=True,
            selected_candidate=[5],
            control_candidates=CONTROLS,
            array_axes=[
                "season",
                "round_index_0_based",
                "checkpoint_index",
                "stock_index",
            ],
            checkpoints_real_seconds=[180, 300, 420],
            stock_order=[
                "PORT",
                "ISLE",
                "AQUA",
                "GRID",
                "FERRY",
                "RECON",
                "MAT",
                "GEN",
                "HAVEN",
                "REIN",
            ],
            units={
                "C00_C01_C02_C05_C08_C09": "USD expected terminal payoff per share",
                "C10_C11": "USD predicted price change from decision+2s to decision+12s",
            },
            executor="research_v5.terminal.simulator.simulate",
            executor_initial_positions_cash_supported=False,
            executor_initial_action_history_supported=False,
            executor_forced_round_end_flatten_supported=False,
            executor_state_carries_between_rounds=True,
            proposal_accepts_external_positions_and_separate_pending=True,
            root_exchange_primitives_used=False,
            no_frozen_outputs_changed=True,
        )
        (HERE / phase / "integration_metadata.json").write_text(
            json.dumps(metadata, indent=2) + "\n"
        )


if __name__ == "__main__":
    main()
