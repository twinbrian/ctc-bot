# Remaining-season terminal signal — v5, handoff v2

## Finding

**Return one frozen candidate, C05: public physical state + quotes predicting
expected terminal settlement.** Its standalone mean is **USD6,624.48** on the
120 previously observed diagnostic seasons121–240, versus USD1,164.31 for the
price/clock control. Combined execution stress averages USD4,305.70. This is a
candidate for the parent's common-account evaluation, not an additive profit
claim or a replacement for the USD11,100.59 incumbent.

The simple-prior explanation fails here: the unconditional train-only settlement
mean control loses USD4,976.19, while time/round-only expected terminal drift earns
USD977.32. Physical information contributes beyond these controls. This evidence
does **not** identify the house's internal formula or prove that it wholly ignores
future storms. It establishes a profitable bounded terminal-horizon forecast in
this retrospective simulator.

## Frozen experiment

Initial fit361–600, inner241–360; all three storms stay with their season. Twelve
policies were declared before scoring, including the two simple-prior controls
requested by the parent. One fixed ridge penalty, 0.10 times training row count;
one model per checkpoint, pooled rounds with round one-hot. No tuning grid,
trees, replay recognition, dates or season IDs in decision features. No seasons
1–120 were loaded. C05 won inner mean and its stress gate; it was frozen before
refitting241–600 and opening diagnostic121–240. No validation retuning occurred.

The signal forecasts terminal **payoff directly** from training settlement
targets. Thus the learning target is E[payoff], including later storms, not an
insurance payoff evaluated at a mean predicted loss. Features are current quotes,
public prior reports, current outage prefix, storm position/velocity/intensity/
radius, company-weighted wind/exposure/peak, simple extrapolations from observed
velocity, and public guidance. Three active-storm checkpoints per round:
real seconds180,300,420. Each permits a60-second execution window; thereafter
positions remain held. Information arriving after a checkpoint is used only at
the next checkpoint, except current quotes used for order selection.

Target each stock's full published limit when fair-minus-price exceeds one-way
cost plus USD0.25; otherwise retain existing inventory. Separate positive/negative
pending reservations, delayed market-price arrivals, direct stock orders only,
one60-action real rolling minute across the entire season. Every actual entry
and rebalance fill pays costs. Inventory/cash carry across both round boundaries;
settlement is applied **once**, after round3. No ETF route or passive-fill credit.

## All inner candidates retained

USD net PnL per season; n120, standalone. Combined means6s latency,
50bps+USD0.04/side,25-share depth and10bps additional adverse execution.

| ID / policy | Baseline mean | Combined mean |
|---|---:|---:|
| C00 no trade/current price | 0.00 | 0.00 |
| C01 unconditional terminal mean | -4,432.27 | -5,482.97 |
| C02 price/clock ridge | 631.25 | 91.95 |
| C03 price + reports/outage | 1,954.62 | 976.36 |
| C04 physical/guidance without quotes | 2,797.50 | 390.12 |
| **C05 full physical + quotes** | **3,892.78** | **1,931.81** |
| C06 structural payoff distribution | 3,054.13 | 695.37 |
| C07 half structural / half price-control | 2,379.49 | 845.69 |
| C08 time/round expected drift | -726.45 | -800.49 |
| C09 C05 capped50shares/stock | 560.16 | 196.99 |
| C10 price/clock ten-second | 0.00 | 0.00 |
| C11 full physical ten-second | 9.53 | -2.89 |

C05 inner median USD4,237.86, worst USD-34,335.95, p05 USD-11,400.35,
worst5% mean USD-19,153.70; win63.3%, mean309.68 actions and USD1,943.90 costs.
Its paired advantage over C02 is USD3,261.53, descriptive season-bootstrap95%
interval USD1,652.26 to USD4,954.32. The capacity-matched50-share terminal control
beats ten-second by USD550.63 (USD241.77 to USD852.69). Same position caps and
checkpoints do not mean equal turnover or duration at risk.

## Frozen retrospective diagnostic

Refit241–600, evaluate121–240, n120 whole seasons. Baseline25bps+USD0.02/side,
2s latency,50shares/symbol/2s; one60-action rolling real minute.

| Policy | Baseline mean | Combined mean |
|---|---:|---:|
| C01 unconditional terminal mean | -4,976.19 | -5,464.17 |
| C02 price/clock ridge | 1,164.31 | 585.55 |
| **C05 frozen physical model** | **6,624.48** | **4,305.70** |
| C08 time/round expected drift | 977.32 | 277.92 |
| C09 matched50-share terminal | 974.15 | 600.60 |
| C10 price/clock ten-second | 0.00 | 0.00 |
| C11 full physical ten-second | 14.90 | 0.53 |

| C05 scenario | Mean | Median | Worst | Wins |
|---|---:|---:|---:|---:|
| Baseline | 6,624.48 | 6,872.01 | -14,649.91 | 75.0% |
|6s latency | 6,541.01 | 6,864.68 | -14,866.67 | 74.2% |
| Double cost | 4,945.88 | 5,658.51 | -22,856.78 | 69.2% |
|25-share depth | 5,941.72 | 6,207.53 | -14,323.13 | 75.0% |
| Combined | 4,305.70 | 4,488.73 | -12,924.13 | 71.7% |

Baseline p05 USD-10,467.28, worst5% mean USD-12,810.64, mean295.15 actions,
USD1,828.65 costs. Descriptive95% mean interval USD4,955.72 to USD8,270.53.
The paired physical increment over C02 is USD5,460.17 (USD4,131.13 to
USD6,829.68); the50-share terminal increment over ten-second is USD959.24
(USD666.25 to USD1,240.72). Intervals condition on the selected design and do
not remove the dataset's previous research/adaptation history.

Declared information-lag10s sensitivity: mean USD6,328.06 baseline and
USD3,859.93 combined. Its inner counterparts were USD3,129.77 and USD1,046.21;
the latter's interval crosses zero. Lag stress does not repair absent historical
receipt timestamps or prove all delayed/out-of-order feeds safe.

## Future storms and nonlinear insurance

C06 explicitly samples current-storm regression residuals and future training
storm damage fractions/outages, with each future storm applied to remaining
undamaged assets. It averages256 nonlinear terminal payoffs, rather than
selecting nearest-neighbor replay seasons. It was positive but inferior to C05
on inner mean and was not promoted for validation trading.

On inner predictions, adding future storms to a current-round-only distribution
changes HAVEN expected value by USD-26.08 in round1 and USD-11.17 in round2;
PORT by USD-18.04 and USD-8.27; RECON by USD+7.20 and USD+2.94. Remaining-season
risk is economically large, but the failed unconditional-prior trade shows that
this size alone is not an exploitable universal short-islands/long-rebuilders rule.

E[HAVEN payoff] minus payoff(E[loss]) averages USD+2.81/1.78/0.15 by rounds1/2/3
on inner forecasts; REIN differences are USD-1.71/-1.10/-0.11. Layer nonlinearities
matter. The structural policy suppressed REIN at51.4% of inner checkpoints when
sampled losses exceeded its identified training range. The method assumes
unconditional independent future-storm severity draws and additive residuals;
these are model approximations. C05 instead learns expected actual payoff.

Validation baseline C05 attribution: HAVEN USD1,881.21, PORT USD1,299.06,
RECON USD945.48; all other stocks collectively USD2,498.74. REIN alone loses
USD36.23. This negative was retained; no symbol was removed after validation.

## Inter-round capacity conflicts and interface

Mean absolute inventory after rounds1/2, respectively:

| Stock | After round1 | After round2 | Limit |
|---|---:|---:|---:|
| PORT |191.7|192.9|200|
| ISLE |278.8|285.0|300|
| AQUA |409.6|464.6|500|
| GRID |349.2|368.8|400|
| FERRY |629.2|691.2|800|
| RECON |430.8|442.1|500|
| MAT |374.2|491.3|700|
| GEN |460.8|520.0|600|
| HAVEN |237.9|239.2|250|
| REIN |170.8|187.1|200|

These positions materially conflict with next-round formation, including ETF
conversion basket legs. They also occupy later-engine stock capacity. Terminal
actions stop by second478, so there is no own-action rolling history left at the
next-round formation window, but within180–480 the sleeve reaches60actions/minute.
Parent must arbitrate desired inventory in one shared account and include any
liquidation/re-entry costs. Standalone PnL must never be summed with formation.

`interface.py` exposes `checkpoint_fair_value(fitted_model, public_cube,
round_index, second, candidate=5)` and `inventory_proposal(...)`. Round indices
are0-based; real-second checkpoints are180/300/420. Proposal output is total
desired inventory for the ten stocks, not an additional sleeve position. Pass
actual common-account positions and separate pending buys/sells. Parent must
retain its common action limiter, legal position/depth reservations and fair
cache. During inactive windows the interface retains effective inventory.

The included `validation/models.pkl` is fit241–600 and is the frozen model for
integration. `inner/models.pkl` is fit361–600. The supplied C05 fair cubes include
explicit evaluation season IDs for alignment, never as trading features.

## Audit, restart and resource record

Five tests cover single settlement/carry, entry costs, delayed arrival price,
ten-second exits, rolling actions/depth and future-path/label/identity invariance.
Independent arithmetic reconstructs35,418 baseline and44,760 combined fills from
arrival quotes, fees, cash and final positions. It matches net PnL, confirms
maximum60actions/rolling minute and50/25shares/symbol/2s. Runtime asserts legal
inventory including separate pending reservations. The causal interface matches
all nine saved C05 checkpoint forecasts exactly.

All fills remain hypothetical house-price fills. Receipt times, books, partial
fills, variable latency, competition and announcements are not established here.
No new testnet trading or paid resources were used. All files are in non-git
scratch; no repo changes, branches, commits or PRs.

Startup-inclusive local OpenCode model estimate at the delivery checkpoint:
**USD21.92**, below USD60 research stop and USD75 allocation. The final attached
usage snapshot supersedes this interim value. Approximately15active minutes,
with the startup restart's downtime excluded. No descendants or paid compute.
All models, predictions, per-season results and atomic tmux completion markers
remain local for recovery. Do not archive this worker until parent has retained
the attachments. The compact bundle contains source, fitted models, complete
negative-result metrics, per-season CSV, selected fair cubes and selected account
checkpoints; raw development data and virtualenv are omitted.

Reproduce from the extracted project root with numpy/scipy/pytest installed and
OMP/OPENBLAS/MKL threads fixed to1: run `research_v5/terminal/run.py inner`, then
`run.py validation` only if its frozen gate permits, then `diagnostics.py`.
Existing completed phase markers prevent accidental restart rescoring.

### Parent integration addendum

`inner/integration_predictions.npz` and `validation/integration_predictions.npz`
include frozen C05 and all controls C00/C01/C02/C08/C09/C10/C11, explicit season
IDs and checkpoint times. Arrays are season × round × checkpoint × ten stocks.
C01–C09 fields are terminal fair values; C00 is the checkpoint quote and its
policy is explicitly no-trade. Do not feed C00's stale checkpoint quote into an
active inventory rule as later quotes change. C10/C11 fields are predicted ten-second
price changes, not terminal prices. Companion metadata identifies fit/evaluation
splits and symbol order. Export reads saved arrays only, with no refit or replay.

The callable standalone `simulator.simulate` starts q/cash at zero and preceding
action ticks empty. It **does not accept initial q/cash, preceding action ticks,
or a force-flat-at-round-end option**. Once started, it retains inventory/cash
and its rolling action history across all three rounds, then settles once.
`inventory_proposal` does accept external positions and separate pending sides,
but parent must provide its own common executor for combining strategies. Adding
a round-end liquidation would change the evaluated policy and is parent-owned.

Our simulator uses its own fill/account implementation and imports only root
symbol/limit constants, plus root economics for the distribution ablation. It
does not call the root action/order/conversion primitives addressed by the
attached integration patch. Frozen standalone outputs remain intact. Parent owns
promotion; this addendum makes no additive standalone claim.

Final handoff budget update: local startup-inclusive measured model estimate
USD34.51 at approximately14:02UTC, before final delivery; reserve USD3 for delivery
overhead. Earlier snapshots above and inside the bundle are retained provenance.
V2 adds both splits' already-frozen control predictions and integration metadata;
it does not change models, decisions, or scored execution outputs.
