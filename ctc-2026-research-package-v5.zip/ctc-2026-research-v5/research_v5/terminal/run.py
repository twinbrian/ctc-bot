"""Checkpointed finite experiment; run via job_runner inside tmux."""

import argparse
import hashlib
import json
from pathlib import Path
import pickle
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
import numpy as np
from research_v5.terminal.model import Models, load_data
from research_v5.terminal.simulator import simulate

HERE = Path(__file__).resolve().parent
SCENARIOS = dict(
    baseline={},
    latency6=dict(latency=6),
    double_cost=dict(bps=50, fixed=0.04),
    depth25=dict(depth=25),
    combined=dict(latency=6, bps=50, fixed=0.04, depth=25, adverse=10),
)
NAMES = [
    "no_trade",
    "training_prior",
    "price_clock",
    "report_outage",
    "physical_noquote",
    "full_physical",
    "distribution",
    "distribution_price_blend",
    "clock_drift",
    "full_clip50",
    "price_short10",
    "full_short10",
]


def write(path, obj):
    path = Path(path)
    path.parent.mkdir(exist_ok=True, parents=True)
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(obj, indent=2, allow_nan=False) + "\n")
    tmp.replace(path)


def npz(path, **arrays):
    tmp = path.with_suffix(".tmp")
    with tmp.open("wb") as f:
        np.savez_compressed(f, **arrays)
    tmp.replace(path)


def summary(x):
    pnl = x["pnl"]
    rng = np.random.default_rng(2117)
    means = pnl[rng.integers(len(pnl), size=(3000, len(pnl)))].mean(1)
    tail = np.sort(pnl)[: max(1, int(np.ceil(0.05 * len(pnl))))]
    return dict(
        n=len(pnl),
        mean=float(pnl.mean()),
        median=float(np.median(pnl)),
        worst=float(pnl.min()),
        p05=float(np.quantile(pnl, 0.05)),
        worst5_mean=float(tail.mean()),
        win_rate=float((pnl > 0).mean()),
        ci95=np.quantile(means, [0.025, 0.975]).tolist(),
        cost=float(x["cost"].mean()),
        actions=float(x["actions"].mean()),
        turnover=float(x["turnover"].mean()),
        max_rolling_actions=int(x["max_rolling_actions"].max()),
        carry_mean_abs_shares=np.abs(x["carry"]).mean(0).tolist(),
        attribution=x["attribution"].mean(0).tolist(),
    )


def run(phase):
    directory = HERE / phase
    directory.mkdir(exist_ok=True)
    if (directory / "COMPLETE.json").exists():
        return
    if phase == "inner":
        train_range, test_range = (361, 600), (241, 360)
        candidates = list(range(12))
    else:
        frozen = json.loads((HERE / "frozen.json").read_text())
        assert frozen["open_validation"]
        candidates = sorted(set(frozen["selected"] + [0, 1, 2, 8, 9, 10, 11]))
        train_range, test_range = (241, 600), (121, 240)
        write(directory / "OPENED.json", dict(frozen=frozen, retrospective=True))
    d = load_data(ROOT / "research_v4/development.npz", *test_range)
    modpath = directory / "models.pkl"
    if modpath.exists():
        model = pickle.loads(modpath.read_bytes())
    else:
        train = load_data(ROOT / "research_v4/development.npz", *train_range)
        model = Models().fit(train)
        temp = modpath.with_suffix(".tmp")
        temp.write_bytes(pickle.dumps(model))
        temp.replace(modpath)
        write(directory / "model_economics.json", model.econ.parameters())
        write(
            directory / "model_fit.json",
            dict(
                structural_rmse=model.label_fit_rmse.tolist(), train_range=train_range
            ),
        )
        del train
    ppath = directory / "predictions.npz"
    if ppath.exists():
        predictions = np.load(ppath)["predictions"]
    else:
        predictions, diag = model.predict(d)
        npz(ppath, predictions=predictions)
        npz(directory / "distribution_diagnostics.npz", **diag)
    result = {}
    for c in candidates:
        result[str(c)] = dict(name=NAMES[c], scenarios={})
        for name, config in SCENARIOS.items():
            assert not (HERE.parent / "STOP.json").exists(), "stop requested"
            path = directory / f"C{c:02}_{name}.npz"
            if path.exists():
                x = dict(np.load(path))
            else:
                x = simulate(
                    d["market"], d["settlement_truth"], predictions[c], c, **config
                )
                npz(path, **x)
            result[str(c)]["scenarios"][name] = summary(x)
            write(directory / "metrics.json", result)
            print(phase, c, name, round(x["pnl"].mean(), 2), flush=True)
    if phase == "inner":
        eligible = [
            c
            for c in range(1, 9)
            if result[str(c)]["scenarios"]["baseline"]["mean"] > 100
            and result[str(c)]["scenarios"]["combined"]["mean"] > 0
        ]
        eligible.sort(
            key=lambda c: result[str(c)]["scenarios"]["baseline"]["mean"], reverse=True
        )
        selected = eligible[:1]
        control = max(
            result[str(c)]["scenarios"]["baseline"]["mean"] for c in [1, 2, 8]
        )
        physical = [
            c
            for c in eligible
            if c in [3, 4, 5, 6, 7]
            and result[str(c)]["scenarios"]["baseline"]["mean"] > control + 100
        ]
        if physical and physical[0] not in selected:
            selected.append(physical[0])
        write(
            HERE / "frozen.json",
            dict(
                selected=selected,
                eligible=eligible,
                open_validation=bool(selected),
                controls=[0, 1, 2, 8, 9, 10, 11],
                plan_sha256=hashlib.sha256((HERE / "PLAN.md").read_bytes()).hexdigest(),
                phase="inner_only_selection",
            ),
        )
    errors = {}
    for c in candidates:
        if c >= 10:
            continue
        err = predictions[c] - d["settlement_truth"][:, None, None, :]
        errors[str(c)] = dict(
            rmse=float(np.sqrt(np.nanmean(err**2))),
            bias=np.nanmean(err, axis=(0, 1, 2)).tolist(),
        )
    write(directory / "prediction_errors.json", errors)
    write(
        directory / "COMPLETE.json",
        dict(
            candidates=candidates,
            n=len(d["market"]),
            train_range=train_range,
            test_range=test_range,
        ),
    )


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("phase", choices=["inner", "validation"])
    run(p.parse_args().phase)
