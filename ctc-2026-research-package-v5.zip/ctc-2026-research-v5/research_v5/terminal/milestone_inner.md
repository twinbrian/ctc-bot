# Inner milestone (standalone)

Fit361–600; inner241–360, 120 whole seasons. C05 full physical terminal forecast:
mean USD3892.78, median USD4237.86, worst USD-34335.95, p05 USD-11400.35,
worst5% mean USD-19153.70, 63.3% wins, 309.68 actions, USD1943.90 costs.
Latency6 mean USD3833.39; double costs USD2473.27; depth25 USD3368.84;
combined6s/double-cost/depth25/adverse10bps USD1931.81.

C01 unconditional prior loses USD4432.27; C08 clock-drift loses USD726.45;
C02 price-clock earns USD631.25. Physical information adds USD3261.53 to C02.
C09 matched 50-share-cap terminal earns USD560.16 vs C11 ten-second USD9.53.
No standalone improvement over v3 is claimed; inter-round holdings occupy most
symbol limits. Frozen candidate is C05 only. All twelve policies retained.
Validation gate passed; freeze precedes refit and retrospective121–240 opening.

Startup-inclusive local model estimate at inner completion: USD16.46574.
Active research approximately ten minutes; restart downtime excluded.
Parent-message tool was temporarily absent from the current tool catalog after
the directory move; this checkpoint preserves the milestone for handoff.
