"""Small fixed-capacity models; decision functions read only public prefixes."""

import numpy as np
from models import StructuralModel

TIMES = (180, 300, 420)
PUBLIC = (
    "market",
    "obs",
    "damage",
    "loss",
    "stage",
    "official",
    "wire",
    "probability",
    "cone",
)
STATIC = ("site_xy", "site_company", "site_weight")


def load_data(path, lo, hi, labels=True):
    z = np.load(path)
    ids = z["season_ids"]
    assert ids.min() >= 121
    ii = np.flatnonzero((ids >= lo) & (ids <= hi))
    d = {k: z[k][ii] for k in PUBLIC}
    d.update({k: z[k] for k in STATIC})
    d["season_ids"] = ids[ii]  # bookkeeping only, never a feature
    if labels:
        d["settlement_truth"] = z["settlement_truth"][ii, :10]
    return d


def wind_at(obs, sites):
    dist = np.linalg.norm(obs[..., None, :2] - sites, axis=-1)
    return obs[..., None, 5] * np.exp(-((dist / obs[..., None, 4]) ** 2))


def weights(d):
    w = np.zeros((len(d["site_company"]), 5))
    w[np.arange(len(w)), d["site_company"]] = d["site_weight"]
    return w


def completed_outage(d, r):
    """Only call for a finished round (or as a training label)."""
    w = wind_at(d["obs"][:, r, :240], d["site_xy"])
    # Age0 has no interval. Last observation also closes final 478..480 interval.
    return ((w[:, 1:] >= 0.35).sum(1) + (w[:, -1] >= 0.35)) @ weights(d) / 60


def snapshot(d, r, t, lag=0):
    """Vectorized public as-of snapshot, output n x p feature blocks."""
    n = len(d["market"])
    tick = max(0, (t - lag) // 2)
    oi = max(0, min(239, (t - lag - 60) // 2))
    wgt = weights(d)
    path = d["obs"][:, r, : oi + 1]
    wind = wind_at(path, d["site_xy"])
    outage = (wind[:, 1:] >= 0.35).sum(1) @ wgt / 60
    prior_d = d["damage"][:, :r, -1].sum(1)
    prior_l = d["loss"][:, :r, -1].sum(1)
    prior_o = sum((completed_outage(d, j) for j in range(r)), np.zeros((n, 5)))
    current = path[:, -1]
    clock = np.tile(np.eye(3)[r], (n, 1))
    quote = d["market"][:, r, tick, :10]
    reports = np.column_stack(
        (
            prior_d,
            prior_l,
            prior_o,
            outage,
            d["damage"][:, r, tick],
            d["loss"][:, r, tick],
            d["stage"][:, r, tick],
        )
    )
    physical = [
        reports,
        current,
        wind[:, -1] @ wgt,
        wind.max(1) @ wgt,
        wind[:, 1:].sum(1) @ wgt * 2,
    ]
    for lead in (60, 120):
        projected = current.copy()
        projected[:, :2] += current[:, 2:4] * lead
        physical.append(wind_at(projected, d["site_xy"]) @ wgt)
    physical.extend((d["probability"][:, r, tick], d["cone"][:, r, tick]))
    for source in ("official", "wire"):
        physical.append(np.eye(7)[d[source][:, r, tick] + 1])
    phys = np.column_stack(physical)
    return dict(
        price=np.column_stack((clock, quote)),
        report=np.column_stack((clock, quote, reports)),
        physical=np.column_stack((clock, phys)),
        full=np.column_stack((clock, quote, phys)),
        quote=quote,
        prior_d=prior_d,
        prior_l=prior_l,
        prior_o=prior_o,
        outage=outage,
    )


class Ridge:
    def fit(self, x, y):
        self.center = x.mean(0)
        self.scale = np.maximum(x.std(0), 1e-8)
        z = (x - self.center) / self.scale
        self.offset = y.mean(0)
        self.coef = np.linalg.solve(
            z.T @ z + 0.10 * len(z) * np.eye(z.shape[1]), z.T @ (y - self.offset)
        )
        return self

    def predict(self, x):
        return (x - self.center) / self.scale @ self.coef + self.offset


class Models:
    def fit(self, d):
        n = len(d["market"])
        settlement = d["settlement_truth"]
        self.prior = settlement.mean(0)
        self.direct = {}
        self.current = {}
        self.residual = {}
        self.drift = {}
        damage = d["damage"][:, :, -1]
        outage = np.stack([completed_outage(d, r) for r in range(3)], 1)
        prior_d = np.cumsum(damage, axis=1) - damage
        frac = damage / np.maximum(1 - prior_d, 0.001)
        self.future = [
            np.column_stack((np.clip(frac[:, r], 0, 1), outage[:, r])) for r in range(3)
        ]
        self.econ = StructuralModel().fit(
            damage.sum(1), outage.sum(1), d["loss"][:, :, -1].sum(1), settlement
        )
        self.label_fit_rmse = np.sqrt(
            np.mean(
                (
                    self.econ.predict(
                        damage.sum(1), outage.sum(1), d["loss"][:, :, -1].sum(1)
                    )[:, :10]
                    - settlement
                )
                ** 2,
                0,
            )
        )
        for k, t in enumerate(TIMES):
            snaps = [snapshot(d, r, t) for r in range(3)]
            for r in range(3):
                self.drift[r, k] = (settlement - snaps[r]["quote"]).mean(0)
            yy = np.concatenate([settlement] * 3)
            short = np.concatenate(
                [
                    d["market"][:, r, (t + 12) // 2, :10]
                    - d["market"][:, r, (t + 2) // 2, :10]
                    for r in range(3)
                ]
            )
            for key in ("price", "report", "physical", "full"):
                xx = np.concatenate([s[key] for s in snaps])
                self.direct[k, key, "terminal"] = Ridge().fit(xx, yy)
                if key in ("price", "full"):
                    self.direct[k, key, "short"] = Ridge().fit(xx, short)
            xx = np.concatenate([s["physical"] for s in snaps])
            cy = np.concatenate(
                [
                    np.column_stack((frac[:, r], outage[:, r] - snaps[r]["outage"]))
                    for r in range(3)
                ]
            )
            self.current[k] = Ridge().fit(xx, cy)
            # Cross-fit by entire season, never splitting rounds of one season.
            fold = np.tile(np.arange(n) % 3, 3)
            resid = np.zeros_like(cy)
            for f in range(3):
                mod = Ridge().fit(xx[fold != f], cy[fold != f])
                resid[fold == f] = cy[fold == f] - mod.predict(xx[fold == f])
            resid -= resid.mean(0)
            self.residual[k] = resid
        return self

    def distribution(self, s, r, k):
        means = self.current[k].predict(s["physical"])
        rng = np.random.default_rng(717 + k)  # no target identity in sampling
        rr = self.residual[k][rng.integers(len(self.residual[k]), size=256)]
        outcomes = means[:, None, :] + rr[None, :, :]
        frac = np.clip(outcomes[:, :, :5], 0, 1)
        dd = s["prior_d"][:, None, :] + (1 - s["prior_d"][:, None, :]) * frac
        oo = (
            s["prior_o"][:, None, :]
            + s["outage"][:, None, :]
            + np.maximum(outcomes[:, :, 5:], 0)
        )
        nofuture_loss = dd @ self.econ.insured_weights
        nofuture = self.econ.predict(dd, oo, nofuture_loss)[:, :, :10].mean(1)
        for future_r in range(r + 1, 3):
            pool = self.future[future_r]
            future = pool[rng.integers(len(pool), size=256)]
            dd = dd + (1 - dd) * future[None, :, :5]
            oo = oo + future[None, :, 5:]
        # Public prior loss is preserved exactly, future loss uses fitted damage weights.
        ll = (
            s["prior_l"][:, None]
            + (dd - s["prior_d"][:, None, :]) @ self.econ.insured_weights
        )
        payoffs = self.econ.predict(dd, oo, ll)[:, :, :10]
        fair = payoffs.mean(1)
        point = self.econ.predict(dd.mean(1), oo.mean(1), ll.mean(1))[:, :10]
        unsafe = ll.max(1) > self.econ.max_training_loss
        return fair, unsafe, fair - point, fair - nofuture

    def predict(self, d, lag=0):
        n = len(d["market"])
        pred = np.zeros((12, n, 3, len(TIMES), 10))
        diagnostics = {"jensen": [], "future_value": [], "unsafe_rein": []}
        for r in range(3):
            for k, t in enumerate(TIMES):
                s = snapshot(d, r, t, lag=lag)
                quote = d["market"][:, r, t // 2, :10]
                pred[0, :, r, k] = quote
                pred[1, :, r, k] = self.prior
                for c, key in (
                    (2, "price"),
                    (3, "report"),
                    (4, "physical"),
                    (5, "full"),
                ):
                    pred[c, :, r, k] = self.direct[k, key, "terminal"].predict(s[key])
                fair, unsafe, jensen, future = self.distribution(s, r, k)
                pred[6, :, r, k] = fair
                pred[7, :, r, k] = (fair + pred[2, :, r, k]) / 2
                pred[6:8, unsafe, r, k, 9] = np.nan
                pred[8, :, r, k] = quote + self.drift[r, k]
                pred[9, :, r, k] = pred[5, :, r, k]
                for c, key in ((10, "price"), (11, "full")):
                    pred[c, :, r, k] = self.direct[k, key, "short"].predict(s[key])
                diagnostics["jensen"].append(jensen)
                diagnostics["future_value"].append(future)
                diagnostics["unsafe_rein"].append(unsafe)
        return pred, {k: np.stack(v, 1) for k, v in diagnostics.items()}
