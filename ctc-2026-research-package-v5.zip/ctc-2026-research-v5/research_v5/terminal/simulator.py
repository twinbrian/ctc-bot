"""Standalone continuous-season account: separate delayed cash fills, one settlement."""

import numpy as np
from common import LIMITS
from research_v5.terminal.model import TIMES


def desired_inventory(fair, quote, effective_inventory, limits, bps=25, fixed=0.02):
    gap = fair - quote
    active = np.isfinite(gap) & (np.abs(gap) > quote * bps / 10000 + fixed + 0.25)
    return np.where(
        active, np.sign(np.nan_to_num(gap)) * limits, effective_inventory
    ).astype(int)


def simulate(
    market,
    settlement,
    predictions,
    candidate,
    *,
    latency=2,
    bps=25,
    fixed=0.02,
    depth=50,
    adverse=0,
    audit=False,
):
    n = len(market)
    prices = market[:, :, :, :10].reshape(n, -1, 10)
    q = np.zeros((n, 10), int)
    buys = np.zeros_like(q)
    sells = np.zeros_like(q)
    cash = np.zeros((n, 10))
    costs = np.zeros_like(cash)
    turnover = np.zeros_like(cash)
    counts = np.zeros((n, 1170), int)
    history = np.zeros((n, 30), int)
    used = np.zeros(n, int)
    carry = np.zeros((n, 2, 10), int)
    limit = LIMITS[:10].astype(int).copy()
    if candidate >= 9:
        limit = np.minimum(limit, 50)
    delay = max(1, int(np.ceil(latency / 2)))
    queue = [[] for _ in range(1170 + delay)]
    rows = np.arange(n)
    max_window = np.zeros(n, int)
    blocked = np.zeros(n, int)
    fill_log = []
    for tick in range(1170):
        slot = tick % 30
        used -= history[:, slot]
        history[:, slot] = 0
        price = prices[:, tick]
        for ii, jj, qty in queue[tick]:
            buys[ii, jj] -= np.maximum(qty, 0)
            sells[ii, jj] -= np.maximum(-qty, 0)
            unit = price[ii, jj] * (bps + adverse) / 10000 + fixed
            cash[ii, jj] -= qty * price[ii, jj] + np.abs(qty) * unit
            costs[ii, jj] += np.abs(qty) * unit
            turnover[ii, jj] += np.abs(qty)
            q[ii, jj] += qty
            if audit:
                fill_log.extend(
                    zip(
                        ii.tolist(),
                        [tick * 2] * len(ii),
                        jj.tolist(),
                        qty.tolist(),
                        price[ii, jj].tolist(),
                    )
                )
        assert np.all(q + buys <= LIMITS[:10]) and np.all(q - sells >= -LIMITS[:10])
        r, local = divmod(tick, 390)
        t = local * 2
        if t == 778 and r < 2:
            carry[:, r] = q
        if candidate == 0:
            continue
        effective = q + buys - sells
        k = next((j for j, start in enumerate(TIMES) if start <= t < start + 60), None)
        if k is None:
            continue
        fair = predictions[:, r, k]
        if candidate >= 10:
            if t == TIMES[k]:
                edge = np.abs(fair) - 2 * (price * bps / 10000 + fixed) - 0.25
                target = np.where(edge > 0, np.sign(fair) * limit, 0).astype(int)
            elif t >= TIMES[k] + 10:
                target = np.zeros_like(q)
            else:
                continue
            gap = target - effective
            score = (
                np.maximum(edge, 0) * np.minimum(np.abs(gap), depth)
                if t == TIMES[k]
                else np.abs(gap).astype(float)
            )
        else:
            target = desired_inventory(fair, price, effective, limit, bps, fixed)
            gap = target - effective
            edge = np.abs(fair - price) - price * bps / 10000 - fixed - 0.25
            score = np.nan_to_num(edge, nan=-1) * np.minimum(np.abs(gap), depth)
        side = np.sign(gap).astype(int)
        room = np.where(side > 0, limit - q - buys, limit + q - sells)
        qty = side * np.minimum(np.minimum(np.abs(gap), depth), np.maximum(room, 0))
        score[qty == 0] = -np.inf
        order = np.argsort(-score, axis=1, kind="stable")
        for rank in range(10):
            jj = order[:, rank]
            valid = (score[rows, jj] > 0) & (used < 60)
            blocked += (score[rows, jj] > 0) & (used >= 60)
            ii = rows[valid]
            j = jj[valid]
            qq = qty[ii, j]
            if not len(ii):
                continue
            assert tick + delay < 1170
            queue[tick + delay].append((ii.copy(), j.copy(), qq.copy()))
            buys[ii, j] += np.maximum(qq, 0)
            sells[ii, j] += np.maximum(-qq, 0)
            used[ii] += 1
            history[ii, slot] += 1
            counts[ii, tick] += 1
        max_window = np.maximum(max_window, used)
        assert (used <= 60).all()
    assert not buys.any() and not sells.any()
    attribution = cash + q * settlement
    result = dict(
        pnl=attribution.sum(1),
        attribution=attribution,
        cost=costs.sum(1),
        turnover=turnover.sum(1),
        actions=counts.sum(1),
        max_rolling_actions=max_window,
        positions=q,
        carry=carry,
        action_ticks=counts,
        blocked=blocked,
    )
    if audit:
        result["fills"] = np.array(fill_log)
    return result
