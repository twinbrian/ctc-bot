# Remaining-season risk: preregistration

Registered before scoring, 2026-10-19. Whole seasons: fit 361–600,
inner 241–360; only if the gate below passes, refit 241–600 and open frozen,
previously observed diagnostic 121–240. Never load seasons 1–120. Decisions
exclude season identity, dates, manifest labels, future paths and exact replay
recognition. Model labels may use training final reports and settlement.

## Hypothesis and fixed capacity

Post-formation prices may underreact to remaining *season* damage, including the
unseen storms after rounds 1 and 2. Forecast terminal expected payoff rather than
the payoff of an expected loss. This differs from v4 post-dissipation and nearest-
neighbor insurer analog research. Read case.json and models.py before defining it.

Decision checkpoints are real seconds 180, 300, 420 in each of three rounds.
No new signal after dissipation. Direct regressions use one fixed standardized
ridge penalty of 0.10 times row count and one model per checkpoint, pooled across
rounds with round one-hot. No hyperparameter search, polynomial expansion or trees.
Direct settlement targets estimate expected nonlinear payoff, including future
storms. Ten-second controls predict the price change from t+2 to t+12.

Physical features: already-published cumulative prior damage/loss, prior and
current outage prefix, current storm location/velocity/radius/intensity, weighted
wind/exposure/peak by company, linear-path projected company wind (60/120s,
not actual future paths), official probabilities/cone and outlook, wire outlook.
Price controls use current ten stock quotes plus round and checkpoint only.

Structural distribution: fit the existing economics on training seasons only.
At each checkpoint, ridge predicts current-storm final damage as fraction of
remaining undamaged assets and remaining outage. Add empirical joint training
residuals (not neighbor selection); clip physical support. Independently draw
unconditional training storm damage fractions/outages for each still-unseen
round, applying each fraction to remaining assets. Average 256 simulated terminal
payoffs. Shared deterministic Monte Carlo draws do not depend on season identity.
REIN above the fitted loss range is suppressed for structural policies because
its detachment is unidentified. Save the frequency and Jensen gap. Forecast-only
diagnostics compare omission of future storms and payoff(mean loss); they are
not selectable trading candidates.

## Exactly 12 candidates

| ID | Fair value | Execution |
|---|---|---|
| C00 | Current price | No trade |
| C01 | Training unconditional terminal mean | Full stock limits |
| C02 | Price/round/checkpoint ridge terminal payoff | Full stock limits |
| C03 | C02 plus reports and outage prefix | Full stock limits |
| C04 | Physical/guidance ridge terminal payoff without quotes | Full stock limits |
| C05 | Full physical/guidance plus quotes, ridge terminal payoff | Full stock limits |
| C06 | Structural remaining-season payoff distribution | Full stock limits |
| C07 | Fixed 50/50 C06 and C02 fair-value blend | Full stock limits |
| C08 | Current quote plus training mean terminal-minus-quote at this round/time | Full stock limits |
| C09 | C05 | 50 shares per stock cap |
| C10 | Price/round/checkpoint ridge ten-second move | One clip, exit t+10 |
| C11 | Full physical/guidance plus quotes ridge ten-second move | One clip, exit t+10 |

No ETFs/conversions in this sleeve. All entries/rebalances pay 25bps plus
USD0.02 per share per side, arrive 2 seconds later, and share one central
60-actions/rolling real minute and 50-shares/symbol/2s depth. Rounds are contiguous
780s blocks; cash, inventory and rate history carry between rounds. Terminal
settlement is applied once after round3, with no invented settlement fee.

Terminal policies update the fair value only at checkpoints, permit orders during
the next 60s, and otherwise carry inventory. At each order decision, compare that
fixed fair to the latest available price. Target +limit or -limit only if the gap
exceeds modeled one-way costs plus USD0.25; otherwise retain inventory (hysteresis).
Prioritize orders by forecast marginal net USD contribution. Respect positive and
negative pending-order reservations separately. Single-clip cap policies use the
same execution logic. Short controls enter at the checkpoint only, use modeled
round-trip costs plus USD0.25, and submit exits ten real seconds after entry
decision. Thus C09/C11 compare matched *position caps*, not identical turnovers.

## Selection and stress

Primary ranking is mean terminal net USD PnL per whole season. Save all twelve
candidates, per-season cash/cost/actions, symbol attribution and inter-round
positions. Evaluate baseline, latency6, double-cost (50bps+USD0.04), depth25, and
combined (6s, double-cost, depth25, adverse10bps) separately.

The pre-scoring parent-request amendment below governs selection and adds C08
as the time/round-only expected-drift comparator. C04 remains physical/no quotes.
All initial draft clarifications were completed before any fit or PnL scoring.
Before validation, freeze candidates and all specifications. Validation evaluates
the selected candidates and C00/C01/C02/C09/C10/C11 controls once; no retuning.
Report paired season bootstrap uncertainty, mean/median/worst/p05/worst5%mean,
win rate, actions, costs and forecast errors. Standalone findings are not additive
to formation; parent owns common-account combination and capacity arbitration.

## Known feed limitation and resources

### Pre-scoring parent-request amendment

Before fitting/scoring, parent requested an explicit time/round-only expected
drift comparator alongside C01's unconditional terminal mean. C08 therefore
replaces the insurer-only subset; still exactly 12 candidates. It estimates
E[terminal settlement - quote at this checkpoint] using training seasons and
adds that constant to the current checkpoint quote. This is not physical alpha.
Selection is correspondingly broadened to allow the prior to win: open validation
if any full-capacity terminal C01–C08 has positive baseline and combined-stress
means and baseline exceeds USD100. Freeze the highest-baseline eligible terminal
candidate and, only if distinct, the best eligible physical C03–C07 that beats
the best of C01/C02/C08 by USD100. This supersedes the earlier physical-only gate.
No outcomes were read before this amendment. Controls include C01/C02/C08 and
matched-cap C09/C10/C11 in frozen validation. C04 remains the no-quote ablation.

The supplied cube has observation age but lacks receipt timestamps. No claim that
canonical delayed publication is fixed. A fixed +10s information lag diagnostic
will be reported if validation opens. Models access only prefix observations.
Zero pre-session spend baseline; initial observed cumulative cost USD1.77 includes
startup. Stop new research at cumulative USD60, hard allocation USD75. At most
two CPU processes and one BLAS/OMP thread, checkpointed tmux jobs, no descendants
or paid resources. Preserve all checkpoints; active-time limit excludes restart
downtime. Initial extraction/reading was about 3 active minutes before restart.
