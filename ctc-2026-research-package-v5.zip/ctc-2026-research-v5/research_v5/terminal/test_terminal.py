import copy
import numpy as np

from research_v5.terminal.model import load_data, snapshot
from research_v5.terminal.simulator import simulate


def test_single_terminal_settlement_and_entry_cost():
    market = np.full((1, 3, 390, 12), 100.0)
    fair = np.full((1, 3, 3, 10), np.nan)
    fair[:, :, :, 0] = 110
    settlement = np.full((1, 10), 110.0)
    a = simulate(market, settlement, fair, 9, audit=True)
    assert a["actions"][0] == 1
    assert a["positions"][0, 0] == 50
    assert np.all(a["carry"][0, :, 0] == 50)
    assert abs(a["cost"][0] - 13.5) < 1e-9
    assert abs(a["pnl"][0] - 486.5) < 1e-9
    assert a["fills"][0, 1] == 182


def test_arrival_price_not_decision_price():
    market = np.full((1, 3, 390, 12), 100.0)
    market[:, 0, 91:, 0] = 103
    market[:, 1:, :, 0] = 103
    fair = np.full((1, 3, 3, 10), np.nan)
    fair[:, :, :, 0] = 110
    a = simulate(market, np.full((1, 10), 110.0), fair, 9)
    assert abs(a["pnl"][0] - (50 * 7 - 50 * (103 * 0.0025 + 0.02))) < 1e-9


def test_round_trip_short_horizon_and_zero_terminal_inventory():
    market = np.full((1, 3, 390, 12), 100.0)
    # Forecast only at first checkpoint; actual fixed ten-second gain is 2.
    fair = np.zeros((1, 3, 3, 10))
    fair[:, 0, 0, 0] = 2
    market[:, 0, 96:, 0] = 102
    a = simulate(market, np.full((1, 10), 999.0), fair, 11)
    assert not a["positions"].any()
    assert a["actions"][0] == 2
    assert abs(a["pnl"][0] - (100 - 50 * (0.27 + 0.275))) < 1e-8


def test_rolling_capacity_and_actual_fill_depth():
    market = np.full((1, 3, 390, 12), 100.0)
    fair = np.full((1, 3, 3, 10), 150.0)
    fair[:, :, 1, :] = 50
    a = simulate(market, np.full((1, 10), 100.0), fair, 5, latency=6, audit=True)
    counts = a["action_ticks"][0]
    windows = np.convolve(counts, np.ones(30, dtype=int), "full")[:1170]
    assert windows.max() <= 60
    assert windows.max() == a["max_rolling_actions"][0]
    fills = a["fills"]
    for t in np.unique(fills[:, 1]):
        for j in range(10):
            assert np.abs(fills[(fills[:, 1] == t) & (fills[:, 2] == j), 3]).sum() <= 50
    assert np.all(
        a["positions"][0]
        <= np.array([200, 300, 500, 400, 800, 500, 700, 600, 250, 200])
    )


def test_prefix_invariance_under_future_and_label_mutation():
    d = load_data("research_v4/development.npz", 361, 362)
    r, t = 1, 300
    before = snapshot(d, r, t)
    altered = copy.deepcopy(d)
    oi = (t - 60) // 2
    altered["obs"][:, r, oi + 1 :] = 777
    altered["obs"][:, r + 1 :] = 777
    for key in (
        "market",
        "damage",
        "loss",
        "stage",
        "official",
        "wire",
        "probability",
        "cone",
    ):
        altered[key][:, r, t // 2 + 1 :] = 0
        altered[key][:, r + 1 :] = 0
    altered["settlement_truth"][:] = -999
    altered["season_ids"][:] = 999999
    after = snapshot(altered, r, t)
    for key in before:
        np.testing.assert_array_equal(before[key], after[key])
