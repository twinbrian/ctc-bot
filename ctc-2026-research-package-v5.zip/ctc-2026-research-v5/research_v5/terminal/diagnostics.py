"""Frozen reporting, declared information-lag stress and independent fill audit."""

import json
from pathlib import Path
import pickle
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
import numpy as np
from common import LIMITS, SYMBOLS
from research_v5.terminal.interface import checkpoint_fair_value
from research_v5.terminal.model import TIMES, load_data
from research_v5.terminal.run import SCENARIOS, npz, summary, write
from research_v5.terminal.simulator import simulate

HERE = Path(__file__).resolve().parent


def paired(a, b):
    delta = a - b
    draws = np.random.default_rng(8281).choice(delta, (5000, len(delta))).mean(1)
    return dict(
        mean=float(delta.mean()),
        ci95=np.quantile(draws, [0.025, 0.975]).tolist(),
        win_rate=float((delta > 0).mean()),
    )


def audit_fills(d, prediction, scenario):
    config = SCENARIOS[scenario]
    actual = simulate(
        d["market"], d["settlement_truth"], prediction, 5, audit=True, **config
    )
    fills = actual["fills"]
    n = len(d["market"])
    q = np.zeros((n, 10), int)
    cash = np.zeros((n, 10))
    costs = np.zeros(n)
    quote = d["market"][:, :, :, :10].reshape(n, 1170, 10)
    bps, fixed, adverse = (
        config.get("bps", 25),
        config.get("fixed", 0.02),
        config.get("adverse", 0),
    )
    ids, ticks, js, qty = [fills[:, k].astype(int) for k in range(4)]
    px = quote[ids, ticks // 2, js]
    np.testing.assert_allclose(px, fills[:, 4], rtol=0, atol=0)
    np.add.at(q, (ids, js), qty)
    fee = np.abs(qty) * (px * (bps + adverse) / 10000 + fixed)
    np.add.at(cash, (ids, js), -qty * px - fee)
    np.add.at(costs, ids, fee)
    pnl = (cash + q * d["settlement_truth"]).sum(1)
    np.testing.assert_allclose(pnl, actual["pnl"], rtol=0, atol=1e-8)
    np.testing.assert_allclose(costs, actual["cost"], rtol=0, atol=1e-8)
    np.testing.assert_array_equal(q, actual["positions"])
    assert np.all(np.abs(q) <= LIMITS[:10])
    # Independently recompute all rolling real-minute windows and fill buckets.
    rolling = np.stack(
        [
            np.convolve(a, np.ones(30, dtype=int), "full")[:1170]
            for a in actual["action_ticks"]
        ]
    )
    assert rolling.max() <= 60
    key = (ids * 1170 + ticks // 2) * 10 + js
    volume = np.bincount(key, weights=np.abs(qty))
    assert volume.max() <= config.get("depth", 50)
    return dict(
        fills=len(fills),
        cash_settlement_identity=True,
        arrival_prices_verified=True,
        max_rolling_actions=int(rolling.max()),
        max_fill_shares_per_symbol_per_2s=float(volume.max()),
        net_pnl_mean=float(pnl.mean()),
    )


def main():
    report = {}
    for phase, (lo, hi) in [("inner", (241, 360)), ("validation", (121, 240))]:
        directory = HERE / phase
        model = pickle.loads((directory / "models.pkl").read_bytes())
        pred = np.load(directory / "predictions.npz")["predictions"]
        dd = np.load(directory / "distribution_diagnostics.npz")
        d = load_data(ROOT / "research_v4/development.npz", lo, hi)
        base = np.load(directory / "C05_baseline.npz")
        control = np.load(directory / "C02_baseline.npz")
        clip = np.load(directory / "C09_baseline.npz")
        short = np.load(directory / "C11_baseline.npz")
        facts = dict(
            full_minus_priceclock=paired(base["pnl"], control["pnl"]),
            matched_cap_terminal_minus_short=paired(clip["pnl"], short["pnl"]),
            jensen_by_round=dd["jensen"]
            .reshape(len(d["market"]), 3, 3, 10)
            .mean((0, 2))
            .tolist(),
            future_storm_value_by_round=dd["future_value"]
            .reshape(len(d["market"]), 3, 3, 10)
            .mean((0, 2))
            .tolist(),
            structural_rein_suppression=float(dd["unsafe_rein"].mean()),
            carry_signed_mean=base["carry"].mean(0).tolist(),
            carry_long_fraction=(base["carry"] > 0).mean(0).tolist(),
            carry_short_fraction=(base["carry"] < 0).mean(0).tolist(),
        )
        # Same frozen models, fixed predeclared sensitivity; no policy selection.
        lagpath = directory / "lag10_predictions.npz"
        if lagpath.exists():
            lag = np.load(lagpath)["predictions"]
        else:
            lag, _ = model.predict(d, lag=10)
            npz(lagpath, predictions=lag)
        facts["lag10"] = {}
        for scenario in ["baseline", "combined"]:
            path = directory / f"C05_lag10_{scenario}.npz"
            if path.exists():
                result = dict(np.load(path))
            else:
                result = simulate(
                    d["market"], d["settlement_truth"], lag[5], 5, **SCENARIOS[scenario]
                )
                npz(path, **result)
            facts["lag10"][scenario] = summary(result)
        if phase == "validation":
            public = {
                k: v
                for k, v in d.items()
                if k not in ["settlement_truth", "season_ids"]
            }
            for r in range(3):
                for k, t in enumerate(TIMES):
                    fair = checkpoint_fair_value(model, public, r, t)
                    np.testing.assert_allclose(
                        fair, pred[5, :, r, k], rtol=0, atol=1e-12
                    )
            facts["interface_parity"] = True
            facts["fill_audit"] = {
                s: audit_fills(d, pred[5], s) for s in ["baseline", "combined"]
            }
        report[phase] = facts
        write(HERE / "diagnostics.json", report)
    print(json.dumps(report, indent=2), flush=True)


if __name__ == "__main__":
    main()
