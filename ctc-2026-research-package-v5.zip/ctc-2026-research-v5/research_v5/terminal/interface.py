"""Causal signal interface. Execution/rate limits belong to the common account.

round_index is zero-based; second is real seconds within the 780-second round.
The public cube may contain only PUBLIC/STATIC keys from model.py. Labels and
season IDs are neither accepted as features nor required by these functions.
"""

import numpy as np
from common import LIMITS, SYMBOLS
from research_v5.terminal.model import TIMES, snapshot
from research_v5.terminal.simulator import desired_inventory


def checkpoint_fair_value(fitted_model, public_cube, round_index, second, candidate=5):
    """Return n x 10 terminal expected payoffs at one scheduled checkpoint.

    Frozen candidate C05 only. C01/C02/C08 are explicitly labeled comparators.
    Parent may cache this output until the next checkpoint, but may execute only
    in the 60-second checkpoint windows evaluated in the standalone research.
    """
    assert second in TIMES and 0 <= round_index < 3
    k = TIMES.index(second)
    state = snapshot(public_cube, round_index, second)
    if candidate == 5:
        return fitted_model.direct[k, "full", "terminal"].predict(state["full"])
    if candidate == 1:
        return np.broadcast_to(fitted_model.prior, state["quote"].shape).copy()
    if candidate == 2:
        return fitted_model.direct[k, "price", "terminal"].predict(state["price"])
    if candidate == 8:
        return state["quote"] + fitted_model.drift[round_index, k]
    raise ValueError("Not a frozen candidate or requested comparator")


def inventory_proposal(
    fair,
    current_quote,
    positions,
    pending_buys,
    pending_sells,
    second,
    bps=25,
    fixed=0.02,
):
    """Return desired account stock inventory; never send an order itself.

    Inputs may be shape(10,) or (n,10). Pending quantities are nonnegative.
    Target is TOTAL desired stock inventory, not an additional independent sleeve.
    Opposing intents from formation need explicit arbitration, not addition.
    No liquidation at round boundaries is requested; terminal settlement once.
    """
    effective = np.asarray(positions) + pending_buys - pending_sells
    active = any(start <= second < start + 60 for start in TIMES)
    desired = (
        desired_inventory(
            np.asarray(fair),
            np.asarray(current_quote),
            effective,
            LIMITS[:10],
            bps,
            fixed,
        )
        if active
        else effective.copy()
    )
    return dict(
        symbols=SYMBOLS[:10],
        terminal_fair=np.asarray(fair),
        desired_inventory=desired,
        execution_window=active,
        hold_between_rounds=True,
        standalone_only=True,
        required_common_action_limiter=True,
    )
