# Fixed-model information-lag sensitivity

No new trading policies, refits or tuning. At the fixed180-second decision, give
the frozen HGB all current-round features/quotes only through170 or150 (10/30s
staleness). Public completed prior rounds remain available. The predicted stock
change must be anchored to the stale feature quote to construct exit fair, then
subtract the actually current180 quote for the order signal. ETF exit fair is the
stock basket. This avoids crediting already-realized price moves to a late bot.

Zero-lag parity must match every saved baseline/strict PnL. Test10/30s under base
and strict combined execution, all five existing disjoint-fit folds. These are
deliberate stale-input distribution stresses, not calibrated network probabilities
or a repair for absent recorded receipt times. Formation/final inputs are held
unchanged; the scope is the active HGB forecast only. No best-lag choice.
