import numpy as np

from common import BASKETS
from research_v5.event_account import run


def test_combined_event_account_conserves_constant_market_cash():
    market = np.full((2, 3, 390, 12), 100.0)
    market[..., 10:] = market[..., :10] @ BASKETS.T
    truth = market[:, 2, -1].copy()
    curve = market[0].copy()
    curve[:, 51:57, 0] += 8
    prediction = {"delta": np.zeros_like(market), "source": np.zeros((2, 3, 390), int)}
    prediction["delta"][:, :, 90, 0] = 3
    prediction["source"][:, :, 90] = 1
    result = run(market, truth, curve, truth, prediction, latency=6, depth=25)
    assert np.all(result["cost"] > 0)
    np.testing.assert_allclose(result["pnl"], -result["cost"], atol=1e-8)
    assert not result["positions"].any()
    assert np.all(result["max_rolling_actions"] <= 60)
    assert np.all(result["phase_flat_times"] <= 700)
