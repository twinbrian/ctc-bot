import numpy as np

from research_v5.scheduled_account import run, shifted


def fixture():
    market = np.full((2, 3, 390, 12), 100.0)
    curve = market[0].copy()
    curve[:, 20:65, :5] += 4
    curve[:, 270:, :5] -= 10
    truth = np.full((2, 12), 100.0)
    return market, truth, curve, truth.copy()


def test_local_clock_translation_preserves_observations():
    source = np.arange(390)[None, None, :, None]
    translated = shifted(source, 180)
    np.testing.assert_array_equal(translated[0, 0, :300, 0], np.arange(90, 390))
    assert np.all(translated[0, 0, 300:, 0] == 389)


def test_static_market_cannot_manufacture_cash_from_routes():
    market, truth, curve, fair = fixture()
    # Set ETF quotes to exact basket parity so conversions cannot capture basis.
    from common import BASKETS

    market[..., 10:] = market[..., :10] @ BASKETS.T
    truth[:, 10:] = truth[:, :10] @ BASKETS.T
    fair = truth.copy()
    curve[..., 10:] = curve[..., :10] @ BASKETS.T
    result = run(market, truth, curve, fair, entry=180, exit_at=540)
    np.testing.assert_allclose(result["pnl"], -result["cost"], atol=1e-8)
    assert result["max_rolling_actions"].max() <= 60
    assert result["max_position_fraction"].max() <= 1
    assert np.all(result["positions"] == 0)
    assert np.all(result["action_ticks"][:, :, 80:90] == 0)


def test_no_actions_or_executions_in_padding():
    args = fixture()
    result = run(*args, entry=300, exit_at=660, latency=6, depth=25)
    assert np.all(result["phase_flat_times"] < 780)
    assert result["max_rolling_actions"].max() <= 60


def test_per_account_jump_matches_clock_default_when_equal():
    from etf_route_v3 import simulate_routes

    market, truth, curve, _ = fixture()
    jump = curve[:, 51:57].mean(1) - curve[:, 10]
    override = np.broadcast_to(jump, (2, 3, 12)).copy()
    default = simulate_routes(market, truth, curve, start=20, exit_at=100, audit=True)
    conditional = simulate_routes(
        market, truth, curve, start=20, exit_at=100, audit=True, forecast_jump=override
    )
    for key in default:
        np.testing.assert_array_equal(default[key], conditional[key])


def test_per_account_jumps_are_not_broadcast_across_accounts():
    from etf_route_v3 import simulate_routes

    market, truth, curve, _ = fixture()
    jump = np.zeros((2, 3, 12))
    jump[0, :, 0] = 5
    full = simulate_routes(market, truth, curve, exit_at=100, forecast_jump=jump)
    assert full["actions"][0] > 0
    assert full["actions"][1] == 0
