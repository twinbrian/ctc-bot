# One bounded long-horizon clock-drift benchmark

Hypothesis: the post-formation house consensus has a predictable remaining-round
drift that ten-second trading loses to repeated fees. Test the simplest train-only
clock/round mean-path signal before attributing gains to complex weather forecasts.

Declare exactly8 candidates: entry second180 or300, earliest exit540 or660,
exposure fraction0.5 or1.0. Forecast is the training mean price change from entry
to the exit-arrival window, anchored at the current price. Same fee gate, routed
basket execution,50-share clips and legal limits as v3. No threshold/model tuning.
Acquire for at most60 seconds. Hold through intermediate news without rebalancing.

Fit curve and economics361–600; inner evaluation241–360. Frozen formation20/100
and exact final-report engine are common. The candidate REPLACES the ten-second
tail, it is not an additive sleeve. Include formation+final-only and the unchanged
wait60 tail as controls. Select highest inner mean including incumbent. Freeze at
most one challenger before diagnostic121–240 with refit241–600. No1–120 access.

Run one continuous action ledger across actual phases and round boundaries.
If formation is not truly flat plus depth cooldown by the fixed entry time, skip
that season-round's new phase. At second740, final-report trading is allowed only
where all earlier phases are flat plus cooldown; otherwise skip it. Never reset
inventory or count conversion marks as cash. Market legs execute after latency.

Implement a local-clock translation around the existing audited route primitive:
phase time0 equals declared entry time; pass actual preceding60s actions; map all
actions and flat times back to the original round. Reject any trade/fill beyond
the actual close. Repeated last-price padding is computational shape only and may
not generate any action or execution. Verify these properties synthetically.

Fixed scenarios:baseline;50bps;latency6;depth25;50bps+latency6+depth25;extra10bps.
All8 inner policies baseline only; apply fixed stresses to the frozen challenger
and incumbent. No outcome-based stress retuning. Save negative policies and label
all data as previously observed/post-selection, not fresh holdout proof.
