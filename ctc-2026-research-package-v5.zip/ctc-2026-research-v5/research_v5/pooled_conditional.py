"""Broader fixed-model replay; no hyperparameter or policy selection."""

import hashlib
import json
import pickle
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from research_v4.lab import summarize_pnl
from research_v5.clock_forecast.forecast import HGB_PARAMS, DriftModels
from research_v5.conditional_research import coherent_jump
from research_v5.handoff_research import npz, write_json
from research_v5.pooled_clock import SCENARIOS
from research_v5.scheduled_account import run
from research_v5.terminal.model import PUBLIC, STATIC

OUT = ROOT / "research_v5/pooled_conditional"


def main():
    OUT.mkdir(exist_ok=True)
    if (OUT / "COMPLETE.json").exists():
        return
    frozen = json.loads((ROOT / "research_v5/conditional/frozen.json").read_text())
    assert frozen["selected"] == "hgb"
    d = dict(np.load(ROOT / "cache.npz"))
    rows = []
    for fold in range(5):
        original = dict(np.load(ROOT / f"results_v2/fold-{fold}-predictions.npz"))
        train, ids = original["train_ids"], original["test_ids"]
        assert not set(train) & set(ids)
        model_path = OUT / f"fold{fold}_models.pkl"
        jump_path = OUT / f"fold{fold}_predictions.npz"
        if jump_path.exists():
            saved = dict(np.load(jump_path))
            np.testing.assert_array_equal(saved["season_ids"], ids + 1)
            stock_jump = saved["jump"]
        else:
            if model_path.exists():
                model = pickle.loads(model_path.read_bytes())
            elif fold == 0:
                # Exactly the same fit membership as the completed diagnostic model.
                np.testing.assert_array_equal(train, np.arange(240, 600))
                model = pickle.loads(
                    (
                        ROOT / "research_v5/clock_forecast/diagnostic/models.pkl"
                    ).read_bytes()
                )
            else:
                fitting = {k: d[k][train] for k in PUBLIC}
                fitting.update({k: d[k] for k in STATIC})
                model = DriftModels().fit(fitting)
            temp = model_path.with_suffix(".tmp")
            temp.write_bytes(pickle.dumps(model))
            temp.replace(model_path)
            public = {k: d[k][ids] for k in PUBLIC}
            public.update({k: d[k] for k in STATIC})
            stock_jump = model.predict_public(public)["hgb"]
            npz(
                jump_path,
                jump=stock_jump,
                season_ids=ids + 1,
                train_season_ids=train + 1,
            )
        take = np.array([np.flatnonzero(original["ids"] == i)[0] for i in ids])
        market, truth = d["market"][ids], d["settlement_truth"][ids]
        jump = coherent_jump(stock_jump, market[:, :, 90])
        for scenario, settings in SCENARIOS.items():
            path = OUT / f"fold{fold}_{scenario}.npz"
            if path.exists():
                result = dict(np.load(path))
            else:
                result = run(
                    market,
                    truth,
                    original["formation_curve"],
                    original["final_fair"][take],
                    entry=180,
                    exit_at=540,
                    fraction=1.0,
                    forecast_jump=jump,
                    **settings,
                )
                npz(path, **result, season_ids=ids + 1)
            row = {"fold": fold, "scenario": scenario, **summarize_pnl(result["pnl"])}
            rows.append(row)
            write_json(OUT / "fold_metrics.json", rows)
            print(json.dumps(row), flush=True)
    pooled = []
    for scenario in SCENARIOS:
        parts = [dict(np.load(OUT / f"fold{f}_{scenario}.npz")) for f in range(5)]
        keys = [
            "pnl",
            "cost",
            "actions",
            "attribution",
            "by_engine",
            "season_ids",
            "max_rolling_actions",
        ]
        combined = {k: np.concatenate([p[k] for p in parts]) for k in keys}
        assert len(set(combined["season_ids"])) == 600
        npz(OUT / f"pooled_{scenario}.npz", **combined)
        row = {
            "scenario": scenario,
            **summarize_pnl(combined["pnl"]),
            "mean_cost_usd": float(combined["cost"].mean()),
            "mean_actions": float(combined["actions"].mean()),
            "worst5_mean_usd": float(np.sort(combined["pnl"])[:30].mean()),
            "mean_engine_pnl": combined["by_engine"].mean(0).tolist(),
        }
        clock = dict(
            np.load(ROOT / f"research_v5/pooled_clock/pooled_clock_{scenario}.npz")
        )
        np.testing.assert_array_equal(combined["season_ids"], clock["season_ids"])
        row["paired_vs_clock"] = summarize_pnl(combined["pnl"] - clock["pnl"])
        row["gross_increment_usd"] = float(
            (combined["pnl"] + combined["cost"] - clock["pnl"] - clock["cost"]).mean()
        )
        row["cost_saved_usd"] = float((clock["cost"] - combined["cost"]).mean())
        pooled.append(row)
    write_json(OUT / "pooled_metrics.json", pooled)
    paths = [
        "research_v5/pooled_conditional.py",
        "research_v5/clock_forecast/forecast.py",
        "research_v5/terminal/model.py",
        "research_v5/scheduled_account.py",
        "etf_route_v3.py",
    ]
    write_json(
        OUT / "COMPLETE.json",
        {
            "policy": frozen,
            "model_parameters": HGB_PARAMS,
            "source_hashes": {
                p: hashlib.sha256((ROOT / p).read_bytes()).hexdigest() for p in paths
            },
            "qualification": "All600 previously observed; fixed policy, held-out fitting by season; post-selection",
        },
    )


if __name__ == "__main__":
    main()
