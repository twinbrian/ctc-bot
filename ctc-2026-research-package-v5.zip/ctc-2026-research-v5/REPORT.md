# CTC 2026: Hurricane Season trading research

## Recommendation

Run two complementary engines:

1. **Short-horizon house-repricing trades**, especially when each storm forms. Predict the next 10-second price change, trade only when it covers both sides of execution costs, and flatten on schedule.
2. **Final-report settlement trades** in round 3. Reconstruct fundamental values from reported damage and measured outages, then submit price-capped orders against stale prices.

The main empirical edge is a repeatable formation-time repricing, with the ETFs reacting later than their constituents. This is a more useful starting point than trying to forecast an entire hurricane perfectly.

**Locked holdout result:** under the baseline hypothetical execution model, the combined strategy averaged **USD 2,077 per season**, with a median of **USD 2,019**, and made money in **118 of 120 seasons**. The worst season lost **USD 750**. A season-level bootstrap puts the mean's 95% interval at **USD 1,887–2,283**.

These are **consensus-price execution scenarios**, not verified executable profits. The supplied data has no spreads, order books, fills, queues, or competitor responses. A 12-second execution delay makes the combined strategy unprofitable. Testnet measurements are the next gating input.

![Holdout performance and execution sensitivity](results/research-dashboard.png)

## 1. Data and experimental design

The supplied archive contains 600 simulated seasons, 1,800 storms, and 702,000 house-consensus price rows. Each season has three rounds and 12 instruments. The underlying sites, baskets, limits and descriptions come from `case.json`; feed semantics come from the case packet and archive README.

The split follows the packet's unusual date convention: larger season numbers are older.

| Partition | Seasons | Purpose |
|---|---|---|
| Training | 600 through 241: 360 seasons | Fit economics, weather features and predictive models |
| Validation | 240 through 121: 120 seasons | Select trading windows, thresholds, sizing and execution configuration |
| Locked test | 120 through 1: 120 seasons | Evaluate frozen strategies and predefined stress scenarios |

All three storms of a season remain in the same partition. The unit of inference and bootstrap resampling is the whole season, not an individual price tick. Positions and accumulated losses are never reset between rounds in the directional challenger; the selected short-horizon engine deliberately closes positions during each round.

The training labels include settlements and future prices. **The predictors do not include future tracks, manifest patterns, erratic-transition times, future reports, final settlements, season IDs, dates, or storm names.** Previous rounds' published final reports are valid inputs. Current-round final reports become available only at publication.

Features are constructed from feed prefixes. A separate public-only adapter, which never opens the manifest or settlements, reproduced batch forecasts at six checkpoints across three seasons. A future-poisoning test verifies that changing later observations, reports and truth arrays cannot change current features.

The development process compared 40 directional policies, six final-report margin/size pairs, and 12 final short-horizon configurations, with additional validation-only execution iterations. Structural kernel exploration used training data. No strategy was changed after inspecting the holdout. The later formation-only benchmark is explicitly a validation-only interpretation exercise, not another untouched test.

## 2. The strongest discovered signal: formation-time repricing

Across the 1,080 training storms, relative to the quote two seconds before formation:

| Time since formation | PORT mean change | HAVEN mean change | ARCH mean change | REBLD mean change |
|---|---:|---:|---:|---:|
| +2 seconds | approximately USD 0.00 | approximately USD 0.00 | USD 0.01 | approximately USD 0.00 |
| +4 seconds | USD 1.88 | USD 3.62 | USD 0.01 | approximately USD 0.00 |
| +10 seconds | USD 1.96 | USD 3.77 | USD 9.31 | USD -2.67 |
| +12 seconds | USD 1.93 | USD 3.74 | USD 9.31 | USD -2.69 |

Stocks start repricing around four seconds after formation; ETFs begin their corresponding move around ten seconds. These are empirical timings at the dataset's two-second resolution, not contractual exchange guarantees. The first official advisory arrives at +30 seconds, so this initial effect precedes it.

The common trade is to buy the underreacting island/insurance exposure and sell rebuilding exposure, with direction and magnitude determined by the fitted predictor rather than hardcoded for every storm. HAVEN, ARCH and PORT account for most of the measured profit.

**About 77% of the short-horizon engine's holdout profit comes from decisions at storm formation.** The remaining profit comes from subsequent repricing and earlier rounds' final reports. Thus, the research does not establish that sophisticated path forecasting is the primary source of alpha.

A simple training-mean, formation-only benchmark produced **USD 1,255 mean validation PnL**, with 97.5% profitable validation seasons and 18 order actions per season. The selected feed-and-price model produced **USD 1,649 mean validation PnL**. This benchmark was examined after strategy selection and supports interpretation, not a fresh performance claim.

![Training-only formation response](results/formation-signal.png)

### Short-horizon implementation

The model predicts each stock's 10-second consensus-price change using:

- Round, storm age and previously published damage/loss totals.
- Current position, velocity, radius and intensity.
- Site-level accumulated wind exposure, peak wind, current wind and closure duration.
- Latest official outlook, island probabilities and cone; latest wire outlook.
- Latest preliminary/final report and its stage.
- Current prices, 10- and 30-second price changes, and changes in feed features.

Ten histogram gradient-boosted regressors use fixed development hyperparameters: 160 iterations, 15 leaves, learning rate 0.06, minimum leaf size 100, L2 regularization 30. Random row-level early stopping is disabled. ETF forecasts are the basket-weighted stock forecasts.

The frozen trading rule is:

```text
Every 20 real seconds:
    mu = predicted next-10-second price change
    one_way_cost = 0.0025 * current_price + USD 0.02
    net_edge = abs(mu) - 2 * one_way_cost - USD 0.10
    quantity = min(50 shares, half the instrument's position limit)
    rank positive opportunities by net_edge * quantity
    trade at most three symbols
    close each position 10 real seconds after its entry fill
```

The baseline order arrives two seconds after the decision. A formation trade therefore enters around +2 seconds and exits around +12 seconds. Entry and exit both pay modeled costs. The last round stops new short-cycle entries before second 730, so the account is flat before the final report at second 740. Earlier rounds can trade their final reports and flatten before the close.

Use current executable books and marketable price limits when implementing this on the exchange. The research short-cycle simulator uses taker fills with assumed costs and depth; introducing live limit-price protection changes fill rates and must be measured separately.

## 3. Recovered fundamental valuation model

The economic mapping is remarkably simple and stable. Define:

- `D_i`: season-total reported incremental damage for company i, as a fraction, not a percentage. Sum the final per-storm increments. A final report replaces that storm's preliminary report.
- `O_i`: site-weighted closure duration in market hours across all storms.
- `L`: season insured loss, in **USD millions**.
- `clip(x, 0, c)`: x bounded between zero and c.

The following are rounded descriptions of the fitted model. The code retains full fitted coefficients.

```text
PORT  = 100 - 55*D_PORT  - 2.4*O_PORT
ISLE  =  60 - 38*D_ISLE
AQUA  =  35 - 20*D_AQUA
GRID  =  50 - 24*D_GRID  - 6.0*O_GRID
FERRY =  25 -  5*D_FERRY - 7.2*O_FERRY

L = 900*D_PORT + 600*D_ISLE + 250*D_AQUA
    + 700*D_GRID + 120*D_FERRY                 [USD millions]

RECON = 40 + 24*(1 - exp(-(0.9*D_PORT + 0.7*D_GRID
                          + 0.12*D_FERRY)))
MAT   = 28 + 14*(1 - exp(-L/1200))
GEN   = 32 + 18*(1 - exp(-O_GRID))

HAVEN = 75 - 0.060*clip(L - 400, 0, 900)
REIN  = 90 - 0.035*max(L - 1300, 0)
```

Every valuation above is in **USD per share**. Opening house prices are forecasts of the season outcome, not these companies' undamaged baseline values.

**HAVEN:** the data identifies attachment near USD 400 million, exhaustion near USD 1,300 million, and a valuation floor near USD 21 per share under unchanged economics.

**REIN:** attachment is near USD 1,300 million. Its upper exhaustion point is **not identified**: the largest training loss is about USD 1,766.2 million. The displayed uncapped hinge is valid over the observed region; do not extrapolate it to arbitrarily large catastrophes or claim the upper limit was recovered.

Rebuilder capacity is explicit: additional damage yields progressively smaller incremental value. FERRY is mostly an outage-duration instrument, while GEN is a saturating claim on GRID's outage duration. AQUA's shelter behavior belongs in the damage-generation process, not in a universal damage-to-price multiplier shared with other companies.

### Outage reconstruction

Training data strongly supports the following wind/closure proxy:

```text
wind_at_site = intensity * exp(-(distance_to_site / radius)^2)
closed = wind_at_site >= 0.35
site_outage_hours += closed * elapsed_real_seconds / 120
company_outage = sum(site_weight * site_outage_hours)
```

The divisor is 120 because one real second represents 30 market seconds. Full observation history matters: sparse late-connection snapshots do not recover all past closure duration.

Simple exposure-integral and peak-wind models did not reconstruct damage comparably well; one PORT specification had approximately seven percentage points of training damage error. The near-exact recovered **valuation** model should not be confused with a recovered, near-exact **future damage** model.

### Out-of-sample settlement accuracy

Using the final round-3 reports plus observed outages:

| Symbol | Holdout RMSE, USD per share |
|---|---:|
| PORT | 0.0146 |
| ISLE | 0.0032 |
| AQUA | 0.0029 |
| GRID | 0.0157 |
| FERRY | 0.0220 |
| RECON | 0.0028 |
| MAT | 0.0028 |
| GEN | 0.0233 |
| HAVEN | 0.0036 |
| REIN | 0.0012 |
| ARCH | 0.0517 |
| REBLD | 0.0233 |

Small remaining errors are consistent with rounded observations/reports and discrete closure integration. These errors support a valuation buffer; they do not prove exact recovery of simulator internals.

Before the final storm ends, terminal value must account for future damage and outages. In particular, apply insurance layers to **total season loss**, never independently to each storm. Expected layer payout is an expectation of the clipped payoff, not the clipped payoff at expected loss. The rejected directional models learned terminal outcomes directly rather than assuming current damage was the full season.

## 4. Final-report execution

At round 3's final report, compute all stock values and ETF basket values immediately. The frozen engine:

- Uses a **USD 0.10-per-share valuation margin**.
- Places buys with a limit of estimated value minus the margin, and sells at estimated value plus the margin.
- Assumes at most 50 shares of executable depth per symbol per two-second interval.
- Allows up to one order per symbol in an interval and at most 20 order actions for this phase.
- Counts outstanding unfilled quantities against position limits.
- Gives no passive-fill credit to orders that do not cross on arrival; they remain reserved until close.
- Holds filled positions to settlement, with no fictitious exit-spread charge.

The final report arrives 40 real seconds before close, but most of the observed stale-price opportunity disappears much sooner. There is no reason to assume all 40 seconds are usable, or to apply the packet's approximately 45-second **announcement** adjustment time to every feed event.

The selected short-cycle cadence requires at most 18 order actions per rolling minute, and endgame reserves at most 20 more. This fits one bot key's 60-action limit. A central rolling limiter should enforce both per-key and team limits using monotonic real time. Three independent bots do not create three independent team budgets.

## 5. Held-out trading results

Baseline assumptions: **25 basis points plus USD 0.02 per share per side**, two-second order latency, and a 50-share per-symbol execution cap. ETF position sizing in the short engine is also limited to half the ETF's position limit. All figures below are **USD per season**.

| Engine | Mean | Median | Profitable seasons | Worst season |
|---|---:|---:|---:|---:|
| Short-horizon repricing | 1,768 | 1,805 | 118 / 120 | -845 |
| Final-report settlement | 309 | 146 | 115 / 120 | 0 |
| Combined | **2,077** | **2,019** | **118 / 120** | **-750** |

The combined 5th percentile was **USD 505**, and its worst-six-season average was **USD 100**. Removing the best 5% of seasons still leaves a mean of **USD 1,932**. Average execution costs were **USD 565 per season**, and average order actions were approximately 58 per season.

The final-report engine's five nonprofitable seasons were zero-trade/zero-profit outcomes in this scenario. Its absence of realized losses is not a live guarantee; missing announcements, stale state, model extrapolation, and actual fills are not represented by this historical outcome.

### Execution stress

| Scenario | Combined mean, USD | Profitable seasons |
|---|---:|---:|
| Baseline | 2,077 | 98.3% |
| 50 bps per side, otherwise baseline | 1,560 | 98.3% |
| 100 bps per side, otherwise baseline | 1,043 | 96.7% |
| Four-second latency | 945 | 88.3% |
| Eight-second latency | 845 | 89.2% |
| Twelve-second latency | **-242** | **31.7%** |
| Ten-share depth cap | 621 | 99.2% |
| 50 bps, four-second latency, 25-share depth | **546** | **86.7%** |
| Additional unanticipated 25 bps adverse execution | 1,569 | 95.0% |

The combined-stress mean's 95% season-bootstrap interval is approximately **USD 450–644**. Increasing the cost parameter also changes which opportunities pass the entry threshold. The extra-adverse-execution scenario instead charges an additional cost without letting the decision rule anticipate it.

Latency sensitivity is nonmonotonic at some intermediate values because stock and ETF repricing occur in stages. The twelve-second failure is the clear boundary observed here, not a universal cutoff inferred from theory.

Maximum drawdowns are marked during short trades at two-second intervals. The combined drawdown reported in the CSV is a conservative sum of component drawdowns, not an exact synchronized portfolio drawdown. There is no annualized Sharpe or percentage-return claim: the competition's scoring is terminal PnL and the packet does not specify a conventional capital denominator.

### Rejected main strategy

The best validation-selected directional challenger averaged **USD 1,946** on the holdout but had only **75%** profitable seasons, a worst season of **USD -6,319**, and a worst-5% average of **USD -3,467**. It is too dependent on getting a small number of uncertain storm outcomes right to be the primary recommendation.

Reversing the selected short model's trade directions produced **USD -2,755** mean holdout PnL, with no profitable seasons. This is a useful sign/control diagnostic, not another model-selection exercise.

## 6. Source reliability and insurance signals

When evaluated against the storm's current true pattern, including a switch to erratic after the manifest transition:

| Source | Training accuracy | Validation accuracy | Holdout accuracy |
|---|---:|---:|---:|
| Official | 69.5% | 70.2% | 69.4% |
| Wire | 39.7% | 38.9% | 40.2% |

These measure correctness of the categorical outlook, not calibration of the island probabilities or the forecast cone. The training confusion matrices and season-bootstrap source intervals are included in the results.

Official guidance is valuable but should not override measured motion. Wire chatter can be informative about **other traders' next actions** even when its meteorological accuracy is poor. Do not automatically invert a wrong-looking rumor; compare the price response with the information already embedded in the book. Repeated statements from one source are correlated evidence, not independent confirmations.

The insurance layer is another useful state variable: HAVEN's marginal damage sensitivity declines as its layer exhausts, while REIN becomes sensitive above its attachment. In a very bad season, “short both insurers equally” is not the correct hedge. ARCH includes HAVEN and therefore concentrates that layer exposure alongside physical damage exposure.

## 7. ETF relative value: attractive candidate, execution unproven

The accounting identities are exact at settlement:

```text
ARCH  = PORT + ISLE + 2*AQUA + GRID + 2*FERRY + HAVEN
REBLD = 2*RECON + 2*MAT + GEN
```

Using actual executable depth for quantity q:

```text
ETF premium edge = ETF bid proceeds - cost to buy the basket
ETF discount edge = proceeds from selling the basket - ETF ask cost
```

For a premium, buy the basket, create ETF shares, and sell the ETF. For a discount, buy and redeem the ETF, then sell the basket. The order may be rearranged only after checking every intermediate inventory state. Creation from zero inventory leaves short constituent positions; it does not eliminate the hedge or create free cash.

ARCH requires six distinct constituent trades, one ETF trade, and a conversion: eight order actions. REBLD requires five. The conversion itself is immediate and fee-free; the multiple market legs are not atomic.

As a **quote-opportunity diagnostic**, at assumed 25-bps-per-side plus USD 0.02 per-share costs on every leg, 13.0% of holdout ARCH timestamps and 5.6% of REBLD timestamps have positive synthetic basket edge. These overlapping timestamp counts are not independent trades. No multi-leg arbitrage PnL is credited in the strategy results. The formation-time ETF lag helps explain why the candidate deserves testnet attention.

Require book freshness, available size on every leg, sufficient action budget and a tested unwind policy. Midpoint or consensus deviations alone are insufficient evidence of executable arbitrage. Monitor direct stock positions and ETF look-through exposure together.

## 8. Testing framework and live-readiness work

### Checks implemented and run

- Whole-season, reverse-chronological training/validation/test separation.
- Causal public-feed features and next-sample/latency-delayed execution.
- Future-data poisoning and six real-data public-prefix parity checks.
- Deduplication, sequence gaps, final-report replacement and snapshot idempotence.
- Competition reset and announcement-driven model invalidation.
- Long/short position room with same-side resting orders.
- ETF conversion value conservation and all-leg capacity checks.
- Rolling per-key/team action limits and reserved capacity.
- Delayed arrival, vanished quote, partial-fill reservation and cash-ledger tests.
- Scheduled short-trade exit and entry-price timing tests.
- Ten execution scenarios, whole-season confidence intervals, attribution, pattern slices and sign-reversal control.

The suite contains **14 passing automated tests**. It is not a full exchange emulator. The simulator does not reconstruct queues, infer unlimited depth from the presence of house liquidity, or award fills because a midpoint touched a limit.

### Next testnet measurements

1. Record news, quotes, full depth, local receipt timestamps, order submissions, acknowledgements and fills together. Use the starter kit's feed checker.
2. Measure formation-to-quote and submit-to-fill timing separately for stocks and ETFs. Verify that the measured formation response survives executable spreads and competitor liquidity.
3. Measure depth and replenishment at the intended 10/25/50-share clips, including the impact of multiple legs and repeated orders.
4. Replay these recorded books through the same strategy callbacks. Calibrate price protection, rejection, partial fills and cancellation races.
5. Run shadow decisions before enabling orders. A known-season testnet replay tests plumbing and execution; it is not a new independent forecasting holdout.

### Announcements and recovery

The research seasons contain no economic announcements. The kit invalidates affected valuation models and dependencies on such an event; it does not claim to parse arbitrary headlines into correct new coefficients. A structured coefficient-change handler and reviewed fallback behavior are required before using the historical formulas in an announcement-affected live season.

Snapshots have only the latest eight headlines and a sparse track. A late connection cannot assume it has recovered all economics changes or full historical outage duration. Persist the raw feed and model state, reconcile actual positions/open orders after reconnects, and resolve ambiguous submissions before retrying them. Key deduplication by competition plus sequence, and use market-clock time for case events but monotonic real time for API rate limits.

## 9. Reproducible deliverables

The accompanying kit contains the source, fitted models, 14 tests, frozen configurations, CSV results, figures, and a public-prefix inference example. It has no exchange credentials or live order connection, and no Ramp repository changes.

See `README.md` for one-command reproduction from the original research archive. The input digest, dependency versions, configuration hash and output checksums are included. The economic coefficients and all headline results can be reproduced locally.

**Bottom line:** prioritize the observed formation repricing and the near-exact final-report valuation model. Treat broad hurricane-direction bets as a secondary research line. The largest remaining uncertainty is whether the house-consensus timing edge is available in executable testnet books at the intended size.
