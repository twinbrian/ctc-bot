"""Final-report burst execution with explicit rolling action/depth constraints.

Only the last round's final report is used. Resting limits that did not cross on
arrival receive no fill credit and reserve inventory until close. This avoids
assuming either IOC support or fictional passive fills. No cancel/replace loop.
"""

import numpy as np

from common import LIMITS


def simulate_endgame(
    market,
    truth,
    fair,
    *,
    cost_bps=25,
    fixed_cost=0.02,
    latency=2,
    fill_cap=50,
    margin=0.20,
    fraction=1.0,
    burst=12,
    action_budget=60,
    fill_fraction=1.0,
    adverse_bps=0.0,
    start_delay=0,
    symbols=None,
):
    n = len(market)
    q = np.zeros((n, 12), dtype=int)
    reserved = np.zeros_like(q)
    cash = np.zeros(n)
    attribution = np.zeros((n, 12))
    actions = np.zeros(n, dtype=int)
    submitted = np.zeros(n, dtype=int)
    fills = np.zeros(n, dtype=int)
    cost = np.zeros(n)
    turnover = np.zeros(n)
    peak = np.zeros(n)
    drawdown = np.zeros(n)
    pending = []
    marks = []
    limit = np.floor(LIMITS * fraction).astype(int)
    delay = max(1, int(np.ceil(latency / 2)))
    allowed = np.ones(12, dtype=bool)
    if symbols is not None:
        allowed[:] = False
        allowed[symbols] = True
    # No orders before this <60s window: total budget also enforces rolling limit.
    for ti in range(370, 390):
        price = market[:, 2, ti]
        for due, i, j, signed, limit_price in list(pending):
            if due != ti:
                continue
            side = np.sign(signed)
            unit_cost = price[i, j] * (cost_bps + adverse_bps) / 10000 + fixed_cost
            execution = price[i, j] + side * unit_cost
            crosses = (execution - limit_price) * side <= 0
            qty = side * np.floor(np.abs(signed) * fill_fraction).astype(int) * crosses
            # Entire requested quantity was reserved; only actual fills release it.
            reserved[i, j] -= qty
            q[i, j] += qty
            cash[i] -= qty * execution
            attribution[i, j] -= qty * execution
            cost[i] += np.abs(qty) * unit_cost
            turnover[i] += np.abs(qty)
            fills[i] += qty != 0
        wealth = cash + np.sum(q * price, axis=1)
        peak = np.maximum(peak, wealth)
        drawdown = np.maximum(drawdown, peak - wealth)
        marks.append(wealth.copy())
        if ti + delay >= 390 or ti * 2 < 740 + start_delay:
            continue
        edge = fair - price
        side = np.sign(edge).astype(int)
        room = limit[None, :] - np.abs(q) - np.abs(reserved)
        qty = np.minimum(fill_cap, np.maximum(room, 0))
        surplus = np.abs(edge) - (price * cost_bps / 10000 + fixed_cost) - margin
        score = surplus * qty
        score[(qty <= 0) | ~allowed[None, :] | ((q + reserved) * side < 0)] = -np.inf
        # At most one order per symbol per observed interval, limiting assumed depth.
        ranking = np.argsort(-score, axis=1)
        for slot in range(min(burst, 12)):
            j = ranking[:, slot]
            valid = (actions < action_budget) & (score[np.arange(n), j] > 0)
            i = np.where(valid)[0]
            if not len(i):
                continue
            jj = j[i]
            signed = qty[i, jj] * side[i, jj]
            cap = fair[i, jj] - side[i, jj] * margin
            reserved[i, jj] += signed
            pending.append((ti + delay, i, jj, signed, cap))
            actions[i] += 1
            submitted[i] += np.abs(signed)
    assert np.all(np.abs(q) + np.abs(reserved) <= limit)
    assert np.all(actions <= action_budget)
    pnl = cash + np.sum(q * truth, axis=1)
    attribution += q * truth
    assert np.allclose(pnl, attribution.sum(1))
    drawdown = np.maximum(drawdown, peak - pnl)
    return {
        "pnl": pnl,
        "positions": q,
        "actions": actions,
        "turnover_shares": turnover,
        "cost": cost,
        "drawdown": drawdown,
        "attribution": attribution,
        "mark_curve": np.stack(marks, axis=1),
        "reserved": reserved,
        "submitted_shares": submitted,
        "fill_orders": fills,
    }
