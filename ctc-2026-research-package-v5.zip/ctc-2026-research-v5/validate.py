"""Select the strategy on validation; freeze its configuration before test."""

import itertools

import numpy as np
import pandas as pd

from backtest import simulate, summarize, uncertainty
from common import dump_json, load_cache, partitions


def main():
    d, p = load_cache("cache.npz"), load_cache("predictions.npz")
    _, val, _ = partitions()
    records = []
    scales = {}
    # This finite search is declared before looking at the lockbox results.
    for mode in ["fundamental", "hybrid"]:
        scales[mode] = uncertainty(p[mode], d["settlement_truth"], p["times"], val)
        for start, z, fraction in itertools.product(
            ["all", "round3", "poststorm", "preliminary", "final"],
            [0.5, 1.0],
            [0.5, 1.0],
        ):
            config = {"start": start, "z": z, "fraction": fraction}
            result = simulate(
                d["market"][val],
                d["settlement_truth"][val],
                p[mode][val],
                p["times"],
                scales[mode],
                **config,
            )
            summary = summarize(result)
            # Mean minus a tail penalty; scoring itself remains terminal USD PnL.
            score = summary["mean_usd"] + 0.25 * min(summary["worst_5pct_mean_usd"], 0)
            records.append(
                {"model": mode, **config, **summary, "selection_score": score}
            )
    df = pd.DataFrame(records).sort_values("selection_score", ascending=False)
    df.to_csv("results/validation_candidates.csv", index=False)
    winner = df.iloc[0]
    frozen = {
        "model": winner["model"],
        "start": winner["start"],
        "z": float(winner["z"]),
        "fraction": float(winner["fraction"]),
        "cost_bps": 25,
        "fixed_cost": 0.02,
        "latency": 2,
        "fill_cap": 50,
        "edge_floor": 0.1,
        "selection": "40 predefined candidates; mean + .25*min(worst5pctmean,0)",
    }
    dump_json("results/frozen_config.json", frozen)
    np.savez("results/uncertainty.npz", **scales)
    print(df.head(12).to_string(index=False))
    print("FROZEN", frozen)


if __name__ == "__main__":
    main()
