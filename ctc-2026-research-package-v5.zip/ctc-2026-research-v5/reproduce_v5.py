"""Rebuild selected policies from the original data, without saved forecast caches."""

import argparse
import json
import pickle
from pathlib import Path

import numpy as np

from models import StructuralModel, features, weather
from prepare import prepare
from research_v4.lab import summarize_pnl
from research_v5.clock_forecast.forecast import DriftModels
from research_v5.conditional_research import coherent_jump
from research_v5.handoff_research import npz, write_json
from research_v5.scheduled_account import run


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-root", type=Path)
    parser.add_argument("--cache", type=Path, default=Path("cache.npz"))
    parser.add_argument("--output", type=Path, default=Path("reproduced_v5"))
    parser.add_argument("--fit-deployment", action="store_true")
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    if not args.cache.exists():
        if args.data_root is None:
            parser.error(
                "Provide --data-root pointing to the extracted case.json/history directory"
            )
        prepare(args.data_root, args.cache)
    d = dict(np.load(args.cache))
    assert len(d["market"]) == 600
    _, damage, outage, loss = features(d, np.array([740]))
    final_outage = weather(d)[2].sum(1)
    rows = []
    for fold in range(5):
        block = np.arange(600) // 120
        evaluate = block == fold
        training = (block != fold) & (block != (fold + 1) % 5)
        ids = np.flatnonzero(evaluate)
        target = args.output / f"fold{fold}_model.pkl"
        if target.exists():
            model, econ = pickle.loads(target.read_bytes())
        else:
            fitting = {
                k: (
                    v[training]
                    if k not in ["advisories", "site_xy", "site_weight", "site_company"]
                    and v.ndim
                    and len(v) == 600
                    else v
                )
                for k, v in d.items()
            }
            model = DriftModels().fit(fitting)
            econ = StructuralModel().fit(
                d["report_truth"][training].sum(1),
                final_outage[training],
                d["loss_truth"][training].sum(1),
                d["settlement_truth"][training],
            )
            temp = target.with_suffix(".tmp")
            temp.write_bytes(pickle.dumps((model, econ)))
            temp.replace(target)
        public = {
            k: (
                v[evaluate]
                if k not in ["advisories", "site_xy", "site_weight", "site_company"]
                and v.ndim
                and len(v) == 600
                else v
            )
            for k, v in d.items()
        }
        jump = coherent_jump(
            model.predict_public(public)["hgb"], d["market"][evaluate, :, 90]
        )
        fair = econ.predict(
            damage[evaluate, 2, 0], outage[evaluate, 2, 0], loss[evaluate, 2, 0]
        )
        curve = d["market"][training].mean(0)
        for policy, forecast in [("clock", None), ("hgb", jump)]:
            result_path = args.output / f"fold{fold}_{policy}.npz"
            if result_path.exists():
                result = dict(np.load(result_path))
            else:
                result = run(
                    d["market"][evaluate],
                    d["settlement_truth"][evaluate],
                    curve,
                    fair,
                    forecast_jump=forecast,
                )
                npz(result_path, **result, season_ids=ids + 1)
            rows.append(
                {"fold": fold, "policy": policy, **summarize_pnl(result["pnl"])}
            )
        write_json(args.output / "fold_metrics.json", rows)
        print("Reproduced fold", fold, flush=True)
    certificate = []
    for policy in ["clock", "hgb"]:
        pnl = np.concatenate(
            [np.load(args.output / f"fold{f}_{policy}.npz")["pnl"] for f in range(5)]
        )
        source = (
            Path("research_v5/pooled_clock/pooled_clock_base.npz")
            if policy == "clock"
            else Path("research_v5/pooled_conditional/pooled_base.npz")
        )
        record = {"policy": policy, **summarize_pnl(pnl)}
        if source.exists():
            old = np.load(source)["pnl"]
            np.testing.assert_allclose(pnl, old, atol=1e-7, rtol=0)
            record["maximum_saved_result_difference"] = float(np.max(np.abs(pnl - old)))
        certificate.append(record)
    if args.fit_deployment:
        # All historical rows are now training; this artifact has no holdout score.
        model = DriftModels().fit(d)
        econ = StructuralModel().fit(
            d["report_truth"].sum(1),
            final_outage,
            d["loss_truth"].sum(1),
            d["settlement_truth"],
        )
        (args.output / "deployment_models.pkl").write_bytes(
            pickle.dumps({"drift": model, "economic": econ})
        )
        npz(args.output / "deployment_curve.npz", curve=d["market"].mean(0))
        write_json(args.output / "deployment_parameters.json", econ.parameters())
    write_json(
        args.output / "COMPLETE.json",
        {
            "results": certificate,
            "qualification": "No cached forecast dependence; frozen post-selection policies, no fresh holdout",
        },
    )
    print(json.dumps(certificate), flush=True)


if __name__ == "__main__":
    main()
