# CTC external research snapshot v4

Start with `REPORT_V4.md`. The research incumbent remains v3. No v4 combined
strategy was validated or promoted. All work is local and unrelated to Ramp repos.

This archive preserves v4 source, plans, compact tables and incomplete follow-ups.
It omits original data, pickle weights, prediction caches, large trade traces and
large NPZ arrays. `PACKAGE_MANIFEST_V4.json` lists every included file and checksum,
plus omitted files and their sizes. The original v3 archive remains the baseline
reproduction artifact. Root simulator sources here include optional shared-budget
interfaces added during unfinished v4 work; they are not the byte-identical v3
release, and old certificates should not be applied to these modified sources.

Completed tracks: initial event research, initial relative-value research,
conditional formation research, insurance rejection, economic-bound diagnostic,
independent audit, and quoted-route-cost numerical evaluation.

Incomplete: event-turnover validation, nonlinear-hedge final handoff, canonical
publication-time scan, historical shared-account evaluation, final combined v4
assessment. Completed inner results are retained, not represented as validation.

Do not run every research script blindly: several use single-use freeze markers.
Read each track's `PLAN.md` and `HANDOFF.md` first. Reproduction on the same data
is not new statistical validation. Development data can be regenerated from the
user-supplied dataset using the root preparation code and
`research_v4/prepare_development.py`; follow the original v3 README for baseline
dependencies and data preparation. The supplied data has already informed research.
