# CTC 2026: the 2r cutoff and a stronger PnL strategy

## Executive finding

**Your 2r hypothesis is strongly supported as the physical damage-support boundary.** On single-site PORT, a cutoff fitted to 1,080 storms perfectly classified zero versus positive damage on another 720 storms. The training observations bracket the boundary between **1.99061r and 2.00953r**. This does not identify the exact boundary to arbitrary precision, or mean that every trade should be triggered at 2r.

**We also exceeded the prior PnL result:** the selected ETF-routed strategy averaged **USD 11,101 per season**, versus **USD 9,337**, an **18.9% improvement** under unchanged baseline execution assumptions. The improvement is primarily execution and inventory allocation, not a claim that the cutoff alone created a profitable weather forecast.

| Metric | Previous strategy | ETF-routed v3 |
|---|---:|---:|
| Mean net PnL | USD 9,337 | USD 11,101 |
| Median net PnL | USD 8,352 | USD 10,018 |
| Profitable seasons | 88.0% | 87.7% |
| Worst season | USD -8,153 | USD -8,756 |
| Worst 5%: average PnL | USD -5,158 | USD -5,911 |
| Mean order actions | 431.2 | 358.9 |
| Mean modeled execution cost | USD 3,194 | USD 3,710 |

Evidence is **post-selection nested simulator evaluation** on all 600 seasons: five folds, each with 360 training / 120 inner-validation / 120 outer-evaluation seasons. The dataset has been examined in prior research. These are not fresh-lockbox or live results. Prices are house consensus, not supplied executable orderbooks.

The paired improvement is **USD 1,763**, with a conditional 95% season-bootstrap interval of **USD 1,608 to USD 1,918**. V3 beat v2 in **81%** of matched seasons and in each outer fold's mean. These intervals omit research-selection, model-fitting and live-execution uncertainty.

![PnL comparison and execution stresses](results_v3/pnl-dashboard-v3.png)

## 1. What is the optimal cutoff?

For a site at distance d from the storm center with radius r and intensity I, use this empirically supported candidate kernel:

```text
rho = distance / radius
wind = intensity * exp(-rho**2)
damage_exposure = wind if rho <= 2 else 0
```

The Gaussian attenuation and the hard support boundary are different components. At d=2r, the untruncated Gaussian is exp(-4), about 1.83% of central intensity; it is not mathematically zero. A hard cutoff is an additional rule inferred from the zero-damage observations.

PORT is the cleanest identification instrument: one fixed site, weight one, fully exposed infrastructure. Define the predictor as the storm's closest observed normalized distance and the label as whether its final reported incremental PORT damage is positive. Fit the threshold only on original training seasons 600–241. The zero-error grid spans 1.995r–2.005r; its midpoint is 2r.

| Subset | Storms | Classification errors at 2r |
|---|---:|---:|
| Train | 1080 | 0 |
| Validation | 360 | 0 |
| Evaluation | 360 | 0 |

The smallest observed zero-damage training distance is 2.00953r; the largest positive-damage distance is 1.99061r. Observations arrive every two seconds and reports are rounded, so the appropriate conclusion is strong support for a 2r rule, not proof of a uniquely estimated infinitesimal threshold. Confirmation subsets were excluded from fitting this boundary but are not globally untouched research data.

The closure threshold is a separate mechanism: earlier valuation identification supported wind >= 0.35. At intensity one, that occurs near **1.025r**, not 2r. A site may take mild damage without closing. At the maximum observed intensity, the inferred closure radius still lies well inside 2r; truncation at 2r changes none of the measured closure flags in the audited training data.

![Cutoff support and damage regression error](results_v3/cutoff-diagnostics-v3.png)

## 2. Regressions: the boundary is clearer than damage severity

For each company, fit site vulnerability coefficients using a cumulative survival model. Accumulate the full observed wind path across storms at each site, preserving the effect of earlier damage, then aggregate with the published site weights:

```text
E_site = sum_over_observed_ticks(2 * wind * indicator(rho <= cutoff))
D_company = sum_sites(weight * (1 - exp(-k_site * cumulative_E_site)))
```

The coefficients are fitted on 360 training seasons, separately for each cutoff. These are effective regression parameters, not recovered simulator constants. The table gives **validation cumulative-damage RMSE in percentage points**, over 120 seasons and all three round endpoints.

| Company | 1r | 1.5r | 2r | 3r | No cutoff |
|---|---:|---:|---:|---:|---:|
| PORT | 15.610 | 7.494 | 6.575 | 6.585 | 6.584 |
| ISLE | 5.874 | 3.921 | 3.636 | 3.666 | 3.666 |
| AQUA | 5.723 | 3.951 | 3.816 | 3.809 | 3.809 |
| GRID | 6.654 | 4.415 | 4.088 | 4.093 | 4.093 |
| FERRY | 6.880 | 4.808 | 4.566 | 4.553 | 4.553 |

Fourteen cutoffs were evaluated from 1r through 3r plus no cutoff. Small radii materially worsen fit, but the error surface is nearly flat beyond approximately 1.9r. Some companies' lowest prediction error is not exactly at 2r: a misspecified severity model can compensate by including small tails that are physically wrong. Thus **support identification favors 2r; predictive-MSE optimization does not tightly identify it**.

For PORT, the fitted fixed-kernel vulnerability is approximately **0.01112 per integrated real-second wind unit**. A supplementary training/validation-only fit allows an intensity exponent and a Gaussian distance coefficient. It estimates **I^0.810 * exp(-0.989 * rho^2)** inside 2r; the spatial coefficient remains close to one, and validation error improves only slightly.

| PORT response family | Training RMSE, pp | Validation RMSE, pp |
|---|---:|---:|
| fixed gaussian | 7.000 | 6.575 |
| free gaussian | 6.976 | 6.516 |
| event linear | 7.448 | 6.781 |
| event capped | 7.175 | 6.672 |

The empirical effective damage rate has a **34.5% coefficient of variation** among 466 substantial training PORT exposures. This is unexplained variation under the chosen model, not proof that the simulator samples random coefficients. A Gaussian path integral alone does not justify treating storm damage as known exactly before the final assessment.

A separate fixed-capacity boosted model predicts incremental per-storm damage from the fully observed path, prior public final damage reports, and round. Its validation PORT RMSE is about 5.44 percentage points. That target is incremental damage, so it must not be compared directly with the cumulative-damage errors above. Full-path features become available only after the storm dissipates.

## 3. Where the additional PnL came from

The strongest established signal remains the scheduled house repricing around storm formation at t=60 real seconds after open. On training-average paths, island stocks and HAVEN tend to appreciate over the formation holding window, while rebuilders tend to fall. V3 estimates that expected change from training seasons, anchors it to the current observed price and trades only directions that exceed modeled entry and exit costs.

The prior policy was action-constrained. Fifty-share clips and a 60-action rolling minute limited the amount of useful exposure it could accumulate and unwind. V3 treats the ETF conversion mechanism as an execution route to the same desired stock exposures.

### Concrete example: acquire 200 ARCH baskets

One basket contains PORT 1, ISLE 1, AQUA 2, GRID 1, FERRY 2, HAVEN 1. Acquiring 200 baskets directly requires 1,600 stock shares and **32 orders** at 50 shares per order. Instead, repeat four times:

1. Redeem 50 ARCH: receive the 50 baskets and become short 50 ETF shares.
2. Buy 50 ARCH from the market to cover the ETF leg.

That requires **eight actions**, including conversions, subject to all component limits and the 50-share ARCH limit. The account cannot redeem all 200 at once. This example describes the basket portion; the implemented strategy also handles residual stock quantities and any desired outright ETF position.

The reverse operation unwinds long stock baskets; creation plus selling ETF shares can establish short rebuilder baskets. Each conversion changes positions with **zero net cash**. ETF market legs still cost money, arrive after latency and consume available depth. This is not risk-free profit from accounting marks, and the separate financing and stock legs are not an atomic market trade.

### Selected policy

- Set desired per-symbol positions from positive expected net formation edges, up to legal limits. Every fold selected the full tested exposure fraction rather than 75%.
- Route common basket components through conversions, then trade the residual stock and ETF quantities directly.
- Reserve positive and negative pending legs separately. An expected offsetting leg cannot create capacity before it fills.
- Start exits at the validation-selected time. Actual completion is constrained by latency, limits and the rolling action budget.
- After flattening, wait one full rolling minute before resuming the existing short-horizon engine. This conservative handover prevents separate engines from double-spending an action budget.
- At the final round's exact damage report, retain structural settlement-value trades using remaining capacity.

Selected formation routes use an average **51 conversion actions per season**, included in total actions. Formation positions become flat at a mean **112 seconds** after open, with a maximum of **136 seconds**. The first official advisory at t=90 can therefore affect these positions; this is not purely pre-advisory profit.

| Engine | Mean net PnL contribution |
|---|---:|
| Formation exposure and exit | USD 10,338 |
| Later short-horizon signals | USD 467 |
| Final-report settlement trades | USD 295 |

About 93.1% of the mean result comes from the formation holding window. Improved direct lot allocation alone averaged **USD 9,626**. The selected routed family averaged **USD 11,101**; that comparison includes the route family's own selected timing and sizes, not a perfectly isolated single-variable treatment effect.

## 4. A negative result worth keeping

We trained ridge and two gradient-boosted residual-value models using the fully observed 2r-truncated path, prices, lags and published reports. In rounds 1–2 they forecast post-final-report prices; in round 3 they forecast settlement. All targets stay outside decision features.

At dissipation, the stronger boosted model's pooled stock forecast RMSE was approximately **USD 1.287**, only slightly better than current house price at **USD 1.294**. After the preliminary report, it was worse: **USD 1.110** versus **USD 1.083**. Small forecast-error gains did not cover the extra execution costs and inventory exposure.

Each fold tested 108 aftermath variants across three models, four entry times, three entry budgets and three edge cushions. **All five folds rejected the aftermath addition** on inner-validation mean PnL.

| Fold | Best direct allocation | Best with aftermath | Best ETF-routed |
|---|---:|---:|---:|
| 0 | USD 9,703 | USD 9,582 | USD 11,329 |
| 1 | USD 10,225 | USD 10,098 | USD 11,829 |
| 2 | USD 9,404 | USD 9,242 | USD 10,872 |
| 3 | USD 9,641 | USD 9,495 | USD 11,147 |
| 4 | USD 9,596 | USD 9,448 | USD 11,071 |

These are inner-validation selection results, not outer-performance claims. The rejected model remains in the research kit so the negative result is reproducible. No new outer-policy search was performed after opening the v3 results.

## 5. Robust testing framework

The objective is the arithmetic mean of **cash plus final-settlement value**, net of modeled costs, subject to exchange constraints. There is no Sharpe, win-rate or downside-loss penalty. Optimizing expected PnL is not the same as maximizing the probability of beating all other teams; the dataset contains no opponent score distribution.

Baseline assumptions remain **25 bps plus USD 0.02 per share per side, two real seconds of latency, 50 market shares per symbol per two-second interval, and one bot key's rolling 60-action limit**. Conversion actions count too. No extra keys, assumed inside-spread fills, free market legs or invented depth were added.

Each fold uses 360 training seasons, 120 inner-validation seasons and 120 outer-evaluation seasons. All three storms remain together. The staged search includes one v2 reference, 36 direct-allocation configurations, 108 aftermath configurations and 24 conversion-route configurations: **169 candidates per fold**. Each stage retains its incumbent. All five final configurations are frozen before outer replay, with file hashes recorded. This is a staged search, not a proof of global optimality.

| Fold | Outer seasons | Entry / earliest exit, s | Later top-k | Outer mean PnL |
|---|---|---|---:|---:|
| 0 | 1–120 | 20 / 100 | 5 | USD 11,150 |
| 1 | 121–240 | 0 / 120 | 5 | USD 10,929 |
| 2 | 241–360 | 0 / 80 | 8 | USD 11,551 |
| 3 | 361–480 | 20 / 80 | 8 | USD 10,798 |
| 4 | 481–600 | 0 / 100 | 5 | USD 11,074 |

For the original oldest-to-newest split, the concrete selected route starts at **t=20** and requests exits from **t=100**, followed by the top-five short-horizon policy every ten seconds and zero additional final-report margin. It produces **USD 11,150** on the original 120 evaluation seasons. Pooled performance evaluates five fold-specific selected policies, not one universal policy chosen from all results.

The framework checks cash/PnL reconciliation, ETF conservation at basket parity, delayed market fills, rejected limit orders, separate pending reservations, price oscillation around final value, slow depth replenishment, future-feature causality, feed deduplication, report replacement and state recovery. The full deterministic suite has **39 passing tests**. The original v2 replay is also reproduced exactly on every season after extending the simulator.

The selected baseline reaches at most **49 actions in any rolling minute**, below 60, and no per-symbol limit is breached. Formation submission bursts peak at 11 actions at one timestamp. Combined action histories are retained. The routed strategy's reported maximum drawdown statistic is a conservative sum of engine drawdowns, not the same path estimator as v2; it is not used to select the policy.

## 6. Fixed-policy execution stresses

Known-cost scenarios let the frozen policy recompute net-edge eligibility at the new cost. The unexpected-cost row charges extra cost without changing its forecast. No stress result determined policy selection.

| Scenario | Mean net PnL | Profitable | Worst season |
|---|---:|---:|---:|
| Baseline | USD 11,101 | 87.7% | USD -8,756 |
| 50 bps per side | USD 7,867 | 77.7% | USD -12,033 |
| 100 bps per side | USD 3,849 | 72.8% | USD -9,354 |
| 4 s latency | USD 10,633 | 85.5% | USD -10,206 |
| 12 s latency | USD 9,708 | 81.8% | USD -11,661 |
| 25 shares / 2 s | USD 7,124 | 87.7% | USD -6,115 |
| 10 shares / 2 s | USD 3,228 | 88.0% | USD -2,763 |
| 50 bps + 4 s latency + 25 shares / 2 s | USD 5,661 | 77.7% | USD -10,013 |
| Unexpected additional 25 bps per side | USD 7,727 | 77.2% | USD -12,341 |
| 50 shares / 10 s | USD 10,708 | 86.8% | USD -9,788 |

The combined stress retains a mean of **USD 5,661**, compared with **USD 4,446** for v2. The slower-replenishment scenario retains a mean of **USD 10,708**. These are sensitivity scenarios, not measured available liquidity.

The decisive untested issues are executable ETF spreads/depth, price protection, our own impact on house inventory, competition for formation liquidity, and live announcements that change valuation parameters. A dataset of consensus marks cannot validate those. Before competition use, record testnet orderbooks and order acknowledgments, verify every conversion/financing sequence, and compare realized shortfall against these assumed costs and capacity. Keep testnet season identity and published future outcomes out of the strategy; exact-replay recognition is an operational check, not a live edge.

## Bottom line

Use **2r to truncate the damage-support kernel**, while keeping closure and trading decisions distinct. Keep uncertainty around damage severity: the regression residual is economically meaningful. For the currently tested expected-PnL objective, the strongest new candidate is the **ETF-routed formation strategy**, with simulated mean **USD 11,101** and worst season **USD -8,756**. The improvement is supported across the five matched folds, but remains conditional on repeatedly examined simulator data and unverified execution assumptions.

The v3 source/results archive includes frozen configurations, all candidate tables, per-season outcomes, physical diagnostics, action audits, tests and reproduction instructions. Large fitted models and caches can be regenerated from the supplied dataset. Everything is local and standalone; no Ramp repository or branch was created.
