"""Compare path-based damage hypotheses using training seasons only."""

import numpy as np
from scipy.optimize import least_squares

from common import load_cache, partitions


def main():
    d = load_cache("cache.npz")
    tr = partitions()[0]
    o = d["obs"][tr, :, :240]
    dist = np.linalg.norm(o[..., None, :2] - d["site_xy"], axis=-1) / o[..., None, 4]
    target = d["report_truth"][tr].cumsum(1)
    for scale in [0.5, 1, 2]:
        wind = o[..., None, 5] * np.exp(-scale * dist**2)
        for kind in ["peak", "integral_linear", "integral_exp"]:
            fits = []
            for j in range(5):
                ix = np.where(d["site_company"] == j)[0]
                w = wind[:, :, :, ix]

                def predict(p):
                    exposure = (
                        np.max(w, axis=2) ** p[-1]
                        if kind == "peak"
                        else np.sum(w ** p[-1], axis=2) * 2
                    )
                    event = (
                        np.clip(exposure * p[:-1], 0, 0.999999)
                        if kind != "integral_exp"
                        else 1 - np.exp(-exposure * p[:-1])
                    )
                    return (1 - np.cumprod(1 - event, axis=1)) @ d["site_weight"][ix]

                x0 = np.r_[np.full(len(ix), 0.8 if kind == "peak" else 0.01), 1.0]
                f = least_squares(
                    lambda p: (predict(p) - target[:, :, j]).ravel(),
                    x0,
                    bounds=(
                        np.r_[np.full(len(ix), 0.000001), 0.05],
                        np.r_[np.full(len(ix), 2), 5],
                    ),
                    max_nfev=300,
                )
                fits.append((float(np.sqrt(np.mean(f.fun**2))), f.x.tolist()))
            print(scale, kind, fits, flush=True)


if __name__ == "__main__":
    main()
