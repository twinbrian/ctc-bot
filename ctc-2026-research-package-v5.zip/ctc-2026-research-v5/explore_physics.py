"""Training-only identification of candidate closure kernels."""

import numpy as np

from common import load_cache, partitions


def main():
    d = load_cache("cache.npz")
    train = partitions()[0]
    obs = d["obs"][train, :, :240]
    dist = (
        np.linalg.norm(obs[..., None, :2] - d["site_xy"], axis=-1) / obs[..., None, 4]
    )
    intensity = obs[..., None, 5]
    y = d["settlement_truth"][train]
    damage = d["report_truth"][train].sum(1)
    weights = np.zeros((17, 5))
    weights[np.arange(17), d["site_company"]] = d["site_weight"]
    best = []
    for power in [1, 2]:
        for scale in [0.5, 1, 2]:
            w = intensity * np.exp(-scale * dist**power)
            for threshold in np.arange(0.1, 0.91, 0.01):
                outage = ((w >= threshold).sum((1, 2)) * 2 / 120) @ weights
                rmses, betas = [], []
                for j in [0, 3, 4]:
                    x = np.c_[np.ones(len(y)), damage[:, j], outage[:, j]]
                    beta = np.linalg.lstsq(x, y[:, j], rcond=None)[0]
                    rmses.append(np.mean((x @ beta - y[:, j]) ** 2))
                    betas.append(beta)
                best.append((sum(rmses), power, scale, threshold, rmses, betas))
    for row in sorted(best, key=lambda r: r[0])[:12]:
        print(row)


if __name__ == "__main__":
    main()
