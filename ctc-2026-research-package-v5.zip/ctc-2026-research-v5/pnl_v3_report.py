"""Render the frozen v3 findings; this script does not select policies."""

import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter
import numpy as np
import pandas as pd

from common import load_cache, partitions
from make_report import main as render_pdf


def usd(value, decimals=0):
    return f"USD {value:,.{decimals}f}"


def table(rows):
    return "\n".join("| " + " | ".join(map(str, row)) + " |" for row in rows)


def main():
    root = Path("results_v3")
    summary = json.loads((root / "summary.json").read_text())
    scores = {x["scenario"]: x for x in summary["scenarios"]}
    prior = {
        x["scenario"]: x
        for x in json.loads(Path("results_v2/summary.json").read_text())["scenarios"]
    }
    base, old = scores["base"], scores["v2_reference"]
    support = json.loads((root / "cutoff_support.json").read_text())
    kernel = json.loads((root / "kernel_sensitivity.json").read_text())
    routes = json.loads((root / "route_audit.json").read_text())
    seasons = pd.read_csv(root / "outer_seasons.csv")
    regressions = pd.read_csv(root / "damage_cutoff_regressions.csv")
    diagnostics = load_cache(root / "damage_diagnostics.npz")
    train, val, test = partitions()
    blue, green, gray, orange = "#37688F", "#0F8877", "#657783", "#CA7733"
    plt.rcParams.update(
        {
            "font.family": "DejaVu Sans",
            "font.size": 10,
            "axes.spines.top": False,
            "axes.spines.right": False,
        }
    )

    fig, axes = plt.subplots(1, 2, figsize=(13.5, 4.9), layout="constrained")
    rng = np.random.default_rng(2026)
    for mask, label, color in [
        (train, "Fit: 1,080 storms", blue),
        (val | test, "Confirmation: 720 storms", green),
    ]:
        x = diagnostics["closest"][mask].ravel()
        y = diagnostics["labels"][mask].astype(float).ravel()
        axes[0].scatter(
            x,
            y + rng.uniform(-0.04, 0.04, len(y)),
            s=21,
            alpha=0.6,
            label=label,
            color=color,
        )
    axes[0].axvline(2, color=orange, lw=2, label="Cutoff = 2r")
    axes[0].axvspan(
        support["training_positive_upper_distance"],
        support["training_zero_lower_distance"],
        color=orange,
        alpha=0.2,
    )
    axes[0].set(
        xlim=(1.5, 2.5),
        ylim=(-0.16, 1.28),
        yticks=[0, 1],
        yticklabels=["Zero", "Positive"],
        xlabel="Closest normalized distance d/r (zoomed)",
        ylabel="Reported PORT storm damage",
        title="2r separates zero and positive damage",
    )
    axes[0].legend(loc="upper right", fontsize=9, frameon=False)
    for split, label, color in [
        ("train", "Training", blue),
        ("validation", "Validation", green),
    ]:
        f = regressions[
            (regressions.company == "PORT") & (regressions.split == split)
        ].copy()
        f["x"] = f.cutoff.replace("none", "3.2").astype(float)
        axes[1].plot(f.x, f.rmse_pp, marker="o", ms=4, color=color, label=label)
    axes[1].axvline(2, color=orange, lw=1.5, ls="--")
    axes[1].set(
        xlabel="Kernel cutoff / radius",
        ylabel="Cumulative damage RMSE (percentage points)",
        title="Damage-amount error barely changes beyond 2r",
        xticks=[1, 1.5, 2, 2.5, 3, 3.2],
        xticklabels=["1", "1.5", "2", "2.5", "3", "None"],
    )
    axes[1].legend(frameon=False)
    axes[1].grid(alpha=0.15)
    fig.suptitle(
        "A physical boundary, not a complete damage model", fontsize=17, weight="bold"
    )
    fig.supxlabel(
        "Single-site PORT avoids ambiguity from site weighting • original season-separated split, previously examined dataset",
        fontsize=9,
        color=gray,
    )
    fig.savefig(root / "cutoff-diagnostics-v3.png", dpi=180)
    plt.close(fig)

    fig, axes = plt.subplots(2, 2, figsize=(13.5, 9.3), layout="constrained")
    stages = ["v2_reference", "allocation_only", "base"]
    values = [scores[k]["mean_usd"] for k in stages]
    ax = axes[0, 0]
    ax.bar([0, 1, 2], values, color=[gray, blue, green])
    for x, value in enumerate(values):
        ax.text(x, value + 160, f"{value:,.0f}", ha="center", weight="bold")
    ax.set(
        xticks=[0, 1, 2],
        xticklabels=[
            "Previous strategy",
            "Better lot allocation",
            "ETF-routed strategy",
        ],
        ylabel="Mean terminal PnL (USD)",
        ylim=(0, 13000),
        title="18.9% higher mean under the same assumptions",
    )
    ax = axes[0, 1]
    for key, label, color in [
        ("v2_reference", "Previous strategy", blue),
        ("base", "ETF-routed strategy", green),
    ]:
        ax.plot(
            np.sort(seasons[key]),
            np.arange(1, 601) / 600,
            label=label,
            color=color,
            lw=2,
        )
    ax.axvline(0, color=gray, ls="--", lw=1)
    ax.set(
        xlabel="Terminal PnL (USD)",
        ylabel="Fraction of seasons",
        title="Higher mean still comes with losing seasons",
    )
    ax.xaxis.set_major_formatter(FuncFormatter(lambda x, _: f"{x / 1000:g}k"))
    ax.legend(frameon=True, facecolor="white", framealpha=0.95, loc="lower right")
    ax = axes[1, 0]
    stress_names = [
        "base",
        "50bps",
        "12s_latency",
        "25_share_depth",
        "combined_stress",
        "10s_depth_replenishment",
    ]
    stress_labels = [
        "Baseline",
        "50 bps each side",
        "12 s latency",
        "25 shares / 2 s",
        "50 bps + 4 s + 25 shares",
        "50 shares / 10 s",
    ]
    y = np.arange(len(stress_names))
    ax.barh(
        y - 0.18,
        [prior[k]["mean_usd"] for k in stress_names],
        height=0.36,
        color=blue,
        label="Previous",
    )
    ax.barh(
        y + 0.18,
        [scores[k]["mean_usd"] for k in stress_names],
        height=0.36,
        color=green,
        label="ETF-routed",
    )
    ax.set(
        yticks=y,
        yticklabels=stress_labels,
        xlabel="Mean net PnL (USD)",
        title="Cost, latency and depth stresses",
    )
    ax.invert_yaxis()
    ax.legend(frameon=True, facecolor="white", framealpha=0.95, loc="lower right")
    ax = axes[1, 1]
    x = np.arange(5)
    ax.bar(
        x - 0.18,
        [f["v2_summary"]["mean_usd"] for f in summary["folds"]],
        width=0.36,
        color=blue,
        label="Previous",
    )
    ax.bar(
        x + 0.18,
        [f["outer_summary"]["mean_usd"] for f in summary["folds"]],
        width=0.36,
        color=green,
        label="ETF-routed",
    )
    ax.set(
        xticks=x,
        xlabel="Outer fold",
        ylabel="Mean net PnL (USD)",
        title="Improvement in each of the five outer folds",
    )
    ax.legend(frameon=True, facecolor="white", framealpha=0.95, loc="lower right")
    fig.suptitle(
        "CTC 2026: from USD 9,337 to USD 11,101 per season", fontsize=19, weight="bold"
    )
    fig.supxlabel(
        "600 seasons • post-selection nested CV • hypothetical consensus fills, not executable order-book observations",
        fontsize=10,
        color=gray,
    )
    fig.savefig(root / "pnl-dashboard-v3.png", dpi=180)
    plt.close(fig)

    metrics = table(
        [
            ["Mean net PnL", usd(old["mean_usd"]), usd(base["mean_usd"])],
            ["Median net PnL", usd(old["median_usd"]), usd(base["median_usd"])],
            ["Profitable seasons", f"{old['win_rate']:.1%}", f"{base['win_rate']:.1%}"],
            ["Worst season", usd(old["minimum_usd"]), usd(base["minimum_usd"])],
            [
                "Worst 5%: average PnL",
                usd(old["worst_5pct_mean_usd"]),
                usd(base["worst_5pct_mean_usd"]),
            ],
            [
                "Mean order actions",
                f"{old['mean_actions']:.1f}",
                f"{base['mean_actions']:.1f}",
            ],
            [
                "Mean modeled execution cost",
                usd(old["mean_cost_usd"]),
                usd(base["mean_cost_usd"]),
            ],
        ]
    )
    support_rows = table(
        [
            [name.title(), values["storms"], values["errors"]]
            for name, values in support["splits"].items()
        ]
    )
    damage = regressions[regressions.split == "validation"].pivot(
        index="company", columns="cutoff", values="rmse_pp"
    )
    damage_rows = table(
        [
            [
                s,
                *[
                    f"{damage.loc[s, c]:.3f}"
                    for c in ["1.0", "1.5", "2.0", "3.0", "none"]
                ],
            ]
            for s in ["PORT", "ISLE", "AQUA", "GRID", "FERRY"]
        ]
    )
    kernel_rows = table(
        [
            [
                r["family"].replace("_", " "),
                f"{r['train_rmse_pp']:.3f}",
                f"{r['validation_rmse_pp']:.3f}",
            ]
            for r in kernel["models"]
        ]
    )
    candidates = pd.concat(
        [pd.read_csv(root / f"fold-{k}-validation.csv") for k in range(5)]
    )
    selection = candidates.groupby(["fold", "stage"]).mean_usd.max().unstack()
    selection_rows = table(
        [
            [k, usd(row.allocation), usd(row.aftermath), usd(row.etf_routing)]
            for k, row in selection.iterrows()
        ]
    )
    fold_rows = table(
        [
            [
                f["fold"],
                f"{120 * f['fold'] + 1}–{120 * (f['fold'] + 1)}",
                f"{f['config']['formation_route']['start']} / {f['config']['formation_route']['exit_at']}",
                f["config"]["ongoing"]["top_k"],
                usd(f["outer_summary"]["mean_usd"]),
            ]
            for f in summary["folds"]
        ]
    )
    stress_order = [
        ("base", "Baseline"),
        ("50bps", "50 bps per side"),
        ("100bps", "100 bps per side"),
        ("4s_latency", "4 s latency"),
        ("12s_latency", "12 s latency"),
        ("25_share_depth", "25 shares / 2 s"),
        ("10_share_depth", "10 shares / 2 s"),
        ("combined_stress", "50 bps + 4 s latency + 25 shares / 2 s"),
        ("extra_25bps_adverse", "Unexpected additional 25 bps per side"),
        ("10s_depth_replenishment", "50 shares / 10 s"),
    ]
    stress_rows = table(
        [
            [
                label,
                usd(scores[k]["mean_usd"]),
                f"{scores[k]['win_rate']:.1%}",
                usd(scores[k]["minimum_usd"]),
            ]
            for k, label in stress_order
        ]
    )
    contributions = table(
        [
            [label, usd(value)]
            for label, value in zip(
                [
                    "Formation exposure and exit",
                    "Later short-horizon signals",
                    "Final-report settlement trades",
                ],
                base["mean_engine_contributions_usd"],
            )
        ]
    )

    report = f"""# CTC 2026: the 2r cutoff and a stronger PnL strategy

## Executive finding

**Your 2r hypothesis is strongly supported as the physical damage-support boundary.** On single-site PORT, a cutoff fitted to 1,080 storms perfectly classified zero versus positive damage on another 720 storms. The training observations bracket the boundary between **1.99061r and 2.00953r**. This does not identify the exact boundary to arbitrary precision, or mean that every trade should be triggered at 2r.

**We also exceeded the prior PnL result:** the selected ETF-routed strategy averaged **{usd(base["mean_usd"])} per season**, versus **{usd(old["mean_usd"])}**, an **18.9% improvement** under unchanged baseline execution assumptions. The improvement is primarily execution and inventory allocation, not a claim that the cutoff alone created a profitable weather forecast.

| Metric | Previous strategy | ETF-routed v3 |
|---|---:|---:|
{metrics}

Evidence is **post-selection nested simulator evaluation** on all 600 seasons: five folds, each with 360 training / 120 inner-validation / 120 outer-evaluation seasons. The dataset has been examined in prior research. These are not fresh-lockbox or live results. Prices are house consensus, not supplied executable orderbooks.

The paired improvement is **{usd(summary["paired_mean_improvement_usd"])}**, with a conditional 95% season-bootstrap interval of **{usd(summary["paired_mean_ci95_usd"][0])} to {usd(summary["paired_mean_ci95_usd"][1])}**. V3 beat v2 in **{summary["paired_win_fraction"]:.0%}** of matched seasons and in each outer fold's mean. These intervals omit research-selection, model-fitting and live-execution uncertainty.

![PnL comparison and execution stresses](results_v3/pnl-dashboard-v3.png)

## 1. What is the optimal cutoff?

For a site at distance d from the storm center with radius r and intensity I, use this empirically supported candidate kernel:

```text
rho = distance / radius
wind = intensity * exp(-rho**2)
damage_exposure = wind if rho <= 2 else 0
```

The Gaussian attenuation and the hard support boundary are different components. At d=2r, the untruncated Gaussian is exp(-4), about 1.83% of central intensity; it is not mathematically zero. A hard cutoff is an additional rule inferred from the zero-damage observations.

PORT is the cleanest identification instrument: one fixed site, weight one, fully exposed infrastructure. Define the predictor as the storm's closest observed normalized distance and the label as whether its final reported incremental PORT damage is positive. Fit the threshold only on original training seasons 600–241. The zero-error grid spans 1.995r–2.005r; its midpoint is 2r.

| Subset | Storms | Classification errors at 2r |
|---|---:|---:|
{support_rows}

The smallest observed zero-damage training distance is 2.00953r; the largest positive-damage distance is 1.99061r. Observations arrive every two seconds and reports are rounded, so the appropriate conclusion is strong support for a 2r rule, not proof of a uniquely estimated infinitesimal threshold. Confirmation subsets were excluded from fitting this boundary but are not globally untouched research data.

The closure threshold is a separate mechanism: earlier valuation identification supported wind >= 0.35. At intensity one, that occurs near **1.025r**, not 2r. A site may take mild damage without closing. At the maximum observed intensity, the inferred closure radius still lies well inside 2r; truncation at 2r changes none of the measured closure flags in the audited training data.

![Cutoff support and damage regression error](results_v3/cutoff-diagnostics-v3.png)

## 2. Regressions: the boundary is clearer than damage severity

For each company, fit site vulnerability coefficients using a cumulative survival model. Accumulate the full observed wind path across storms at each site, preserving the effect of earlier damage, then aggregate with the published site weights:

```text
E_site = sum_over_observed_ticks(2 * wind * indicator(rho <= cutoff))
D_company = sum_sites(weight * (1 - exp(-k_site * cumulative_E_site)))
```

The coefficients are fitted on 360 training seasons, separately for each cutoff. These are effective regression parameters, not recovered simulator constants. The table gives **validation cumulative-damage RMSE in percentage points**, over 120 seasons and all three round endpoints.

| Company | 1r | 1.5r | 2r | 3r | No cutoff |
|---|---:|---:|---:|---:|---:|
{damage_rows}

Fourteen cutoffs were evaluated from 1r through 3r plus no cutoff. Small radii materially worsen fit, but the error surface is nearly flat beyond approximately 1.9r. Some companies' lowest prediction error is not exactly at 2r: a misspecified severity model can compensate by including small tails that are physically wrong. Thus **support identification favors 2r; predictive-MSE optimization does not tightly identify it**.

For PORT, the fitted fixed-kernel vulnerability is approximately **0.01112 per integrated real-second wind unit**. A supplementary training/validation-only fit allows an intensity exponent and a Gaussian distance coefficient. It estimates **I^0.810 * exp(-0.989 * rho^2)** inside 2r; the spatial coefficient remains close to one, and validation error improves only slightly.

| PORT response family | Training RMSE, pp | Validation RMSE, pp |
|---|---:|---:|
{kernel_rows}

The empirical effective damage rate has a **{kernel["residual"]["coefficient_of_variation"]:.1%} coefficient of variation** among {kernel["residual"]["storms"]} substantial training PORT exposures. This is unexplained variation under the chosen model, not proof that the simulator samples random coefficients. A Gaussian path integral alone does not justify treating storm damage as known exactly before the final assessment.

A separate fixed-capacity boosted model predicts incremental per-storm damage from the fully observed path, prior public final damage reports, and round. Its validation PORT RMSE is about 5.44 percentage points. That target is incremental damage, so it must not be compared directly with the cumulative-damage errors above. Full-path features become available only after the storm dissipates.

## 3. Where the additional PnL came from

The strongest established signal remains the scheduled house repricing around storm formation at t=60 real seconds after open. On training-average paths, island stocks and HAVEN tend to appreciate over the formation holding window, while rebuilders tend to fall. V3 estimates that expected change from training seasons, anchors it to the current observed price and trades only directions that exceed modeled entry and exit costs.

The prior policy was action-constrained. Fifty-share clips and a 60-action rolling minute limited the amount of useful exposure it could accumulate and unwind. V3 treats the ETF conversion mechanism as an execution route to the same desired stock exposures.

### Concrete example: acquire 200 ARCH baskets

One basket contains PORT 1, ISLE 1, AQUA 2, GRID 1, FERRY 2, HAVEN 1. Acquiring 200 baskets directly requires 1,600 stock shares and **32 orders** at 50 shares per order. Instead, repeat four times:

1. Redeem 50 ARCH: receive the 50 baskets and become short 50 ETF shares.
2. Buy 50 ARCH from the market to cover the ETF leg.

That requires **eight actions**, including conversions, subject to all component limits and the 50-share ARCH limit. The account cannot redeem all 200 at once. This example describes the basket portion; the implemented strategy also handles residual stock quantities and any desired outright ETF position.

The reverse operation unwinds long stock baskets; creation plus selling ETF shares can establish short rebuilder baskets. Each conversion changes positions with **zero net cash**. ETF market legs still cost money, arrive after latency and consume available depth. This is not risk-free profit from accounting marks, and the separate financing and stock legs are not an atomic market trade.

### Selected policy

- Set desired per-symbol positions from positive expected net formation edges, up to legal limits. Every fold selected the full tested exposure fraction rather than 75%.
- Route common basket components through conversions, then trade the residual stock and ETF quantities directly.
- Reserve positive and negative pending legs separately. An expected offsetting leg cannot create capacity before it fills.
- Start exits at the validation-selected time. Actual completion is constrained by latency, limits and the rolling action budget.
- After flattening, wait one full rolling minute before resuming the existing short-horizon engine. This conservative handover prevents separate engines from double-spending an action budget.
- At the final round's exact damage report, retain structural settlement-value trades using remaining capacity.

Selected formation routes use an average **{routes["mean_conversion_actions_per_season"]:.0f} conversion actions per season**, included in total actions. Formation positions become flat at a mean **{routes["formation_flat_seconds_after_open"]["mean"]:.0f} seconds** after open, with a maximum of **{routes["formation_flat_seconds_after_open"]["maximum"]} seconds**. The first official advisory at t=90 can therefore affect these positions; this is not purely pre-advisory profit.

| Engine | Mean net PnL contribution |
|---|---:|
{contributions}

About 93.1% of the mean result comes from the formation holding window. Improved direct lot allocation alone averaged **{usd(scores["allocation_only"]["mean_usd"])}**. The selected routed family averaged **{usd(base["mean_usd"])}**; that comparison includes the route family's own selected timing and sizes, not a perfectly isolated single-variable treatment effect.

## 4. A negative result worth keeping

We trained ridge and two gradient-boosted residual-value models using the fully observed 2r-truncated path, prices, lags and published reports. In rounds 1–2 they forecast post-final-report prices; in round 3 they forecast settlement. All targets stay outside decision features.

At dissipation, the stronger boosted model's pooled stock forecast RMSE was approximately **USD 1.287**, only slightly better than current house price at **USD 1.294**. After the preliminary report, it was worse: **USD 1.110** versus **USD 1.083**. Small forecast-error gains did not cover the extra execution costs and inventory exposure.

Each fold tested 108 aftermath variants across three models, four entry times, three entry budgets and three edge cushions. **All five folds rejected the aftermath addition** on inner-validation mean PnL.

| Fold | Best direct allocation | Best with aftermath | Best ETF-routed |
|---|---:|---:|---:|
{selection_rows}

These are inner-validation selection results, not outer-performance claims. The rejected model remains in the research kit so the negative result is reproducible. No new outer-policy search was performed after opening the v3 results.

## 5. Robust testing framework

The objective is the arithmetic mean of **cash plus final-settlement value**, net of modeled costs, subject to exchange constraints. There is no Sharpe, win-rate or downside-loss penalty. Optimizing expected PnL is not the same as maximizing the probability of beating all other teams; the dataset contains no opponent score distribution.

Baseline assumptions remain **25 bps plus USD 0.02 per share per side, two real seconds of latency, 50 market shares per symbol per two-second interval, and one bot key's rolling 60-action limit**. Conversion actions count too. No extra keys, assumed inside-spread fills, free market legs or invented depth were added.

Each fold uses 360 training seasons, 120 inner-validation seasons and 120 outer-evaluation seasons. All three storms remain together. The staged search includes one v2 reference, 36 direct-allocation configurations, 108 aftermath configurations and 24 conversion-route configurations: **169 candidates per fold**. Each stage retains its incumbent. All five final configurations are frozen before outer replay, with file hashes recorded. This is a staged search, not a proof of global optimality.

| Fold | Outer seasons | Entry / earliest exit, s | Later top-k | Outer mean PnL |
|---|---|---|---:|---:|
{fold_rows}

For the original oldest-to-newest split, the concrete selected route starts at **t=20** and requests exits from **t=100**, followed by the top-five short-horizon policy every ten seconds and zero additional final-report margin. It produces **{usd(summary["folds"][0]["outer_summary"]["mean_usd"])}** on the original 120 evaluation seasons. Pooled performance evaluates five fold-specific selected policies, not one universal policy chosen from all results.

The framework checks cash/PnL reconciliation, ETF conservation at basket parity, delayed market fills, rejected limit orders, separate pending reservations, price oscillation around final value, slow depth replenishment, future-feature causality, feed deduplication, report replacement and state recovery. The full deterministic suite has **39 passing tests**. The original v2 replay is also reproduced exactly on every season after extending the simulator.

The selected baseline reaches at most **{base["max_rolling_actions"]} actions in any rolling minute**, below 60, and no per-symbol limit is breached. Formation submission bursts peak at {routes["maximum_actions_at_one_tick"]} actions at one timestamp. Combined action histories are retained. The routed strategy's reported maximum drawdown statistic is a conservative sum of engine drawdowns, not the same path estimator as v2; it is not used to select the policy.

## 6. Fixed-policy execution stresses

Known-cost scenarios let the frozen policy recompute net-edge eligibility at the new cost. The unexpected-cost row charges extra cost without changing its forecast. No stress result determined policy selection.

| Scenario | Mean net PnL | Profitable | Worst season |
|---|---:|---:|---:|
{stress_rows}

The combined stress retains a mean of **{usd(scores["combined_stress"]["mean_usd"])}**, compared with **{usd(prior["combined_stress"]["mean_usd"])}** for v2. The slower-replenishment scenario retains a mean of **{usd(scores["10s_depth_replenishment"]["mean_usd"])}**. These are sensitivity scenarios, not measured available liquidity.

The decisive untested issues are executable ETF spreads/depth, price protection, our own impact on house inventory, competition for formation liquidity, and live announcements that change valuation parameters. A dataset of consensus marks cannot validate those. Before competition use, record testnet orderbooks and order acknowledgments, verify every conversion/financing sequence, and compare realized shortfall against these assumed costs and capacity. Keep testnet season identity and published future outcomes out of the strategy; exact-replay recognition is an operational check, not a live edge.

## Bottom line

Use **2r to truncate the damage-support kernel**, while keeping closure and trading decisions distinct. Keep uncertainty around damage severity: the regression residual is economically meaningful. For the currently tested expected-PnL objective, the strongest new candidate is the **ETF-routed formation strategy**, with simulated mean **{usd(base["mean_usd"])}** and worst season **{usd(base["minimum_usd"])}**. The improvement is supported across the five matched folds, but remains conditional on repeatedly examined simulator data and unverified execution assumptions.

The v3 source/results archive includes frozen configurations, all candidate tables, per-season outcomes, physical diagnostics, action audits, tests and reproduction instructions. Large fitted models and caches can be regenerated from the supplied dataset. Everything is local and standalone; no Ramp repository or branch was created.
"""
    Path("REPORT_V3.md").write_text(report)
    render_pdf("REPORT_V3.md", "../ctc-2026-research-report-v3.pdf", "v3")


if __name__ == "__main__":
    main()
