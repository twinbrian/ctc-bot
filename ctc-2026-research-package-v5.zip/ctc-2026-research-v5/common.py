"""Shared, explicit contracts. Time is real seconds; currency is USD."""

import json
from pathlib import Path

import numpy as np

SYMBOLS = [
    "PORT",
    "ISLE",
    "AQUA",
    "GRID",
    "FERRY",
    "RECON",
    "MAT",
    "GEN",
    "HAVEN",
    "REIN",
    "ARCH",
    "REBLD",
]
PHYSICAL = SYMBOLS[:5]
OUTLOOKS = ["direct", "chain", "recurve", "stall", "eyewall", "erratic"]
ISLANDS = ["cascadia_prime", "coral_key", "azure_isle", "palm_atoll"]
LIMITS = np.array([200, 300, 500, 400, 800, 500, 700, 600, 250, 200, 50, 100])
BASKETS = np.zeros((2, 10))
BASKETS[0, [0, 1, 2, 3, 4, 8]] = [1, 1, 2, 1, 2, 1]
BASKETS[1, [5, 6, 7]] = [2, 2, 1]


def partitions():
    """Oldest -> newest: train 600..241, validate 240..121, lockbox 120..1."""
    ids = np.arange(1, 601)
    return ids >= 241, (ids >= 121) & (ids <= 240), ids <= 120


def with_etfs(stock_values):
    return np.concatenate([stock_values, stock_values @ BASKETS.T], axis=-1)


def load_cache(path):
    return dict(np.load(path, allow_pickle=False))


def dump_json(path, value):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")


def real_second(timestamp):
    # datetime64[ns]/pandas cannot represent the oldest fictional years.
    h, m, s = map(int, timestamp.split("T")[1].split(":")[:3])
    return (h * 3600 + m * 60 + s - 34200) / 30
