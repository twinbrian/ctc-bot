# CTC 2026 — V5 research package

Start with **REPORT_V5.md** or the included PDF. The main discovery is a scheduled directional reversal, with a much longer holding horizon than the previous ten-second predictor. Highest pooled historical mean: **USD 19,230.10 per season**; the simpler scheduled control is **USD 19,189.16**. These are post-selection estimates on 600 previously researched seasons, using hypothetical execution.

## Reproduce the main result

Use Python 3.12 and install `requirements-v5.txt` in a virtual environment. Extract the original `hurricane-season-research.zip` supplied by the organizer. Point `--data-root` to the directory containing `case.json` and `history/`:

```bash
python -m pip install -r requirements-v5.txt
OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 python reproduce_v5.py --data-root /path/to/hurricane-season-research --output reproduced_v5
```

The command creates `cache.npz` if absent. It fits both frozen policies in five whole-season folds, each using 360 training seasons and 120 evaluation seasons; the adjacent 120-season block is excluded from fitting. It writes per-season PnL, costs, actions, account states, fitted models, fold metrics and `COMPLETE.json`. When packaged pooled result files are present, it checks reproduced PnL against them. The recorded reproduction matched all 600 per-season PnLs **exactly** for both policies after refitting from the existing public-data cache, without using saved forecasts. The raw ZIP-to-cache path is supported; this run did not independently recertify every cached raw payload.

For an all-600 research fit, append `--fit-deployment`. This artifact has no independent performance score. The included `research_v5/reproduction/deployment_models.pkl` contains the drift and structural models; `deployment_curve.npz` is the all-600 mean curve. These are research models, not a connected exchange bot. Load only trusted model files.

Completed outputs are reused on restart. Use a **new output directory** after changing source, settings or data; the simple reproducer does not automatically invalidate older checkpoints. Original fitted fold models are omitted from this compact package, so the default reproduction fits them again.

## Key files

- `research_v5/scheduled_account.py`: shared-account replay of formation, active-storm holding and final settlement phases.
- `research_v5/clock_forecast/forecast.py`: frozen 94-feature ridge/HGB forecasts, with an online `predict_round` interface.
- `research_v5/terminal/model.py`: public-as-of feature construction used by the forecast.
- `models.py`: structural terminal economics; `prepare.py`: public-feed cache construction.
- `etf_route_v3.py`, `pnl_v2_simulator.py`, `replay_contract.py`: execution, conversions, pending-side limits and rolling action constraints.
- `research_v5/report/*.csv`: season-aligned PnL, summary stresses, all 54 execution settings per policy, all 30 bootstrap results and forward panels.
- `research_v5/pooled_clock/`, `pooled_conditional/`: saved pooled outcomes and split membership.
- `research_v5/execution_matrix/`, `stability_execution/`, `information_lag/`: full frozen sensitivity outputs.
- `research_v5/audit/`, `audit_schedule/`: metadata, synthetic execution and independent fill-ledger audit evidence.
- `research_v5/*PLAN*.md`, child `PLAN.md`/`frozen.json`: bounded experiment declarations and negative results.
- `PACKAGE_MANIFEST_V5.json`: hashes of packaged files and explicit omissions. Raw data, large duplicate models/caches and local agent logs are excluded.

The broader experiment scripts retain their original checkpoint paths. The compact package is sufficient for the main `reproduce_v5.py` entry point and inspection of all reported outcomes; rebuilding every historic experiment also requires the omitted development/prediction caches or regeneration from their source scripts. Omission is explicit in the manifest.

## Timing and interfaces

All strategy times are **real seconds after market open**, not storm age. Market time advances 30 times faster. Formation acquisition starts at 20 seconds and liquidation starts at 100; the active phase enters at 180 and starts liquidation at 540. These are submission times, not guaranteed flat times. The final-report phase begins at 740 in round 3, only after prior inventory and gross pending orders are flat and depth cooldown is satisfied.

`scheduled_account.run(..., forecast_jump=None)` is the simple scheduled policy. Passing a finite array of shape `[season, round, 12]` uses conditional expected price changes. `DriftModels.predict_round` returns ten stock jumps; use `coherent_jump` to value the ETF baskets from the stock exit fairs. Never pass ten-second predicted changes as terminal fair values, and never add standalone sleeve inventories/PnLs together.

## Tested scope and live work remaining

The saved source suite passes 50 tests plus 34 subtests on pending capacity, ledger identities, continuous rate limits, causal handoffs and account integration. Selected tests can be run with:

```bash
python -m pytest tests/test_v3.py tests/test_pnl_v2.py research_v4/lead/test_shared_account.py research_v5/test_scheduled_account.py research_v5/test_event_account.py research_v5/audit/test_contract.py
```

No order-book or live receipt data were supplied. Recorded spreads, depth, partial fills, rejects, price protection, other-team impact and actual announcement economics are the remaining deployment questions. Use the testnet to record those conditions and run the same accounting model before enabling a live strategy. Keep competition ID and sequence deduplication, snapshot recovery, pending-order reconciliation, per-key/team action budgets and announcement parameter changes in a real adapter.

All work was external/local. No Ramp repository branch, commit or PR was created.
