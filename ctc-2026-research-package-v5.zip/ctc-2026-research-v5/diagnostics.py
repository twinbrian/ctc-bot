"""Post-selection interpretation. Does not alter the frozen trading strategy."""

import json

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from backtest import summarize
from common import SYMBOLS, dump_json, load_cache, partitions, with_etfs
from short_horizon import simulate_short


def source_intervals(d, mask):
    ads = d["advisories"]
    ids = np.arange(1, 601)[mask]
    rng = np.random.default_rng(2026)
    draws = rng.integers(0, len(ids), (10000, len(ids)))
    records = []
    for official in [0, 1]:
        counts = []
        for season in ids:
            rows = ads[(ads[:, 0] == season) & (ads[:, 3] == official)]
            counts.append([np.sum(rows[:, 4] == rows[:, 5]), len(rows)])
        counts = np.array(counts)
        b = counts[draws].sum(1)
        lo, hi = np.quantile(b[:, 0] / b[:, 1], [0.025, 0.975])
        records.append(
            {
                "source": "official" if official else "wire",
                "accuracy_ci95": [float(lo), float(hi)],
            }
        )
    return records


def main():
    d, p = load_cache("cache.npz"), load_cache("short_predictions.npz")
    train, val, test = partitions()
    records = []
    for split, mask in [("training", train), ("validation", val)]:
        baseline = d["market"][mask, :, 29]
        for t in range(50, 102, 2):
            change = (d["market"][mask, :, t // 2] - baseline).mean((0, 1))
            records.append(
                {"split": split, "second_after_open": t, **dict(zip(SYMBOLS, change))}
            )
    df = pd.DataFrame(records)
    df.to_csv("results/formation_response.csv", index=False)
    fig, axes = plt.subplots(1, 2, figsize=(12, 4))
    selected = df[df.split == "training"]
    for symbol in ["PORT", "HAVEN", "ISLE", "RECON"]:
        axes[0].plot(selected.second_after_open - 60, selected[symbol], label=symbol)
    for symbol in ["ARCH", "REBLD"]:
        axes[1].plot(selected.second_after_open - 60, selected[symbol], label=symbol)
    for ax in axes:
        ax.axvline(0, color="black", linestyle="--", alpha=0.5)
        ax.axvline(30, color="gray", linestyle=":", alpha=0.5)
        ax.set(
            xlabel="Real seconds since formation", ylabel="Mean change from t=-2s (USD)"
        )
        ax.grid(alpha=0.2)
        ax.legend()
    axes[0].set_title("Stocks begin repricing at about +4s")
    axes[1].set_title("ETFs begin repricing at about +10s")
    fig.suptitle(
        "Formation response • Training data only • First advisory arrives at +30s"
    )
    fig.tight_layout()
    fig.savefig("results/formation-signal.png", dpi=180)
    plt.close(fig)
    cfg = json.load(open("results/engines_frozen.json"))["short_horizon"]
    # Simple calendar-only benchmark, estimated solely from training returns.
    # Validation is already a development set; this is an interpretive diagnostic.
    times = p["times"]
    expected = (
        d["market"][train][:, :, np.minimum(times + 10, 778) // 2, :10]
        - d["market"][train][:, :, times // 2, :10]
    ).mean(0)
    calendar = np.broadcast_to(with_etfs(expected), p["delta"][val].shape).copy()
    formation_only = np.zeros_like(calendar)
    formation_only[:, :, times == 60] = calendar[:, :, times == 60]
    bench = {}
    for name, delta in [
        ("calendar_only", calendar),
        ("formation_only", formation_only),
    ]:
        result = simulate_short(
            d["market"][val], d["settlement_truth"][val], delta, times, **cfg
        )
        bench[name] = summarize(result)
    dump_json(
        "results/interpretation.json",
        {
            "validation_only_benchmarks": bench,
            "holdout_source_cluster_bootstrap": source_intervals(d, test),
            "note": "Interpretation performed after strategy freeze and holdout evaluation. No strategy changes or fresh-lockbox claims.",
        },
    )
    print(json.dumps(bench, indent=2))


if __name__ == "__main__":
    main()
