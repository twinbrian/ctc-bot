"""Package v2 without overwriting v1 artifacts."""

import json
import platform
import shutil
import sys
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

from package_results import digest


def main():
    root = Path(__file__).parent
    results = root / "results_v2"
    summary = json.loads((results / "summary.json").read_text())
    test_run = json.loads((results / "verification.json").read_text())
    certificate = {
        "python": sys.version,
        "platform": platform.platform(),
        "model_threads": {"OMP_NUM_THREADS": 1, "OPENBLAS_NUM_THREADS": 1},
        "test_run": test_run,
        "input_audit": json.loads((root / "cache.audit.json").read_text()),
        "original_data_zip_sha256": digest(
            "/tmp/files/f977-hurricane-season-research.zip"
        ),
        "frozen_config_sha256": {
            str(f["fold"]): f["frozen_sha256"] for f in summary["folds"]
        },
        "objective": summary["objective"],
        "qualification": summary["qualification"],
        "repository_changes": False,
        "result_type": "Hypothetical consensus-price execution scenarios, not verified exchange fills",
    }
    (results / "reproduction_certificate.json").write_text(
        json.dumps(certificate, indent=2) + "\n"
    )
    files = sorted(
        set(
            list(root.glob("*.py"))
            + list(root.glob("*.md"))
            + list(root.glob("*.pkl"))
            + list(root.glob("requirements*.txt"))
            + [root / "environment.json", root / "cache.audit.json"]
            + list((root / "tests").glob("*.py"))
            + [p for p in (root / "results").iterdir() if p.is_file()]
            + [
                p
                for p in results.iterdir()
                if p.is_file() and not p.name.endswith("-predictions.npz")
            ]
        )
    )
    manifest = {str(p.relative_to(root)): digest(p) for p in files}
    sums = root / "SHA256SUMS_V2.json"
    sums.write_text(json.dumps(manifest, indent=2) + "\n")
    files.append(sums)
    prefix = "ctc-2026-research-kit-v2/"
    archive = root.parent / "ctc-2026-research-kit-v2.zip"
    with ZipFile(archive, "w", ZIP_DEFLATED, compresslevel=6) as z:
        for p in files:
            z.write(p, prefix + str(p.relative_to(root)))
        for version in ["v1", "v2"]:
            pdf = root.parent / f"ctc-2026-research-report-{version}.pdf"
            z.write(pdf, prefix + pdf.name)
    with ZipFile(archive) as z:
        assert z.testzip() is None
    compact = root.parent / "ctc-2026-code-results-v2.zip"
    compact_manifest = {
        name: value for name, value in manifest.items() if not name.endswith(".pkl")
    }
    with (
        ZipFile(archive) as source,
        ZipFile(compact, "w", ZIP_DEFLATED, compresslevel=6) as target,
    ):
        for item in source.infolist():
            if item.filename.endswith(".pkl"):
                continue
            contents = source.read(item.filename)
            if item.filename.endswith("SHA256SUMS_V2.json"):
                contents = (json.dumps(compact_manifest, indent=2) + "\n").encode()
            target.writestr(item.filename, contents)
    with ZipFile(compact) as z:
        assert z.testzip() is None
    shutil.copyfile(
        results / "pnl-dashboard-v2.png", root.parent / "ctc-2026-pnl-dashboard-v2.png"
    )
    print(f"Packaged {len(files) + 2} files; {archive.stat().st_size / 1e6:.2f} MB")
    print(archive)
    print(f"Compact source/results: {compact.stat().st_size / 1e6:.2f} MB; {compact}")


if __name__ == "__main__":
    main()
