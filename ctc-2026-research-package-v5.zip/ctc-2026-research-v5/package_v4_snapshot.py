"""Package recovered saved research only; never fit, tune or replay a strategy."""

import hashlib
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

from make_report import main as render_report


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    root = Path(__file__).resolve().parent
    pdf = root.parent / "ctc-2026-research-report-v4.pdf"
    render_report(str(root / "REPORT_V4.md"), str(pdf), "v4 research snapshot")
    candidates = list(root.glob("*.py")) + list(root.glob("*.md"))
    candidates += list(root.glob("requirements*.txt"))
    candidates += list((root / "tests").glob("*.py"))
    candidates += list((root / "research_v4").rglob("*"))
    included, omitted = [], []
    for path in sorted(set(candidates)):
        if not path.is_file() or any(
            x.startswith(".") for x in path.relative_to(root).parts
        ):
            continue
        name = str(path.relative_to(root))
        if "__pycache__" in path.parts:
            continue
        if path.suffix not in {
            ".py",
            ".md",
            ".txt",
            ".json",
            ".jsonl",
            ".csv",
            ".log",
            ".sh",
        }:
            omitted.append({"path": name, "bytes": path.stat().st_size})
            continue
        if path.stat().st_size > 500_000 or path.name in {
            "opencode-openapi.json",
            "packet.txt",
            "packet_compact.txt",
        }:
            omitted.append({"path": name, "bytes": path.stat().st_size})
            continue
        included.append(path)
    manifest = {
        "status": "recovered research snapshot; no promoted v4 strategy",
        "qualification": "Post-selection hypothetical execution; not fresh holdout or live fills",
        "sha256": {str(p.relative_to(root)): digest(p) for p in included},
        "pdf_sha256": digest(pdf),
        "omitted": omitted,
    }
    path = root / "PACKAGE_MANIFEST_V4.json"
    path.write_text(json.dumps(manifest, indent=2) + "\n")
    included.append(path)
    archive = root.parent / "ctc-2026-research-snapshot-v4.zip"
    prefix = "ctc-2026-research-snapshot-v4/"
    with ZipFile(archive, "w", ZIP_DEFLATED, compresslevel=6) as zipped:
        for path in included:
            zipped.write(path, prefix + str(path.relative_to(root)))
        zipped.write(pdf, prefix + pdf.name)
    with ZipFile(archive) as zipped:
        assert zipped.testzip() is None
        for name, expected in manifest["sha256"].items():
            assert hashlib.sha256(zipped.read(prefix + name)).hexdigest() == expected
    print(
        json.dumps(
            {
                "files": len(included) + 1,
                "archive_mb": archive.stat().st_size / 1e6,
                "pdf": str(pdf),
                "archive": str(archive),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
