"""Validation-only engine comparison, including explicit execution stress."""

import json

import pandas as pd

from backtest import summarize
from common import dump_json, load_cache, partitions
from endgame import simulate_endgame
from short_horizon import simulate_short


def main():
    d, p = load_cache("cache.npz"), load_cache("predictions.npz")
    short = load_cache("short_predictions.npz")
    _, val, _ = partitions()
    market, truth = d["market"][val], d["settlement_truth"][val]
    fair = p["structural"][val, 2, list(p["times"]).index(740)]
    end = []
    for margin in [0.1, 0.2, 0.4]:
        for fraction in [0.5, 1.0]:
            config = {"margin": margin, "fraction": fraction}
            result = simulate_endgame(market, truth, fair, action_budget=20, **config)
            stressed = simulate_endgame(
                market,
                truth,
                fair,
                cost_bps=50,
                latency=4,
                fill_cap=25,
                action_budget=20,
                **config,
            )
            end.append(
                {
                    **config,
                    **summarize(result),
                    "stress_mean_usd": float(stressed["pnl"].mean()),
                }
            )
    end_df = pd.DataFrame(end).sort_values("stress_mean_usd", ascending=False)
    end_df.to_csv("results/endgame_validation.csv", index=False)
    print("ENDGAME", end_df.to_string(index=False), sep="\n")
    s = []
    for cycle in [10, 20]:
        for threshold in [0.1, 0.25, 0.5]:
            for k in [1, 3]:
                config = {"threshold": threshold, "top_k": k, "cycle_seconds": cycle}
                result = simulate_short(
                    market, truth, short["delta"][val], short["times"], **config
                )
                stress = simulate_short(
                    market,
                    truth,
                    short["delta"][val],
                    short["times"],
                    cost_bps=50,
                    latency=4,
                    **config,
                )
                s.append(
                    {
                        **config,
                        **summarize(result),
                        "stress_mean_usd": float(stress["pnl"].mean()),
                    }
                )
    short_df = pd.DataFrame(s).sort_values("stress_mean_usd", ascending=False)
    short_df.to_csv("results/short_validation.csv", index=False)
    print("SHORT HORIZON", short_df.to_string(index=False), sep="\n")
    best_e, best_s = end_df.iloc[0], short_df.iloc[0]
    primary = {
        "margin": float(best_e["margin"]),
        "fraction": float(best_e["fraction"]),
        "cost_bps": 25,
        "fixed_cost": 0.02,
        "latency": 2,
        "fill_cap": 50,
        "burst": 12,
        "action_budget": 20,
    }
    challenger = {
        "threshold": float(best_s["threshold"]),
        "top_k": int(best_s["top_k"]),
        "cost_bps": 25,
        "fixed_cost": 0.02,
        "latency": 2,
        "fill_cap": 50,
        "fraction": 0.5,
        "cycle_seconds": int(best_s["cycle_seconds"]),
    }
    frozen = {
        "primary": primary,
        "short_horizon": challenger,
        "short_horizon_enabled": bool(best_s["stress_mean_usd"] > 0),
        "directional_challenger": json.load(open("results/frozen_config.json")),
        "selection_note": "40 directional + 6 final-report + 12 short-horizon final validation candidates, plus 6 earlier short-cycle diagnostics; final/short ranked by 50bps, 4s stress mean. No test inspected. Maximum 36 short-cycle actions/min + 20 endgame actions <=60.",
    }
    dump_json("results/engines_frozen.json", frozen)
    print("FROZEN ENGINES", frozen)


if __name__ == "__main__":
    main()
