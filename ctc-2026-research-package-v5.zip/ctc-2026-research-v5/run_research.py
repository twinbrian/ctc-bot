"""Reproduce the frozen research workflow from the original extracted archive."""

import argparse
import os
import subprocess
import sys
from pathlib import Path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("data", type=Path)
    args = parser.parse_args()
    data = args.data.resolve()
    env = dict(os.environ, OMP_NUM_THREADS="4", OPENBLAS_NUM_THREADS="1")
    commands = [
        ["prepare.py", str(data), "--out", "cache.npz"],
        ["train.py"],
        ["validate.py"],
        ["short_horizon.py"],
        ["select_engines.py"],
        ["evaluate.py"],
        ["diagnostics.py"],
        ["-m", "pytest", "-q"],
    ]
    for command in commands:
        subprocess.run([sys.executable, *command], check=True, env=env)


if __name__ == "__main__":
    main()
