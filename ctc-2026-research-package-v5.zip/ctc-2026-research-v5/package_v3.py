"""Package compact, versioned source/results without data or fitted model weights."""

import json
import platform
import sys
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

from package_results import digest


def main():
    root = Path(__file__).parent
    results = root / "results_v3"
    summary = json.loads((results / "summary.json").read_text())
    certificate = {
        "python": sys.version,
        "platform": platform.platform(),
        "model_threads": {"OMP_NUM_THREADS": 1, "OPENBLAS_NUM_THREADS": 1},
        "verification": json.loads((results / "verification.json").read_text()),
        "input_audit": json.loads((root / "cache.audit.json").read_text()),
        "original_data_zip_sha256": digest(
            "/tmp/files/f977-hurricane-season-research.zip"
        ),
        "frozen_config_sha256": {
            str(f["fold"]): f["frozen_sha256"] for f in summary["folds"]
        },
        "objective": "Mean net terminal USD PnL on inner-validation seasons",
        "qualification": summary["qualification"],
        "repository_changes": False,
        "result_type": "Hypothetical consensus-price execution scenarios; not actual orderbook fills",
        "omissions": "Raw data, pickle model weights and large prediction caches; see README_V3.md to regenerate",
    }
    (results / "reproduction_certificate.json").write_text(
        json.dumps(certificate, indent=2) + "\n"
    )
    files = (
        list(root.glob("*.py"))
        + list(root.glob("*.md"))
        + list(root.glob("requirements*.txt"))
    )
    files += list((root / "tests").glob("*.py"))
    files += [root / "environment.json", root / "cache.audit.json"]
    for folder in ["results", "results_v2", "results_v3"]:
        files += [
            p
            for p in (root / folder).iterdir()
            if p.is_file()
            and p.suffix != ".pkl"
            and not p.name.endswith("-predictions.npz")
        ]
    files = sorted(set(files))
    sums = {str(p.relative_to(root)): digest(p) for p in files}
    pdf = root.parent / "ctc-2026-research-report-v3.pdf"
    sums[pdf.name] = digest(pdf)
    checksum_file = root / "SHA256SUMS_V3.json"
    checksum_file.write_text(json.dumps(sums, indent=2) + "\n")
    files.append(checksum_file)
    archive = root.parent / "ctc-2026-code-results-v3.zip"
    prefix = "ctc-2026-research-kit-v3/"
    with ZipFile(archive, "w", ZIP_DEFLATED, compresslevel=6) as z:
        for path in files:
            z.write(path, prefix + str(path.relative_to(root)))
        z.write(pdf, prefix + pdf.name)
    with ZipFile(archive) as z:
        assert z.testzip() is None
        import hashlib

        for name, value in sums.items():
            assert hashlib.sha256(z.read(prefix + name)).hexdigest() == value, name
    print(f"Packaged {len(files) + 1} files, {archive.stat().st_size / 1e6:.2f} MB")
    print(archive)


if __name__ == "__main__":
    main()
