"""Render the research Markdown into a self-contained PDF (optional dependency)."""

import re
from pathlib import Path
from xml.sax.saxutils import escape

from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (
    Image,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
    XPreformatted,
)


def inline(text):
    text = escape(text)
    text = re.sub(r"\*\*(.*?)\*\*", r"<b>\1</b>", text)
    text = re.sub(r"`([^`]+)`", r'<font name="Mono">\1</font>', text)
    return text


def main(source="REPORT.md", target="../ctc-2026-research-report-v1.pdf", version="v1"):
    fonts = Path("/usr/share/fonts/truetype/dejavu")
    pdfmetrics.registerFont(TTFont("Body", str(fonts / "DejaVuSans.ttf")))
    pdfmetrics.registerFont(TTFont("BodyBold", str(fonts / "DejaVuSans-Bold.ttf")))
    pdfmetrics.registerFont(TTFont("Mono", str(fonts / "DejaVuSansMono.ttf")))
    pdfmetrics.registerFontFamily(
        "Body", normal="Body", bold="BodyBold", italic="Body", boldItalic="BodyBold"
    )
    styles = getSampleStyleSheet()
    body = ParagraphStyle(
        "ResearchBody", fontName="Body", fontSize=9, leading=13, spaceAfter=7
    )
    cell = ParagraphStyle(
        "ResearchCell", parent=body, fontSize=8, leading=11, spaceAfter=0
    )
    code = ParagraphStyle(
        "ResearchCode",
        fontName="Mono",
        fontSize=7.8,
        leading=11,
        backColor=colors.HexColor("#F3F6F8"),
        borderPadding=8,
        spaceAfter=10,
    )
    headings = {
        level: ParagraphStyle(
            "Heading" + str(level),
            parent=styles["Heading1"],
            fontName="BodyBold",
            fontSize={1: 21, 2: 14, 3: 11}[level],
            leading={1: 26, 2: 19, 3: 15}[level],
            textColor=colors.HexColor("#15384D"),
            spaceBefore=14,
            spaceAfter=9,
            keepWithNext=True,
        )
        for level in [1, 2, 3]
    }
    target = Path(target)
    width = A4[0] - 84
    doc = SimpleDocTemplate(
        str(target),
        pagesize=A4,
        rightMargin=42,
        leftMargin=42,
        topMargin=42,
        bottomMargin=42,
        title=f"CTC 2026 Trading Research — {version}",
        author="Research prepared for Ryan Kim",
    )
    lines = Path(source).read_text().splitlines()
    story = []
    i = 0
    while i < len(lines):
        line = lines[i]
        if not line.strip():
            i += 1
            continue
        if line.startswith("```"):
            block = []
            i += 1
            while i < len(lines) and not lines[i].startswith("```"):
                block.append(lines[i])
                i += 1
            story.append(XPreformatted(escape("\n".join(block)), code))
        elif line.startswith("|"):
            rows = []
            while i < len(lines) and lines[i].startswith("|"):
                parts = [x.strip() for x in lines[i].strip("|").split("|")]
                if not all(re.fullmatch(r"[-: ]+", x) for x in parts):
                    rows.append(parts)
                i += 1
            lengths = [
                max(8, min(45, max(len(re.sub(r"\*|`", "", row[j])) for row in rows)))
                for j in range(len(rows[0]))
            ]
            total = sum(lengths)
            columns = [width * x / total for x in lengths]
            formatted = [[Paragraph(inline(x), cell) for x in row] for row in rows]
            table = Table(formatted, colWidths=columns, repeatRows=1, hAlign=TA_LEFT)
            table.setStyle(
                TableStyle(
                    [
                        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#E5EFF4")),
                        (
                            "ROWBACKGROUNDS",
                            (0, 1),
                            (-1, -1),
                            [colors.white, colors.HexColor("#F7FAFC")],
                        ),
                        ("VALIGN", (0, 0), (-1, -1), "TOP"),
                        ("TOPPADDING", (0, 0), (-1, -1), 6),
                        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
                        ("LINEBELOW", (0, 0), (-1, 0), 0.7, colors.HexColor("#9DB5C3")),
                    ]
                )
            )
            story.extend([table, Spacer(1, 10)])
            continue
        elif line.startswith("!["):
            path = re.search(r"\]\((.*?)\)", line).group(1)
            img = Image(path)
            img.drawHeight *= width / img.drawWidth
            img.drawWidth = width
            story.extend([img, Spacer(1, 12)])
        elif line.startswith("#"):
            level = min(len(line) - len(line.lstrip("#")), 3)
            story.append(Paragraph(inline(line.lstrip("# ")), headings[level]))
        else:
            paragraph = [line]
            while (
                i + 1 < len(lines)
                and lines[i + 1].strip()
                and not lines[i + 1].startswith(("#", "|", "```", "![", "- "))
                and not re.match(r"^\d+\. ", lines[i + 1])
            ):
                i += 1
                paragraph.append(lines[i])
            text = " ".join(paragraph)
            if text.startswith("- "):
                story.append(Paragraph(inline(text[2:]), body, bulletText="•"))
            else:
                story.append(Paragraph(inline(text), body))
        i += 1

    def footer(canvas, document):
        canvas.saveState()
        canvas.setFont("Body", 7)
        canvas.setFillColor(colors.HexColor("#526775"))
        canvas.drawString(
            42,
            22,
            f"CTC 2026 • {version} • Historical simulation; executable fills unverified",
        )
        canvas.drawRightString(A4[0] - 42, 22, str(document.page))
        canvas.restoreState()

    doc.build(story, onFirstPage=footer, onLaterPages=footer)
    print(target.resolve())


if __name__ == "__main__":
    main()
